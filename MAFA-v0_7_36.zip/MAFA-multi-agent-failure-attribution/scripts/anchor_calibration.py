"""
anchor_calibration.py
=====================
Fits and evaluates the black-box half of the uncertainty model on
MedAgentAudit's released human evaluation, with no API calls at all.

Instances
---------
383 (qid, failure_code) pairs that appear both in
``structured_logs_for_audit_human_evaluation/`` (carrying the auditor's binary
label ``mas_audit_result``) and in the six annotator exports (three human
verdicts each).  Label = human majority vote.

The auditor's own ``auditor_reasoning`` text is recovered from
``audit_results/{mas}_{dataset}_{llm}.jsonl`` using the same selection rule the
release script used: the first round in which the mode's log key is present,
entry [0].

What this can and cannot validate
---------------------------------
CAN: B1 verbalised-style cues, B2 evidence groundedness (do the auditor's own
quoted spans exist in the transcript), B3 structural/context features.
CANNOT: W1/W2, the logprob signal -- MedAgentAudit released text, not
logprobs.  So treat every number here as a *lower bound* on what the full
hybrid can do.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

STATUS_KEY = {
    "1.1.1": ("1_1_1_factual_hallucination", "factual_hallucination_status"),
    "1.2.1": ("1_2_1_neglect_or_misinterpretation_of_modality_info", "modality_neglect_status"),
    "2.1.1": ("2_1_1_role_assignment", "role_task_alignment"),
    "2.1.2": ("2_1_2_domain_specific_knowledge_activation", "knowledge_activation_status"),
    "2.2.1": ("2_2_1_repetition_of_initial_views", "interaction_redundancy"),
    "2.2.2": ("2_2_2_unresolved_conflicts", "conflict_resolution_status"),
    "3.1.1": ("3_1_1_suppression_of_minority_views", "suppression_status"),
    "3.1.2": ("3_1_2_authority_bias", "authority_bias_status"),
    "3.1.3": ("3_1_3_neglect_of_contradictions", "neglect_of_conflict_status"),
    "3.2.1": ("3_2_1_self_contradiction_when_decision", "inter_round_consistency_status"),
}

HUMAN_KAPPA = {"1.1.1": .731, "1.2.1": .710, "2.1.1": .723, "2.1.2": .707,
               "2.2.1": .731, "2.2.2": .650, "3.1.1": .531, "3.1.2": .516,
               "3.1.3": .422, "3.2.1": .646}

VQA = {"PathVQA", "SLAKE", "VQA-RAD"}

HEDGE = re.compile(
    r"\b(may|might|could|appears?|seems?|suggests?|possibly|perhaps|arguably|"
    r"somewhat|unclear|ambiguous|debatable|borderline|potentially|likely|"
    r"not entirely|difficult to|hard to|questionable)\b", re.I)
ASSERT = re.compile(
    r"\b(clearly|explicitly|directly|definitively|entirely|no evidence|"
    r"there is no|does not|never|precisely|unambiguous|strictly|verbatim|"
    r"accurately|correctly|fully)\b", re.I)
CONTRAST = re.compile(r"\b(however|although|though|but|whereas|nevertheless|"
                      r"on the other hand|that said)\b", re.I)
NOFAIL = re.compile(r"\b(no conflict|no contradiction|no disagreement|"
                    r"not applicable|no failure|no hallucination|"
                    r"consistent with|grounded in|is appropriate)\b", re.I)
QUOTE = re.compile(r"[\"\u201c]([^\"\u201d]{12,240})[\"\u201d]|'([^']{12,240})'")
WS = re.compile(r"\s+")


def norm(t: str) -> str:
    t = unicodedata.normalize("NFKC", t)
    for a, b in [("\u201c", '"'), ("\u201d", '"'), ("\u2018", "'"),
                 ("\u2019", "'"), ("\u2014", "-"), ("\u2013", "-")]:
        t = t.replace(a, b)
    return WS.sub(" ", t).strip().lower()


# --------------------------------------------------------------------------- #
# Data assembly
# --------------------------------------------------------------------------- #

def load_instances(release: Path):
    struct = {}
    for f in (release / "human_eval/structured_logs_for_audit_human_evaluation").glob("*.jsonl"):
        for line in f.open(encoding="utf-8"):
            r = json.loads(line)
            struct[(r["qid"], r["failure_code"])] = r

    votes = defaultdict(list)
    meta = {}
    for f in (release / "human_eval/results/audit_results").glob("*.json"):
        for v in json.load(f.open(encoding="utf-8"))["annotations"].values():
            k = (v["caseId"], v["taxonomyKey"])
            votes[k].append(1 if v["verdict"] == "yes" else 0)
            meta[k] = v

    keys = [k for k in votes if k in struct]
    return struct, votes, meta, keys


def build_reasoning_index(release: Path, needed: set[tuple[str, str, str]]):
    """needed = {(mas, dataset, llm)} -> {(qid, code): (reasoning, n_rounds, n_entries)}"""
    idx: dict[tuple[str, str], tuple[str, int, int]] = {}
    adir = release / "audit_results"
    for mas, dataset, llm in sorted(needed):
        p = adir / f"{mas}_{dataset}_{llm}.jsonl"
        if not p.exists():
            continue
        for line in p.open(encoding="utf-8"):
            rec = json.loads(line)
            audit = (rec.get("case_history") or {}).get("audit")
            if not audit:
                continue
            rounds = audit.get("rounds") or []
            for code, (log_key, status) in STATUS_KEY.items():
                for rnd in rounds:
                    entries = rnd.get(log_key)
                    if not entries:
                        continue
                    ar = entries[0].get("audit_result") or {}
                    if status not in ar:
                        continue
                    idx[(rec["qid"], code)] = (
                        ar.get("auditor_reasoning", ""), len(rounds), len(entries))
                    break
    return idx


# --------------------------------------------------------------------------- #
# Features
# --------------------------------------------------------------------------- #

FEATURE_NAMES = [
    "ai_verdict", "reason_logwords", "hedge_rate", "assert_rate",
    "contrast_rate", "nofail_hit", "n_quotes", "quote_groundedness",
    "has_ungrounded_quote", "enumerated", "agent_mentions",
    "collab_logchars", "n_rounds", "n_audit_entries", "is_vqa",
    "answer_correct", "aleatoric_kappa", "stage_1", "stage_2", "stage_3",
]


def featurise(rec, reasoning, n_rounds, n_entries, code):
    txt = reasoning or ""
    words = txt.split()
    nw = max(len(words), 1)
    collab = rec.get("collaboration_text") or ""
    ncollab = norm(collab)

    quotes = [a or b for a, b in QUOTE.findall(txt)]
    grounded = [1.0 if norm(q) in ncollab else 0.0 for q in quotes]

    agent_tokens = set(re.findall(r"\b(doctor_\d|agent_\d|meta|synthesizer|"
                                  r"decision[- ]?maker|reviewer)\b", txt, re.I))

    ai = 1.0 if str(rec.get("mas_audit_result", "0")).strip() == "1" else 0.0
    stage = code.split(".")[0]
    return [
        ai,
        math.log1p(nw),
        len(HEDGE.findall(txt)) / nw * 100,
        len(ASSERT.findall(txt)) / nw * 100,
        len(CONTRAST.findall(txt)) / nw * 100,
        1.0 if NOFAIL.search(txt) else 0.0,
        min(len(quotes), 6) / 6.0,
        float(np.mean(grounded)) if grounded else 0.5,
        1.0 if (grounded and min(grounded) == 0.0) else 0.0,
        1.0 if re.search(r"\b[123]\)", txt) else 0.0,
        min(len(agent_tokens), 4) / 4.0,
        math.log1p(len(collab)),
        float(n_rounds),
        math.log1p(n_entries),
        1.0 if rec.get("dataset") in VQA else 0.0,
        1.0 if str(rec.get("mas_predicted_answer", "")).strip()[:1]
        == str(rec.get("ground_truth", "")).strip()[:1] else 0.0,
        HUMAN_KAPPA.get(code, 0.55),
        1.0 if stage == "1" else 0.0,
        1.0 if stage == "2" else 0.0,
        1.0 if stage == "3" else 0.0,
    ]


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #

def ece(p, y, bins=10):
    p, y = np.asarray(p), np.asarray(y)
    n, tot = len(p), 0.0
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        m = (p > lo) & (p <= hi) if b else (p <= hi)
        if m.sum() == 0:
            continue
        tot += m.sum() / n * abs(p[m].mean() - y[m].mean())
    return tot


def risk_coverage(p, y, conf=None):
    """conf defaults to |2p-1|.  Returns list of (coverage, selective error)."""
    p, y = np.asarray(p), np.asarray(y)
    c = np.abs(2 * p - 1) if conf is None else np.asarray(conf)
    order = np.argsort(-c)
    pred = (p > 0.5).astype(int)
    out = []
    for k in range(1, len(p) + 1):
        idx = order[:k]
        out.append((k / len(p), float((pred[idx] != y[idx]).mean())))
    return out


def at_coverage(rc, target):
    best = min(rc, key=lambda t: abs(t[0] - target))
    return best[1]


# --------------------------------------------------------------------------- #

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--release", required=True,
                    help="path to github_release_files/")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score, brier_score_loss
    from sklearn.model_selection import StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline

    rel = Path(args.release)
    struct, votes, meta, keys = load_instances(rel)
    combos = {(struct[k]["mas"], struct[k]["dataset"], struct[k]["llm"])
              for k in keys}
    print(f"instances={len(keys)}  mas/dataset/llm combos={len(combos)}")

    ridx = build_reasoning_index(rel, combos)
    print(f"recovered auditor_reasoning for "
          f"{sum(1 for k in keys if k in ridx)}/{len(keys)} instances")

    X, y, codes, ai = [], [], [], []
    for k in keys:
        rec, code = struct[k], k[1]
        reasoning, nr, ne = ridx.get(k, ("", 1, 1))
        X.append(featurise(rec, reasoning, nr, ne, code))
        v = votes[k]
        y.append(1 if sum(v) >= len(v) / 2 else 0)
        codes.append(code)
        ai.append(1 if str(rec.get("mas_audit_result", "0")).strip() == "1" else 0)
    X, y, ai = np.array(X, float), np.array(y), np.array(ai)
    codes = np.array(codes)

    print(f"\nbaseline: auditor label vs human majority  "
          f"acc={float((ai == y).mean()):.4f}")

    # ---- out-of-fold calibrated probabilities --------------------------- #
    oof = np.zeros(len(y))
    skf = StratifiedKFold(5, shuffle=True, random_state=args.seed)
    strat = np.array([f"{c}_{t}" for c, t in zip(codes, y)])
    for tr, te in skf.split(X, strat):
        m = make_pipeline(StandardScaler(),
                          LogisticRegression(max_iter=3000, C=0.5))
        m.fit(X[tr], y[tr])
        oof[te] = m.predict_proba(X[te])[:, 1]

    pred = (oof > 0.5).astype(int)
    print(f"calibrated model: acc={float((pred == y).mean()):.4f}  "
          f"AUC={roc_auc_score(y, oof):.4f}  "
          f"Brier={brier_score_loss(y, oof):.4f}  "
          f"ECE={ece(oof, y):.4f}")
    print(f"raw auditor label as probability:      "
          f"Brier={brier_score_loss(y, ai.astype(float)):.4f}  "
          f"ECE={ece(ai.astype(float), y):.4f}")

    # ---- risk-coverage --------------------------------------------------- #
    rc = risk_coverage(oof, y)
    rng = np.random.default_rng(args.seed)
    rand = np.mean([[at_coverage(risk_coverage(oof, y, rng.random(len(y))), c)
                     for c in (.5, .6, .7, .8, .9, 1.0)] for _ in range(20)],
                   axis=0)
    print("\ncoverage  selective-error  random-routing-error")
    for c, r in zip((.5, .6, .7, .8, .9, 1.0), rand):
        print(f"  {c:4.0%}      {at_coverage(rc, c):.4f}           {r:.4f}")

    # ---- per-code -------------------------------------------------------- #
    print("\ncode    n   auditor-acc  model-acc  AUC    mean-conf  human-kappa")
    for code in sorted(set(codes)):
        m = codes == code
        try:
            auc = roc_auc_score(y[m], oof[m])
        except ValueError:
            auc = float("nan")
        print(f"{code}  {m.sum():3d}    {float((ai[m]==y[m]).mean()):.3f}"
              f"       {float((pred[m]==y[m]).mean()):.3f}    {auc:.3f}"
              f"   {np.abs(2*oof[m]-1).mean():.3f}      "
              f"{HUMAN_KAPPA.get(code, float('nan')):.3f}")

    # ---- leave-one-code-out (does it transfer to an unseen code?) -------- #
    loco = np.zeros(len(y))
    for code in sorted(set(codes)):
        te = codes == code
        m = make_pipeline(StandardScaler(),
                          LogisticRegression(max_iter=3000, C=0.5))
        m.fit(X[~te], y[~te])
        loco[te] = m.predict_proba(X[te])[:, 1]
    print(f"\nleave-one-code-out: acc={float(((loco>.5).astype(int)==y).mean()):.4f}"
          f"  AUC={roc_auc_score(y, loco):.4f}  ECE={ece(loco, y):.4f}")
    rcl = risk_coverage(loco, y)
    print("  selective error @70% coverage: "
          f"{at_coverage(rcl, .7):.4f}  @50%: {at_coverage(rcl, .5):.4f}")

    # ---- ablation -------------------------------------------------------- #
    print("\nablation (5-fold AUC, cumulative feature groups)")
    groups = {
        "ai_verdict only": [0],
        "+ text style (B1)": [0, 1, 2, 3, 4, 5, 9],
        "+ groundedness (B2)": [0, 1, 2, 3, 4, 5, 9, 6, 7, 8, 10],
        "+ context (B3)": list(range(len(FEATURE_NAMES))),
    }
    for name, cols in groups.items():
        p = np.zeros(len(y))
        for tr, te in skf.split(X, strat):
            m = make_pipeline(StandardScaler(),
                              LogisticRegression(max_iter=3000, C=0.5))
            m.fit(X[tr][:, cols], y[tr])
            p[te] = m.predict_proba(X[te][:, cols])[:, 1]
        print(f"  {name:24s} AUC={roc_auc_score(y, p):.4f}  "
              f"ECE={ece(p, y):.4f}  acc={float(((p>.5).astype(int)==y).mean()):.4f}")

    # ---- coefficients ---------------------------------------------------- #
    m = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, C=0.5))
    m.fit(X, y)
    coef = m[-1].coef_[0]
    print("\nstandardised coefficients (full fit)")
    for n, c in sorted(zip(FEATURE_NAMES, coef), key=lambda t: -abs(t[1])):
        print(f"  {n:22s} {c:+.3f}")


if __name__ == "__main__":
    main()
