#!/usr/bin/env python3
"""Experiment A -- does an agreement gate certify agreement with experts?

AdaMAST (arXiv 2607.16387) accepts an induced taxonomy when four LLM
annotators reach mean pairwise Cohen's kappa >= 0.75, and says plainly that
this "certifies that the taxonomy is consistently applicable; it does not
certify that its codes are correct". Its one external correctness check runs
at *area* granularity (3 buckets, kappa 0.725); at leaf granularity, where the
codes are actually consumed, agreement with the TRAIL experts is ~0.34 while
the annotators agree with each other at 0.587-0.794.

That is a ~2x gap between what the gate measures and what it is used to
certify, visible in their own Tables 23 and 24. This script asks whether it
reproduces in a medical domain on codes whose human agreement we can compute
directly.

The substrate is MedAgentAudit's audit human-eval set: 400 instances,
10 codes x 20 positive x 20 negative, each judged yes/no by 3 of 6 clinicians.
Gold is majority of 3. Recomputed here, mean pairwise human kappa is 0.635 and
no single code reaches 0.75.

Four annotators, one per model family, all given the identical prompt:
one code, one collaboration transcript, one binary verdict. Then, in the same
units:

  * LLM-LLM mean pairwise kappa   -- what an agreement gate would see
  * LLM-gold kappa               -- what it is taken to certify
  * human-human mean pairwise    -- the ceiling either could aspire to

Resumable: results append to <work>/panel_<model>.jsonl and a rerun skips
instances already present.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import glob
import json
import os
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mafa.taxonomy import SEED_MODES                              # noqa: E402

HUMAN_EVAL = ("/home/claude/work/maa/MedAgentAudit-9.2/datasets_and_logs/"
              "github_release_files/human_eval")

#: one per family, so agreement is not inflated by shared weights -- the
#: cross-family panel is the configuration AdaMAST reports in its main text.
PANEL = {
    "glm-5.3-flash": ("https://open.bigmodel.cn/api/paas/v4/",
                      "0c86451768dd4ed7933f237b2cd90d45.bNebLs5BB56cIUhh"),
    "qwen3.8-flash": ("https://llm-scj6eyeb8xhvz109.cn-beijing.maas.aliyuncs."
                      "com/compatible-mode/v1",
                      "sk-7ba73405681d47b3a9931b3ea1174c4b"),
    "deepseek-flash": ("https://api.deepseek.com",
                       "sk-3cc3c1d453d843a8a155837af71e6b9d"),
    "gpt-5.6-sol-disc": ("https://aihubmix.com/v1",
                         "sk-hHecHumBRXWUjWwOD28a462e290f4a33AbBdDd74F0D96dF5"),
}

MODES = {m.code: m for m in SEED_MODES}

SYSTEM = (
    "You audit transcripts of medical multi-agent systems for one specific "
    "failure mode at a time. You answer only with the JSON object you are "
    "asked for."
)

TEMPLATE = """Failure mode under audit.

Code: {code}
Name: {name}
Definition: {definition}
The question to answer: {anchor}

Below is the full collaboration transcript of a medical multi-agent system on
one case. Decide whether THIS failure mode occurred anywhere in it.

Judge only the mode defined above. Other problems in the transcript, however
serious, are not what is being asked. A final answer that happens to be right
does not rule the mode out, and a final answer that happens to be wrong does
not rule it in.

--- transcript ---
{transcript}
--- end transcript ---

Reply with exactly this JSON and nothing else:
{{"verdict": "yes" or "no", "why": "<one sentence>"}}"""


def load_instances():
    """The 400 audited instances, keyed the way the human files key them."""
    by_case = {}
    for f in sorted(glob.glob(os.path.join(
            HUMAN_EVAL, "structured_logs_for_audit_human_evaluation",
            "*.jsonl"))):
        for line in open(f, encoding="utf-8"):
            r = json.loads(line)
            by_case[(r["qid"], r["failure_code"])] = r
    return by_case


def build_items(by_case, gold_meta):
    """Join the transcripts to the human auditIds via (caseId, taxonomyKey)."""
    code_of = gold_meta["code_of"]
    items, missing = [], 0
    for audit_id, code in code_of.items():
        case = audit_id.split("_", 2)[2] if audit_id.startswith("case_") \
            else audit_id
        rec = by_case.get((case, code))
        if rec is None:
            missing += 1
            continue
        items.append({"audit_id": audit_id, "case": case, "code": code,
                      "transcript": rec.get("collaboration_text") or "",
                      "mas": rec.get("mas"), "llm": rec.get("llm"),
                      "dataset": rec.get("dataset")})
    return items, missing


def ask(client, model, item, max_chars):
    m = MODES[item["code"]]
    text = item["transcript"]
    if len(text) > max_chars:          # keep both ends; failures cluster late
        head, tail = max_chars // 3, max_chars - max_chars // 3
        text = (text[:head] + "\n\n[... transcript truncated ...]\n\n"
                + text[-tail:])
    prompt = TEMPLATE.format(code=m.code, name=m.name, definition=m.definition,
                             anchor=m.anchor_question, transcript=text)
    kw = {"model": model,
          "messages": [{"role": "system", "content": SYSTEM},
                       {"role": "user", "content": prompt}],
          "response_format": {"type": "json_object"},
          "max_tokens": 4000}
    if model.startswith("glm"):
        # glm-5.3-flash always reasons and rejects effort "none" with a 400.
        kw["extra_body"] = {"thinking": {"type": "enabled"}}
    r = client.chat.completions.create(**kw)
    raw = (r.choices[0].message.content or "").strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1].removeprefix("json").strip()
    d = json.loads(raw)
    v = str(d.get("verdict", "")).strip().lower()
    if v not in ("yes", "no"):
        raise ValueError(f"unparseable verdict {v!r}")
    return v, str(d.get("why", ""))[:300]


def run_model(model, items, work, concurrency, max_chars):
    from openai import OpenAI
    base, key = PANEL[model]
    client = OpenAI(base_url=base, api_key=key, timeout=300, max_retries=3)
    out = Path(work) / f"panel_{model}.jsonl"
    done = set()
    if out.exists():
        for line in open(out, encoding="utf-8"):
            try:
                done.add(json.loads(line)["audit_id"])
            except Exception:
                pass
    todo = [i for i in items if i["audit_id"] not in done]
    print(f"[{model}] {len(done)} done, {len(todo)} to do")
    lock = threading.Lock()
    n_ok = n_err = 0

    def one(item):
        nonlocal n_ok, n_err
        try:
            v, why = ask(client, model, item, max_chars)
            rec = {"audit_id": item["audit_id"], "code": item["code"],
                   "verdict": v, "why": why}
            n_ok += 1
        except Exception as e:                       # noqa: BLE001
            rec = {"audit_id": item["audit_id"], "code": item["code"],
                   "verdict": None, "error": f"{type(e).__name__}: {e}"[:200]}
            n_err += 1
        with lock:
            with open(out, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if (n_ok + n_err) % 25 == 0:
                print(f"[{model}] {n_ok + n_err}/{len(todo)} "
                      f"(errors {n_err})", flush=True)

    with cf.ThreadPoolExecutor(max_workers=concurrency) as ex:
        list(ex.map(one, todo))
    print(f"[{model}] finished: {n_ok} ok, {n_err} errors -> {out}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", default="/home/claude/work/runs/panel")
    ap.add_argument("--models", default=",".join(PANEL))
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--max-chars", type=int, default=24000)
    a = ap.parse_args()

    Path(a.work).mkdir(parents=True, exist_ok=True)
    gold_meta = json.load(open("/home/claude/work/runs/human_gold.json"))
    items, missing = build_items(load_instances(), gold_meta)
    print(f"{len(items)} instances joined to transcripts, {missing} unmatched")
    if missing:
        print("  unmatched instances are dropped from every arm, so the "
              "panel and the humans are scored on the same set")

    for model in a.models.split(","):
        model = model.strip()
        if model:
            run_model(model, items, a.work, a.concurrency, a.max_chars)


if __name__ == "__main__":
    sys.exit(main())
