#!/bin/sh
# deepseek-flash Arm B: the six-code ablation that produces the residual pool.
#
# Chosen over gpt on cost. The arithmetic that made it viable: the support
# requirement is now max(absolute_floor, 0.05 x pool, 2 x min_cluster_size),
# and the share term grows with the pool, so a bigger pool is not
# automatically an easier gate. At deepseek's measured novel rate the pool
# lands near 200, where the requirement stays at 10 and a cluster of the size
# glm produced (9 out of 73) would scale to roughly 25. gpt's larger pool
# (~470) raises the requirement to 24 in the same motion. Both pass; deepseek
# is cheaper and this is not a race.
#
# `--reasoner-effort low --reasoner-max-tokens 24000` is required, not
# optional: deepseek-flash always reasons, and the default 6000-token reasoner
# budget is consumed by the chain of thought on long transcripts, leaving no
# message block. 4 of the first 9 traces failed as `model_empty_output` before
# this was set.
#
# Counts ANNOTATED trace_ids, not lines: Stage 1 appends on failure and again
# on the retry that fixes it, and reading `wc -l` as progress once declared an
# arm finished with 17 traces still outstanding.
D=/home/claude/work/mafa/MAFA-multi-agent-failure-attribution
R=/home/claude/work/runs
cd "$D" || exit 1
want=180
export OPENAI_API_KEY=sk-3cc3c1d453d843a8a155837af71e6b9d
export OPENAI_BASE_URL=https://api.deepseek.com

n=$(python3 - "$R/ds_seed6_180/stage1.jsonl" <<'PY'
import json, sys
try:
    ok = set()
    for line in open(sys.argv[1], encoding="utf-8"):
        try:
            r = json.loads(line)
        except Exception:
            continue
        if r.get("annotation"):
            ok.add(r["trace_id"])
    print(len(ok))
except FileNotFoundError:
    print(0)
PY
)
n=${n:-0}
echo "ds_seed6_180: $n/$want annotated"
[ "$n" -ge "$want" ] && exit 1
if ps aux | grep -v grep | grep -q "work $R/ds_seed6_180"; then exit 0; fi
echo "restarting"
setsid nohup python3 -u scripts/run_stage1.py \
  --data data --trace-ids /home/claude/work/ab4_180_ids.txt \
  --model deepseek-flash --concurrency 16 --scorer-mode verbalised \
  --reasoner-effort low --reasoner-max-tokens 24000 --no-images \
  --taxonomy "$R/ds_seed6_180/seed_taxonomy.json" \
  --work "$R/ds_seed6_180" >> "$R/ds_seed6.log" 2>&1 < /dev/null &
exit 0
