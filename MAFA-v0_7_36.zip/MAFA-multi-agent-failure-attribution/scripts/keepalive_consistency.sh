#!/bin/sh
# Agent then step consistency sampling, k votes per SLOT.
#
# The previous version called the agent level done at 800 total votes. That
# is a proxy for "every slot has k votes" and it failed exactly where proxies
# fail: 858 votes on file, 170 of 220 slots at k=5, and 47 slots with none at
# all -- the tasks consumed during the stretch when 66% of calls truncated.
# The ninth instance of the same shape in this project: a total standing in
# for a per-unit condition, never checked at the boundary.
#
# Done now means every slot at k. Nothing else.
D=/home/claude/work/mafa/MAFA-multi-agent-failure-attribution
W=/home/claude/work/runs/consistency
cd "$D" || exit 1
K=5

short () {   # $1 level, $2 expected slot count -> slots still below K
  python3 - "$W/votes_$1_glm-5.3-flash.jsonl" "$2" "$K" <<'PY'
import collections, json, sys
path, want, k = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
c = collections.Counter()
try:
    for line in open(path, encoding="utf-8"):
        try:
            r = json.loads(line)
        except Exception:
            continue
        if r.get("vote") is not None:
            c[(r["trace_id"], r["slot_key"])] += 1
except FileNotFoundError:
    pass
full = sum(1 for v in c.values() if v >= k)
print(want - full)
PY
}

running () { ps aux | grep -v grep | grep -q "validate_consistency_levels.py --level $1"; }

a=$(short agent 220); echo "agent: $a of 220 slots below k=$K"
if [ "$a" -gt 0 ]; then
  running agent && exit 0
  echo "launching agent top-up"
  setsid nohup python3 -u scripts/validate_consistency_levels.py --level agent \
    --work "$W" --k $K --n-traces 40 --concurrency 3 \
    >> /home/claude/work/runs/cons_agent.log 2>&1 < /dev/null &
  exit 0
fi

# step slot count is fixed by --max-steps 3 over 40 traces; read it from the
# first run's header rather than hard-coding it
s_total=$(grep -o '\[step\] 40 traces -> [0-9]*' /home/claude/work/runs/cons_step.log \
          2>/dev/null | tail -1 | grep -o '[0-9]*$')
s_total=${s_total:-9999}
s=$(short step "$s_total"); echo "step: $s of $s_total slots below k=$K"
if [ "$s" -gt 0 ]; then
  running step && exit 0
  echo "launching step"
  setsid nohup python3 -u scripts/validate_consistency_levels.py --level step \
    --work "$W" --k $K --n-traces 40 --max-steps 3 --concurrency 3 \
    >> /home/claude/work/runs/cons_step.log 2>&1 < /dev/null &
  exit 0
fi
echo "both levels complete"; exit 1
