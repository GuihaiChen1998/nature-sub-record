#!/usr/bin/env python3
"""Validate consistency calibration on real slots with real human labels.

Everything in §14 was measured on a fixture. This runs the same backends on
the MedAgentAudit audit human-eval set -- 400 instances, ten codes, each
judged by three clinicians, gold = majority -- which is the only place in this
project where a mistake-level slot has a human label.

The measurement is direct: sample the same binary question k times at
temperature 1.0, take the agreement rate as the confidence, and score it
against the clinicians. The single-sample verdict from the panel run (§10) is
the baseline it has to beat, and the supervised head's 0.046 ECE on the
pseudo-anchors is the ceiling it is not expected to reach.

Resumable: votes append to <work>/votes_<model>.jsonl, one line per
(audit_id, sample index), and a rerun tops up whatever is missing.
"""
from __future__ import annotations

import argparse
import collections
import concurrent.futures as cf
import json
import os
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mafa.taxonomy import SEED_MODES                              # noqa: E402

HUMAN_EVAL = ("/home/claude/work/maa/MedAgentAudit-9.2/datasets_and_logs/"
              "github_release_files/human_eval")
MODES = {m.code: m for m in SEED_MODES}

ENDPOINTS = {
    "glm-5.3-flash": ("https://open.bigmodel.cn/api/paas/v4/",
                      "0c86451768dd4ed7933f237b2cd90d45.bNebLs5BB56cIUhh"),
}

SYSTEM = ("You audit transcripts of medical multi-agent systems for one "
          "specific failure mode at a time. You answer only with the JSON "
          "object you are asked for.")

TEMPLATE = """Failure mode under audit.

Code: {code}
Name: {name}
Definition: {definition}
The question to answer: {anchor}

Below is the full collaboration transcript of a medical multi-agent system on
one case. Decide whether THIS failure mode occurred anywhere in it.

Judge only the mode defined above. Other problems in the transcript, however
serious, are not what is being asked. A final answer that happens to be right
does not rule the mode out, and a final answer that happens to be wrong does
not rule it in.

--- transcript ---
{transcript}
--- end transcript ---

Reply with exactly this JSON and nothing else:
{{"verdict": "yes" or "no", "why": "<one sentence>"}}"""


def load_items():
    import glob
    by_case = {}
    for f in sorted(glob.glob(os.path.join(
            HUMAN_EVAL, "structured_logs_for_audit_human_evaluation",
            "*.jsonl"))):
        for line in open(f, encoding="utf-8"):
            r = json.loads(line)
            by_case[(r["qid"], r["failure_code"])] = r
    meta = json.load(open("/home/claude/work/runs/human_gold.json"))
    out = []
    for audit_id, code in meta["code_of"].items():
        case = audit_id.split("_", 2)[2] if audit_id.startswith("case_") \
            else audit_id
        rec = by_case.get((case, code))
        if rec is None:
            continue
        out.append({"audit_id": audit_id, "code": code,
                    "transcript": rec.get("collaboration_text") or ""})
    return out, meta


def ask(client, model, item, max_chars, temperature):
    m = MODES[item["code"]]
    text = item["transcript"]
    if len(text) > max_chars:
        head, tail = max_chars // 3, max_chars - max_chars // 3
        text = text[:head] + "\n\n[... truncated ...]\n\n" + text[-tail:]
    kw = {"model": model,
          "messages": [{"role": "system", "content": SYSTEM},
                       {"role": "user", "content": TEMPLATE.format(
                           code=m.code, name=m.name, definition=m.definition,
                           anchor=m.anchor_question, transcript=text)}],
          "response_format": {"type": "json_object"},
          "max_tokens": 4000,
          #: temperature 1.0 on purpose. Sampling at 0 would return the same
          #: verdict k times and the agreement rate would be a constant 1.0 --
          #: the method needs the model's own output distribution, not k
          #: copies of its mode.
          "temperature": temperature}
    if model.startswith("glm"):
        kw["extra_body"] = {"thinking": {"type": "enabled"}}
    r = client.chat.completions.create(**kw)
    raw = (r.choices[0].message.content or "").strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1].removeprefix("json").strip()
    v = str(json.loads(raw).get("verdict", "")).strip().lower()
    if v not in ("yes", "no"):
        raise ValueError(f"unparseable verdict {v!r}")
    return 1 if v == "yes" else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", default="/home/claude/work/runs/consistency")
    ap.add_argument("--model", default="glm-5.3-flash")
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--concurrency", type=int, default=12)
    ap.add_argument("--max-chars", type=int, default=24000)
    ap.add_argument("--temperature", type=float, default=1.0)
    a = ap.parse_args()

    from openai import OpenAI
    base, key = ENDPOINTS[a.model]
    client = OpenAI(base_url=base, api_key=key, timeout=300, max_retries=3)
    Path(a.work).mkdir(parents=True, exist_ok=True)
    out = Path(a.work) / f"votes_{a.model}.jsonl"

    items, _ = load_items()
    have: collections.Counter = collections.Counter()
    if out.exists():
        for line in open(out, encoding="utf-8"):
            try:
                r = json.loads(line)
                if r.get("vote") is not None:
                    have[r["audit_id"]] += 1
            except Exception:
                pass

    todo = []
    for it in items:
        for j in range(a.k - have[it["audit_id"]]):
            todo.append(it)
    print(f"[cons] {len(items)} instances, k={a.k}; "
          f"{sum(have.values())} votes on file, {len(todo)} to draw")

    lock = threading.Lock()
    done = [0]

    def one(item):
        try:
            v = ask(client, a.model, item, a.max_chars, a.temperature)
            rec = {"audit_id": item["audit_id"], "code": item["code"],
                   "vote": v}
        except Exception as e:                                # noqa: BLE001
            rec = {"audit_id": item["audit_id"], "code": item["code"],
                   "vote": None, "error": f"{type(e).__name__}"[:60]}
        with lock:
            with open(out, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec) + "\n")
            done[0] += 1
            if done[0] % 50 == 0:
                print(f"[cons] {done[0]}/{len(todo)}", flush=True)

    with cf.ThreadPoolExecutor(max_workers=a.concurrency) as ex:
        list(ex.map(one, todo))
    print(f"[cons] finished -> {out}")


if __name__ == "__main__":
    sys.exit(main())
