#!/usr/bin/env python3
"""Check the environment before spending anything.

    python scripts/preflight.py --data data
"""
import argparse
import collections

from _common import add_common, configs, load_all_traces, load_taxonomy, make_client
from mafa import build_slot_plan, probe_logprob_support
from mafa.annotator_client import ScorerConfig


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--probe-retries", type=int, default=3)
    a = ap.parse_args()

    traces = load_all_traces(a)
    tax = load_taxonomy(a)
    print(f"[pre] {len(traces)} traces  "
          f"{dict(collections.Counter(t.framework for t in traces))}")
    print(f"[pre] outcome split "
          f"{dict(collections.Counter(t.outcome_split for t in traces))}")
    bad = [t.trace_id for t in traces
           if len(set(t.agent_uids)) != len(t.agent_uids)]
    print(f"[pre] duplicate agent uids: {len(bad)}")

    slots = collections.Counter()
    excl = collections.Counter()
    for t in traces:
        p = build_slot_plan(t, tax)
        slots[t.framework] += len(p)
        for c in p.excluded_codes:
            excl[f"{t.framework}:{c}"] += 1
    print(f"[pre] mean slots/trace by framework: "
          f"{ {k: round(v / max(sum(1 for t in traces if t.framework == k), 1), 1) for k, v in slots.items()} }")
    print(f"[pre] most excluded codes: {excl.most_common(6)}")

    cli = make_client(a)
    _, s = configs(a)
    ok = any(probe_logprob_support(cli, s) for _ in range(a.probe_retries))
    print(f"[pre] logprobs on {a.model}: {ok}"
          + ("" if ok else "  -> scorer will fall back to verbalised 0-100"))
    if ok:
        print("[pre] NOTE also confirm top_logprobs returns ALTERNATIVES, not "
              "just the emitted token; some proxies strip them, which "
              "quantises p_token to 0/1 and weakens the white-box signal.")


if __name__ == "__main__":
    main()
