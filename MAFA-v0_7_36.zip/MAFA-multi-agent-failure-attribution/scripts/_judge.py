"""Build the Stage 4 judge, optionally on a different model family.

Cross-family is the point, not a convenience. The A/B triage decides whether a
failure is already covered by an existing code; if the model that produced the
annotation also answers that, the result is a self-assessment and "the
annotator agreed with itself" is not evidence of anything.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path


class CachedJudge:
    """A judge that remembers its answers on disk.

    Stage 4 spends an hour of Opus calls on one ablation, and a run that dies
    at cluster 7 of 10 -- a key running out, a process reaped -- throws all of
    it away and starts again at cluster 1. Everything else is already
    replayable: embeddings are cached, HDBSCAN is deterministic, Stage 1
    resumes by trace_id. The judge was the only step that was not, which made
    it the only reason a restart was expensive.

    Keyed on model + system + prompt, so a changed prompt misses and a replay
    hits.

    **Repeats must not collapse.** `repeats=3` exists to measure the spread
    between independent re-audits; serving one cached answer three times would
    report a spread of 0.00 on every cluster and silently disable the
    `max_rate_spread` check that was added after a verdict flipped 0/5 to 5/5.
    So identical questions asked N times in a run occupy N separate slots,
    numbered by order of asking. Replay reproduces the numbering because the
    triage loop is sequential and deterministic; if it is ever parallelised,
    this scheme breaks and must be replaced by an explicit repeat index.
    """

    def __init__(self, inner, path, model: str) -> None:
        self.inner = inner
        self.path = Path(path)
        self.model_name = model
        self._mem: dict[str, dict] = {}
        self._seen: set[str] = set()
        self.hits = self.misses = 0
        if self.path.exists():
            for line in self.path.open(encoding="utf-8"):
                line = line.strip()
                if line:
                    d = json.loads(line)
                    self._mem[d["k"]] = d["v"]
            print(f"[judge] replaying {len(self._mem)} cached answers "
                  f"from {self.path}")

    def __call__(self, prompt: str, system: str = "") -> dict:
        base = hashlib.sha256(
            f"{self.model_name}\x00{system}\x00{prompt}".encode()
        ).hexdigest()[:32]
        n = 0
        while f"{base}#{n}" in self._seen:
            n += 1
        key = f"{base}#{n}"
        self._seen.add(key)
        if key in self._mem:
            self.hits += 1
            return self._mem[key]
        self.misses += 1
        v = self.inner(prompt, system)
        self._mem[key] = v
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"k": key, "v": v}, ensure_ascii=False) + "\n")
        return v


def build_judge(args, make_client, cache_path=None):
    """Build the judge. Pass `cache_path` to make an interrupted run cheap to
    resume: every answer is written there and replayed on the next attempt."""
    inner = _build_inner(args, make_client)
    if cache_path is None:
        return inner
    model = (getattr(args, "judge_model", None) or getattr(args, "model", "?"))
    return CachedJudge(inner, cache_path, model)


def _build_inner(args, make_client):
    backend = getattr(args, "judge_backend", "openai")
    if backend == "anthropic":
        from mafa.reaudit_llm import make_anthropic_judge
        key = os.environ.get(args.judge_key_env)
        if not key:
            sys.exit(f"set {args.judge_key_env} for --judge-backend anthropic")
        url = args.judge_base_url or os.environ.get("ANTHROPIC_BASE_URL")
        if not url:
            sys.exit("give --judge-base-url or set ANTHROPIC_BASE_URL "
                     "(without a trailing /v1)")
        model = args.judge_model or "claude-opus-5"
        print(f"[judge] anthropic {model} @ {url}")
        return make_anthropic_judge(key, url, model)
    from mafa.reaudit_llm import LLMJudge
    model = args.judge_model or args.model
    print(f"[judge] openai-compatible {model}")
    if model == args.model:
        print("[judge] WARNING same model as the annotator; the A/B triage "
              "becomes a self-assessment. Prefer --judge-backend anthropic.")
    return LLMJudge(make_client(args), model=model)
