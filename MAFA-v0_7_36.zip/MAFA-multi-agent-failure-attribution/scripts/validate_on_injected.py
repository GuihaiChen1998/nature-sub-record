#!/usr/bin/env python3
"""Validate the annotator against the simulated split's free ground truth.

    python scripts/run_stage1.py --data data/simulated --work runsim
    python scripts/validate_on_injected.py --data data/simulated --work runsim

Measures, with no human annotation at all:

  agent recall      of the agents that carried an injected fault, how many did
                    the annotator flag
  agent specificity measured on UPSTREAM clean agents only -- those that
                    finish speaking before the first injection. Downstream
                    clean agents are reported separately and are NOT a clean
                    negative set: a corrupted claim propagates, the agent that
                    receives it can genuinely fail, and flagging that is right
                    even though the injection label calls it a false positive.
                    Measured on 63 traces, pooling the two understates
                    specificity by 0.27 (0.905 upstream vs 0.634 downstream,
                    z = 2.48, p = 0.013).
  step recall       did it flag the injected steps
  earliest-step     did earliest_fault_step_id match the first injected step,
                    exactly and within +/-1

Read these as an UPPER bound on natural-failure performance. Injected faults
are deliberately inserted and tend to be blunter than the ones a system
commits on its own; recall here does not transfer. Specificity transfers
better, because a false positive on a confirmed-clean agent is a false
positive either way.

The MAST code of each injection is reported alongside but is NOT used to score
error-level accuracy: MAST and MedAgentAudit are different label spaces, and
mapping them is the job of coverage_matrix.py, not of an accuracy number.
"""
import argparse
import collections
import json

from _common import add_common, load_all_traces, load_taxonomy
from mafa.pipeline import load_stage1


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--by-strategy", action="store_true",
                    help="break results down by injection strategy")
    a = ap.parse_args()

    traces = [t for t in load_all_traces(a) if t.is_simulated]
    if not traces:
        raise SystemExit("no simulated traces found; this script needs the "
                         "injected split (traces with multi_injection_info)")
    tax = load_taxonomy(a)
    anns = load_stage1(f"{a.work}/stage1.jsonl", traces, tax)
    print(f"[val] {len(anns)} annotated simulated traces\n")

    agg = collections.Counter()
    per_fm = collections.defaultdict(collections.Counter)
    per_strategy = collections.defaultdict(collections.Counter)
    off = []

    for t in traces:
        ann = anns.get(t.trace_id)
        if ann is None:
            continue
        flagged_agents = {s.key.split("::", 1)[1]
                          for s in ann.flagged_slots() if s.kind == "agent"}
        flagged_steps = {s.key.split("::", 1)[1]
                         for s in ann.flagged_slots() if s.kind == "step"}

        inj_a = t.injected_agents
        up_a, dn_a = t.upstream_clean_agents, t.downstream_clean_agents
        agg["tp_agent"] += len(flagged_agents & inj_a)
        agg["fn_agent"] += len(inj_a - flagged_agents)
        agg["fp_up"] += len(flagged_agents & up_a)
        agg["tn_up"] += len(up_a - flagged_agents)
        agg["fp_dn"] += len(flagged_agents & dn_a)
        agg["tn_dn"] += len(dn_a - flagged_agents)

        inj_s = t.injected_steps
        agg["tp_step"] += len(flagged_steps & inj_s)
        agg["fn_step"] += len(inj_s - flagged_steps)

        truth = t.earliest_injected_step
        pred = ann.earliest_fault_step_id
        agg["n_trace"] += 1
        if pred and truth:
            order = {s.step_id: s.idx for s in t.steps}
            d = order.get(pred, -99) - order[truth]
            off.append(d)
            agg["earliest_exact"] += int(d == 0)
            agg["earliest_within1"] += int(abs(d) <= 1)
            agg["earliest_early"] += int(d < 0)
        elif truth and not pred:
            agg["earliest_missing"] += 1

        for i in t.injections:
            hit = i.agent_uid in flagged_agents
            per_fm[i.fm_error_type]["n"] += 1
            per_fm[i.fm_error_type]["hit"] += hit
            per_strategy[i.strategy]["n"] += 1
            per_strategy[i.strategy]["hit"] += hit

    def rate(a_, b_):
        return a_ / b_ if b_ else float("nan")

    import math

    def wilson(k, n, z=1.96):
        if not n:
            return float("nan"), float("nan")
        p = k / n
        d = 1 + z * z / n
        c = (p + z * z / (2 * n)) / d
        h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
        return c - h, c + h

    rec = rate(agg["tp_agent"], agg["tp_agent"] + agg["fn_agent"])
    n_up, n_dn = agg["tn_up"] + agg["fp_up"], agg["tn_dn"] + agg["fp_dn"]
    spec_up = rate(agg["tn_up"], n_up)
    spec_dn = rate(agg["tn_dn"], n_dn)
    spec_pool = rate(agg["tn_up"] + agg["tn_dn"], n_up + n_dn)
    prec = rate(agg["tp_agent"], agg["tp_agent"] + agg["fp_up"] + agg["fp_dn"])
    lo1, hi1 = wilson(agg["tn_up"], n_up)
    lo2, hi2 = wilson(agg["tn_dn"], n_dn)

    print(f"agent recall          {rec:.3f}   n={agg['tp_agent'] + agg['fn_agent']}")
    print(f"specificity UPSTREAM  {spec_up:.3f}   n={n_up:4d}  95% CI "
          f"[{lo1:.3f}, {hi1:.3f}]   <- the headline number")
    print(f"specificity DOWNSTREAM{spec_dn:.3f}   n={n_dn:4d}  95% CI "
          f"[{lo2:.3f}, {hi2:.3f}]   <- contaminated, not a clean negative set")
    print(f"specificity pooled    {spec_pool:.3f}   n={n_up + n_dn:4d}"
          "   <- reported only for comparability; do not lead with it")
    print(f"precision (vs all clean) {prec:.3f}")
    if n_up < 100:
        print(f"[val] WARNING only {n_up} upstream negatives. Frameworks whose "
              "injections start at step 1 (dylan) contribute almost none; "
              "clinical_agent and clinical_agent5 yield far more.")
    print(f"step-level    recall={rate(agg['tp_step'], agg['tp_step'] + agg['fn_step']):.3f}")
    n = agg["n_trace"]
    print(f"earliest step exact={rate(agg['earliest_exact'], n):.3f}  "
          f"within1={rate(agg['earliest_within1'], n):.3f}  "
          f"predicted-too-early={rate(agg['earliest_early'], n):.3f}  "
          f"not predicted={agg['earliest_missing']}")
    if off:
        print(f"              offset distribution: "
              f"{dict(sorted(collections.Counter(off).items())[:9])}")

    print("\nagent recall by injected MAST code (detection, NOT label accuracy)")
    for code, c in sorted(per_fm.items()):
        print(f"  {code}  n={c['n']:5d}  recall={rate(c['hit'], c['n']):.3f}")

    if a.by_strategy:
        print("\nby injection strategy")
        for s, c in sorted(per_strategy.items()):
            print(f"  {s:22s} n={c['n']:5d}  recall={rate(c['hit'], c['n']):.3f}")

    out = f"{a.work}/injected_validation.json"
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"aggregate": dict(agg),
                   "agent_recall": rec,
                   "specificity_upstream": spec_up,
                   "specificity_downstream": spec_dn,
                   "specificity_pooled": spec_pool,
                   "n_upstream": n_up, "n_downstream": n_dn,
                   "agent_precision": prec,
                   "per_fm": {k: dict(v) for k, v in per_fm.items()},
                   "per_strategy": {k: dict(v) for k, v in per_strategy.items()},
                   "note": "upper bound on natural-failure recall; MAST codes "
                           "are detection targets only, not label targets; "
                           "downstream clean agents are contaminated by "
                           "propagation and are not a valid negative set"},
                  fh, indent=2)
    print(f"\n-> {out}")


if __name__ == "__main__":
    main()
