#!/usr/bin/env python3
"""Stage 2a: choose the slots humans should adjudicate, and write the task file.

    python scripts/make_anchor_tasks.py --work run01 --budget 300 --step-traces 120

Give the resulting tasks.jsonl to N annotators independently; each fills
`human_votes` (binary tasks) or `human_choice` (step tasks). Two or more
annotators are needed for Head B.
"""
import argparse
import json
from pathlib import Path

from _common import add_common, group_by, load_all_traces, load_taxonomy
from mafa import AnchorSampler, SamplerConfig, Pipeline, PipelineConfig
from mafa.pipeline import load_stage1


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--budget", type=int, default=300,
                    help="binary slots to adjudicate (step tasks are extra)")
    ap.add_argument("--step-traces", type=int, default=120)
    ap.add_argument("--annotators", type=int, default=3)
    ap.add_argument("--frozen-share", type=float, default=0.3)
    a = ap.parse_args()

    traces = load_all_traces(a)
    tax = load_taxonomy(a)
    work = Path(a.work)
    pl = Pipeline.__new__(Pipeline)          # no API client needed here
    pl.tax, pl.cfg = tax, PipelineConfig(work_dir=a.work,
                                         group_by=group_by(a))
    pl.dir, pl.anchor_pool = work, None
    pl.annotations = load_stage1(work / "stage1.jsonl", traces, tax)
    print(f"[tasks] loaded {len(pl.annotations)} annotations")

    feats = pl.features(traces)
    s = AnchorSampler(SamplerConfig(budget=a.budget, group_by=group_by(a),
                                    n_step_traces=a.step_traces,
                                    frozen_share=a.frozen_share))
    tasks = s.select(pl.annotations, feats, traces)
    print(s.export(tasks, work / "tasks.jsonl", n_annotators=a.annotators))

    split = s.reserve_frozen(tasks)
    (work / "frozen_split.json").write_text(json.dumps(
        {k: sorted(v) for k, v in split.items()}, indent=2), encoding="utf-8")
    print(f"[tasks] frozen={len(split['frozen_trace_ids'])} traces, "
          f"calibration={len(split['calibration_trace_ids'])} "
          f"-> {work}/frozen_split.json")
    print(f"[tasks] now copy {work}/tasks.jsonl to {a.annotators} annotators")


if __name__ == "__main__":
    main()
