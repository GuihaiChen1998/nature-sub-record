#!/bin/sh
# Restart any ablation that is no longer running.
#
# Long jobs here get reaped during idle periods, so "did it finish" and "is it
# alive" are different questions and only the first one matters. A restart is
# cheap because judge_cache.jsonl replays every answer already paid for; the
# run redoes its control flow, hits the cache, and continues from where it
# stopped. Finished runs have ablation.json and are left alone.
D=/home/claude/mafa_work/MAFA-multi-agent-failure-attribution
cd "$D" || exit 1
. /tmp/env.sh

for w in run_ab3 run_ab4; do
    if [ -f "$D/$w/ablation.json" ]; then
        echo "$w: done"
        continue
    fi
    if ps aux | grep -v grep | grep -q "work $D/$w"; then
        echo "$w: running, cache $(wc -l < "$D/$w/judge_cache.jsonl" 2>/dev/null || echo 0)"
        continue
    fi
    echo "$w: dead, restarting (cache $(wc -l < "$D/$w/judge_cache.jsonl" 2>/dev/null || echo 0))"
    setsid nohup python3 -u "$D/scripts/ablate_seed.py" \
        --data "$D/data" --work "$D/$w" \
        --seed 1.2.1,2.1.1,2.2.2,3.1.1,3.1.2,3.1.3 \
        --judge-backend anthropic --judge-model claude-opus-5 \
        >> "/tmp/$(basename "$w").log" 2>&1 < /dev/null &
done
