#!/usr/bin/env python3
"""Put candidate codes in front of a clinician, with the evidence attached.

    python scripts/export_for_human_read.py \\
        --run results/gpt-5.6-sol/stage4/run_ab3_clean_n180 \\
        --out results/gpt-5.6-sol/stage4/human_read_clean.md \\
        --quotes 4

Of the three validation routes, this is the only one that can say a discovered
code is *real* rather than merely *stable*. Cross-sample recurrence shows the
loop is tracking something in the traces; a fold-back run shows the code is
usable. Neither can tell you the mechanism is a genuine clinical reasoning
failure and not a confidently-worded artefact of clustering. A person reading
the quotes can.

It is deliberately cheap: a few dozen minutes of reading, no annotation
protocol, no anchor pool. That is the point -- it is meant to be done early and
often, before spending judge calls on something nobody has eyeballed.

**Read the quotes before the definition.** The definition was written by a
model that had just read a cluster of items and was asked to name what they
share; it will sound coherent whether or not the cluster is. The quotes are
from the transcripts. If the quotes do not look like instances of one
mechanism, the definition is describing a cluster that should not exist, and
that is the finding.

Three questions per code, and the third is the one that matters:

    1. Is this a real failure mode, or an artefact of clustering?
    2. Do the quotes all show the same mechanism?
    3. Would a clinician reviewing this consultation call it an error?

A code that fails (3) may still be a genuine regularity in the traces and still
be useless for the purpose of this project.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", required=True)
    ap.add_argument("--stage1", default=None,
                    help="defaults to <run>/stage1.jsonl")
    ap.add_argument("--out", required=True)
    ap.add_argument("--quotes", type=int, default=4)
    ap.add_argument("--data", default="data")
    ap.add_argument("--min-cluster-size", type=int, default=6,
                    help="must match the value the run used")
    ap.add_argument("--all-clusters", action="store_true",
                    help="include clusters that did not pass the gates")
    a = ap.parse_args()

    run = Path(a.run)
    d = json.loads((run / "ablation.json").read_text(encoding="utf-8"))
    admitted = {x["cluster"]: x for x in d.get("admitted", [])}
    by_id = {c["id"]: c for c in d["clusters"]}

    # Rebuild the clusters to recover their members. `ablation.json` records
    # support but not member trace_ids, and the cluster's *name* is written by
    # the summariser, so it does not match the proposal names it was built
    # from -- matching on it recovers nothing. Rebuilding is exact rather than
    # approximate: the embeddings are cached and HDBSCAN is deterministic, so
    # this reproduces the same partition the run used.
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from mafa import (Taxonomy, cluster_residuals, collect_residuals,
                      make_embedder)
    from mafa.pipeline import load_stage1
    from mafa.trace_adapter import load_dir

    s1 = Path(a.stage1 or (run / "stage1.jsonl"))
    traces = list(load_dir(a.data))
    by = {t.trace_id: t for t in traces}
    tax = Taxonomy.load(run / "seed_taxonomy.json")
    res = collect_residuals(load_stage1(s1, traces, tax).values(), None, by)
    embed = make_embedder("openai", model="text-embedding-3-small",
                          cache_path=str(run / "embeddings.jsonl"))
    clusters, _ = cluster_residuals(res, embed,
                                    min_cluster_size=a.min_cluster_size)
    members = {c.cluster_id: c.items for c in clusters}
    if not any(by_id.get(cid, {}).get("n") == len(members.get(cid, []))
               for cid in by_id):
        print("[warn] rebuilt clusters do not line up with ablation.json; "
              "quotes may belong to the wrong code. Check --min-cluster-size.")

    ids = sorted(by_id, key=lambda i: -by_id[i]["n"])
    if not a.all_clusters:
        ids = [i for i in ids if i in admitted]

    L: list[str] = []
    L.append(f"# Candidate failure codes for review — `{run.name}`\n")
    L.append(f"{d['n_traces']} traces, {d['n_residual']} residual items, "
             f"{len(d['clusters'])} clusters, {len(admitted)} admitted.\n")
    L.append("Read the quotes before the definition. The definition was "
             "written by a model that had just been shown the cluster and "
             "asked what its members share, so it will read as coherent "
             "whether or not the cluster is. The quotes come from the "
             "transcripts.\n")
    L.append("For each code below:\n")
    L.append("- [ ] **Real mechanism**, or an artefact of clustering?\n"
             "- [ ] **Do the quotes show one mechanism**, or several?\n"
             "- [ ] **Would a clinician call this an error** in the "
             "consultation?\n")
    L.append("\n---\n")

    for cid in ids:
        c, adm = by_id[cid], admitted.get(cid)
        L.append(f"\n## {c['name']}\n")
        L.append(f"cluster {cid} · support **{c['n']}** · triage `{c['triage']}`"
                 + (" · **admitted**" if adm else "") + "\n")
        fw = c.get("frameworks") or {}
        if fw:
            L.append(f"frameworks: {', '.join(f'{k} {v}' for k, v in fw.items())}"
                     f" · phases: "
                     f"{', '.join(f'{k} {v}' for k, v in (c.get('phases') or {}).items())}\n")
        if adm:
            L.append(f"\nnearest held-out code: `{adm['nearest_held_out']}` "
                     f"(cosine {adm['nearest_cosine']}) — judged distinct\n")

        items = members.get(cid, [])
        qs = [(it, q) for it in items for q in (it.evidence or []) if q.strip()]
        L.append(f"\n**Evidence from the transcripts** "
                 f"({min(len(qs), a.quotes)} of {len(qs)} quotes, "
                 f"{len(items)} members):\n")
        for it, q in qs[:a.quotes]:
            L.append(f"\n> {q[:400]}\n>\n> — `{it.framework}` / "
                     f"{it.phase} / proposed as *{it.proposed_name}*\n")
        if not qs:
            L.append("\n*(no members rebuilt for this cluster — "
                     "check --min-cluster-size against the run)*\n")

        if adm:
            L.append(f"\n<details><summary>Definition as written by the "
                     f"summariser</summary>\n\n{adm['definition']}\n\n</details>\n")
        L.append("\nVerdict: ______    Notes:\n\n---\n")

    Path(a.out).write_text("".join(L), encoding="utf-8")
    print(f"-> {a.out}  ({len(ids)} code(s), "
          f"{sum(len(members.get(i, [])) for i in ids)} cluster members)")


if __name__ == "__main__":
    main()
