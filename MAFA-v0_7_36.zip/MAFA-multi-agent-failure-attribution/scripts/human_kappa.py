#!/usr/bin/env python3
"""Human inter-annotator agreement on MedAgentAudit's audit human-eval set.

400 instances, 10 codes x 20 positive x 20 negative, each judged yes/no by
exactly 3 of 6 experts in a balanced incomplete block design (pairwise
overlaps 66-134). This is the floor AdaMAST's kappa >= 0.75 acceptance gate
would be measured against in this domain, and the reference the LLM panel is
scored against in the same units.

Gold is majority of 3, which is always decisive with an odd panel and a binary
verdict.
"""
import collections
import glob
import itertools
import json
import os
import sys

ROOT = ("/home/claude/work/maa/MedAgentAudit-9.2/datasets_and_logs/"
        "github_release_files/human_eval")


def load_human():
    per = {}
    for f in sorted(glob.glob(os.path.join(ROOT, "results/audit_results",
                                           "annotator_*_audit.json"))):
        d = json.load(open(f, encoding="utf-8"))
        per[d["auditor"]["id"]] = {
            k: (v["verdict"], v["taxonomyKey"])
            for k, v in d["annotations"].items()}
    return per


def cohen_kappa(pairs):
    """pairs: [(a, b), ...] of binary labels."""
    n = len(pairs)
    if n == 0:
        return float("nan"), 0
    po = sum(1 for a, b in pairs if a == b) / n
    ca = collections.Counter(a for a, _ in pairs)
    cb = collections.Counter(b for _, b in pairs)
    pe = sum(ca[k] / n * cb[k] / n for k in set(ca) | set(cb))
    if pe == 1.0:
        return float("nan"), n          # one label only; kappa undefined
    return (po - pe) / (1 - pe), n


def main():
    per = load_human()
    ids = sorted(per)
    all_keys = sorted(set().union(*[set(v) for v in per.values()]))
    code_of = {}
    for a in ids:
        for k, (_, c) in per[a].items():
            code_of[k] = c

    print(f"{len(all_keys)} instances, {len(ids)} annotators, "
          f"{sum(len(v) for v in per.values())} judgments")

    # ---- gold: majority of the 3 who saw it --------------------------------
    gold = {}
    for k in all_keys:
        vs = [per[a][k][0] for a in ids if k in per[a]]
        gold[k] = collections.Counter(vs).most_common(1)[0][0]
    unan = sum(1 for k in all_keys
               if len({per[a][k][0] for a in ids if k in per[a]}) == 1)
    print(f"unanimous 3/3: {unan}/{len(all_keys)} ({unan/len(all_keys):.1%}); "
          f"the rest were 2-1 splits")
    print(f"gold positives: {sum(1 for v in gold.values() if v=='yes')}")

    # ---- pairwise human kappa ---------------------------------------------
    print("\npairwise human Cohen's kappa (overlapping instances only)")
    ks = []
    for a, b in itertools.combinations(ids, 2):
        shared = sorted(set(per[a]) & set(per[b]))
        if not shared:
            continue
        k, n = cohen_kappa([(per[a][s][0], per[b][s][0]) for s in shared])
        ks.append(k)
        print(f"  {a}-{b}  n={n:>4}  kappa={k:.3f}")
    ks = [k for k in ks if k == k]
    print(f"  mean pairwise kappa = {sum(ks)/len(ks):.3f}  "
          f"(min {min(ks):.3f}, max {max(ks):.3f})")

    # ---- per code ----------------------------------------------------------
    print("\nper-code mean pairwise human kappa")
    rows = []
    for code in sorted(set(code_of.values())):
        sub = []
        for a, b in itertools.combinations(ids, 2):
            shared = [s for s in set(per[a]) & set(per[b])
                      if code_of[s] == code]
            if len(shared) < 8:
                continue
            k, _ = cohen_kappa([(per[a][s][0], per[b][s][0]) for s in shared])
            if k == k:
                sub.append(k)
        n = sum(1 for k in all_keys if code_of[k] == code)
        m = sum(sub) / len(sub) if sub else float("nan")
        rows.append((code, n, m, len(sub)))
        print(f"  {code}  n={n:>3}  kappa={m:.3f}  ({len(sub)} pairs)")
    ok = [m for _, _, m, _ in rows if m == m]
    print(f"  range {min(ok):.3f} - {max(ok):.3f}; "
          f"{sum(1 for m in ok if m >= 0.75)}/{len(ok)} codes reach 0.75")

    json.dump({"gold": gold, "code_of": code_of},
              open("/home/claude/work/runs/human_gold.json", "w"))
    print("\n-> /home/claude/work/runs/human_gold.json")


if __name__ == "__main__":
    sys.exit(main())
