#!/usr/bin/env python3
"""Four candidate admission gates, scored on the same 400 instances.

AdaMAST accepts a taxonomy when four LLM annotators reach mean pairwise
Cohen's kappa >= 0.75, and states that this certifies consistent
applicability, not correctness. This script asks what that gate, and three
alternatives, would decide on MedAgentAudit's audit human-eval set -- where
the human agreement it would have to beat is directly computable.

Gates compared:
  G-A  AdaMAST as published: 4-annotator mean pairwise kappa >= 0.75
  G-B  human-relative: panel kappa >= the human kappa for that same code
  G-C  validity: panel-majority vs expert gold kappa >= the human floor
  G-D  selective: unanimity as a routing signal -- what does auto-deciding the
       unanimous instances cost, and how much human labour does it save?

G-D is the one that matches the protocol the clinicians actually used (3
judges, majority, 74% unanimous) and the one that produces an operating point
rather than a verdict.
"""
import collections
import itertools
import json
import os

PANEL_DIR = "/home/claude/work/runs/panel"
MODELS = ["glm-5.3-flash", "qwen3.8-flash", "deepseek-flash",
          "gpt-5.6-sol-disc"]
HUMAN_KAPPA = {"1.1.1": 0.643, "1.2.1": 0.652, "2.1.1": 0.693, "2.1.2": 0.744,
               "2.2.1": 0.713, "2.2.2": 0.676, "3.1.1": 0.496, "3.1.2": 0.273,
               "3.1.3": 0.441, "3.2.1": 0.551}
HUMAN_MEAN = 0.635


def kappa(pairs):
    n = len(pairs)
    if n == 0:
        return float("nan")
    po = sum(1 for a, b in pairs if a == b) / n
    ca, cb = collections.Counter(a for a, _ in pairs), \
        collections.Counter(b for _, b in pairs)
    pe = sum(ca[k] / n * cb[k] / n for k in set(ca) | set(cb))
    return float("nan") if pe == 1.0 else (po - pe) / (1 - pe)


def main():
    meta = json.load(open("/home/claude/work/runs/human_gold.json"))
    gold, code_of = meta["gold"], meta["code_of"]

    v = {}
    for m in MODELS:
        v[m] = {}
        for line in open(os.path.join(PANEL_DIR, f"panel_{m}.jsonl"),
                         encoding="utf-8"):
            r = json.loads(line)
            if r.get("verdict"):
                v[m][r["audit_id"]] = r["verdict"]
        print(f"{m:<18} {len(v[m])}/400 parsed")

    # Score every arm on the instances every model answered, so no gate gets
    # an easier subset than another.
    ids = sorted(set(gold) & set.intersection(*[set(v[m]) for m in MODELS]))
    print(f"\ncommon instances: {len(ids)}")
    print(f"gold positives: {sum(1 for i in ids if gold[i]=='yes')}")
    for m in MODELS:
        y = sum(1 for i in ids if v[m][i] == "yes")
        acc = sum(1 for i in ids if v[m][i] == gold[i]) / len(ids)
        print(f"  {m:<18} says yes {y:>3}  raw agreement with gold {acc:.1%}")

    # ---- G-A: what the agreement gate sees --------------------------------
    print("\n=== G-A  AdaMAST as published: mean pairwise LLM kappa >= 0.75")
    ks = {}
    for a, b in itertools.combinations(MODELS, 2):
        k = kappa([(v[a][i], v[b][i]) for i in ids])
        ks[(a, b)] = k
        print(f"  {a[:14]:<15} {b[:14]:<15} kappa={k:.3f}")
    llm_mean = sum(ks.values()) / len(ks)
    print(f"  mean pairwise LLM kappa = {llm_mean:.3f}   "
          f"gate {'PASSES' if llm_mean >= 0.75 else 'FAILS'} at 0.75")
    print(f"  human mean pairwise     = {HUMAN_MEAN:.3f}")

    # ---- validity: the same panel against the experts ---------------------
    def majority(i, models):
        c = collections.Counter(v[m][i] for m in models)
        return c.most_common(1)[0][0]

    maj = {i: majority(i, MODELS) for i in ids}
    k_gold = kappa([(maj[i], gold[i]) for i in ids])
    print(f"\n  panel majority vs expert gold: kappa={k_gold:.3f}")
    print(f"  ratio (agreement with itself / agreement with experts) = "
          f"{llm_mean / k_gold:.2f}x" if k_gold > 0 else "")

    # ---- per code: G-B and G-C -------------------------------------------
    print("\n=== per code: LLM self-agreement vs validity vs the human floor")
    print(f"  {'code':<7}{'humanK':>8}{'llmK':>8}{'vs gold':>9}"
          f"{'G-A':>6}{'G-B':>6}{'G-C':>6}")
    tally = collections.Counter()
    for code in sorted(HUMAN_KAPPA):
        sub = [i for i in ids if code_of[i] == code]
        kl = [kappa([(v[a][i], v[b][i]) for i in sub])
              for a, b in itertools.combinations(MODELS, 2)]
        kl = [x for x in kl if x == x]
        kl = sum(kl) / len(kl) if kl else float("nan")
        kg = kappa([(maj[i], gold[i]) for i in sub])
        ga = kl >= 0.75
        gb = kl >= HUMAN_KAPPA[code]
        gc = kg >= HUMAN_KAPPA[code]
        tally["A"] += ga
        tally["B"] += gb
        tally["C"] += gc
        print(f"  {code:<7}{HUMAN_KAPPA[code]:>8.3f}{kl:>8.3f}{kg:>9.3f}"
              f"{'Y' if ga else '.':>6}{'Y' if gb else '.':>6}"
              f"{'Y' if gc else '.':>6}")
    print(f"  codes admitted -- G-A {tally['A']}/10, G-B {tally['B']}/10, "
          f"G-C {tally['C']}/10")

    # ---- G-D: unanimity as a routing signal ------------------------------
    print("\n=== G-D  selective: route the split cases to a human")
    for label, models in [("4-model panel", MODELS),
                          ("3-model panel (matches the clinicians)",
                           MODELS[:3])]:
        unan = [i for i in ids if len({v[m][i] for m in models}) == 1]
        split = [i for i in ids if i not in set(unan)]
        acc_u = sum(1 for i in unan if v[models[0]][i] == gold[i]) / len(unan)
        acc_s = sum(1 for i in split
                    if majority(i, models) == gold[i]) / max(len(split), 1)
        acc_all = sum(1 for i in ids if majority(i, models) == gold[i]) / len(ids)
        print(f"  {label}")
        print(f"    unanimous  {len(unan):>3}/{len(ids)} "
              f"({len(unan)/len(ids):>5.1%})  accuracy vs gold {acc_u:.1%}")
        print(f"    split      {len(split):>3}/{len(ids)} "
              f"({len(split)/len(ids):>5.1%})  majority accuracy {acc_s:.1%}")
        print(f"    auto-decide the unanimous: coverage {len(unan)/len(ids):.1%}"
              f" at error {1-acc_u:.1%}  (blanket majority error "
              f"{1-acc_all:.1%})")

    # the clinicians' own version of the same split, for scale
    print("  clinicians (3 judges, from the audit files)")
    print("    unanimous  296/400 (74.0%) -- gold is their majority, so their "
          "unanimous accuracy is 100% by construction;")
    print("    the comparable number is the 26.0% they had to resolve 2-1.")


if __name__ == "__main__":
    main()
