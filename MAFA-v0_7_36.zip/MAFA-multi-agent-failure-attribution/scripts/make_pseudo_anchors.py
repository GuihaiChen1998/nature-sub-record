#!/usr/bin/env python3
"""Build an anchor pool from the injection log, with no human in the loop.

    python scripts/make_pseudo_anchors.py \\
        --data data/AEGIS-custom-simulated-faults-dataset \\
        --stage1 run_sim/stage1.jsonl \\
        --out run_sim/pseudo_anchors.jsonl

`examples/pseudo_anchors.jsonl` has been in the repository since before this
log starts and nothing in it says how it was made -- the 745 calibration slots
could not be regenerated, extended, or pointed at a different split. This
script is that missing step, written by reading the file's own shape: one
record per slot, `votes` a single-element list, `pool` either `calibration` or
`frozen`.

**A pseudo-anchor is not a human label.** The injection log says which agent
was tampered with, so an agent slot is labelled 1 if that agent was injected
and 0 otherwise. That is ground truth about *what was done to the trace*, not
about whether a clinician would call the agent's output wrong, and the two
differ in a way that matters here: an injected agent may recover, and an
untouched downstream agent may propagate the fault and deserve a 1. Use this
to exercise the calibration and routing code and to get an operating point;
do not report its numbers as accuracy against human judgement.

**Head B cannot be fitted from this.** One vote per slot means no
disagreement, and disagreement is the entire signal Head B models. The fit
prints `single-annotator anchors: Head B disabled` and ranks the queue on
model risk alone. Only real annotators close that gap.

Upstream slots only, by default: agents that finished speaking before the
injection step are the one clean negative set available. Downstream agents may
genuinely have been contaminated, so scoring them as negatives would punish
the annotator for being right -- the same reason `validate_on_injected.py`
reports upstream and downstream specificity separately and leads with
upstream.
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True)
    ap.add_argument("--stage1", required=True,
                    help="annotations, to restrict to traces that were scored")
    ap.add_argument("--out", required=True)
    ap.add_argument("--frozen-share", type=float, default=0.3)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--no-step-slots", dest="step_slots", action="store_false",
                    help="omit step-level anchors. They are what calibrates "
                         "the step head; without them every step set is the "
                         "full candidate list and routing is 100% REVIEW.")
    ap.add_argument("--include-downstream", action="store_true",
                    help="also emit agents after the injection point. They are "
                         "not clean negatives; off by default.")
    a = ap.parse_args()

    from mafa.pipeline import AnchorPool, AnchorSlot
    from mafa.trace_adapter import load_dir

    scored = {json.loads(l)["trace_id"] for l in Path(a.stage1).open(encoding="utf-8")
              if json.loads(l).get("annotation") is not None}
    traces = [t for t in load_dir(a.data) if t.trace_id in scored]
    print(f"[anchors] {len(traces)} of {len(scored)} annotated traces found in {a.data}")

    slots: list[AnchorSlot] = []
    stats = Counter()
    for t in traces:
        inj = t.injections or []
        if not inj:
            stats["no injection log"] += 1
            continue
        # Injection is a dataclass, not a dict
        injected_agents = {i.agent_uid for i in inj if i.agent_uid}
        # the earliest injected step bounds "upstream"
        steps = [s.step_id for s in t.steps]
        first = min((steps.index(i.step_id) for i in inj
                     if i.step_id in steps), default=None)
        if first is None:
            stats["injection step not in trace"] += 1
            continue
        for ag in t.agents:
            uid = getattr(ag, "agent_uid", None) or str(ag)
            idx = [k for k, s in enumerate(t.steps) if s.agent_uid == uid]
            if not idx:
                continue
            upstream = max(idx) < first
            label = 1 if uid in injected_agents else 0
            if not upstream and label == 0 and not a.include_downstream:
                stats["downstream negative skipped"] += 1
                continue
            slots.append(AnchorSlot(t.trace_id, f"agent::{uid}", [label]))
            stats[f"label={label} {'upstream' if upstream else 'downstream'}"] += 1

        # Step slots: ALL of them, or none. `_step_calibration_data` drops any
        # trace whose marked set != its step_ids, because a partially marked
        # trace cannot say "no step fired" and treating it as NONE would
        # fabricate calibration points. The injection log covers a whole trace
        # by construction -- every step is either injected or it is not -- so
        # this is one of the few labels that can honestly be completed without
        # a human. Without these the step head stays uncalibrated, every step
        # set is the full candidate list, and routing is 100% REVIEW.
        if a.step_slots:
            injected_steps = {i.step_id for i in inj if i.step_id}
            for s in t.steps:
                slots.append(AnchorSlot(
                    t.trace_id, f"step::{s.step_id}",
                    [1 if s.step_id in injected_steps else 0]))
            stats["traces with complete step slots"] += 1

    if not slots:
        raise SystemExit("no slots built; check --data has injection logs")

    rng = random.Random(a.seed)
    by_trace: dict[str, list[AnchorSlot]] = {}
    for s in slots:
        by_trace.setdefault(s.trace_id, []).append(s)
    ids = sorted(by_trace)
    rng.shuffle(ids)
    # split by trace, never by slot: two slots from one trace on opposite
    # sides of the split would leak the trace across calibration and frozen
    n_frozen = int(len(ids) * a.frozen_share)
    frozen_ids = set(ids[:n_frozen])
    pool = AnchorPool([s for s in slots if s.trace_id not in frozen_ids],
                      [s for s in slots if s.trace_id in frozen_ids])
    pool.save(a.out)
    print(f"[anchors] {dict(stats)}")
    print(f"[anchors] {pool}")
    print(f"-> {a.out}")
    pos = sum(1 for s in slots if s.label == 1)
    print(f"[anchors] {pos}/{len(slots)} positive ({pos/len(slots):.1%}); "
          f"one vote per slot, so Head B will not fit")


if __name__ == "__main__":
    main()
