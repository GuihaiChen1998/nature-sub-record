#!/usr/bin/env python3
"""Does the same failure mechanism turn up in two unrelated samples?

    python scripts/cross_sample_validate.py \\
        --runs results/gpt-5.6-sol/stage4/run_ab3_clean_n180 \\
               results/gpt-5.6-sol/stage4/run_ab4_faulty_n180 \\
        --out results/gpt-5.6-sol/stage4/cross_sample.json

Why this rather than held-out recovery
--------------------------------------
The ablation's own yardstick -- hide four codes, see if the loop finds them --
has two problems. In deployment there is no ground truth for an unseen
framework, so recovery rate measures nothing about the thing we actually want.
And the annotator has very likely read the source taxonomies during
pretraining, so "recovered 2.2.1" is ambiguous between finding a mechanism and
recalling a label.

Cross-sample recurrence has neither problem. Two disjoint sets of traces are
clustered, named and triaged independently. If the same mechanism surfaces in
both at comparable support, that is evidence the loop is tracking something in
the traces rather than packaging noise into confident prose -- and it needs no
answer key.

It is evidence, not proof. Two samples drawn from the same four frameworks
share whatever quirks those frameworks have; recurrence across *frameworks*, or
across a framework held out entirely, would be stronger. Read this alongside
`export_for_human_read.py` (does a clinician agree the mechanism is real?) and
a fold-back run (does adding the code absorb residue without mislabelling?).

What it reports
---------------
Pairs clusters between runs by cosine over name+definition, then reports for
each pair: support on both sides, framework mix, and whether the two runs
reached the same triage verdict. **Verdict agreement is reported separately
from cluster recurrence because they do not travel together** -- on the first
two runs, four of the largest clusters recurred but two of them were judged
differently.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def load(run: Path) -> list[dict]:
    d = json.loads((run / "ablation.json").read_text(encoding="utf-8"))
    admitted = {a["cluster"]: a for a in d.get("admitted", [])}
    out = []
    for c in d["clusters"]:
        if not c.get("name"):
            continue
        c = dict(c)
        c["admitted"] = c["id"] in admitted
        c["definition"] = admitted.get(c["id"], {}).get("definition", "")
        out.append(c)
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", nargs=2, required=True)
    ap.add_argument("--labels", nargs=2, default=["A", "B"])
    ap.add_argument("--out", default=None)
    ap.add_argument("--min-cosine", type=float, default=0.45,
                    help="below this the pairing is not claimed")
    ap.add_argument("--embed-cache", default=None)
    a = ap.parse_args()

    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from mafa import make_embedder

    runs = [load(Path(r)) for r in a.runs]
    cache = a.embed_cache or str(Path(a.runs[0]) / "embeddings.jsonl")
    embed = make_embedder("openai", model="text-embedding-3-small",
                          cache_path=cache)

    def vecs(cs):
        # name and definition together: a name alone is four words and pairs
        # things that merely sound alike
        E = np.asarray(embed([f"{c['name']}\n{c['definition']}" for c in cs]))
        return E / np.linalg.norm(E, axis=1, keepdims=True)

    EA, EB = vecs(runs[0]), vecs(runs[1])
    S = EA @ EB.T

    pairs, recurring, verdict_agree = [], 0, 0
    for i, ca in enumerate(runs[0]):
        j = int(S[i].argmax())
        cb, cos = runs[1][j], float(S[i, j])
        paired = cos >= a.min_cosine
        agree = ca["triage"] == cb["triage"]
        recurring += paired
        verdict_agree += paired and agree
        pairs.append({
            "cosine": round(cos, 3), "paired": paired,
            "verdict_agrees": agree if paired else None,
            a.labels[0]: {"id": ca["id"], "n": ca["n"], "triage": ca["triage"],
                          "name": ca["name"], "admitted": ca["admitted"],
                          "frameworks": ca.get("frameworks")},
            a.labels[1]: {"id": cb["id"], "n": cb["n"], "triage": cb["triage"],
                          "name": cb["name"], "admitted": cb["admitted"],
                          "frameworks": cb.get("frameworks")}})

    pairs.sort(key=lambda p: -p[a.labels[0]]["n"])
    print(f"{'cosine':>6} {'pair':>5} {'same verdict':>13}   "
          f"{a.labels[0]} (n, triage)  <->  {a.labels[1]} (n, triage)")
    for p in pairs:
        x, y = p[a.labels[0]], p[a.labels[1]]
        mark = "yes" if p["paired"] else " - "
        vm = ("same" if p["verdict_agrees"] else "DIFFER") if p["paired"] else ""
        print(f"{p['cosine']:>6} {mark:>5} {vm:>13}   "
              f"{x['name'][:34]:34} {x['n']:>4} {x['triage']:>4}  <->  "
              f"{y['name'][:34]:34} {y['n']:>4} {y['triage']:>4}")

    both = [p for p in pairs if p["paired"]
            and p[a.labels[0]]["admitted"] and p[a.labels[1]]["admitted"]]
    print(f"\nclusters recurring across both samples : {recurring}/{len(pairs)}"
          f"  (cosine >= {a.min_cosine})")
    print(f"of those, same triage verdict          : {verdict_agree}/{recurring}"
          "   <- reported separately on purpose")
    print(f"admitted in BOTH runs                  : {len(both)}")
    for p in both:
        print(f"  - {p[a.labels[0]]['name']}  "
              f"(n={p[a.labels[0]]['n']} / {p[a.labels[1]]['n']})")

    if a.out:
        rep = {"runs": a.runs, "labels": a.labels, "min_cosine": a.min_cosine,
               "n_recurring": recurring, "n_verdict_agree": verdict_agree,
               "admitted_in_both": [p[a.labels[0]]["name"] for p in both],
               "pairs": pairs}
        Path(a.out).write_text(json.dumps(rep, indent=2, ensure_ascii=False),
                               encoding="utf-8")
        print(f"\n-> {a.out}")


if __name__ == "__main__":
    main()
