#!/bin/sh
# gpt-only supervisor, counting annotated traces rather than file lines.
#
# The previous version used `wc -l` on stage1.jsonl as the progress measure.
# Stage 1 appends a record on failure and appends a second one when the retry
# succeeds, so the file grows faster than the corpus is covered: 194 lines for
# 180 traces of which 163 were annotated and 17 were still outstanding. The
# supervisor read 194 >= 180, declared Arm A finished and started Arm B on an
# incomplete control. A cheap proxy for the quantity that matters, never
# checked at the boundary -- the same shape as the name filter counted by
# whitespace and the logprob probe read off one backend.
#
# `done` now means: every trace_id in the run has a record carrying an
# annotation. Nothing else.
R=/home/claude/work/runs
D=/home/claude/work/mafa/MAFA-multi-agent-failure-attribution
cd "$D" || exit 1
want=180
export OPENAI_API_KEY=sk-hHecHumBRXWUjWwOD28a462e290f4a33AbBdDd74F0D96dF5
export OPENAI_BASE_URL=https://aihubmix.com/v1
FLAGS="--model gpt-5.6-sol-disc --concurrency 12 --no-images"

annotated () {   # $1 workdir -> number of trace_ids with an annotation
  python3 - "$R/$1/stage1.jsonl" <<'PY'
import json, sys
try:
    ok = set()
    for line in open(sys.argv[1], encoding="utf-8"):
        try:
            r = json.loads(line)
        except Exception:
            continue
        if r.get("annotation"):
            ok.add(r["trace_id"])
    print(len(ok))
except FileNotFoundError:
    print(0)
PY
}

launch () {
  n=$(annotated "$1"); n=${n:-0}
  if [ "$n" -ge "$want" ]; then echo "$1: done ($n/$want annotated)"; return 1; fi
  if ps aux | grep -v grep | grep -q "work $R/$1"; then
    echo "$1: running ($n/$want annotated)"; return 0
  fi
  echo "$1: restarting at $n/$want annotated"
  setsid nohup python3 -u scripts/run_stage1.py \
    --data data --trace-ids /home/claude/work/ab4_180_ids.txt \
    $FLAGS $2 --work "$R/$1" >> "$R/$3" 2>&1 < /dev/null &
  return 0
}

launch gpt_full180 "" gpt_full180.log
if [ $? -ne 0 ]; then
  launch gpt_seed6_180 "--taxonomy $R/gpt_seed6_180/seed_taxonomy.json" \
    gpt_seed6.log
fi
exit 0
