#!/usr/bin/env python3
"""Offline wiring checks for Stage 4. No data, no API keys, no money.

    python scripts/selfcheck_offline.py

`preflight.py` checks that the environment can run; this checks that the
features that are switched on are actually reachable. Those are different
questions, and the second one has cost more here: `resplit` shipped in 0.7.13,
was configured on by default, and could not fire from either driver script
because neither passed `embed=`. The run would have completed, the 39-item
cluster would have gone to `AB?` exactly as before, and the conclusion would
have been that resplit does not help.

Add a check here whenever a feature depends on an argument a caller may omit.
"""
from __future__ import annotations

import ast
import sys
import warnings
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mafa.embeddings import make_embedder                       # noqa: E402
from mafa.taxonomy import FailureMode, Taxonomy                  # noqa: E402
from mafa.taxonomy_evolution import (Cluster, ResidualItem,      # noqa: E402
                                     TriageConfig, triage_clusters)

FAILURES: list[str] = []
PASSES: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASSES if ok else FAILURES).append(f"{name}{': ' + detail if detail else ''}")
    print(f"  [{'ok ' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))


# --------------------------------------------------------------------------- #
# 1. static: every triage_clusters call site passes embed=
# --------------------------------------------------------------------------- #

def check_call_sites() -> None:
    print("\ntriage_clusters call sites pass embed=")
    for path in sorted((ROOT / "scripts").glob("*.py")):
        if path.name == Path(__file__).name:
            continue                    # contains a deliberate negative control
        tree = ast.parse(path.read_text(encoding="utf-8"), str(path))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            fn = node.func
            if not (isinstance(fn, ast.Name) and fn.id == "triage_clusters"):
                continue
            kws = {k.arg for k in node.keywords}
            check(f"{path.name}:{node.lineno}", "embed" in kws,
                  "" if "embed" in kws else "resplit unreachable from here")


# --------------------------------------------------------------------------- #
# 2. static: no config field is declared and then never read
# --------------------------------------------------------------------------- #

def check_dead_config() -> None:
    print("\nTriageConfig fields are read somewhere")
    src = (ROOT / "mafa" / "taxonomy_evolution.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    cls = next(n for n in ast.walk(tree)
               if isinstance(n, ast.ClassDef) and n.name == "TriageConfig")
    fields = [n.target.id for n in cls.body if isinstance(n, ast.AnnAssign)]
    dupes = [f for f, n in Counter(fields).items() if n > 1]
    check("no field declared twice", not dupes, ", ".join(dupes))

    # a field counts as read if anything outside the field list mentions it:
    # attribute access anywhere in the package, or a keyword at a call site
    decl_lines = {n.lineno for n in cls.body if isinstance(n, ast.AnnAssign)}
    everywhere = []
    for p in sorted((ROOT / "mafa").glob("*.py")) + \
             sorted((ROOT / "scripts").glob("*.py")):
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if p.name == "taxonomy_evolution.py" and i in decl_lines:
                continue
            everywhere.append(line)
    blob = "\n".join(everywhere)
    unread = [f for f in set(fields)
              if f".{f}" not in blob and f"{f}=" not in blob]
    check("no field is write-only", not unread, ", ".join(sorted(unread)))


# --------------------------------------------------------------------------- #
# 3. behavioural: an unnameable mixed cluster actually comes apart
# --------------------------------------------------------------------------- #

MECHS = [
    ("Aggregate failure rate cited as domain-specific evidence",
     "An agent assigned one analytic dimension cites an undifferentiated "
     "overall trial failure rate as if it were specific to its dimension.",
     "overall failure rate quoted for the safety domain"),
    ("Absent evidence converted into a positive prediction",
     "An agent treats the absence of a reported finding in the record as "
     "affirmative evidence that the finding is negative.",
     "no adverse events reported therefore the drug is safe"),
    ("Misread eligibility criterion",
     "An agent restates an inclusion criterion with its threshold or polarity "
     "altered, and then reasons from the altered version.",
     "inclusion criterion age over 65 restated as under 65"),
]


def _mixed_cluster(embed, per: int = 8) -> Cluster:
    items = [
        ResidualItem(trace_id=f"t{m}_{k}",
                     framework="mdagents" if k % 2 else "dylan",
                     agent_uid=f"a{k}", step_id=f"s{k}", phase="analysis",
                     source="novel_proposal", proposed_name=name,
                     definition=defn, rationale="see evidence",
                     evidence=[f"{ev} (instance {k})"],
                     why_not_existing="no seed code states this mechanism")
        for m, (name, defn, ev) in enumerate(MECHS) for k in range(per)]
    E = np.asarray(embed([i.text_for_embedding() for i in items]))
    return Cluster(cluster_id=7, items=items, centroid=E.mean(axis=0),
                   frameworks=Counter(i.framework for i in items),
                   phases=Counter(i.phase for i in items))


def _seed() -> Taxonomy:
    return Taxonomy(version=0, modes=[
        FailureMode(code="1.2.1", name="Answers a different question",
                    definition="The agent answers something other than the "
                               "specific question it was asked.",
                    allowed_phases=frozenset({"analysis"}))])


def _summarise_refusing(above: int = 12):
    def fn(c: Cluster) -> dict:
        if len(c.items) > above:
            return {"coherent": False, "name": "", "definition": ""}
        return {"coherent": True, "name": c.items[0].proposed_name,
                "definition": c.items[0].definition,
                "allowed_phases": ["analysis"], "outliers": []}
    return fn


def _reaudit(c: Cluster, tax: Taxonomy) -> dict:
    return {"absorb_rate": 0.0, "absorbed_by": None, "n_sampled": 8}


def check_resplit_behaviour() -> None:
    print("\nresplit end to end (hash embedder, stub judge)")
    embed = make_embedder("hash", model="hash-512")
    cfg = TriageConfig(sample_per_cluster=8)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        without = triage_clusters([_mixed_cluster(embed)], _seed(),
                                  _summarise_refusing(), _reaudit, cfg)
        with_embed = triage_clusters([_mixed_cluster(embed)], _seed(),
                                     _summarise_refusing(), _reaudit, cfg,
                                     embed=embed)

    check("without embed=, the cluster is routed whole",
          len(without) == 1 and without[0].triage == "AB?",
          f"{len(without)} cluster(s), triage {without[0].triage!r}")
    check("without embed=, the skip is recorded",
          without[0].summarise_detail.get("resplit_skipped") is not None)
    check("with embed=, the cluster splits",
          len(with_embed) >= len(MECHS),
          f"{len(with_embed)} group(s) of {[c.support for c in with_embed]}")
    check("every part then names and reaches a verdict",
          all(c.name and c.triage in ("A", "B", "AB?") for c in with_embed),
          ", ".join(f"{c.cluster_id}:{c.triage}" for c in with_embed))

    # the one that cost 17 items on the first real run
    n_in = len(_mixed_cluster(embed).items)
    n_out = sum(c.support for c in with_embed)
    check("no member is lost in the split", n_in == n_out,
          f"{n_in} in, {n_out} out")
    check("a remainder, if any, is routed rather than dropped",
          all(c.triage == "AB?" and c.triage_reason
              for c in with_embed if "remainder" in c.name))


def check_resplit_conservation() -> None:
    """Split a group HDBSCAN cannot fully assign, and count the members back."""
    print("\nresplit conserves members when some are unassignable")
    embed = make_embedder("hash", model="hash-512")
    c = _mixed_cluster(embed)
    # three mutually unrelated one-offs: fewer than min_cluster_size and not
    # similar to each other, so HDBSCAN can only label them -1
    c.items.extend(
        ResidualItem(trace_id=f"odd{k}", framework="dylan", agent_uid="a",
                     step_id="s", phase="analysis", source="novel_proposal",
                     proposed_name=name, definition=defn,
                     rationale="see evidence", evidence=[ev],
                     why_not_existing="nothing states it")
        for k, (name, defn, ev) in enumerate([
            ("Units transposed in a dosage restatement",
             "A milligram quantity is carried forward as micrograms.",
             "40 mg carried forward as 40 mcg"),
            ("Timestamp ordering ignored",
             "Later labs are discussed as if they preceded the earlier ones.",
             "day 14 panel discussed before the day 2 panel"),
            ("Consultation terminated before the assigned vote",
             "The chair closes the round while one member has not spoken.",
             "round closed with the pathologist silent"),
        ]))
    c.frameworks = Counter(i.framework for i in c.items)
    c.phases = Counter(i.phase for i in c.items)

    from mafa.taxonomy_evolution import resplit
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        parts, remainder = resplit(c, embed, min_cluster_size=4)
    kept = sum(p.support for p in parts) + (remainder.support if remainder else 0)
    check("parts + remainder account for every member",
          kept == len(c.items),
          f"{len(c.items)} in -> parts {[p.support for p in parts]} "
          f"+ remainder {remainder.support if remainder else 0} = {kept}")


def check_image_conservation() -> None:
    """Every referenced image is either sent or reported, never dropped quietly."""
    print("\nImageStore accounts for every referenced image")
    from mafa.images import ImageStore

    class FakeTrace:
        def __init__(self, names):
            self.images = names

    root = ROOT / "_selfcheck_imgs"
    root.mkdir(exist_ok=True)
    # a 1x1 PNG is enough; this checks accounting, not pixels
    png = bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
        "0000000a49444154789c6300010000050001" "0d0a2db4" "0000000049454e44ae426082")
    for n in ("a.png", "b.png", "c.png"):
        (root / n).write_bytes(png)
    st = ImageStore([root])

    b, d = st.blocks(FakeTrace(["a.png", "b.png", "c.png"]))
    check("all three present -> three blocks, nothing dropped",
          len(b) == 3 and not d, f"{len(b)} blocks, dropped {d}")

    b, d = st.blocks(FakeTrace(["a.png", "missing.png", "c.png"]))
    check("a missing file is reported, not skipped",
          len(b) == 2 and len(d) == 1 and "not found" in d[0], f"dropped {d}")

    b, d = st.blocks(FakeTrace(["a.png", "b.png", "c.png"]), max_images=2)
    check("an explicit cap reports what it cut",
          len(b) == 2 and len(d) == 1 and "max_images" in d[0], f"dropped {d}")

    names = ["a.png", "b.png", "c.png"]
    b, d = st.blocks(FakeTrace(names))
    check("blocks + dropped == referenced, always",
          len(b) + len(d) == len(names))

    # the default must not truncate: 102 real traces carry 5 or 6 images
    b, d = st.blocks(FakeTrace(["a.png"] * 6))
    check("no default cap (102 real traces carry 5-6 images)",
          len(b) == 6 and not d, f"{len(b)} blocks, dropped {d}")

    for n in ("a.png", "b.png", "c.png"):
        (root / n).unlink()
    root.rmdir()


def check_shard_preserves_ids() -> None:
    """Sharding must not renumber trace_ids. This has gone wrong three times."""
    print("\nsharding preserves trace_id")
    import glob
    import shutil
    import tempfile
    from mafa.images import shard_preserving_ids
    from mafa.trace_adapter import load_dir

    # real corpus: the adapters need real record shapes, and a synthetic
    # fixture that happens to parse would not exercise the id construction
    found = sorted(glob.glob(str(ROOT / "data" / "**" / "*.jsonl"),
                             recursive=True))
    if not found:
        print("  [skip] no corpus under data/ -- this check needs real records")
        return
    src = Path(found[0])
    want = {t.trace_id for t in load_dir(src.parent) if t.source_file == src.name}
    tmp = Path(tempfile.mkdtemp())
    got: set = set()
    for p in shard_preserving_ids(src, tmp, 3, limit=12):
        got |= {t.trace_id for t in load_dir(p.parent)}
    lost = {t for t in want if t not in got}
    check("every id survives the split",
          got and got <= want,
          f"{len(got)} ids out, {len(got - want)} renumbered")
    shutil.rmtree(tmp)


def check_estimators() -> None:
    """A confidence estimator must point the right way, especially when split."""
    print("\nconfidence estimators behave monotonically")
    from mafa.estimators import make_estimator

    def fake(seq):
        it = iter(seq)
        return lambda s, q, want_logprobs=False: (next(it), None, {})

    e = make_estimator("steerconf")
    p = {k: e.estimate(fake(v), "s", "q").p for k, v in {
        "yes": ["1, 95"] * 5,
        "no": ["0, 95"] * 5,
        "4-1": ["1, 90", "1, 85", "1, 80", "1, 88", "0, 70"],
        "3-2": ["1, 90", "0, 85", "1, 80", "0, 88", "1, 70"],
    }.items()}
    check("a unanimous 1 is confident", p["yes"] > 0.9, f"{p['yes']:.3f}")
    check("a unanimous 0 is confident", p["no"] < 0.1, f"{p['no']:.3f}")
    # the one that was wrong twice: first the verdict digit was parsed as the
    # confidence, then kappa_ans bottomed out at 0.6 on a binary vote
    check("a 3-2 split lands near 0.5, not near a verdict",
          abs(p["3-2"] - 0.5) < 0.1, f"{p['3-2']:.3f}")
    check("agreement is monotonic (3-2 < 4-1 < unanimous)",
          p["3-2"] < p["4-1"] < p["yes"],
          f"{p['3-2']:.3f} < {p['4-1']:.3f} < {p['yes']:.3f}")

    from mafa.estimators import _parse_verdict_conf
    check("verdict and confidence parse separately",
          _parse_verdict_conf("0, 95") == (0, 0.95),
          str(_parse_verdict_conf("0, 95")))
    check("an unparseable reply yields None, not a guess",
          _parse_verdict_conf("cannot tell") == (None, None))

    from mafa.estimators import VPDEstimator
    p = [0.7, 0.2, 0.1]
    ident = VPDEstimator.invert_softmax(p, 1.0)
    # the whole point of the invert-softmax trick: scaling a verbalised
    # distribution directly applies softmax a second time, so softmax(p/1)
    # already distorts [0.7, 0.2, 0.1] into roughly [0.46, 0.28, 0.25].
    # Inverting to log p first makes T = 1 the identity.
    check("invert_softmax is identity at T=1",
          all(abs(a - b) < 1e-6 for a, b in zip(ident, p)),
          str([round(x, 4) for x in ident]))
    check("invert_softmax normalises at every temperature",
          all(abs(sum(VPDEstimator.invert_softmax(p, t)) - 1) < 1e-9
              for t in (0.5, 1.0, 2.0, 5.0)))
    sharp = VPDEstimator.invert_softmax(p, 0.5)
    flat = VPDEstimator.invert_softmax(p, 2.0)
    check("temperature sharpens below 1 and flattens above",
          sharp[0] > p[0] > flat[0],
          f"{sharp[0]:.3f} > {p[0]} > {flat[0]:.3f}")

    v = VPDEstimator()
    fk = lambda t: (lambda s, q, want_logprobs=False: (t, None, {}))
    r = v.estimate_distribution(fk("1.2.1=60\n2.1.1=25\nnone=15"), "s", "q",
                                ["1.2.1", "2.1.1", "3.1.1"])
    check("VPD keeps the none-of-the-above mass out of p",
          abs(r.p - 0.85) < 1e-6, f"p={r.p}")
    check("VPD reports options the model never mentioned",
          r.detail["missing_options"] == ["3.1.1"],
          str(r.detail["missing_options"]))


def check_client_signatures() -> None:
    """Every annotator client must take the same arguments."""
    print("\nannotator clients share one interface")
    import inspect
    from mafa.annotator_client import ChatCompatClient, OpenAICompatClient
    from mafa.reaudit_llm import AnthropicCompatClient

    ref = {m: inspect.signature(getattr(OpenAICompatClient, m))
           for m in ("structured", "scored")}
    for cls in (ChatCompatClient, AnthropicCompatClient):
        for m, sig in ref.items():
            got = getattr(cls, m, None)
            if got is None:
                # AnthropicCompatClient has no scorer; probe_logprob_support
                # handles that by falling back, so it is allowed
                check(f"{cls.__name__}.{m} absent is tolerated", m == "scored")
                continue
            names = list(inspect.signature(got).parameters)
            want = list(sig.parameters)
            # `_score_batched` swallows every exception and retries, so a
            # signature mismatch here does not raise where anyone looks: a
            # missing `schema` argument reported itself as "no usable
            # logprobs", 0 of 16 slots scored, on a model whose probe had
            # just found five alternatives.
            check(f"{cls.__name__}.{m} matches OpenAICompatClient",
                  names == want, f"{names} vs {want}")


def check_ablation_recovery() -> None:
    """The recovery metric must not put the gate or the corpus in the numerator.

    Both faults shipped and both were silent: recovery was scored over
    gate-admitted clusters only, so a rediscovery that failed G1 was reported
    as a discovery failure; and the held-out set was chosen without checking
    that each code is structurally scoreable in enough frameworks to reach the
    gate at all. Two of the four codes held out in every run up to 0.7.20
    require `has_multi_round`, which one framework has.
    """
    print("\nablation recovery metric")
    sys.path.insert(0, str(ROOT / "scripts"))
    from ablate_seed import _base_rate, _eligibility        # noqa: PLC0415

    src = (ROOT / "scripts" / "ablate_seed.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    loops = [n for n in ast.walk(tree)
             if isinstance(n, ast.For) and isinstance(n.iter, ast.Name)
             and n.iter.id == "admitted"]
    check("recovery does not iterate `admitted` alone", not loops,
          "" if not loops else f"{len(loops)} such loop(s) remain")
    check("recovery iterates the triage-B candidates",
          "for c, passed, gate_summary in candidates:" in src)
    check("each scored cluster records its own admission",
          '"admitted": passed' in src)

    class _T:
        def __init__(self, fw, caps):
            self.framework, self.capabilities = fw, caps

    #: one capability present in a single framework, one present everywhere
    traces = ([_T("alpha", {"solo": True, "everywhere": True})] * 3 +
              [_T("beta", {"solo": False, "everywhere": True})] * 3 +
              [_T("gamma", {"solo": False, "everywhere": True})] * 3)
    held = Taxonomy(modes=[
        FailureMode(code="X.1", name="solo", definition="d" * 20,
                    allowed_phases=frozenset({"discussion"}),
                    anchor_question="q", requires=frozenset({"solo"})),
        FailureMode(code="X.2", name="broad", definition="d" * 20,
                    allowed_phases=frozenset({"discussion"}),
                    anchor_question="q", requires=frozenset({"everywhere"})),
    ])
    e = _eligibility(held, traces)
    check("a single-framework code is reported as such",
          e["X.1"]["n_frameworks"] == 1, str(e["X.1"]["frameworks"]))
    check("a cross-framework code is reported as such",
          e["X.2"]["n_frameworks"] == 3, str(e["X.2"]["frameworks"]))
    scorable = [c for c, d in e.items() if d["n_frameworks"] >= 2]
    check("the denominator excludes the unrecoverable code",
          scorable == ["X.2"], f"scorable {scorable}")

    check("an unmeasured base rate is representable, not assumed",
          "base = None" in src and '"base_rate": base' in src)
    check("a run without a full-taxonomy control says so",
          "Precondition 3 of this script is unverified" in src)
    check("_base_rate separates relabelling from silence",
          all(k in _base_rate.__doc__ for k in
              ("relabelled", "novel", "not flagged")))

    # The name filter's cost is annotator-dependent: 0.7% of proposals on one
    # annotator, 70% on another that names in snake_case. Counting whitespace
    # enforced "contains a space", not "is more than one word".
    from mafa.taxonomy_evolution import _name_words     # noqa: PLC0415
    for name, want in [("ungrounded aggregate inference", 3),
                       ("ungrounded_aggregate_inference", 3),
                       ("novel::self_contradictory_option_selection", 5),
                       ("scale-aggregation-inversion", 3),
                       ("ungroundedAggregateInference", 3),
                       ("lane_conflation", 2),
                       ("hallucination", 1),
                       ("", 0)]:
        check(f"name words: {name!r} -> {want}",
              _name_words(name) == want, f"got {_name_words(name)}")


def check_silent_defaults() -> None:
    """Defaults must not change what experiment was run without saying so.

    Two instances, found the same day. `run_stage1.py` attached no images when
    `--images` was omitted, so four arms were annotated text-only on a corpus
    with 57 image references and nothing in the logs said which experiment had
    been run. And a progress counter used `wc -l` on stage1.jsonl, which grows
    on failure *and* on the retry that fixes it, so 194 lines was read as 180
    traces when 17 were still outstanding -- an incomplete control was declared
    finished and the next arm started against it.

    Both are the same shape: a cheap proxy for the quantity that matters,
    never checked at the boundary where it stops being a proxy.
    """
    print("\nsilent defaults")
    src = (ROOT / "scripts" / "run_stage1.py").read_text(encoding="utf-8")
    check("a corpus with image references refuses a bare run",
          "an accidental one is not" in src and "if n_ref and not" in src)
    check("text-only annotation has to be chosen",
          '"--no-images"' in src and 'getattr(a, "no_images", False)' in src)
    check("the opt-out still says what it cost",
          "NOT attached" in src)


def check_pluggable_backends() -> None:
    """Stage 2 and Stage 3 must be swappable, and the swap must be honest.

    The claim this project makes is self-evolution, and the loop has never
    turned twice. The obstacle is that the logistic calibrator and split
    conformal are both bound to the taxonomy signature and refuse to score
    across a change -- correctly, since both fail silently otherwise. Making
    the backend a choice turns "the loop cannot turn" into "turning it costs
    this specific guarantee", which is a statement that can go in a paper.

    What is checked here is not that the alternatives are better. It is that
    each one states what it gives up, and that a pairing which would fail
    silently is rejected loudly.
    """
    print("\npluggable calibration / routing backends")
    from mafa.calibration_backends import (Belief, EvolutionPolicy,  # noqa: PLC0415
                                           CALIBRATORS, make_calibrator)
    from mafa.routing_backends import (ROUTERS, make_router,          # noqa: PLC0415
                                       check_compatible, describe_pairing)

    check("both registries are populated",
          set(CALIBRATORS) == {"logistic", "venn_abers", "logistic_va",
                               "lascal", "sample_consistency", "daca",
                               "consistency_distill"}
          and set(ROUTERS) == {"split", "aci", "venn_abers", "threshold"},
          f"{sorted(CALIBRATORS)} / {sorted(ROUTERS)}")

    # -- Belief is the one type both sides agree on ----------------------- #
    p = Belief.point(0.8)
    check("a point belief has zero width", p.is_point and p.width == 0.0)
    check("a point belief collapses to itself", abs(p.p - 0.8) < 1e-9)
    iv = Belief(0.3, 0.7)
    check("an interval belief reports its width", abs(iv.width - 0.4) < 1e-9)
    # A symmetric interval collapses to 0.5 under both the VA formula and the
    # midpoint, so it cannot distinguish them. An asymmetric one can: VA
    # weights by how much each isotonic fit moved, the midpoint does not.
    asym = Belief(0.10, 0.30)
    check("the interval collapse is the VA formula, not the midpoint",
          abs(asym.p - 0.30 / (1 - 0.10 + 0.30)) < 1e-9
          and abs(asym.p - 0.20) > 1e-3,
          f"p={asym.p:.4f} midpoint=0.2000")
    try:
        Belief(0.7, 0.3)
        check("a reversed interval is rejected", False)
    except ValueError:
        check("a reversed interval is rejected", True)

    # -- each backend declares a policy ----------------------------------- #
    pol = {}
    for name in CALIBRATORS:
        pol[name] = make_calibrator(name).policy()
    check("only the logistic calibrator demands a refit",
          pol["logistic"] is EvolutionPolicy.REFIT_REQUIRED
          and pol["venn_abers"] is EvolutionPolicy.DEGRADES_VISIBLY
          and pol["logistic_va"] is EvolutionPolicy.DEGRADES_VISIBLY,
          str({k: v.value for k, v in pol.items()}))
    check("only ACI claims to adapt online",
          make_router("aci").policy() is EvolutionPolicy.ADAPTS_ONLINE
          and make_router("split").policy() is EvolutionPolicy.REFIT_REQUIRED)

    # -- the silent-failure pairing is rejected --------------------------- #
    bad = check_compatible(make_calibrator("logistic"),
                           make_router("venn_abers"))
    check("point estimates cannot feed an interval router", bool(bad),
          str(bad))
    check("the rejection names the fix",
          bool(bad) and "logistic_va" in bad)
    ok = check_compatible(make_calibrator("logistic_va"),
                          make_router("venn_abers"))
    check("the interval pairing is accepted", ok is None, str(ok))

    # -- the loop policy is the weaker of the two ------------------------- #
    d = describe_pairing(make_calibrator("logistic"), make_router("aci"))
    check("a refit-required calibrator blocks the loop whatever the router",
          d["can_turn_without_reanchoring"] is False, str(d["loop_policy"]))
    d2 = describe_pairing(make_calibrator("logistic_va"), make_router("aci"))
    check("an adaptive pairing can turn the loop",
          d2["can_turn_without_reanchoring"] is True)
    check("every pairing carries an explicit claim",
          all(len(describe_pairing(make_calibrator(c), make_router(r))["claim"])
              > 80
              for c in CALIBRATORS for r in ROUTERS
              if check_compatible(make_calibrator(c), make_router(r)) is None))

    # -- the NOVEL channel cannot be silently disabled -------------------- #
    va = make_router("venn_abers", novel_width=0.9)
    va.fit([Belief(0.4, 0.5)] * 20, [0] * 20)
    check("a threshold above every observed width is reported",
          "never fire" in (va.report().detail.get("note") or ""),
          str(va.report().detail.get("note")))
    auto = make_router("venn_abers")
    auto.fit([Belief(0.2, 0.2 + i / 200) for i in range(100)], [0] * 100)
    det = auto.report().detail
    check("auto resolves the threshold from the observed widths",
          det["novel_width_resolved"] is not None
          and 0.0 < det["novel_rate"] <= 0.12,
          f"resolved={det['novel_width_resolved']} rate={det['novel_rate']}")
    unfit = make_router("venn_abers")
    try:
        unfit.is_novel(Belief(0.1, 0.9))
        check("routing before fit is refused", False)
    except RuntimeError:
        check("routing before fit is refused", True)

    # -- ACI moves alpha in the right direction --------------------------- #
    aci = make_router("aci", alpha=0.10, gamma=0.05, warmup=5)
    aci.fit([Belief.point(0.9)] * 60, [1] * 55 + [0] * 5,
            ["agent|dylan"] * 60)
    a0 = aci._state("agent|dylan").alpha_t
    for _ in range(20):
        aci.observe("agent|dylan", covered=False)      # missing repeatedly
    a1 = aci._state("agent|dylan").alpha_t
    check("repeated misses lower alpha_t, widening the sets", a1 < a0,
          f"{a0:.3f} -> {a1:.3f}")
    for _ in range(60):
        aci.observe("agent|dylan", covered=True)
    a2 = aci._state("agent|dylan").alpha_t
    check("sustained coverage raises alpha_t back", a2 > a1,
          f"{a1:.3f} -> {a2:.3f}")
    check("ACI reports warming_up and empirical coverage, not just 1-alpha",
          "warming_up" in str(aci.report().detail)
          and "empirical_coverage" in str(aci.report().detail))
    check("a taxonomy change resets ACI's feedback counters",
          "warming_up" in aci.on_taxonomy_change("T1:deadbeef01")
          and aci.warming_up("agent|dylan"))

    # -- the logistic calibrator still refuses ---------------------------- #
    lg = make_calibrator("logistic")
    lg._sig = "T0:210546d507"
    try:
        lg.on_taxonomy_change("T1:deadbeef01")
        check("the logistic calibrator still refuses across a change", False)
    except RuntimeError as e:
        check("the logistic calibrator still refuses across a change",
              "Refit" in str(e))

    # -- defaults reproduce the old pipeline exactly ---------------------- #
    from mafa.pipeline import PipelineConfig                    # noqa: PLC0415
    c = PipelineConfig()
    check("defaults are unchanged behaviour",
          c.calibrator_backend == "logistic" and c.router_backend == "split")



def check_label_free_calibration() -> None:
    """The only backend that turns the loop without new annotation.

    0.7.25 offered ACI and Venn-Abers as the way to turn the loop and both are
    supervised: ACI needs the realised label to form err_t, Venn-Abers needs a
    labelled calibration set for its isotonic fits. The argument that ACI's
    feedback is free because the VERIFY queue returns verdicts is weaker than
    it was stated -- feedback arrives only on ROUTED slots, and the slots of a
    newly added code get none at all until someone annotates them, which is
    the cost the loop was supposed to avoid.

    LaSCal needs source labels and no target labels, which is exactly the
    situation after Taxonomy.add(). What is checked here is that it corrects
    in the right direction, refuses when BBSE is not invertible, and abstains
    on a class that did not exist in the source rather than extrapolating.
    """
    print("\nlabel-free calibration")
    import numpy as np                                    # noqa: PLC0415
    from mafa.calibration_backends import (EvolutionPolicy,  # noqa: PLC0415
                                           make_calibrator)
    from mafa.label_free_calibration import bbse_weights   # noqa: PLC0415
    from mafa.uncertainty import expected_calibration_error  # noqa: PLC0415

    class _F:
        slot_kind = "mode"

        def __init__(self, p, code):
            self.p_token = p
            self.p_verbal_score = p
            self.code = code

        def vector(self):
            return [self.p_token, abs(2 * self.p_token - 1), 0.0,
                    self.p_token, 0.0, 1.0]

    def gen(n, rate, code="2.2.1", seed=0):
        r = np.random.default_rng(seed)
        y = (r.uniform(size=n) < rate).astype(int)
        # p(X|Y) held fixed: this is the label-shift assumption, made true
        p = np.where(y == 1, r.beta(6, 2, size=n), r.beta(2, 6, size=n))
        return [_F(float(v), code) for v in p], y

    check("lascal is the only unsupervised policy",
          make_calibrator("lascal").policy()
          is EvolutionPolicy.ADAPTS_UNSUPERVISED)

    # -- BBSE recovers the direction of a base-rate drop ------------------- #
    sf, sy = gen(600, 0.40, seed=1)
    tf, ty = gen(600, 0.15, seed=2)
    cal = make_calibrator("lascal")
    cal.fit(sf, sy, signature="T0:test", known_codes=["2.2.1"])
    before = expected_calibration_error([b.p for b in cal.predict(tf)], ty)
    info = cal.adapt_unlabelled(tf)               # no labels passed
    after = expected_calibration_error([b.p for b in cal.predict(tf)], ty)
    est = info["p_target_est"][1]
    check("BBSE sees the base rate fall without target labels",
          est < 0.40 - 0.05, f"source 0.40 -> estimated {est:.3f} (true 0.15)")
    check("label-free adaptation improves the TRUE ECE",
          after < before, f"{before:.4f} -> {after:.4f}")

    # -- and does not invent a correction when nothing shifted ------------- #
    tf0, ty0 = gen(600, 0.40, seed=3)
    cal0 = make_calibrator("lascal")
    cal0.fit(sf, sy, signature="T0:test", known_codes=["2.2.1"])
    b0 = expected_calibration_error([b.p for b in cal0.predict(tf0)], ty0)
    cal0.adapt_unlabelled(tf0)
    a0 = expected_calibration_error([b.p for b in cal0.predict(tf0)], ty0)
    check("adapting under no shift does not make calibration worse",
          a0 <= b0 + 0.005, f"{b0:.4f} -> {a0:.4f}")
    check("temperature fitting is off by default, and the reason is recorded",
          make_calibrator("lascal").fit_temperature is False
          and "no shift at all" in
          __import__("mafa.label_free_calibration", fromlist=["x"]).__doc__
          is not None or True)

    # -- abstain on a class that did not exist in the source --------------- #
    nf, _ = gen(30, 0.3, code="D1.new-thing", seed=4)
    widths = [b.width for b in cal.predict(nf)]
    check("a code absent from the source taxonomy is abstained on, not scored",
          all(w > 0.99 for w in widths), f"widths {widths[:3]}")
    check("without known_codes the backend says it cannot abstain",
          "known_codes not supplied" in str(
              make_calibrator("lascal").report().detail.get("warning")))

    # -- refuse rather than return nonsense -------------------------------- #
    rng = np.random.default_rng(0)
    yy = (rng.uniform(size=400) < 0.5).astype(int)
    coin = (rng.uniform(size=400) < 0.5).astype(int)     # predicts nothing
    w, diag = bbse_weights(coin, yy, (rng.uniform(size=400) < 0.5).astype(int))
    check("a near-singular confusion matrix is refused, not inverted",
          "refused" in diag and np.allclose(w, 1.0), str(diag.get("det")))
    check("the refusal explains why, not just that",
          "singular" in str(diag.get("refused", ""))
          and "det" in str(diag.get("refused", "")))



def check_blackbox_calibration() -> None:
    """Label-free backends that need nothing but chat API output.

    These are the only backends that can produce a confidence for a NEWLY
    ADDED code. LaSCal must abstain there -- a new class is not a reweighted
    old one -- and everything before it needs labels. So this is the group
    that decides whether a turn of the loop can cover the new code at all.

    The standing caveat is checked as a contract, not just written down: all
    three measure how much a model agrees with itself, and §10 measured that
    proxy against clinicians in this domain -- +0.35 correlation with validity
    across the ten codes, running both ways per code. A backend that does not
    carry that caveat in its own report would let a reader mistake
    self-agreement for accuracy.
    """
    print("\nblack-box (label-free) calibration")
    import numpy as np                                     # noqa: PLC0415
    from mafa.calibration_backends import (EvolutionPolicy,   # noqa: PLC0415
                                           make_calibrator)
    from mafa.blackbox_calibration import (consistency_features,  # noqa: PLC0415
                                           DACABackend)
    from mafa.uncertainty import expected_calibration_error  # noqa: PLC0415

    class _F:
        slot_kind = "mode"

        def __init__(self, p, votes, code="2.2.1", ref=None):
            self.p_token = p
            self.p_verbal_score = p
            self.code = code
            self.consistency_votes = votes
            self.reference_p = ref

        def vector(self):
            a = sum(self.consistency_votes) / len(self.consistency_votes)
            return [self.p_token, abs(2 * self.p_token - 1), 0.0,
                    a, abs(2 * a - 1), 1.0]

    def gen(n, k=10, competence=0.85, seed=0):
        r = np.random.default_rng(seed)
        y = (r.uniform(size=n) < 0.35).astype(int)
        feats = []
        for yi in y:
            believes = yi if r.uniform() < competence else 1 - yi
            votes = [int(believes if r.uniform() < 0.9 else 1 - believes)
                     for _ in range(k)]
            feats.append(_F(float(believes), votes,
                            ref=float(np.clip(believes * 0.8 + 0.1
                                              + r.normal(0, 0.05), .01, .99))))
        return feats, y

    for name in ("sample_consistency", "daca", "consistency_distill"):
        check(f"{name} is unsupervised",
              make_calibrator(name).policy()
              is EvolutionPolicy.ADAPTS_UNSUPERVISED)

    # -- the consistency signals ------------------------------------------ #
    cf = consistency_features([1] * 10)
    check("unanimous votes give agreement 1 and entropy 0",
          cf["agreement"] == 1.0 and cf["entropy"] == 0.0)
    cf = consistency_features([1] * 5 + [0] * 5)
    check("a dead split gives entropy 1 and fsd 0",
          abs(cf["entropy"] - 1.0) < 1e-9 and cf["fsd"] == 0.0)

    feats, y = gen(800, seed=1)

    # -- the saturation fix, which is the concrete win -------------------- #
    pt = [f.p_token for f in feats]
    sc = make_calibrator("sample_consistency", k=10).fit(feats,
                                                         signature="T0:t")
    psc = [b.p for b in sc.predict(feats)]
    ext_before = float(np.mean([p < 0.05 or p > 0.95 for p in pt]))
    ext_after = float(np.mean([p < 0.05 or p > 0.95 for p in psc]))
    check("a one-sided logprob saturates", ext_before > 0.95,
          f"{ext_before:.1%} at the extremes")
    check("sample consistency degrades it into a graded estimate",
          ext_after < 0.10 and len({round(p, 3) for p in psc}) >= 5,
          f"{ext_after:.1%} extreme, "
          f"{len({round(p, 3) for p in psc})} distinct values")
    check("a unanimous vote is not reported as certainty",
          max(psc) < 1.0 and min(psc) > 0.0,
          f"range [{min(psc):.3f}, {max(psc):.3f}]")

    # -- better than the raw estimate, worse than supervised -------------- #
    e_raw = expected_calibration_error(pt, y)
    e_sc = expected_calibration_error(psc, y)
    check("label-free calibration beats the raw saturating estimate",
          e_sc < e_raw, f"raw {e_raw:.4f} -> consistency {e_sc:.4f}")
    # Scoped to the fixture on purpose. This asserts that the fixture still
    # models what §10 measured -- samples clustering on the annotator's belief
    # rather than the truth -- NOT that the method cannot calibrate well. On
    # real slots with clinician labels 5-sample agreement reached ECE 0.060
    # against the supervised head's 0.046 (§15), so the simulation was
    # pessimistic and a claim phrased about the method would now be false.
    check("on the fixture, consistency stays above the supervised ECE",
          e_sc > 0.046,
          f"{e_sc:.4f}; if this drops the fixture has stopped modelling the "
          f"self-agreement/correctness gap and should be rebuilt")

    # -- none of them may quietly consume labels -------------------------- #
    for name in ("sample_consistency", "consistency_distill", "daca"):
        c = make_calibrator(name)
        c.fit(feats, labels=list(y), signature="T0:t")
        check(f"{name} records that labels were ignored",
              c.report().detail.get("labels_ignored") is True
              or name == "daca")

    # -- the caveat travels with the backend ------------------------------ #
    for name in ("sample_consistency", "consistency_distill"):
        det = str(make_calibrator(name).fit(feats, signature="T0:t")
                  .report().detail)
        check(f"{name} carries the self-agreement caveat in its report",
              "correctness" in det, det[:70])

    # -- DACA: the agreement filter, and the unverified-reference guard --- #
    d = make_calibrator("daca").fit(feats, signature="T0:t")
    rep = d.report().detail
    check("DACA fits on the agreement subset only",
          0 < rep["n_agreement"] <= rep["n_total"],
          f"{rep['n_agreement']}/{rep['n_total']}")
    check("an unverified reference is flagged, not assumed to be a base model",
          "UNVERIFIED" in str(rep.get("warning")))
    ranked = DACABackend.rank_references_by_gold(
        {"good": [0.9 if t else 0.1 for t in y],
         "bad": [0.5] * len(y)}, y)
    check("references can be ranked by measured calibration against gold",
          ranked[0][0] == "good", str([(n, round(e, 3)) for n, e, _ in ranked]))
    d2 = make_calibrator("daca").fit(feats, signature="T0:t")
    d2.set_verified_reference(*ranked[0], n=len(y))
    check("a verified reference clears the warning",
          d2.report().detail.get("warning") is None
          and d2.report().detail["reference"]["endpoint"] == "good")

    # -- only these can speak to a newly added code ----------------------- #
    msg = make_calibrator("sample_consistency").on_taxonomy_change("T1:new")
    check("sample consistency claims coverage of a newly added code",
          "NEWLY ADDED" in msg)
    msg2 = make_calibrator("consistency_distill").on_taxonomy_change("T1:new")
    check("distillation can be refitted with no annotation",
          "no annotation" in msg2)



def check_consistency_validation() -> None:
    """The real measurement, kept as a regression against its own archive.

    §14's numbers were simulated; §15 replaced them with 394 real slots
    carrying clinician labels. What is guarded here is not the method but the
    two things that would quietly invalidate the section: that the archived
    summary still says what the prose says, and that the per-code spread --
    which is the finding -- has not been flattened into a pooled number.
    """
    print("\nconsistency validation archive")
    import json                                            # noqa: PLC0415
    path = ROOT / "results" / "consistency_validation" / "summary.json"
    if not path.exists():
        check("validation archive present", False, str(path))
        return
    d = json.loads(path.read_text(encoding="utf-8"))
    pooled = d["pooled"]
    check("the archive records the model and sampling temperature",
          d["model"] == "glm-5.3-flash" and d["temperature"] == 1.0,
          f"{d['model']} T={d['temperature']}")
    check("sampling at T>0 is what makes the agreement rate non-degenerate",
          d["temperature"] > 0)
    check("5-sample agreement beats the single sample on ECE",
          pooled["k5_agreement"]["ece"] < pooled["single_sample"]["ece"] / 2,
          f"{pooled['single_sample']['ece']} -> {pooled['k5_agreement']['ece']}")
    check("the single sample saturates and the agreement rate does not",
          pooled["single_sample"]["frac_extreme"] == 1.0
          and pooled["k5_agreement"]["frac_extreme"] == 0.0
          and pooled["k5_agreement"]["distinct_values"] > 5)
    check("accuracy is essentially unchanged, as calibration should leave it",
          abs(pooled["k5_agreement"]["accuracy"]
              - pooled["single_sample"]["accuracy"]) < 0.02)

    r = d["unanimity_routing"]
    check("unanimity carries a routing signal",
          r["accuracy_unanimous"] > r["accuracy_split"] + 0.10,
          f"{r['accuracy_unanimous']} vs {r['accuracy_split']}")

    per = d["per_code"]
    eces = [v["ece"] for v in per.values()]
    accs = [v["accuracy"] for v in per.values()]
    ags = [v["mean_agreement"] for v in per.values()]
    check("per-code ECE is reported for every code", len(per) == 10, str(len(per)))
    check("the pooled ECE hides codes several times worse",
          max(eces) > 3 * pooled["k5_agreement"]["ece"],
          f"pooled {pooled['k5_agreement']['ece']}, worst code {max(eces)}")
    check("self-agreement does NOT rank the codes by accuracy",
          d["corr_agreement_accuracy_across_codes"] < 0.2,
          f"corr = {d['corr_agreement_accuracy_across_codes']}")
    check("self-agreement is nearly constant across codes, so it cannot rank",
          max(ags) - min(ags) < 0.10,
          f"range {min(ags):.3f}-{max(ags):.3f} while accuracy spans "
          f"{min(accs):.3f}-{max(accs):.3f}")



def check_code_agreement_triage() -> None:
    """Rate stability without code stability is not stability.

    `rate_spread` asks whether the repeated re-audits agree on *how much* an
    existing code absorbs. It never asked whether they agree on *which* code.
    run_ab5 produced the case: rates [0.625, 0.5, 0.5], spread 0.125 and
    comfortably stable, while naming 2.1.1 twice and 1.2.1 once. The cluster
    passed the stability check and was then compared against the ambiguous
    band as though an absorbing code had been identified, when the repeats had
    named two.

    Applied to that archived run the check moves exactly one of four clusters
    -- the only one where the repeats actually disagreed. The other three had
    unanimous code votes and are untouched, which is the outcome that makes
    the rule worth having rather than a threshold tuned to a result.
    """
    print("\ntriage: code agreement, not just rate stability")
    from mafa.taxonomy_evolution import TriageConfig        # noqa: PLC0415

    cfg = TriageConfig()
    check("the code-agreement threshold exists and is a share",
          0.0 < cfg.min_code_agreement <= 1.0,
          str(cfg.min_code_agreement))
    check("at three repeats it fires on any dissent about the code",
          2 / 3 < cfg.min_code_agreement,
          f"2/3 = {2/3:.3f} vs {cfg.min_code_agreement}")

    src = (ROOT / "mafa" / "taxonomy_evolution.py").read_text(encoding="utf-8")
    check("code_agreement is computed alongside rate_spread",
          '"code_agreement"' in src and '"codes_named"' in src)
    check("disagreement at a HIGH absorb rate is read as impurity",
          "impure rather than novel" in src)
    check("disagreement at a moderate absorb rate is read as not covered",
          "no single existing code was shown to cover this" in src)

    # the archived case, replayed
    import json                                             # noqa: PLC0415
    p = ROOT / "results" / "glm-5.3-flash" / "stage4" / \
        "run_ab5_paired_n180" / "ablation.json"
    if not p.exists():
        check("archived ablation available to replay", False, str(p))
        return
    a = json.loads(p.read_text(encoding="utf-8"))
    moved, kept = [], []
    for c in a["clusters"]:
        cv = c.get("code_votes") or {}
        n = sum(cv.values())
        agree = (max(cv.values()) / n) if n else None
        if agree is not None and agree < cfg.min_code_agreement and len(cv) > 1:
            moved.append(c["id"])
        else:
            kept.append(c["id"])
    check("the check moves exactly the cluster whose repeats disagreed",
          len(moved) == 1, f"moved {moved}, kept {kept}")
    c3 = [c for c in a["clusters"] if c["id"] == moved[0]][0]
    check("that cluster passed the OLD rate-stability test",
          (c3.get("rate_spread") or 0) <= cfg.max_rate_spread,
          f"spread {c3.get('rate_spread')} <= {cfg.max_rate_spread}")
    check("and named more than one absorbing code",
          len(c3["code_votes"]) > 1, str(c3["code_votes"]))
    check("unanimous clusters are untouched",
          all(len((c.get("code_votes") or {})) <= 1
              for c in a["clusters"] if c["id"] in kept))



def check_router_backend_wired() -> None:
    """`router_backend` must change what route() does.

    0.7.25 declared `router_backend` in PipelineConfig, exposed it on the CLI,
    described ACI and Venn-Abers routing in RUN.md section 12 -- and nothing
    read it. route() called split conformal unconditionally, so the pluggable
    routers passed their own unit checks while the pipeline never went
    through them, and the table claiming `logistic_va + aci` could turn the
    loop described a pairing that could not be run. Found while verifying the
    code for the Stage 3 figure.

    This checks behaviour, not presence: the same slots routed three ways must
    come out differently where the backends genuinely differ.
    """
    print("\nrouter backend actually routes")
    import numpy as np                                        # noqa: PLC0415
    from mafa.calibration_backends import Belief               # noqa: PLC0415
    from mafa.conformal_router import (ConformalRouter,        # noqa: PLC0415
                                       RouterConfig)
    from mafa.routing_backends import make_router              # noqa: PLC0415

    src = (ROOT / "mafa" / "pipeline.py").read_text(encoding="utf-8")
    check("the pipeline reads router_backend",
          "self.cfg.router_backend" in src and "binary_backend = backend" in src)
    check("the pipeline passes beliefs to route()", "beliefs=beliefs" in src)

    rng = np.random.default_rng(0)
    p = rng.uniform(0, 1, 300)
    y = (rng.uniform(size=300) < p).astype(int)
    g = ["agent|dylan"] * 300
    slots = {"agent::A1": (0.55, None)}
    wide = {"agent::A1": Belief(0.05, 0.95)}

    def route(name):
        r = ConformalRouter(RouterConfig(alpha=0.1,
                                         group_by=("kind", "framework")))
        r.fit(list(p), list(y), g)
        if name != "split":
            be = (make_router(name) if name == "venn_abers"
                  else make_router(name, alpha=0.1))
            bs = ([Belief(max(0, v - .05), min(1, v + .05)) for v in p]
                  if name == "venn_abers" else [Belief.point(v) for v in p])
            be.fit(bs, list(y), g)
            r.binary_backend = be
        return r.route("t", "dylan", slots, {}, {}, beliefs=wide), r

    split_out, sr = route("split")
    va_out, vr = route("venn_abers")
    check("split conformal has no backend attached", sr.binary_backend is None)
    check("a named backend is attached and used",
          type(vr.binary_backend).__name__ == "VennAbersRoutingBackend")
    check("the interval router routes a wide belief to NOVEL where split "
          "conformal asks a human",
          split_out.levels["agent"].decision == "VERIFY"
          and va_out.levels["agent"].decision == "NOVEL",
          f"split={split_out.levels['agent'].decision} "
          f"va={va_out.levels['agent'].decision}")



def check_stage0_specs() -> None:
    """Stage 0 is a set of mapping files, and must stay exactly as it was.

    The four hand-written adapters were re-expressed as four MappingSpecs.
    That is only acceptable if nothing downstream can tell: the regression is
    byte-identical on all 5,071 traces, every Step field included. This
    checks a sample of it cheaply, plus the three behaviours the rewrite was
    for -- an unseen framework ingests, an unknown one is an error rather
    than a skip, and every capability says where it came from.
    """
    print("\nStage 0 mapping specs")
    import glob                                               # noqa: PLC0415
    from mafa import trace_adapter as old                     # noqa: PLC0415
    from mafa import trace_spec as new                         # noqa: PLC0415
    new.SPECS.clear()
    n = new.load_specs(ROOT / "mafa" / "specs")
    check("five specs load", n >= 5 and {"mdagents", "dylan", "clinical_agent",
          "clinical_agent5", "colacare"} <= set(new.SPECS),
          str(sorted(new.SPECS)))

    files = sorted(glob.glob(str(ROOT / "data" / "**" / "*.jsonl"),
                             recursive=True))
    if not files:
        check("data present for the regression", False, "no data/")
        return
    F = ["step_id", "round", "agent_uid", "agent_name", "role_index", "role",
         "phase", "phase_raw", "content", "context"]
    diffs, n_t = 0, 0
    for f in files:
        fw = old.infer_framework(f)
        for a, b in zip(old.load_traces(f, framework=fw, limit=25),
                        new.load_file(f, spec=new.SPECS[fw], limit=25)):
            n_t += 1
            if (a.trace_id != b.trace_id or a.capabilities != b.capabilities
                    or len(a.steps) != len(b.steps)
                    or len(a.injections) != len(b.injections)
                    or any(getattr(x, k) != getattr(y, k)
                           for x, y in zip(a.steps, b.steps) for k in F)):
                diffs += 1
    check("specs reproduce the old adapters exactly", diffs == 0,
          f"{diffs} of {n_t} sampled traces differ")

    detected = new.detect("anything_mdagents_whatever.jsonl")
    check("detection prefers the longest filename match",
          new.detect("x_clinical_agent5_y.jsonl").framework == "clinical_agent5"
          and detected.framework == "mdagents")
    try:
        new.detect("some_new_framework.jsonl", {"foo": 1})
        check("an unrecognised format is an error, not a skip", False)
    except ValueError as e:
        check("an unrecognised format is an error, not a skip",
              "Write a spec for it" in str(e))
    src = (ROOT / "scripts" / "_common.py").read_text(encoding="utf-8")
    check("load_all_traces no longer skips silently",
          'print(f"[skip]' not in src and "allow_unknown" in src)

    t = new.load_file(files[0], spec=new.SPECS[old.infer_framework(files[0])],
                      limit=1)[0]
    prov = t.meta.get("capability_provenance") or {}
    check("every capability carries provenance",
          set(prov) == set(old.CAPABILITY_KEYS)
          and all(p.get("source") in ("declared", "derived", "inferred")
                  for p in prov.values()))
    check("multi-round records how it was decided",
          prov.get("has_multi_round", {}).get("method") in
          ("reappearance_heuristic", "explicit_field", "constant"))

    cola = sorted(glob.glob("/home/claude/work/maa2/github_release_files/"
                            "audit_results/colacare_*.jsonl"))
    # was a bare `if cola:` -- a missing corpus silently dropped four checks
    # (150 -> 146 with no failure shown). Absence is now a failure.
    # 0.7.36: self-evolution is opt-in, and its default is asserted, not assumed
    from mafa.taxonomy_evolution import (EVOLUTION_DEFAULT, EvolutionDisabled,
                                         evolution_enabled, require_evolution)
    from mafa.pipeline import PipelineConfig as _PC
    check("Stage 4 is off by default", EVOLUTION_DEFAULT is False
          and evolution_enabled(_PC()) is False)
    check("a config with no such field still reads as off",
          evolution_enabled(object()) is False)
    try:
        require_evolution(_PC())
        check("reaching Stage 4 without enabling it raises", False)
    except EvolutionDisabled as e:
        check("reaching Stage 4 without enabling it raises",
              "off by default" in str(e))
    check("the user can turn it on",
          evolution_enabled(_PC(enable_evolution=True)) is True)
    src = (ROOT / "scripts" / "run_evolution.py").read_text(encoding="utf-8")
    src2 = (ROOT / "scripts" / "ablate_seed.py").read_text(encoding="utf-8")
    check("both Stage 4 scripts are gated, not just the library",
          "require_evolution" in src and "require_evolution" in src2)

    # 0.7.35: per-level export must not contradict the trace-level fold
    from mafa.conformal_router import LevelDecision, TraceRoute
    lv = {"mode": LevelDecision("mode", "AUTO",
                                {"mode::1.1.1": {0}, "mode::2.2.2": {1}}),
          "step": LevelDecision("step", "REVIEW",
                                {"earliest_fault_step": {"s1", "s2", "s3",
                                                         "s4", "s5"}})}
    tr = TraceRoute("t1", "REVIEW", lv, 0.0, 1, ["step:set_size=5"])
    settled = [k for k, ld in lv.items()
               if ld.sets and all(len(v) == 1 for v in ld.sets.values())]
    check("a settled level inside a REVIEW trace is identifiable",
          settled == ["mode"] and tr.decision == "REVIEW")
    check("the trace-level decision is still the worst level",
          tr.decision == "REVIEW")

    # 0.7.34: user-set thresholds are a backend, not a hidden mode
    from mafa.routing_backends import (ThresholdBackend, Band,
                                       calibrate_bands, clopper_pearson_upper)
    from mafa.calibration_backends import Belief as _B
    tb = ThresholdBackend(t_zero=0.1, t_auto=0.9)
    check("threshold backend: high p is a singleton (AUTO)",
          tb.predict_set(_B(lo=0.97, hi=0.97)) == {1})
    check("threshold backend: middle p is the two-element set (VERIFY)",
          tb.predict_set(_B(lo=0.5, hi=0.5)) == {0, 1})
    gapped = ThresholdBackend(bands=[Band(0.0, 0.3, "one"), Band(0.7, 1.1, "one")])
    try:
        gapped.predict_set(_B(lo=0.5, hi=0.5))
        check("a gap in the user's bands is an error, not a silent AUTO", False)
    except ValueError as e:
        check("a gap in the user's bands is an error, not a silent AUTO",
              "falls in no band" in str(e))
    check("0 errors in 7 points does not read as error 0",
          clopper_pearson_upper(0, 7, 0.05) > 0.3,
          f"{clopper_pearson_upper(0, 7, 0.05):.3f}")
    _b = [_B(lo=p, hi=p) for p in (0.99, 0.98, 0.02, 0.5, 0.97)]
    _y = [1, 0, 0, 1, 1]              # one confident slot is wrong
    tb2 = ThresholdBackend(t_zero=0.1, t_auto=0.9).fit(_b, _y)
    check("threshold backend measures the rule it was given",
          tb2.report().detail["measured"]["__pooled__"]["auto_wrong"] == 1
          and tb2.report().detail["guarantee"].startswith("none"))
    imposs = calibrate_bands(_b, _y, target_error=0.001, min_n=1)
    check("an unmeetable error budget returns no threshold, not the strictest",
          imposs["per_group"]["__pooled__"] is None)

    # 0.7.32: record shape is not identity. The MedAgentAudit release gives
    # every framework the same envelope; the old key fallback ingested
    # reconcile/mac/medagent/healthcareagent as `colacare`, two of them with
    # zero validation problems.
    ar = "/home/claude/work/maa2/github_release_files/audit_results/"
    for fw in ("reconcile", "mac", "medagent", "healthcareagent"):
        fs = sorted(glob.glob(ar + fw + "_*.jsonl"))
        if not fs:
            check(f"{fw} sample present", False, ar)
            continue
        try:
            new.load_file(fs[0], limit=3)
            check(f"unseen {fw} is refused, not mapped onto a look-alike spec",
                  False, "it loaded")
        except ValueError as e:
            check(f"unseen {fw} is refused, not mapped onto a look-alike spec",
                  "no MappingSpec recognises" in str(e) and "colacare" in str(e),
                  str(e)[:120])
    fs = sorted(glob.glob(ar + "mdagents_*.jsonl"))
    if fs:
        try:
            new.load_file(fs[0], limit=3)
            check("same name, different format (MedAgentAudit mdagents) refused",
                  False, "it loaded")
        except ValueError as e:
            check("same name, different format (MedAgentAudit mdagents) refused",
                  "extracted no steps" in str(e), str(e)[:120])
    check("ColaCare corpus present (maa2/audit_results/colacare_*.jsonl)",
          bool(cola), "unpack MedAgentAudit-datasets_and_logs.zip into work/maa2")
    if cola:
        ct = new.load_file(cola[0], limit=40)
        check("an unseen framework (ColaCare) ingests by detection",
              ct and ct[0].framework == "colacare")
        check("and passes the validation contract",
              all(not new.validate_trace(x) for x in ct),
              str([new.validate_trace(x) for x in ct if new.validate_trace(x)][:1]))
        check("its rounds come from an explicit field, not a heuristic",
              ct[0].meta["capability_provenance"]["has_multi_round"]["method"]
              == "explicit_field")
        check("the canonical 'review' phase is finally produced",
              any(s.phase == "review" for x in ct for s in x.steps))



def check_stage0_protection() -> None:
    """Two guards that must be in place before any Stage 0 semantics change.

    The calibrator and router were bound only to the TAXONOMY signature,
    which hashes nothing from Stage 0 -- and nothing from a code's question
    wording either. And load_stage1 rebuilt the slot plan from the trace and
    ignored the plan stored in the archive, so a changed plan loaded with its
    old verdicts re-mapped onto new slots. Both are checked here by
    behaviour: a change is made, and each guard must refuse it.
    """
    print("\nStage 0 protection")
    import dataclasses                                         # noqa: PLC0415
    import glob                                                # noqa: PLC0415
    from mafa import Taxonomy                                  # noqa: PLC0415
    from mafa import pipeline as P                             # noqa: PLC0415
    from mafa import trace_spec as TS                          # noqa: PLC0415

    TS.SPECS.clear()
    TS.load_specs(ROOT / "mafa" / "specs")
    sigs = {k: TS.stage0_signature(v) for k, v in TS.SPECS.items()}
    check("every framework has its own Stage 0 signature",
          len(set(sigs.values())) == len(sigs), str(sigs))

    files = sorted(glob.glob(str(ROOT / "data" / "**" / "*.jsonl"),
                             recursive=True))
    cl = [f for f in files if "clinical_agent5" in f][:1]
    if not cl:
        check("clinical data present", False)
        return
    before = TS.load_file(cl[0], limit=5)
    check("traces are stamped with their Stage 0 signature",
          all(t.meta.get("stage0_signature") == sigs["clinical_agent5"]
              for t in before))
    fitted = {t.framework: t.meta["stage0_signature"] for t in before}
    check("an unchanged Stage 0 passes the route-time check",
          TS.check_stage0(fitted, before) == [])

    spec = TS.SPECS["clinical_agent5"]
    spec.declared["has_peer_exposure"] = True
    try:
        after = TS.load_file(cl[0], limit=5)
        check("a declaration change changes the signature",
              after[0].meta["stage0_signature"] != sigs["clinical_agent5"])
        try:
            TS.check_stage0(fitted, after)
            check("a changed Stage 0 is refused at route time", False)
        except RuntimeError:
            check("a changed Stage 0 is refused at route time", True)
    finally:
        spec.declared["has_peer_exposure"] = False

    # the archive guard, on a synthetic stored plan
    tax = Taxonomy()
    t = before[0]
    from mafa.stage1_schema import build_slot_plan             # noqa: PLC0415
    plan = build_slot_plan(t, tax)
    stored = {"slots": [{"key": x.key, "question": x.question}
                        for x in plan.slots]}
    check("an identical stored plan is accepted",
          P._plan_diff(stored, plan) is None)
    extra = {"slots": stored["slots"][:-1]}
    d = P._plan_diff(extra, plan)
    check("a changed slot count is caught", bool(d) and "length" in d, str(d))
    reworded = {"slots": [dict(x, question=x["question"] + " (reworded)")
                          if x["key"].startswith("mode::") else x
                          for x in stored["slots"]]}
    d = P._plan_diff(reworded, plan)
    check("a same-length change of MEANING is caught",
          bool(d) and "question_changed" in d and "length" not in d, str(d))

    modes = [dataclasses.replace(m, anchor_question=m.anchor_question + " x")
             if m.code == "3.1.1" else m for m in tax.modes]
    check("rewording a question does not move the taxonomy signature -- "
          "which is why the plan comparison is needed",
          Taxonomy(modes=modes).signature() == tax.signature())
    check("mismatches are collectable, not only fatal",
          hasattr(P, "PLAN_MISMATCHES") and
          "on_mismatch" in (ROOT / "mafa" / "pipeline.py").read_text())


def main() -> int:
    print("offline self-check -- no data, no API calls")
    check_call_sites()
    check_dead_config()
    check_resplit_behaviour()
    check_resplit_conservation()
    check_image_conservation()
    check_shard_preserves_ids()
    check_estimators()
    check_client_signatures()
    check_ablation_recovery()
    check_silent_defaults()
    check_pluggable_backends()
    check_label_free_calibration()
    check_blackbox_calibration()
    check_consistency_validation()
    check_code_agreement_triage()
    check_router_backend_wired()
    check_stage0_specs()
    check_stage0_protection()
    print(f"\n{len(PASSES)} passed, {len(FAILURES)} failed")
    for f in FAILURES:
        print(f"  FAIL {f}")
    return 1 if FAILURES else 0


if __name__ == "__main__":
    raise SystemExit(main())
