#!/usr/bin/env python3
"""Hold codes out of the taxonomy and see whether the evolution loop finds them.

    python scripts/ablate_seed.py --data data --work run_ab5 \\
        --seed 1.2.1,2.1.1,2.2.2,3.1.2,3.1.3 \\
        --judge-backend anthropic --judge-model claude-opus-5

Why this exists
---------------
Run with the full ten-code taxonomy, Stage 4 absorbed every cluster and admitted
nothing. That is the right outcome — there was nothing new to find — but it
leaves the loop demonstrated only in its refusal. Holding codes out creates a
case where something genuinely *should* be discovered, and turns "can it
evolve" into a number: of k codes removed, how many come back.

Three things have to hold or the experiment measures nothing
------------------------------------------------------------
1. **The unmasked re-audit sees only the seed.** It is the step that decides
   whether a cluster is already covered; hand it the full taxonomy and the
   held-out codes absorb their own rediscovery on the spot. This script builds
   the reduced taxonomy once and uses it everywhere, including there.

2. **Matching is semantic, never by name.** A rediscovered code will be called
   something else -- "repeated the same opinion without adding anything" rather
   than "2.2.1 Repetition of initial views". Recovery is scored by embedding
   proximity to the held-out definition and, separately, by an independent
   judge asked whether the two describe the same failure. Both are reported;
   they disagree often enough to be worth seeing. Every cluster that reaches
   triage B is scored, admitted or not: scoring the admitted only puts the
   gate in the numerator, so a rediscovery that fails G1 was recorded as a
   discovery failure. Admission is reported alongside, not instead.

3. **Hold out codes the corpus actually exhibits, and can exhibit.** Two
   separate conditions, and only the first was ever checked. *Can* is
   structural: `requires` is satisfied per trace from the capability vector, so
   a code needing `has_multi_round` is scoreable in dylan alone on this corpus,
   can never produce a cross-framework cluster, and is unrecoverable under
   `min_frameworks >= 2` before the run starts. The script now computes this
   and reports recovery against the *eligible* held-out codes.
   *Does* is empirical: pass ``--full-taxonomy-stage1`` pointing at the same
   traces annotated under the full taxonomy, and the base rate becomes a
   number instead of an assumption. Without it the run says so and the miss is
   uninterpretable. ``--suggest-holdout`` prints the observed counts.

   Every run in this project before 0.7.21 was subject to both gaps: the four
   held-out codes included two that are dylan-only, and no full-taxonomy
   annotation of the ablated traces existed anywhere. See RUN.md §8.

What it cannot settle
---------------------
The annotator has very likely seen MedAgentAudit and MAST in pretraining, so a
recovered code is not invented from nothing. What is being tested is whether
the *pipeline* surfaces a real, repeated failure that its current taxonomy
cannot express, and packages it well enough to survive the admission gate --
not whether the model could have derived it de novo. Say so when reporting.
"""
import argparse
import collections
import json
from pathlib import Path

from _common import (add_common, configs, load_all_traces, load_taxonomy,
                     make_client)
from _judge import build_judge
from mafa import (GateConfig, Taxonomy, TriageConfig, cluster_residuals,
                  code_centroids, collect_residuals, evaluate_gate,
                  make_embedder, suggest_distinctness_threshold,
                  triage_clusters)
from mafa.pipeline import load_stage1
from mafa.reaudit_llm import (make_distinctness, make_summarise,
                              make_unmasked_reaudit)

SAME_PROMPT = """\
Two descriptions of a failure in a medical multi-agent consultation are below.
They were written independently and use different words.

A  {a_name}
{a_def}

B  {b_name}
{b_def}

Would a domain expert say these describe the same failure? They do if an
annotator applying one would flag the same passages as an annotator applying
the other. Superficially similar wording is not enough, and different wording
for the same mechanism does not make them different.

Return JSON:
{{
  "same": true or false,
  "confidence": "low" | "medium" | "high",
  "reasoning": "one or two sentences",
  "distinguishing_case": "a transcript that one would flag and the other would not, if any"
}}
"""


def _eligibility(held, traces) -> dict:
    """For each held-out code, the frameworks whose structure could exhibit it.

    `requires` is checked against each trace's capability vector, exactly as
    `Taxonomy.applicable` does, so this is the same notion of scoreability
    Stage 1 uses when it builds the slot plan.
    """
    out = {}
    for m in held.modes:
        fws = collections.Counter(
            t.framework for t in traces
            if all(t.capabilities.get(r, False) for r in m.requires))
        out[m.code] = {"frameworks": sorted(fws),
                       "n_frameworks": len(fws),
                       "n_traces": sum(fws.values()),
                       "by_framework": dict(fws)}
    return out


def _base_rate(path, traces, full, held, anns_reduced):
    """Observed base rate of the held-out codes under the FULL taxonomy.

    Without this, "0 of k recovered" cannot be told apart from "those codes
    never fired on this corpus" -- the failure mode the module docstring names
    and that every run in the archive up to 0.7.20 was subject to, because no
    full-taxonomy annotation of the same traces existed.

    Returns per-code counts plus, for each (trace, agent, step) the full run
    labelled with a held-out code, what the reduced run did with it: relabelled
    under a kept code, proposed as a novel mode, or not flagged.
    """
    anns_full = load_stage1(path, traces, full)
    shared = sorted(set(anns_full) & set(anns_reduced))
    codes = {m.code for m in held.modes}
    counts: collections.Counter = collections.Counter()
    fate: dict = {c: collections.Counter() for c in codes}
    absorbed: dict = {c: collections.Counter() for c in codes}
    for tid in shared:
        fpos = {(f.agent_uid, f.step_id): f.code
                for f in anns_full[tid].findings}
        rpos = {(f.agent_uid, f.step_id): f.code
                for f in anns_reduced[tid].findings}
        rnov = {(n.agent_uid, n.step_id) for n in anns_reduced[tid].novel_modes}
        for key, code in fpos.items():
            if code not in codes:
                continue
            counts[code] += 1
            if key in rnov:
                fate[code]["proposed as novel"] += 1
            elif key in rpos:
                fate[code]["relabelled under a kept code"] += 1
                absorbed[code][rpos[key]] += 1
            else:
                fate[code]["not flagged at all"] += 1
    return {"n_paired": len(shared),
            "counts": dict(counts),
            "fate": {c: dict(v) for c, v in fate.items()},
            "absorbed_by": {c: dict(v) for c, v in absorbed.items()}}


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--seed", default="",
                    help="comma-separated codes to KEEP; the rest are held out")
    ap.add_argument("--suggest-holdout", action="store_true",
                    help="print observed code frequencies and exit")
    ap.add_argument("--judge-backend", default="openai",
                    choices=["openai", "anthropic"])
    ap.add_argument("--judge-model", default=None)
    ap.add_argument("--judge-key-env", default="ANTHROPIC_API_KEY")
    ap.add_argument("--judge-base-url", default=None)
    ap.add_argument("--embed-backend", default="openai")
    ap.add_argument("--embed-model", default="text-embedding-3-small")
    ap.add_argument("--embed-base-url", default=None,
                    help="embedding endpoint, when it differs from the "
                         "annotator's. deepseek serves no embeddings, so a "
                         "deepseek run must point this elsewhere or the whole "
                         "stage dies on a 404 after the annotations are done.")
    ap.add_argument("--embed-key-env", default="OPENAI_API_KEY")
    ap.add_argument("--min-cluster-size", type=int, default=6)
    ap.add_argument("--min-support", type=int, default=8)
    ap.add_argument("--min-framework-fraction", type=float, default=0.0,
                    help="cap the framework requirement at this share of the "
                         "frameworks that could exhibit the failure at all; "
                         "0 disables")
    ap.add_argument("--ignore-framework-eligibility", action="store_true",
                    help="count frameworks against the whole corpus rather "
                         "than against the ones whose structure permits the "
                         "failure. A recruitment-stage failure can only ever "
                         "appear in a framework that recruits, so this makes "
                         "the requirement unsatisfiable for such codes.")
    ap.add_argument("--min-frameworks", type=int, default=1)
    ap.add_argument("--gates", default="G1,G2")
    ap.add_argument("--structural-reaudit", action="store_true",
                    help="filter the re-audit's candidate codes by "
                         "allowed_phases and requires. OFF by default: it "
                         "collapses the candidate set to one code for most "
                         "items, lowering absorb rates by framing alone. "
                         "See run_ab2/filter_arms.json.")
    ap.add_argument("--full-taxonomy-stage1", default=None,
                    help="stage1.jsonl for the SAME traces annotated under the "
                         "full taxonomy. Establishes the base rate of the "
                         "held-out codes, which is what tells '0 recovered' "
                         "apart from 'those codes never fired here'. Without "
                         "it the run proceeds and says so.")
    ap.add_argument("--enable-evolution", action="store_true",
                    help="Stage 4 grows the taxonomy, which changes the label "
                         "space and voids calibration done before it. Off by "
                         "default; this script does nothing without it.")
    a = ap.parse_args()
    from mafa.taxonomy_evolution import require_evolution
    require_evolution(a, what=__file__.split("/")[-1])

    traces = load_all_traces(a)
    full = load_taxonomy(a)
    work = Path(a.work)
    by = {t.trace_id: t for t in traces}

    # ---- frequency report ------------------------------------------------- #
    if a.suggest_holdout:
        src = work / "stage1.jsonl"
        if not src.exists():
            raise SystemExit(f"{src} not found; run Stage 1 with the full "
                             "taxonomy first so frequencies can be counted")
        anns = load_stage1(src, traces, full)
        cnt = collections.Counter(f.code for ann in anns.values()
                                  for f in ann.findings)
        print(f"[freq] over {len(anns)} traces\n")
        for m in full.modes:
            print(f"  {m.code}  {cnt.get(m.code, 0):4d}  {m.name}")
        print("\nHold out codes with enough support to be findable; removing a "
              "code that never fires measures the corpus, not the method.")
        return

    if not a.seed:
        raise SystemExit("give --seed with the codes to keep, or "
                         "--suggest-holdout to see the frequencies")
    keep = {c.strip() for c in a.seed.split(",") if c.strip()}
    unknown = keep - {m.code for m in full.modes}
    if unknown:
        raise SystemExit(f"unknown codes: {sorted(unknown)}")
    seed = full.subset(lambda m: m.code in keep)
    held = full.subset(lambda m: m.code not in keep)
    print(f"[ablate] seed {sorted(keep)}")
    print(f"[ablate] held out {[m.code for m in held.modes]}")
    print(f"[ablate] seed signature {seed.signature()}\n")

    # ---- can each held-out code even be recovered? ------------------------ #
    # Precondition 3 of the docstring, made into a number. A code whose
    # `requires` is satisfied in one framework only cannot produce a
    # cross-framework cluster, so with min_frameworks >= 2 it is unrecoverable
    # by construction and does not belong in the denominator. This is the
    # 0.7.10 lesson (G1 counts eligible frameworks, not corpus frameworks)
    # applied to the recovery metric, which never learned it.
    elig = _eligibility(held, traces)
    print("[ablate] held-out eligibility (structural, before any annotation)")
    for code, d in sorted(elig.items()):
        note = ""
        if d["n_frameworks"] < max(a.min_frameworks, 1):
            note = (f"  <== UNRECOVERABLE: needs {a.min_frameworks} "
                    f"frameworks, eligible in {d['n_frameworks']}")
        print(f"  {code}  eligible in {d['frameworks'] or '[]'} "
              f"({d['n_traces']} traces){note}")
    scorable = [m.code for m in held.modes
                if elig[m.code]["n_frameworks"] >= max(a.min_frameworks, 1)]
    unscorable = [m.code for m in held.modes if m.code not in scorable]
    if unscorable:
        print(f"[ablate] {len(unscorable)} held-out code(s) excluded from the "
              f"denominator as structurally unrecoverable: {unscorable}")
    print(f"[ablate] recovery will be reported out of {len(scorable)}, "
          f"not {len(held.modes)}\n")

    src = work / "stage1.jsonl"
    if not src.exists():
        raise SystemExit(
            f"{src} not found. Annotate with the REDUCED taxonomy first:\n"
            f"  python scripts/run_stage1.py --data {a.data} --work {a.work} "
            f"--taxonomy {work / 'seed_taxonomy.json'}\n"
            f"(seed taxonomy written to that path now)")
    seed.save(work / "seed_taxonomy.json")

    anns = load_stage1(src, traces, seed)
    print(f"[ablate] {len(anns)} annotations under the reduced taxonomy")

    residuals = collect_residuals(anns.values(), None, by)
    print(f"[ablate] residual pool {len(residuals)} items")
    if len(residuals) < a.min_cluster_size:
        raise SystemExit("too little residue to cluster; the seed may be too "
                         "large, or the corpus too small")

    embed = make_embedder(a.embed_backend, model=a.embed_model,
                          cache_path=str(work / "embeddings.jsonl"),
                          base_url=a.embed_base_url,
                          api_key_env=a.embed_key_env)
    clusters, noise = cluster_residuals(residuals, embed,
                                        min_cluster_size=a.min_cluster_size)
    print(f"[ablate] {len(clusters)} clusters, {len(noise)} noise")

    judge = build_judge(a, make_client, cache_path=work / "judge_cache.jsonl")
    tcfg = TriageConfig(sample_per_cluster=8,
                        reaudit_respects_structure=a.structural_reaudit)
    print(f"[ablate] re-audit respects allowed_phases/requires: "
          f"{tcfg.reaudit_respects_structure}")
    # NOTE the reduced taxonomy here: the re-audit must not see what was held out
    # embed= is not optional in practice: without it the resplit branch in
    # triage_clusters is unreachable and an unnameable cluster is routed to a
    # human exactly as it was before 0.7.13, with nothing saying why.
    clusters = triage_clusters(clusters, seed, make_summarise(judge),
                               make_unmasked_reaudit(judge, tcfg), tcfg,
                               embed=embed)
    for c in clusters:
        print(f"  cluster {c.cluster_id}: n={c.support} fw={c.n_frameworks} "
              f"-> {c.triage}  {c.name[:54]!r}")

    # ---- gate, still against the reduced taxonomy ------------------------- #
    sug = suggest_distinctness_threshold(embed, seed)
    cfg = GateConfig(enabled=tuple(g.strip() for g in a.gates.split(",")),
                     min_support=a.min_support,
                     min_frameworks=a.min_frameworks,
                     min_framework_fraction=a.min_framework_fraction,
                     max_centroid_cos=sug["suggested_max_centroid_cos"])
    caps = None if a.ignore_framework_eligibility else {
        t.framework: t.capabilities for t in traces}
    cent = code_centroids(embed, seed)
    admitted, candidates = [], []
    for c in clusters:
        if c.triage != "B":
            continue
        g = evaluate_gate(c, seed, cent, None, None,
                          make_distinctness(judge), cfg,
                          pool_size=len(residuals), framework_caps=caps)
        print(f"  gate {c.cluster_id}: {g.summary()}")
        # Recovery is scored over every cluster that reached B, not only the
        # admitted ones. Scoring admitted-only puts the gate in the numerator:
        # a cluster that rediscovers a held-out code and then fails G1 was
        # recorded as "not recovered", with nothing distinguishing a discovery
        # failure from a gate rejection. Admission is kept as a field.
        candidates.append((c, bool(g.passed), g.summary()))
        if g.passed:
            admitted.append(c)
    print(f"  {len(candidates)} cluster(s) at triage B, {len(admitted)} "
          f"admitted; recovery scored over all {len(candidates)}")

    # ---- did anything admitted match a held-out code? --------------------- #
    held_cent = code_centroids(embed, held)
    import numpy as np

    rows = []
    for c, passed, gate_summary in candidates:
        cos = {code: float(np.dot(c.centroid, v) /
                           (np.linalg.norm(c.centroid) * np.linalg.norm(v) + 1e-9))
               for code, v in held_cent.items()}
        nearest = max(cos, key=cos.get) if cos else None
        verdict = {}
        for code in sorted(cos, key=lambda k: -cos[k])[:3]:
            m = held.get(code)
            try:
                r = judge(SAME_PROMPT.format(
                    a_name=c.name, a_def=c.definition,
                    b_name=m.name, b_def=m.definition))
            except Exception as e:                        # noqa: BLE001
                r = {"same": None, "reasoning": str(e)[:120]}
            verdict[code] = {"same": r.get("same"),
                             "confidence": r.get("confidence"),
                             "why": str(r.get("reasoning") or "")[:220],
                             "cosine": round(cos[code], 4)}
        matched = [k for k, v in verdict.items()
                   if v["same"] and v["confidence"] in ("medium", "high")]
        rows.append({"cluster": c.cluster_id, "name": c.name,
                     "definition": c.definition, "support": c.support,
                     "frameworks": dict(c.frameworks),
                     "admitted": passed, "gate": gate_summary,
                     "nearest_held_out": nearest,
                     "nearest_cosine": round(cos.get(nearest, 0), 4),
                     "judge": verdict, "matched": matched})

    found = {code for r in rows for code in r["matched"]}
    found_admitted = {code for r in rows if r["admitted"]
                      for code in r["matched"]}
    # The denominator is the codes that could have been recovered, not every
    # code that was removed. A single-framework code under min_frameworks >= 2
    # is unrecoverable by construction and counting it inflates the miss.
    missed = [c for c in scorable if c not in found]
    novel_beyond = [r for r in rows if not r["matched"]]

    print("\n=== recovery")
    print(f"  held out                  {[m.code for m in held.modes]}")
    print(f"  scorable (eligible)       {scorable}")
    if unscorable:
        print(f"  excluded as unrecoverable {unscorable}")
    print(f"  clusters at triage B      {len(candidates)} "
          f"({len(admitted)} admitted)")
    print(f"  recovered                 {sorted(found)}  "
          f"({len(found)}/{len(scorable)})")
    print(f"    of which also admitted  {sorted(found_admitted)}  "
          f"({len(found_admitted)}/{len(scorable)})")
    print(f"  not recovered             {missed}")
    print(f"  B clusters matching none  {len(novel_beyond)}")
    if found - found_admitted:
        print(f"  NOTE recovered but blocked by the gate: "
              f"{sorted(found - found_admitted)} -- a discovery success and a "
              f"gate rejection, which the old admitted-only metric reported "
              f"as a discovery failure")
    for r in rows:
        tag = "admitted" if r["admitted"] else "NOT admitted"
        print(f"\n  {r['name']!r}  n={r['support']}  [{tag}]")
        if not r["admitted"]:
            print(f"    gate: {r['gate']}")
        print(f"    closest held-out: {r['nearest_held_out']} "
              f"(cosine {r['nearest_cosine']})")
        for code, v in r["judge"].items():
            print(f"    vs {code}: same={v['same']} ({v['confidence']}) "
                  f"cos={v['cosine']}  {v['why'][:130]}")

    # ---- base rate: did the held-out codes ever fire here? ---------------- #
    base = None
    if a.full_taxonomy_stage1:
        base = _base_rate(a.full_taxonomy_stage1, traces, full, held, anns)
        print(f"\n=== base rate under the full taxonomy "
              f"({base['n_paired']} paired traces)")
        for m in held.modes:
            n = base["counts"].get(m.code, 0)
            if not n:
                print(f"  {m.code}: 0 positives -- NOT EXHIBITED on these "
                      f"traces; a miss here measures the corpus")
                continue
            parts = ", ".join(f"{k} {v}" for k, v
                              in sorted(base["fate"][m.code].items(),
                                        key=lambda kv: -kv[1]))
            print(f"  {m.code}: {n} positives -> {parts}")
            if base["absorbed_by"][m.code]:
                print(f"      absorbed by {base['absorbed_by'][m.code]}")
    else:
        print("\n[ablate] no --full-taxonomy-stage1 given: the base rate of "
              "the held-out codes on these traces is UNMEASURED, so a miss "
              "cannot be told apart from a code that never fires here. "
              "Precondition 3 of this script is unverified for this run.")

    out = work / "ablation.json"
    out.write_text(json.dumps({
        "seed": sorted(keep), "held_out": [m.code for m in held.modes],
        "n_traces": len(anns), "n_residual": len(residuals),
        "clusters": [{"id": c.cluster_id, "n": c.support, "triage": c.triage,
                      "name": c.name, "absorbed_by": c.absorbing_code,
                      "absorb_rate": round(c.absorb_rate, 3),
                      # why it landed there. Without these, an AB? has to be
                      # reconstructed from the thresholds after the fact.
                      "triage_reason": c.triage_reason,
                      "rates": c.reaudit_detail.get("rates"),
                      "rate_spread": c.reaudit_detail.get("rate_spread"),
                      "code_votes": c.reaudit_detail.get("code_votes"),
                      "n_sampled": c.reaudit_detail.get("n_sampled"),
                      "codes_withheld": c.reaudit_detail.get("codes_withheld"),
                      "respects_structure":
                          c.reaudit_detail.get("respects_structure"),
                      "frameworks": dict(c.frameworks),
                      "phases": dict(c.phases)} for c in clusters],
        # `candidates` is every triage-B cluster; `admitted` is the subset the
        # gate passed. The key is kept as "admitted" for file compatibility
        # with runs before 0.7.21, but each row now carries its own
        # `admitted` flag and gate summary.
        "admitted": rows,
        "n_triage_b": len(candidates), "n_admitted": len(admitted),
        "scorable_held_out": scorable,
        "unrecoverable_held_out": unscorable,
        "held_out_eligibility": elig,
        "recovered": sorted(found), "not_recovered": missed,
        "recovered_and_admitted": sorted(found_admitted),
        "base_rate": base,
        "note": "matching is semantic; a recovered code carries a different "
                "name. The annotator has likely seen the source taxonomies in "
                "pretraining, so this tests whether the pipeline surfaces and "
                "packages a failure its taxonomy cannot express, not whether "
                "the model derives it de novo. Recovery is scored over every "
                "triage-B cluster and reported against the structurally "
                "eligible held-out codes; `base_rate` is null when no "
                "full-taxonomy annotation was supplied, in which case a miss "
                "is not interpretable.",
    }, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n-> {out}")


if __name__ == "__main__":
    main()
