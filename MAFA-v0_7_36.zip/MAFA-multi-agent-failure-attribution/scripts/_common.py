"""Shared plumbing for the driver scripts."""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mafa import (OpenAICompatClient, ReasonerConfig, ScorerConfig,  # noqa: E402
                  Taxonomy, load_traces)


def add_common(ap: argparse.ArgumentParser) -> argparse.ArgumentParser:
    ap.add_argument("--data", default="data",
                    help="directory searched recursively for trace .jsonl files")
    ap.add_argument("--work", default="run01", help="working directory")
    ap.add_argument("--limit", type=int, default=None,
                    help="cap traces per file (smoke tests)")
    ap.add_argument("--trace-ids", default=None,
                    help="file of trace_ids, one per line or a JSON list, or "
                         "a stage1.jsonl to take them from. Restricts the run "
                         "to exactly those traces. A control run that is to be "
                         "compared per instance against an existing run MUST "
                         "use this: `--limit` takes the first n per file, "
                         "which is a different set.")
    ap.add_argument("--taxonomy", default=None,
                    help="taxonomy JSON; omit to use the T0 seed")
    ap.add_argument("--model", default="gpt-5.6-sol",
                    help="reasoner model (reasoning on, no logprobs)")
    ap.add_argument("--scorer-model", default=None,
                    help="scorer model; defaults to --model. Must support "
                         "logprobs at reasoning effort 'none'.")
    ap.add_argument("--base-url", default=os.environ.get("OPENAI_BASE_URL"))
    ap.add_argument("--group-by", default="kind",
                    help="Mondrian grouping, comma separated: "
                         "kind,framework,code,split")
    return ap


def load_all_traces(args):
    files = sorted(glob.glob(os.path.join(args.data, "**", "*.jsonl"),
                             recursive=True))
    if not files:
        sys.exit(f"no .jsonl found under {args.data!r}")
    # Stage 0 through the spec layer. Byte-identical to the old adapters on
    # all 5,071 AEGIS traces (every Step field, capabilities, injections,
    # rounds, split), and it also reads frameworks the old adapters could
    # not -- ColaCare's 2,395 traces load with zero validation problems.
    from mafa import trace_spec
    if not trace_spec.SPECS:
        trace_spec.load_specs(Path(__file__).resolve().parents[1]
                              / "mafa" / "specs")
    traces, unknown = [], []
    for f in files:
        try:
            traces += trace_spec.load_file(f, limit=args.limit)
        except ValueError as e:
            unknown.append((os.path.basename(f), str(e)))
    if unknown:
        # This used to print `[skip]` and carry on, which dropped every file
        # from an unrecognised framework and shrank the corpus without
        # saying so. It is an error now unless the caller opts in.
        msg = "\n".join(f"  {n}: {e.split('.')[0]}" for n, e in unknown)
        if getattr(args, "allow_unknown", False):
            print(f"[stage0] SKIPPING {len(unknown)} unrecognised file(s) "
                  f"because --allow-unknown was given:\n{msg}")
        else:
            sys.exit(f"{len(unknown)} file(s) under {args.data!r} match no "
                     f"MappingSpec:\n{msg}\nWrite a spec in mafa/specs/, or "
                     f"pass --allow-unknown to skip them on purpose.")
    if not traces:
        sys.exit("no traces loaded; check --data and the filename convention")
    wanted = _read_trace_ids(getattr(args, "trace_ids", None))
    if wanted is not None:
        traces = [t for t in traces if t.trace_id in wanted]
        missing = wanted - {t.trace_id for t in traces}
        print(f"[ids] {len(traces)} of {len(wanted)} requested trace_ids found")
        if missing:
            # trace_id embeds the source file and line, so a mismatch here is
            # almost always a re-shard or a different --data root, not a
            # genuinely absent trace. It unpaired 51 traces once (0.7.19); it
            # is not going to do so silently again.
            sys.exit(f"{len(missing)} requested trace_ids are not in --data, "
                     f"e.g. {sorted(missing)[:3]}. A partial control run "
                     f"cannot be paired; fix --data rather than proceeding.")
    return traces


def _read_trace_ids(path):
    """trace_ids from a plain list, a JSON array, or an existing stage1.jsonl."""
    if not path:
        return None
    raw = open(path, encoding="utf-8").read().strip()
    if not raw:
        sys.exit(f"--trace-ids {path!r} is empty")
    if raw.lstrip().startswith("["):
        return set(json.loads(raw))
    out = set()
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("{"):
            out.add(json.loads(line)["trace_id"])
        else:
            out.add(line)
    return out


def load_taxonomy(args) -> Taxonomy:
    return Taxonomy.load(args.taxonomy) if args.taxonomy else Taxonomy()


def make_client(args):
    """Build the annotator client for the requested backend.

    `anthropic` exists for two reasons that arrived together: aiberm serves
    `messages.create` but answers `500 not implemented` on the Responses API,
    so the OpenAI-compatible client cannot reach claude-opus-5 there at all;
    and images have to go to a model that reads them properly, which on this
    corpus means claude-opus-5 rather than deepseek-flash.
    """
    backend = getattr(args, "annotator_backend", "openai")
    if backend == "chat":
        # endpoints that honour structured output only on chat.completions
        from openai import OpenAI
        from mafa.annotator_client import ChatCompatClient
        key = os.environ.get("OPENAI_API_KEY")
        if not key:
            sys.exit("set OPENAI_API_KEY")
        return ChatCompatClient(
            OpenAI(api_key=key, base_url=args.base_url, timeout=300,
                   max_retries=2))
    if backend == "anthropic":
        from anthropic import Anthropic
        from mafa.reaudit_llm import AnthropicCompatClient
        key = os.environ.get(getattr(args, "annotator_key_env",
                                     "ANTHROPIC_API_KEY"))
        if not key:
            sys.exit("set ANTHROPIC_API_KEY for --annotator-backend anthropic")
        base = (getattr(args, "base_url", None)
                or os.environ.get("ANTHROPIC_BASE_URL") or "")
        return AnthropicCompatClient(
            Anthropic(api_key=key,
                      base_url=base.rstrip("/").replace("/v1", "") or None,
                      timeout=300, max_retries=2))
    from openai import OpenAI
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        sys.exit("set OPENAI_API_KEY")
    return OpenAICompatClient(
        OpenAI(api_key=key, base_url=args.base_url, timeout=180, max_retries=2))


def configs(args, **kw):
    """Build the two configs, letting explicit kwargs win over the defaults."""
    rd = dict(model=args.model,
              max_output_tokens=getattr(args, "reasoner_max_tokens", None) or 6000,
              max_chars_per_step=2500)
    # Reasoning models bill their chain of thought against this budget. On
    # deepseek-flash a short dylan trace spent 5371 tokens reasoning; at a
    # 6000 cap the answer itself has nowhere to go and the call returns empty
    # content, which surfaces as "Expecting value: line 1 column 1 (char 0)"
    # several layers up and looks like a malformed response rather than a
    # truncated one. Raise the budget for such models rather than retrying.
    if getattr(args, "reasoner_effort", None):
        rd["reasoning_effort"] = args.reasoner_effort
    sd = dict(model=getattr(args, "scorer_model", None) or args.model,
              concurrency=4, negatives_per_kind=2)
    rd.update({k: v for k, v in kw.items()
               if k in ReasonerConfig.__dataclass_fields__})
    sd.update({k: v for k, v in kw.items()
               if k in ScorerConfig.__dataclass_fields__})
    return ReasonerConfig(**rd), ScorerConfig(**sd)


def group_by(args) -> tuple[str, ...]:
    return tuple(g.strip() for g in args.group_by.split(",") if g.strip())
