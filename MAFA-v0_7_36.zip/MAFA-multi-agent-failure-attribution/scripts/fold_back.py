#!/usr/bin/env python3
"""Fold discovered codes back into the taxonomy and measure what they cost.

    # 1. build the extended taxonomy
    python scripts/fold_back.py build \\
        --seed run_ab3/seed_taxonomy.json \\
        --from-run results/gpt-5.6-sol/stage4/run_ab3_clean_n180 \\
        --out run_fb/fold_taxonomy.json

    # 2. annotate the same traces twice, seed and extended, then
    python scripts/fold_back.py compare \\
        --before run_fb/base/stage1.jsonl --before-taxonomy run_fb/seed_taxonomy.json \\
        --after  run_fb/ext/stage1.jsonl  --after-taxonomy  run_fb/fold_taxonomy.json \\
        --data data --out run_fb/foldback.json

Of the three validation routes this is the only one that can say a discovered
code is *useful*. Cross-sample recurrence says the loop tracks something real;
a human read says the mechanism exists. Neither says the code earns a place in
the taxonomy — a code can name a genuine regularity and still be unusable
because it is too vague to apply consistently, or because it wins items that
an existing code was already handling correctly.

Four numbers, and the last two are the ones that can kill a code:

    uptake       how often the new code is assigned at all. Zero means the
                 annotator cannot find it in the wild even though clustering
                 found it in the residue -- usually a definition that only
                 makes sense next to its cluster.
    residual     residual items per trace, before and after. This should fall.
                 A code that adds no coverage is decoration.
    displacement how many slots the old codes kept in the baseline and lost to
                 a new code. Some displacement is the point -- a better code
                 should take items an older, vaguer one was stretching to
                 cover. Large displacement is the opposite: a vague new code
                 hoovering up work that was already being done.
    violations   phase-illegal assignments and quotes that cannot be located
                 in the transcript, before and after.

**Paired or nothing.** Both runs must be the same annotator on the same
trace_ids. Residual counts move ±17% between two runs of the same annotator on
the same 36 traces, so an unpaired comparison measures the noise floor.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def cmd_build(a) -> None:
    from mafa.taxonomy import Taxonomy

    seed = json.loads(Path(a.seed).read_text(encoding="utf-8"))
    run = json.loads((Path(a.from_run) / "ablation.json").read_text(encoding="utf-8"))
    admitted = run.get("admitted", [])
    if not admitted:
        raise SystemExit(f"{a.from_run} admitted nothing; nothing to fold back")

    by_id = {c["id"]: c for c in run["clusters"]}
    modes = list(seed["modes"])
    added = []
    for i, adm in enumerate(admitted, start=1):
        c = by_id.get(adm["cluster"], {})
        phases = sorted((c.get("phases") or {}).keys())
        code = f"D{seed.get('version', 0)}.{i}"
        modes.append({
            "code": code,
            "name": adm["name"],
            "definition": adm["definition"],
            # the phases its own members actually occupied. Widening this to
            # every phase would let the code drift; narrowing it to one would
            # be a claim the cluster does not support.
            "allowed_phases": phases,
            "requires": [],
            "provenance": {
                "discovered_in": Path(a.from_run).name,
                "cluster": adm["cluster"], "support": adm["support"],
                "frameworks": adm.get("frameworks"),
                "nearest_held_out": adm.get("nearest_held_out"),
                "nearest_cosine": adm.get("nearest_cosine")},
        })
        added.append((code, adm["name"], adm["support"], phases))

    out = dict(seed)
    out["modes"] = modes
    out["changelog"] = list(seed.get("changelog", [])) + [
        f"fold-back: +{len(added)} discovered code(s) from "
        f"{Path(a.from_run).name}"]
    Path(a.out).write_text(json.dumps(out, indent=2, ensure_ascii=False),
                           encoding="utf-8")
    Taxonomy.load(a.out)              # fail here rather than mid-annotation
    print(f"{len(seed['modes'])} seed + {len(added)} discovered "
          f"-> {len(modes)} codes  ->  {a.out}")
    for code, name, sup, ph in added:
        print(f"  {code}  {name[:58]:58} support {sup:>3}  phases {ph}")


def _load(path, traces, tax):
    from mafa.pipeline import load_stage1
    return load_stage1(path, traces, tax)


def cmd_compare(a) -> None:
    from mafa import Taxonomy, collect_residuals
    from mafa.trace_adapter import load_dir

    traces = list(load_dir(a.data))
    by = {t.trace_id: t for t in traces}
    tb = Taxonomy.load(a.before_taxonomy)
    ta = Taxonomy.load(a.after_taxonomy)
    seed_codes = {m.code for m in tb.modes}
    new_codes = {m.code for m in ta.modes} - seed_codes

    B = _load(a.before, traces, tb)
    A = _load(a.after, traces, ta)
    shared = sorted(set(B) & set(A))
    if not shared:
        raise SystemExit("the two runs share no trace_ids; this comparison "
                         "is only meaningful paired")
    if len(shared) < len(B) or len(shared) < len(A):
        print(f"[compare] {len(shared)} shared of {len(B)} before / "
              f"{len(A)} after; using the intersection")

    def assigned(ann) -> dict[str, str]:
        """slot key -> code, for mode slots this run judged positive.

        The verdict is NOT on the slot. `plan.slots` carries the code the slot
        asks about and `ann.verdicts` carries the answers, aligned by index --
        reading `slot.code` alone returns every code that was *offered*, which
        makes uptake look identical in both arms, and reading it as "assigned"
        makes uptake look like zero. Both were wrong here before this was
        checked against the raw verdicts.
        """
        out = {}
        verdicts = list(getattr(ann, "verdicts", None) or [])
        for s, v in zip(getattr(ann.plan, "slots", []), verdicts):
            if getattr(s, "kind", None) != "mode":
                continue
            if str(v).lower() in ("1", "yes", "true"):
                out[s.key] = s.code
        return out

    bmap = {t: assigned(B[t]) for t in shared}
    amap = {t: assigned(A[t]) for t in shared}

    uptake = Counter()
    seed_before, seed_after = Counter(), Counter()
    # Displacement cannot be read off slot keys: a mode slot's key is
    # `mode::<code>`, so the new codes bring new keys rather than taking over
    # existing ones, and a key-level diff would always report zero. What a new
    # code taking work from an old one actually looks like is the old code
    # going positive less often once the new one is on offer, on the same
    # traces. So compare per-code positive counts across the paired set.
    for t in shared:
        for k, code in amap[t].items():
            if code in new_codes:
                uptake[code] += 1
            elif code in seed_codes:
                seed_after[code] += 1
        for k, code in bmap[t].items():
            if code in seed_codes:
                seed_before[code] += 1
    displacement = Counter()
    for code in seed_codes:
        delta = seed_before[code] - seed_after[code]
        if delta:
            displacement[code] = delta

    rb = collect_residuals([B[t] for t in shared], None, by)
    ra = collect_residuals([A[t] for t in shared], None, by)

    def viol(runmap, path):
        c = Counter()
        for line in Path(path).open(encoding="utf-8"):
            for v in (json.loads(line).get("violations") or []):
                c[str(v)[:60]] += 1
        return c

    vb, va = viol(bmap, a.before), viol(amap, a.after)

    n = len(shared)
    print(f"\npaired on {n} traces\n")
    print(f"{'':22} {'before':>10} {'after':>10}")
    print(f"{'residual items':22} {len(rb):>10} {len(ra):>10}")
    print(f"{'  per trace':22} {len(rb)/n:>10.2f} {len(ra)/n:>10.2f}")
    print(f"{'violations':22} {sum(vb.values()):>10} {sum(va.values()):>10}")
    print(f"\nuptake of the folded-in codes:")
    if not uptake:
        print("  none assigned anywhere -- the annotator could not find these "
              "in the wild\n  even though clustering found them in the residue")
    for code, k in uptake.most_common():
        name = next(m.name for m in ta.modes if m.code == code)
        print(f"  {code:8} {k:>4} slot(s)   {name[:52]}")
    print(f"\nseed codes: positive count before -> after "
          f"(negative delta = the seed code fires MORE with the new codes on "
          f"offer, which is not displacement)")
    for code in sorted(seed_codes):
        b, a_ = seed_before[code], seed_after[code]
        if b or a_:
            print(f"  {code:8} {b:>4} -> {a_:<4}  delta {b-a_:+d}")

    rep = {"n_paired": n, "new_codes": sorted(new_codes),
           "residual_before": len(rb), "residual_after": len(ra),
           "residual_per_trace_before": round(len(rb)/n, 3),
           "residual_per_trace_after": round(len(ra)/n, 3),
           "uptake": dict(uptake),
           "seed_positive_before": dict(seed_before),
           "seed_positive_after": dict(seed_after),
           "displacement": dict(displacement),
           "violations_before": dict(vb), "violations_after": dict(va)}
    if a.out:
        Path(a.out).write_text(json.dumps(rep, indent=2, ensure_ascii=False),
                               encoding="utf-8")
        print(f"\n-> {a.out}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--seed", required=True)
    b.add_argument("--from-run", required=True)
    b.add_argument("--out", required=True)
    b.set_defaults(fn=cmd_build)
    c = sub.add_parser("compare")
    c.add_argument("--before", required=True)
    c.add_argument("--before-taxonomy", required=True)
    c.add_argument("--after", required=True)
    c.add_argument("--after-taxonomy", required=True)
    c.add_argument("--data", default="data")
    c.add_argument("--out", default=None)
    c.set_defaults(fn=cmd_compare)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
