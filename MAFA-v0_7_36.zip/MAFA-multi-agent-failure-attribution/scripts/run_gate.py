#!/usr/bin/env python3
"""Run the admission gate on the clusters that reach triage B, and report.

Standing on its own rather than inside `ablate_seed.py` because the question
here is not about recovery: it is whether **any** code gets through the gate
for the first time in this project's history. Up to 0.7.28 the count was zero,
and §8 traced that to three things, of which the last was the triage rounding
a code-level disagreement into a pooled absorb rate (fixed in 0.7.29).

What this does NOT do: re-run the re-audit. The archived run's per-cluster
re-audit detail is reused, so the triage is recomputed from recorded votes
under the current TriageConfig rather than by paying for the judge again.
That keeps the comparison honest -- the same evidence, a different reading of
it -- and it means the gate is scored against exactly the clusters §14
reported.

G1 and G2 only. G3 (utility) and G4 (anti-regression) each need the annotator
re-run over a held-out split and an anchor set with the candidate folded in;
that is the expensive half and it is stated as not-run rather than skipped
silently.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np                                                # noqa: E402

from mafa import Taxonomy                                         # noqa: E402
from mafa.taxonomy_evolution import (Cluster, GateConfig,         # noqa: E402
                                     TriageConfig, eligible_frameworks,
                                     evaluate_gate)
from scripts._common import load_all_traces                       # noqa: E402


def retriage(rec: dict, cfg: TriageConfig) -> tuple[str, str]:
    """Recompute the A/B/AB? call from the recorded re-audit votes."""
    lo, hi = cfg.absorb_threshold - cfg.ambiguous_band, \
        cfg.absorb_threshold + cfg.ambiguous_band
    cv = rec.get("code_votes") or {}
    n_coded = sum(cv.values())
    agree = (max(cv.values()) / n_coded) if n_coded else None
    rate = float(rec.get("absorb_rate") or 0.0)
    spread = float(rec.get("rate_spread") or 0.0)
    n = int(rec.get("n_sampled") or 0)

    if agree is not None and agree < cfg.min_code_agreement and len(cv) > 1:
        if rate >= hi:
            return "AB?", (f"{len(cv)} different absorbing codes {cv} at "
                           f"absorb_rate {rate:.2f}: impure, split first")
        return "B", (f"{len(cv)} different absorbing codes {cv} "
                     f"(agreement {agree:.2f} < {cfg.min_code_agreement}); no "
                     f"single code was shown to cover it despite "
                     f"absorb_rate {rate:.2f}")
    if spread > cfg.max_rate_spread:
        return "AB?", f"rates unstable, spread {spread:.2f}"
    if n < cfg.min_votes:
        return "AB?", f"only {n} votes"
    if not cv:
        return "B", "no existing code absorbed any item"
    if rate >= hi:
        return "A", f"absorb_rate {rate:.2f} >= {hi:.2f}"
    if rate <= lo:
        return "B", f"absorb_rate {rate:.2f} <= {lo:.2f}"
    return "AB?", f"absorb_rate {rate:.2f} inside [{lo:.2f}, {hi:.2f}]"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ablation", required=True)
    ap.add_argument("--seed-taxonomy", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--min-support", type=int, default=None)
    ap.add_argument("--min-cluster-size", type=int, default=None,
                    help="the clusterer's floor, so the support requirement "
                         "can be coupled to it. run_ab5 used 5.")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    ab = json.loads(Path(a.ablation).read_text(encoding="utf-8"))
    seed = Taxonomy.load(a.seed_taxonomy)
    traces = load_all_traces(argparse.Namespace(
        data=a.data, limit=None, framework=None, split=None, trace_ids=None))
    caps: dict[str, dict[str, bool]] = {}
    for t in traces:
        caps.setdefault(t.framework, dict(t.capabilities))

    # G2 needs the cluster centroid and the seed codes' centroids in the same
    # embedding space. The archived ablation.json persists neither the member
    # embeddings nor, for this run, the cluster definition -- `definition` is
    # null on the very cluster in question. So G2 is NOT evaluable from the
    # archive, and saying so is more useful than evaluating it against a
    # zero centroid and reporting a pass.
    #
    # That is a reproducibility gap in its own right: a run's artifacts should
    # contain what is needed to re-run its own gate. Recorded in RUN.md.
    cfg = GateConfig(enabled=("G1",))
    if a.min_support is not None:
        cfg.min_support = a.min_support
    if a.min_cluster_size is not None:
        cfg.min_cluster_size = a.min_cluster_size
    tcfg = TriageConfig()

    print(f"pool {ab['n_residual']} residuals, {len(ab['clusters'])} clusters")
    print(f"gate: G1 support only (absolute floor {cfg.min_support}, "
          f"share {cfg.min_support_frac}, {cfg.support_multiple}x "
          f"min_cluster_size={cfg.min_cluster_size}, "
          f"min_frameworks={cfg.min_frameworks})")
    print("G2 distinctness NOT evaluable: the archive persists neither member "
          "embeddings nor the cluster definition.")
    print("G3 utility and G4 anti-regression NOT run: each needs the "
          "annotator re-run over a held-out split and the anchor set with the "
          "candidate folded in.\n")

    report = []
    for c in ab["clusters"]:
        was = c["triage"]
        now, why = retriage(c, tcfg)
        line = {"cluster": c["id"], "n": c["n"], "name": c["name"],
                "triage_before": was, "triage_now": now, "reason": why,
                "frameworks": c["frameworks"], "phases": c.get("phases")}
        print(f"c{c['id']} n={c['n']:<3} {was:<4} -> {now:<4} {c['name'][:52]}")
        print(f"    {why}")

        if now != "B":
            line["gate"] = "not evaluated (triage != B)"
            report.append(line)
            continue

        # `support` is len(items), so the gate needs objects to count. Only
        # the framework field is read by G1; everything else is left absent so
        # a criterion reaching for it fails loudly rather than scoring a
        # default.
        class _Stub:
            def __init__(self, fw):
                self.framework = fw
        items = [_Stub(fw) for fw, n in c["frameworks"].items()
                 for _ in range(n)]
        cl = Cluster(cluster_id=c["id"], items=items, centroid=np.zeros(8))
        cl.name, cl.definition = c["name"], c.get("definition") or ""
        cl.frameworks = Counter(c["frameworks"])
        cl.phases = Counter(c.get("phases") or {})
        cl.triage = "B"
        elig = eligible_frameworks(cl, caps)
        line["eligible_frameworks"] = elig
        print(f"    eligible frameworks (by capability): {elig}")

        g = evaluate_gate(cl, seed, {}, None, None, None, cfg,
                          pool_size=ab["n_residual"], framework_caps=caps)
        line["gate"] = g.summary()
        line["gate_detail"] = g.detail
        line["passed"] = bool(g.passed)
        print(f"    {g.summary()}")
        print(f"    detail: {json.dumps(g.detail, default=str)[:300]}")
        report.append(line)

    passed = [r for r in report if r.get("passed")]
    print(f"\n=== {len(passed)} cluster(s) passed the enabled gates")
    for r in passed:
        print(f"  c{r['cluster']}  {r['name']}")
    if a.out:
        Path(a.out).write_text(json.dumps(
            {"gate_config": {"enabled": list(cfg.enabled),
                             "min_support": cfg.min_support,
                             "min_frameworks": cfg.min_frameworks,
                             "max_centroid_cos": cfg.max_centroid_cos},
             "triage_config": {"min_code_agreement": tcfg.min_code_agreement,
                               "absorb_threshold": tcfg.absorb_threshold,
                               "ambiguous_band": tcfg.ambiguous_band},
             "not_evaluable": ["G2 distinctness (archive lacks member "
                               "embeddings and cluster definition)"],
             "not_run": ["G3 utility", "G4 anti_regression"],
             "clusters": report}, indent=1, ensure_ascii=False),
            encoding="utf-8")
        print(f"-> {a.out}")


if __name__ == "__main__":
    sys.exit(main())
