#!/usr/bin/env python3
"""Stage 1: annotate every trace. Resumable, no human labels required.

    python scripts/run_stage1.py --data data --work run01
"""
import argparse
import time

from _common import (add_common, configs, load_all_traces, load_taxonomy,
                     make_client)
from mafa import Pipeline, PipelineConfig


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--reasoner-max-tokens", type=int, default=None,
                    help="output budget for the reasoner. Reasoning models "
                         "bill their chain of thought against it: deepseek-"
                         "flash needs ~16000 or it returns empty content on "
                         "traces whose reasoning runs long.")
    ap.add_argument("--reasoner-effort", default=None)
    ap.add_argument("--scorer-mode", default="auto",
                    choices=["auto", "logprob", "verbalised", "steerconf",
                             "vpd", "both"],
                    help="auto picks logprob only when the endpoint returns "
                         "real top_logprobs alternatives; use 'both' to keep "
                         "the saturated logprob and the graded self-report as "
                         "separate features")
    ap.add_argument("--legacy-prompt", action="store_true",
                    help="pre-0.6.2 prompt: no base-rate framing, no evidence "
                         "rule. Run it on the same traces as the current "
                         "prompt to measure what the revision bought.")
    ap.add_argument("--single-pass", action="store_true",
                    help="disable the outcome-blind split (ablation only)")
    ap.add_argument("--granularity", default="trace",
                    choices=["trace", "agent", "agent_step"])
    ap.add_argument("--annotator-backend", default="openai",
                    choices=["openai", "anthropic", "chat"],
                    help="anthropic uses the Messages API. Needed for aiberm, "
                         "which returns 500 on the Responses API.")
    ap.add_argument("--annotator-key-env", default="ANTHROPIC_API_KEY")
    ap.add_argument("--no-images", action="store_true",
                    help="annotate text-only even though the corpus "
                         "references images. Required to make that choice "
                         "explicit; without it a corpus with image "
                         "references and no --images is an error rather than "
                         "a silent text-only run.")
    ap.add_argument("--images", default=None,
                    help="directory of image files. When set, a trace's own "
                         "images are attached to the ANNOTATOR's prompt (the "
                         "audited agents never saw them). Makes the run a new "
                         "measurement: pair it, do not pool it.")
    a = ap.parse_args()

    traces = load_all_traces(a)
    tax = load_taxonomy(a)
    store = None
    if a.images:
        from mafa.images import ImageStore
        store = ImageStore([a.images])
        ref, miss, ex = store.coverage(traces)
        print(f"[images] {len(store)} files indexed; {ref} referenced, "
              f"{miss} missing" + (f" e.g. {ex}" if ex else ""))
        if len(store) == 0:
            raise SystemExit(f"--images {a.images!r} indexed nothing")
    else:
        # A corpus that references images, annotated with none of them
        # attached, is a different experiment from the same corpus annotated
        # with them -- and the default said nothing about which one was run.
        # Four arms were annotated this way before anyone noticed, and only
        # the 0.7.19 ablation (n=28, one annotator) made the result
        # defensible after the fact. The run is still allowed, because the
        # ablation says images move very little on this corpus, but it has to
        # be chosen rather than fallen into.
        n_ref = sum(len(getattr(t, "images", None) or []) for t in traces)
        if n_ref and not getattr(a, "no_images", False):
            raise SystemExit(
                f"{n_ref} image references across {len(traces)} traces and no "
                f"--images given. Pass --images <dir> to attach them, or "
                f"--no-images to annotate text-only on purpose. A text-only "
                f"run is a valid experiment; an accidental one is not.")
        if n_ref:
            print(f"[images] --no-images: {n_ref} references NOT attached; "
                  f"1.2.1 verdicts in particular are made without the pixels")
    r, s = configs(a, concurrency=a.concurrency,
                   two_pass_outcome_blind=not a.single_pass,
                   legacy_prompt=a.legacy_prompt, mode=a.scorer_mode)
    pl = Pipeline(make_client(a), tax,
                  PipelineConfig(work_dir=a.work, group_by=("kind",),
                                 mode_granularity=a.granularity), r, s,
                  image_store=store)
    print(f"[run] {len(traces)} traces | taxonomy {tax.signature()} | "
          f"two-pass={not a.single_pass} | "
          f"prompt={'legacy' if a.legacy_prompt else 'current'}")
    t0 = time.time()
    pl.annotate(traces)
    print(f"[run] done in {time.time() - t0:.0f}s -> {a.work}/stage1.jsonl")


if __name__ == "__main__":
    main()
