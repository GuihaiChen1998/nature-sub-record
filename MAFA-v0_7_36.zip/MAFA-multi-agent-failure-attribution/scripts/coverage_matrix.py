#!/usr/bin/env python3
"""Measure how much of MAST the MedAgentAudit seed taxonomy actually covers,
and use the answer to validate the Stage 4 A/B triage.

    python scripts/run_stage1.py --data data/simulated --work runsim
    python scripts/coverage_matrix.py --data data/simulated --work runsim
    python scripts/coverage_matrix.py --data data/simulated --work runsim --reaudit

Why this exists
---------------
MedAgentAudit's premise is that general-purpose failure taxonomies do not fit
medical multi-agent systems. So far that premise is an assertion. The simulated
split makes it measurable: every trace carries a known MAST fault at a known
agent and step, the annotator sees only the MedAgentAudit seed, and the
contingency between the two is exactly the quantity in question.

It is also the only place the Stage 4 A/B triage can be checked. On natural
traces there is no ground truth for "is this failure already covered by an
existing code", so the triage mechanism is unverifiable there. Here there is:
run the same unmasked re-audit the triage uses, and compare its verdict against
what the MAST definition actually says.

Two things this deliberately does NOT do
----------------------------------------
It never puts MAST definitions in the annotator's prompt -- the faults were
generated from them, so a model holding them would be finding what it was told
to find. And it does not score "did the annotator pick the right code", because
the two taxonomies are different label spaces and there is no right code to
pick. What it scores is coverage: was the failure expressible at all.

Attribution rule
----------------
An injection is matched to an annotator finding by agent, since the seed
taxonomy is scored at trace level by default and only findings carry a
location. `--strict-step` additionally requires the step to match, which is a
harsher and more informative number: an annotator that flags the right agent
for the wrong turn has not really localised the fault.
"""
import argparse
import collections
import json
from pathlib import Path

from _judge import build_judge
from _common import add_common, load_all_traces, load_taxonomy, make_client
from mafa.mast import MAST, PRIOR_MAPPING
from mafa.pipeline import load_stage1
from mafa.taxonomy_evolution import UNMASKED_REAUDIT_PROMPT

MISS = "__miss__"
NOVEL = "NOVEL"


def build_matrix(traces, anns, strict_step: bool):
    """MAST code -> Counter over MedAgentAudit codes / NOVEL / miss."""
    mat = collections.defaultdict(collections.Counter)
    examples = collections.defaultdict(list)
    for t in traces:
        ann = anns.get(t.trace_id)
        if ann is None:
            continue
        by_agent = collections.defaultdict(list)
        for f in ann.findings:
            by_agent[f.agent_uid].append(f)
        novel_agents = {n.agent_uid for n in ann.novel_modes
                        if any(e.grounded for e in n.evidence)}

        for inj in t.injections:
            hits = [f for f in by_agent.get(inj.agent_uid, [])
                    if not strict_step or f.step_id == inj.step_id]
            if hits:
                for f in hits:
                    mat[inj.fm_error_type][f.code] += 1
                    if len(examples[(inj.fm_error_type, f.code)]) < 3:
                        examples[(inj.fm_error_type, f.code)].append({
                            "trace_id": t.trace_id, "agent": inj.agent_uid,
                            "step": inj.step_id,
                            "injection": inj.description[:200],
                            "annotator_rationale": f.rationale[:200]})
            elif inj.agent_uid in novel_agents:
                mat[inj.fm_error_type][NOVEL] += 1
            else:
                mat[inj.fm_error_type][MISS] += 1
    return mat, examples


def report_matrix(mat):
    codes = sorted(mat)
    seen = sorted({c for row in mat.values() for c in row
                   if c not in (MISS, NOVEL)})
    head = "MAST      n     cov%   " + " ".join(f"{c:>6s}" for c in seen) \
           + "  NOVEL   miss"
    print(head)
    print("-" * len(head))
    rows = {}
    for m in codes:
        row = mat[m]
        n = sum(row.values())
        cov = sum(v for k, v in row.items() if k not in (MISS, NOVEL)) / max(n, 1)
        rows[m] = {"n": n, "coverage": round(cov, 3),
                   "dist": {k: v for k, v in row.most_common()}}
        cells = " ".join(f"{row.get(c, 0):6d}" for c in seen)
        print(f"{m:8s} {n:5d} {cov:6.1%}   {cells}  {row.get(NOVEL, 0):5d} "
              f"{row.get(MISS, 0):6d}")
    return rows, seen


def dominant(mat, m):
    row = {k: v for k, v in mat[m].items() if k not in (MISS, NOVEL)}
    if not row:
        return None
    return max(row, key=row.get)


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--strict-step", action="store_true",
                    help="require the finding's step to match the injected step")
    ap.add_argument("--reaudit", action="store_true",
                    help="run the unmasked re-audit on uncovered cases; costs "
                         "one LLM call per sampled case")
    ap.add_argument("--reaudit-sample", type=int, default=8,
                    help="cases sampled per MAST code for the re-audit")
    ap.add_argument("--judge-backend", default="openai",
                    choices=["openai", "anthropic"],
                    help="Stage 4 judge. Prefer a DIFFERENT family from the "
                         "annotator: the A/B triage decides whether a failure "
                         "is already covered, and letting the annotating model "
                         "decide that makes it a self-assessment.")
    ap.add_argument("--judge-model", default=None)
    ap.add_argument("--judge-key-env", default="ANTHROPIC_API_KEY")
    ap.add_argument("--judge-base-url", default=None)
    ap.add_argument("--min-coverage", type=float, default=0.5,
                    help="a MAST code counts as covered above this rate")
    a = ap.parse_args()

    traces = [t for t in load_all_traces(a) if t.is_simulated]
    if not traces:
        raise SystemExit("no simulated traces; this needs the injected split")
    tax = load_taxonomy(a)
    anns = load_stage1(f"{a.work}/stage1.jsonl", traces, tax)
    print(f"[cov] {len(anns)} annotated simulated traces, "
          f"{sum(len(t.injections) for t in traces)} injections, "
          f"matching by {'agent+step' if a.strict_step else 'agent'}\n")

    mat, examples = build_matrix(traces, anns, a.strict_step)
    rows, seen = report_matrix(mat)

    covered = [m for m in rows if rows[m]["coverage"] >= a.min_coverage]
    uncovered = [m for m in rows if rows[m]["coverage"] < a.min_coverage]
    print(f"\ncovered by the seed taxonomy ({len(covered)}/{len(rows)} at "
          f">={a.min_coverage:.0%}): {covered}")
    print(f"NOT covered: {uncovered}")

    print("\nagainst the prior mapping in mafa/mast.py "
          "(hypothesis, not ground truth)")
    agree = 0
    for m in sorted(rows):
        pred, obs = PRIOR_MAPPING.get(m), dominant(mat, m)
        pred_cov, obs_cov = pred is not None, m in covered
        ok = pred_cov == obs_cov
        agree += ok
        print(f"  {m}  predicted={str(pred):7s} observed={str(obs):7s} "
              f"cov={rows[m]['coverage']:.2f}  {'ok' if ok else 'MISMATCH'}")
    print(f"  prior agreed on {agree}/{len(rows)} codes")

    out = {"matching": "agent+step" if a.strict_step else "agent",
           "n_traces": len(anns), "rows": rows,
           "covered": covered, "uncovered": uncovered,
           "prior_agreement": f"{agree}/{len(rows)}",
           "mast_definitions": {m: MAST[m] for m in rows if m in MAST},
           "examples": {f"{k[0]}->{k[1]}": v for k, v in examples.items()}}

    # ---- validate the A/B triage against ground truth ------------------- #
    if a.reaudit:
        judge = build_judge(a, make_client)
        codes_block = "\n".join(f"- {mm.code} {mm.name}: {mm.definition}"
                                for mm in tax.modes)
        triage = {}
        for m in sorted(rows):
            pool = [(t, i) for t in traces for i in t.injections
                    if i.fm_error_type == m and i.description]
            absorbed = n = 0
            for t, inj in pool[: a.reaudit_sample]:
                item = (f"FAILURE: {MAST.get(m, m)}\n"
                        f"PHASE: {next((s.phase for s in t.steps if s.step_id == inj.step_id), '?')}\n"
                        f"EVIDENCE: {inj.description[:600]}")
                try:
                    r = judge(UNMASKED_REAUDIT_PROMPT.format(
                        item=item, codes=codes_block))
                except Exception as e:                    # noqa: BLE001
                    print(f"[cov] re-audit {m}: {e}")
                    continue
                n += 1
                absorbed += bool(r.get("absorbed_by")) and \
                    str(r.get("confidence", "")).lower() in {"medium", "high"}
            rate = absorbed / n if n else float("nan")
            # ground truth: a code the seed taxonomy covers SHOULD be absorbed
            expected_A = m in covered
            called_A = rate >= 0.5
            triage[m] = {"absorb_rate": round(rate, 3), "n": n,
                         "expected": "A" if expected_A else "B",
                         "called": "A" if called_A else "B",
                         "correct": expected_A == called_A}
            print(f"  triage {m}  rate={rate:.2f}  expected="
                  f"{'A' if expected_A else 'B'}  called="
                  f"{'A' if called_A else 'B'}  "
                  f"{'ok' if expected_A == called_A else 'WRONG'}")
        ok = sum(1 for v in triage.values() if v["correct"])
        print(f"\nA/B triage agreed with ground truth on {ok}/{len(triage)} "
              "MAST codes")
        out["triage_validation"] = triage
        out["triage_accuracy"] = f"{ok}/{len(triage)}"

    p = Path(a.work) / "coverage_matrix.json"
    p.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\n-> {p}")
    print("\nNote: 'miss' means the annotator flagged nothing at that agent. On "
          "an injected trace that is a false negative, but injected faults are "
          "blunter than natural ones, so read it as a floor on the miss rate, "
          "not an estimate of it.")


if __name__ == "__main__":
    main()
