#!/usr/bin/env python3
"""Paired comparison of two Stage 1 runs on the same traces.

    python scripts/run_stage1.py --data data/sim --work run_legacy --legacy-prompt
    python scripts/run_stage1.py --data data/sim --work run_current
    python scripts/compare_prompts.py --data data/sim \\
        --a run_legacy --b run_current

Paired, on identical traces, because the quantity of interest is small and the
between-trace variance is large: mdagents injects four of seven agents while
clinical_agent injects two of six, so an unpaired comparison across different
samples can move specificity by more than any prompt change would.

If the simulated split is used, specificity is computed against the confirmed
clean agents; otherwise only the flag counts are comparable.
"""
import argparse
import collections
import json
from pathlib import Path

from _common import add_common, load_all_traces, load_taxonomy
from mafa.pipeline import load_stage1


def summarise(anns, traces, label):
    by = {t.trace_id: t for t in traces}
    agg = collections.Counter()
    for tid, ann in anns.items():
        t = by.get(tid)
        if t is None:
            continue
        flagged = {s.key.split("::", 1)[1]
                   for s in ann.flagged_slots() if s.kind == "agent"}
        agg["n_trace"] += 1
        agg["flagged"] += len(flagged)
        agg["agents"] += len(t.agent_uids)
        agg["findings"] += len(ann.findings)
        agg["violations"] += len(ann.violations)
        agg["ungrounded"] += sum(
            1 for f in ann.findings for e in f.evidence if not e.grounded)
        agg["novel"] += len(ann.novel_modes)
        if t.is_simulated:
            agg["tp"] += len(flagged & t.injected_agents)
            agg["fp"] += len(flagged & t.clean_agents)
            agg["fn"] += len(t.injected_agents - flagged)
            agg["tn"] += len(t.clean_agents - flagged)
            agg["earliest_hit"] += int(
                ann.earliest_fault_step_id == t.earliest_injected_step)
    r = lambda x, y: x / y if y else float("nan")   # noqa: E731
    return {
        "label": label, "n_trace": agg["n_trace"],
        "flag_rate": round(r(agg["flagged"], agg["agents"]), 3),
        "recall": round(r(agg["tp"], agg["tp"] + agg["fn"]), 3),
        "specificity": round(r(agg["tn"], agg["tn"] + agg["fp"]), 3),
        "precision": round(r(agg["tp"], agg["tp"] + agg["fp"]), 3),
        "earliest_exact": round(r(agg["earliest_hit"], agg["n_trace"]), 3),
        "findings_per_trace": round(r(agg["findings"], agg["n_trace"]), 2),
        "ungrounded_quotes": agg["ungrounded"],
        "violations_per_trace": round(r(agg["violations"], agg["n_trace"]), 2),
        "novel_per_trace": round(r(agg["novel"], agg["n_trace"]), 2),
        "confirmed_negatives": agg["tn"] + agg["fp"],
    }


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--a", required=True, help="baseline work dir")
    ap.add_argument("--b", required=True, help="candidate work dir")
    args = ap.parse_args()

    traces = load_all_traces(args)
    tax = load_taxonomy(args)
    A = load_stage1(Path(args.a) / "stage1.jsonl", traces, tax)
    B = load_stage1(Path(args.b) / "stage1.jsonl", traces, tax)
    shared = sorted(set(A) & set(B))
    if not shared:
        raise SystemExit("the two runs share no traces; pair them first")
    print(f"[cmp] {len(A)} vs {len(B)} annotated, {len(shared)} paired\n")
    A = {k: A[k] for k in shared}
    B = {k: B[k] for k in shared}

    sa, sb = summarise(A, traces, args.a), summarise(B, traces, args.b)
    keys = [k for k in sa if k != "label"]
    w = max(len(k) for k in keys)
    print(f"{'metric':{w}s}  {args.a:>14s}  {args.b:>14s}   delta")
    for k in keys:
        va, vb = sa[k], sb[k]
        d = ("" if not isinstance(va, (int, float)) or va != va or vb != vb
             else f"{vb - va:+.3f}")
        print(f"{k:{w}s}  {str(va):>14s}  {str(vb):>14s}   {d}")

    neg = sa["confirmed_negatives"]
    if neg and neg < 100:
        print(f"\n[cmp] WARNING only {neg} confirmed negatives. A specificity "
              "difference here is not distinguishable from noise; 300+ is a "
              "reasonable floor, and frameworks with a higher clean-agent "
              "fraction (dylan, clinical_agent) give more per trace.")

    out = Path(args.b) / "prompt_comparison.json"
    out.write_text(json.dumps({"paired_traces": len(shared), "a": sa, "b": sb},
                              indent=2), encoding="utf-8")
    print(f"\n-> {out}")


if __name__ == "__main__":
    main()
