"""L3 trial: claude-opus-5 proposes a MappingSpec per framework from a path
inventory; stage0_auto.verify accepts or returns problems. ColaCare is run
as if unseen and scored against the hand-written spec on every trace."""
import sys, glob, json, itertools, time
sys.path.insert(0, '.')
from anthropic import Anthropic
from mafa import trace_spec as TS, stage0_auto as A
TS.load_specs('mafa/specs')
AR = '/home/claude/work/maa2/github_release_files/audit_results/'
OUT = '/home/claude/work/l3'
cl = Anthropic(api_key='sk-jX2XaZ3vH8bMtYBhkR6VukoN532HknmtpYyjEB3ZVX8lvC2N',
               base_url='https://aiberm.com', timeout=600, max_retries=3)

def ask(system, user):
    m = cl.messages.create(model='claude-opus-5', max_tokens=8000, system=system,
                           messages=[{'role': 'user', 'content': user}])
    return next(b.text for b in m.content if getattr(b, 'type', None) == 'text')

def sample(fw, per_file=10):
    out = []
    for f in sorted(glob.glob(AR + fw + '_*.jsonl')):
        with open(f) as fh:
            out += [json.loads(l) for l in itertools.islice(fh, per_file)]
    return out

for fw in sys.argv[1:]:
    recs = sample(fw)
    hint = sorted(glob.glob(AR + fw + '_*.jsonl'))[0].split('/')[-1]
    t0 = time.time()
    res = A.propose(recs, ask, fw + ('_l3' if fw == 'colacare' else ''), hint, TS,
                    log=lambda s: print(s, flush=True))
    print(f'[{fw}] accepted={res["accepted"]} rounds={len(res["history"])} '
          f'{time.time()-t0:.0f}s', flush=True)
    json.dump({k: v for k, v in res.items() if k != 'report'},
              open(f'{OUT}/{fw}.json', 'w'), indent=1, ensure_ascii=False)
