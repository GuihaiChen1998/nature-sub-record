#!/usr/bin/env python3
"""Stages 2b and 3: calibrate on the anchors, then route every trace.

    python scripts/fit_and_route.py --work run01 \
        --annotated run01/done_1.jsonl run01/done_2.jsonl run01/done_3.jsonl

`--annotated` takes the per-annotator task files a human filled in. An anchor
pool that has already been merged and split -- anything written by
`AnchorPool.save`, including the pseudo-anchor pool harvested from the injection
log -- is a different format and is loaded with `--anchor-pool` instead:

    python scripts/fit_and_route.py --work run01 \
        --anchor-pool examples/pseudo_anchors.jsonl

Passing a saved pool to `--annotated` does not fail loudly: `load_completed`
looks for `human_votes`, finds none, and returns an empty list, so the run dies
several steps later complaining about zero usable anchors. Hence two flags.
"""
import argparse
import json
from pathlib import Path

from _common import add_common, group_by, load_all_traces, load_taxonomy
from mafa import AnchorPool, Pipeline, PipelineConfig, merge_annotators
from mafa.pipeline import load_stage1


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--annotated", nargs="+",
                     help="one completed task file per annotator")
    src.add_argument("--anchor-pool",
                     help="a pool already merged and split, as written by "
                          "AnchorPool.save (e.g. examples/pseudo_anchors.jsonl)")
    ap.add_argument("--alpha", type=float, default=0.10)
    ap.add_argument("--calibrator-backend", default="logistic",
                    choices=["logistic", "venn_abers", "logistic_va"],
                    help="Stage 2 backend. 'logistic' refuses to score across "
                         "a taxonomy change (current behaviour); the Venn-Abers "
                         "backends emit an interval and keep scoring, reporting "
                         "width instead of failing silently.")
    ap.add_argument("--auto-threshold", type=float, default=0.9,
                    help="router-backend=threshold: p >= this routes AUTO")
    ap.add_argument("--zero-threshold", type=float, default=0.1,
                    help="router-backend=threshold: p <= this routes AUTO(0)")
    ap.add_argument("--error-budget", type=float, default=None,
                    help="router-backend=threshold: ignore the two thresholds "
                         "and pick the most permissive ones whose upper 95%% "
                         "bound on auto-route error meets this target; per "
                         "Mondrian group, and refuses a group where no "
                         "threshold meets it")
    ap.add_argument("--router-backend", default="split",
                    choices=["split", "aci", "venn_abers", "threshold"],
                    help="Stage 3 backend. 'split' is finite-sample valid under "
                         "exchangeability and void after a taxonomy change; "
                         "'aci' re-earns long-run coverage from the human "
                         "verdicts the queue already produces; 'venn_abers' "
                         "routes from the interval and uses width, not the "
                         "empty set, as the NOVEL channel; 'threshold' takes "
                         "the cuts from the user and carries no guarantee -- "
                         "it measures the rule instead of certifying it.")
    ap.add_argument("--aci-gamma", type=float, default=0.05)
    a = ap.parse_args()

    traces = load_all_traces(a)
    tax = load_taxonomy(a)
    work = Path(a.work)

    pl = Pipeline.__new__(Pipeline)
    pl.tax = tax
    pl.cfg = PipelineConfig(work_dir=a.work, alpha=a.alpha,
                            group_by=group_by(a),
                            calibrator_backend=a.calibrator_backend,
                            router_backend=a.router_backend,
                            aci_gamma=a.aci_gamma)
    if (a.calibrator_backend, a.router_backend) != ("logistic", "split"):
        from mafa.calibration_backends import make_calibrator
        from mafa.routing_backends import make_router, check_compatible, \
            describe_pairing
        _c, _r = make_calibrator(a.calibrator_backend), \
            make_router(a.router_backend)
        bad = check_compatible(_c, _r)
        if bad:
            raise SystemExit(f"incompatible backends: {bad}")
        print(f"[fit] pairing {json.dumps(describe_pairing(_c, _r), indent=2)}")
    pl.dir, pl.anchor_pool = work, None
    pl.calibrator = pl.router = None
    pl.fit_report = {}
    pl.annotations = load_stage1(work / "stage1.jsonl", traces, tax)

    if a.anchor_pool:
        # already merged and already split: the frozen half is the ruler G4
        # measures against, so re-splitting it here would defeat the point
        pool = AnchorPool.load(a.anchor_pool)
        print(f"[fit] loaded pool from {a.anchor_pool}")
    else:
        merged = merge_annotators(a.annotated)
        if not merged:
            raise SystemExit(
                f"no anchors parsed from {a.annotated}. If these files were "
                "written by AnchorPool.save, pass them with --anchor-pool.")
        split_path = work / "frozen_split.json"
        if split_path.exists():
            split = json.loads(split_path.read_text())
            frozen_ids = set(split["frozen_trace_ids"])
            pool = AnchorPool([m for m in merged if m.trace_id not in frozen_ids],
                              [m for m in merged if m.trace_id in frozen_ids])
        else:
            print("[fit] no frozen_split.json; splitting now (less reproducible)")
            pool = AnchorPool.split(merged, frozen_share=0.3)
    print(pool)
    pool.save(work / "anchors.jsonl")

    rep = pl.fit(pool, traces)
    print(json.dumps({k: rep[k] for k in
                      ("taxonomy_signature", "n_anchors_used", "head_b_fitted",
                       "head_a", "selective_error", "step_head")},
                     indent=2, default=str))
    routes = pl.route(traces)
    pl.export_buckets(traces, routes)
    pl.export_level_buckets(traces, routes)


if __name__ == "__main__":
    main()
