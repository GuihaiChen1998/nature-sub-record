#!/usr/bin/env python3
"""What does filtering the re-audit by structure actually change?

    python scripts/measure_reaudit_filter.py --work run_ab2 --out run_ab2/filter.json

Stage 1 has always refused to score a code whose `allowed_phases` excludes the
step, or whose `requires` the trace cannot satisfy. The Stage-4 re-audit did
not, and on run_ab2 that let 1.2.1 -- legal only in discussion /
independent_analysis / review -- absorb a cluster that was 20/22 at
`recruitment`.

Applying the filter is one line. Knowing what it buys is not, because the
filter does two things at once on this taxonomy: it removes codes that cannot
legally apply, *and* it collapses the candidate set from six codes to one for
almost every item, turning the judge's task from discrimination into a yes/no.
Both move the absorb rate. Three arms separate them:

    off       every code offered, as before 0.7.16
    requires  filter on capabilities only -- a hard structural fact about the
              framework, not a taxonomy-authoring judgement
    full      capabilities and allowed_phases

Groups are rebuilt from the cached embeddings so all three arms see exactly the
same items; nothing here re-clusters or re-names. Only the re-audit is measured.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from _common import make_client                                  # noqa: E402
from _judge import build_judge                                   # noqa: E402
from mafa import (Taxonomy, cluster_residuals, collect_residuals,  # noqa: E402
                  make_embedder)
from mafa.pipeline import load_stage1                            # noqa: E402
from mafa.reaudit_llm import (REAUDIT_SYSTEM, UNMASKED_REAUDIT_PROMPT,  # noqa: E402
                              normalise_code)
from mafa.taxonomy_evolution import resplit                      # noqa: E402
from mafa.trace_adapter import load_dir                          # noqa: E402

ARMS = ("off", "requires", "full")
ACCEPT = {"medium", "high"}


def candidates(item, modes, arm):
    if arm == "off":
        return list(modes)
    out = []
    for m in modes:
        if not m.applies_to(item.capabilities or {}):
            continue
        ph = item.phase or ""
        if arm == "full" and ph and ph != "unknown" and m.allowed_phases \
                and ph not in m.allowed_phases:
            continue
        out.append(m)
    return out


def one_vote(judge, item, modes, arm, tax):
    cands = candidates(item, modes, arm)
    if not cands:
        return {"trace_id": item.trace_id, "phase": item.phase,
                "n_candidates": 0, "absorbed_by": None, "confidence": "",
                "reasoning": "no code legal here"}
    codes = "\n".join(f"- {m.code} {m.name}: {m.definition}" for m in cands)
    try:
        r = judge(UNMASKED_REAUDIT_PROMPT.format(
            item=item.text_for_embedding(), codes=codes), REAUDIT_SYSTEM)
    except Exception as e:                                       # noqa: BLE001
        return {"trace_id": item.trace_id, "error": str(e)[:160],
                "n_candidates": len(cands), "absorbed_by": None,
                "confidence": ""}
    return {"trace_id": item.trace_id, "phase": item.phase,
            "n_candidates": len(cands),
            "absorbed_by": normalise_code(r.get("absorbed_by"), tax),
            "confidence": str(r.get("confidence", "")).lower(),
            "reasoning": str(r.get("reasoning") or "")[:200]}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data", default="data")
    ap.add_argument("--work", default="run_ab2")
    ap.add_argument("--out", default=None)
    ap.add_argument("--sample", type=int, default=8)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--judge-backend", default="anthropic")
    ap.add_argument("--judge-model", default="claude-opus-5")
    ap.add_argument("--judge-key-env", default="ANTHROPIC_API_KEY")
    ap.add_argument("--judge-base-url", default=None)
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--model", default="gpt-5.6-sol-disc")
    a = ap.parse_args()
    work = Path(a.work)

    traces = list(load_dir(a.data))
    by = {t.trace_id: t for t in traces}
    tax = Taxonomy.load(work / "seed_taxonomy.json")
    res = collect_residuals(
        load_stage1(work / "stage1.jsonl", traces, tax).values(), None, by)
    embed = make_embedder("openai", model="text-embedding-3-small",
                          cache_path=str(work / "embeddings.jsonl"))
    clusters, _ = cluster_residuals(res, embed, min_cluster_size=6)

    groups = []
    for c in sorted(clusters, key=lambda c: -c.support):
        parts, rem = resplit(c, embed, min_cluster_size=4)
        if parts:
            groups += [(f"c{p.cluster_id}", p) for p in parts]
            if rem:
                groups.append((f"c{rem.cluster_id}(remainder)", rem))
        else:
            groups.append((f"c{c.cluster_id}", c))
    print(f"[measure] {len(res)} residuals -> groups "
          + ", ".join(f"{n}:{g.support}" for n, g in groups))

    judge = build_judge(a, make_client)
    modes = list(tax.modes)
    jobs = [(arm, rep, name, i)
            for arm in ARMS for rep in range(a.repeats)
            for name, g in groups for i in range(min(a.sample, g.support))]
    gmap = dict(groups)
    print(f"[measure] {len(jobs)} judge calls across {len(ARMS)} arms")

    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs = [ex.submit(one_vote, judge, gmap[name].items[i], modes, arm, tax)
                for arm, rep, name, i in jobs]
        raw = [f.result() for f in futs]

    results: dict = {}
    for (arm, rep, name, _), v in zip(jobs, raw):
        results.setdefault(arm, {}).setdefault(name, {}).setdefault(rep, []).append(v)

    report: dict = {"arms": {}, "groups": {n: {
        "n": g.support, "frameworks": dict(g.frameworks),
        "phases": dict(g.phases)} for n, g in groups}}
    for arm in ARMS:
        print(f"\n=== arm {arm}")
        report["arms"][arm] = {}
        for name, _ in groups:
            per_rep = results[arm][name]
            rates, codes = [], Counter()
            for rep, votes in sorted(per_rep.items()):
                acc = [v for v in votes
                       if v.get("absorbed_by") and v.get("confidence") in ACCEPT]
                n = len([v for v in votes if "error" not in v])
                rates.append(len(acc) / n if n else 0.0)
                codes.update(v["absorbed_by"] for v in acc)
            spread = max(rates) - min(rates) if rates else 0.0
            top = codes.most_common(1)[0][0] if codes else None
            ncand = [v["n_candidates"] for v in per_rep[0]]
            report["arms"][arm][name] = {
                "rates": [round(r, 3) for r in rates],
                "mean_rate": round(sum(rates) / len(rates), 3),
                "spread": round(spread, 3), "top_code": top,
                "code_votes": dict(codes), "n_candidates": ncand,
                "detail": per_rep[0]}
            print(f"  {name:20} rates {[round(r,2) for r in rates]} "
                  f"spread {spread:.2f}  -> {top}  cands {ncand}")

    out = Path(a.out or (work / "filter_arms.json"))
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False),
                   encoding="utf-8")
    print(f"\n-> {out}")


if __name__ == "__main__":
    main()
