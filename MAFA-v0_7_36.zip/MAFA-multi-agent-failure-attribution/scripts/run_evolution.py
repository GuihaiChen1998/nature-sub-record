#!/usr/bin/env python3
"""Stage 4: residual pool -> clusters -> A/B triage -> admission gate -> T(k+1).

Preview mode needs no human labels at all -- it runs on the NOVEL proposals
Stage 1 already produced:

    python scripts/run_evolution.py --work run01 --gates G1,G2

Full mode adds the expensive gates once anchors exist:

    python scripts/run_evolution.py --work run01 --gates G1,G2,G3,G4 \
        --held-out 60
"""
import argparse
import json
from pathlib import Path

from _judge import build_judge
from _common import (add_common, configs, load_all_traces, load_taxonomy,
                     make_client)
from mafa import (GateConfig, Pipeline, PipelineConfig, TriageConfig,
                  admit, cluster_residuals, code_centroids, collect_residuals,
                  evaluate_gate, evolution_report, make_embedder, revise_scope,
                  suggest_distinctness_threshold, triage_clusters)
from mafa.pipeline import load_stage1
from mafa.reaudit_llm import (LLMJudge, make_anchor_fn, make_annotate_with,
                              make_distinctness, make_summarise,
                              make_unmasked_reaudit, make_utility_fn)


def main():
    ap = add_common(argparse.ArgumentParser(description=__doc__))
    ap.add_argument("--gates", default="G1,G2")
    ap.add_argument("--embed-backend", default="openai",
                    choices=["openai", "vllm", "hash"])
    ap.add_argument("--embed-model", default="text-embedding-3-small")
    ap.add_argument("--embed-base-url", default=None,
                    help="embedding endpoint, when it differs from the "
                         "annotator's. deepseek serves no embeddings, so a "
                         "deepseek run must point this elsewhere or the whole "
                         "stage dies on a 404 after the annotations are done.")
    ap.add_argument("--embed-key-env", default="OPENAI_API_KEY")
    ap.add_argument("--min-cluster-size", type=int, default=8)
    ap.add_argument("--min-support", type=int, default=12)
    ap.add_argument("--min-framework-fraction", type=float, default=0.0,
                    help="cap the framework requirement at this share of the "
                         "frameworks that could exhibit the failure at all; "
                         "0 disables")
    ap.add_argument("--ignore-framework-eligibility", action="store_true",
                    help="count frameworks against the whole corpus rather "
                         "than against the ones whose structure permits the "
                         "failure. A recruitment-stage failure can only ever "
                         "appear in a framework that recruits, so this makes "
                         "the requirement unsatisfiable for such codes.")
    ap.add_argument("--min-frameworks", type=int, default=2)
    ap.add_argument("--absorb-threshold", type=float, default=0.5)
    ap.add_argument("--ambiguous-band", type=float, default=0.15)
    ap.add_argument("--held-out", type=int, default=60,
                    help="traces used by G3; ignored unless G3 is enabled")
    ap.add_argument("--judge-backend", default="openai",
                    choices=["openai", "anthropic"],
                    help="Stage 4 judge. Prefer a DIFFERENT family from the "
                         "annotator: the A/B triage decides whether a failure "
                         "is already covered, and letting the annotating model "
                         "decide that makes it a self-assessment.")
    ap.add_argument("--judge-model", default=None)
    ap.add_argument("--judge-key-env", default="ANTHROPIC_API_KEY")
    ap.add_argument("--judge-base-url", default=None)
    ap.add_argument("--auto-threshold", action="store_true",
                    help="derive max_centroid_cos from the taxonomy geometry")
    ap.add_argument("--enable-evolution", action="store_true",
                    help="Stage 4 grows the taxonomy, which changes the label "
                         "space and voids calibration done before it. Off by "
                         "default; this script does nothing without it.")
    a = ap.parse_args()
    from mafa.taxonomy_evolution import require_evolution
    require_evolution(a, what=__file__.split("/")[-1])

    traces = load_all_traces(a)
    tax = load_taxonomy(a)
    work = Path(a.work)
    gates = tuple(g.strip() for g in a.gates.split(",") if g.strip())

    pl = Pipeline.__new__(Pipeline)
    pl.tax, pl.cfg = tax, PipelineConfig(work_dir=a.work)
    pl.dir, pl.anchor_pool = work, None
    pl.annotations = load_stage1(work / "stage1.jsonl", traces, tax)

    routes = None
    rp = work / "routes.jsonl"
    if rp.exists():
        routes = {}
        for line in rp.open(encoding="utf-8"):
            d = json.loads(line)
            routes[d["trace_id"]] = type("R", (), {
                "decision": d["decision"],
                "levels": {k: type("L", (), {"empty_keys": []})()
                           for k in d.get("sets", {})}})()
    residuals = collect_residuals(pl.annotations.values(), routes,
                                  {t.trace_id: t for t in traces})
    print(f"[evolve] residual pool: {len(residuals)} items "
          f"(routes.jsonl {'used' if routes else 'absent -- NOVEL only'})")
    if not residuals:
        print("[evolve] nothing to cluster; Stage 1 proposed no grounded NOVEL")
        return

    embed = make_embedder(a.embed_backend, model=a.embed_model,
                          cache_path=str(work / "embeddings.jsonl"),
                          base_url=a.embed_base_url,
                          api_key_env=a.embed_key_env)
    cfg = GateConfig(enabled=gates, min_support=a.min_support,
                     min_frameworks=a.min_frameworks,
                     min_framework_fraction=a.min_framework_fraction)
    caps = None if a.ignore_framework_eligibility else {
        t.framework: t.capabilities for t in traces}
    if a.auto_threshold:
        sug = suggest_distinctness_threshold(embed, tax)
        cfg.max_centroid_cos = sug["suggested_max_centroid_cos"]
        print(f"[evolve] G2 threshold from taxonomy geometry: {sug}")

    clusters, noise = cluster_residuals(residuals, embed,
                                        min_cluster_size=a.min_cluster_size)
    print(f"[evolve] {len(clusters)} clusters, {len(noise)} noise")

    judge = build_judge(a, make_client, cache_path=work / "judge_cache.jsonl")
    tcfg = TriageConfig(absorb_threshold=a.absorb_threshold,
                        ambiguous_band=a.ambiguous_band)
    # see the note in ablate_seed.py: resplit is dead without embed=
    clusters = triage_clusters(clusters, tax, make_summarise(judge),
                               make_unmasked_reaudit(judge, tcfg), tcfg,
                               embed=embed)
    for c in clusters:
        print(f"  cluster {c.cluster_id}: n={c.support} fw={c.n_frameworks} "
              f"rate={c.absorb_rate:.2f} -> {c.triage}  {c.name[:48]!r}")

    utility_fn = anchor_fn = None
    if "G3" in gates or "G4" in gates:
        r, s = configs(a)
        annotate_with = make_annotate_with(make_client(a), r, s)
        if "G3" in gates:
            utility_fn = make_utility_fn(annotate_with, traces[: a.held_out])
        if "G4" in gates:
            from mafa import AnchorPool
            pool = AnchorPool.load(work / "anchors.jsonl")
            frozen_ids = {x.trace_id for x in pool.frozen}
            anchor_fn = make_anchor_fn(
                annotate_with,
                [t for t in traces if t.trace_id in frozen_ids],
                anchor_pool=pool)

    cent = code_centroids(embed, tax)
    for c in clusters:
        if c.triage == "A":
            tax = revise_scope(tax, c)
            print(f"  -> scope revision on {c.absorbing_code} (T{tax.version})")
        elif c.triage == "B":
            g = evaluate_gate(c, tax, cent, utility_fn, anchor_fn,
                              make_distinctness(judge), cfg,
                              pool_size=len(residuals), framework_caps=caps)
            print(f"  -> gate {c.cluster_id}: {g.summary()}")
            if g.passed:
                tax = admit(tax, c, g)
                print(f"     admitted as {tax.modes[-1].code} (T{tax.version})")

    tax.save(work / f"taxonomy_T{tax.version}.json")
    (work / "evolution_report.json").write_text(
        json.dumps(evolution_report(tax, clusters, noise), indent=2,
                   default=str), encoding="utf-8")
    print(f"[evolve] T{tax.version} with {len(tax.modes)} codes -> "
          f"{work}/taxonomy_T{tax.version}.json")
    print(f"[evolve] report -> {work}/evolution_report.json")
    if tax.signature() != load_taxonomy(a).signature():
        print("[evolve] the taxonomy changed: re-run run_stage1.py with "
              f"--taxonomy {work}/taxonomy_T{tax.version}.json, then refit. "
              "The old calibrator and conformal quantiles are invalid.")


if __name__ == "__main__":
    main()
