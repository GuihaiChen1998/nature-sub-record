#!/usr/bin/env python3
"""Consistency calibration at the agent and step levels.

§15 measured 5-sample agreement at the **mode** level, against clinicians.
That is the level where the project has no anchors, so it was the right place
to start, but it leaves the obvious question open: does the same thing work on
the two levels that actually carry most of the routing traffic?

Here the ground truth is free. The simulated split's injection log records
which agents were corrupted and at which steps, and that label is independent
of the taxonomy -- adding or removing a failure code does not change whether
an agent was injected. So this is a measurement the project can repeat after
every turn of the loop without spending an annotation.

One thing the injection labels are not: a clean negative set downstream of the
first injection. A corrupted claim propagates, and an agent that receives it
can genuinely fail while the injection log still calls it clean. Following
`validate_on_injected.py`, specificity is reported on **upstream** clean
agents only -- those that finish speaking before the first injected step --
with the downstream ones broken out separately rather than pooled.

Resumable: votes append to <work>/votes_<level>_<model>.jsonl.
"""
from __future__ import annotations

import argparse
import collections
import concurrent.futures as cf
import json
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mafa import Taxonomy                                         # noqa: E402
from mafa.stage1_schema import build_slot_plan                    # noqa: E402
from scripts._common import load_all_traces                       # noqa: E402

ENDPOINTS = {
    "glm-5.3-flash": ("https://open.bigmodel.cn/api/paas/v4/",
                      "0c86451768dd4ed7933f237b2cd90d45.bNebLs5BB56cIUhh"),
}

SYSTEM = ("You audit transcripts of medical multi-agent consultations. You "
          "answer only with the JSON object you are asked for.")

#: The agent and step slot questions are NOT self-contained. "one of the
#: applicable failure modes" and "a failure" refer to the taxonomy block that
#: Stage 1 renders above the slot list, and asking them without it turns a
#: bounded question into "did this agent do anything wrong at all".
#:
#: The first run of this script omitted the block. glm flagged roughly 80% of
#: agents, specificity on upstream clean agents came back at 0.526, and the
#: resulting ECE of 0.249 measured the prompt rather than consistency
#: calibration. Mode-level slots were unaffected, because each of those
#: questions carries its own code definition.
TAXONOMY_BLOCK = """The failure modes that apply to this collaboration are:

{codes}

A passage counts as a failure only if it matches one of the modes above.
Problems outside this list, however serious, are not what is being asked."""

TEMPLATE = """Below is the transcript of a medical multi-agent consultation.

--- transcript ---
{transcript}
--- end transcript ---

{taxonomy}

Question: {question}

Answer on the transcript alone. Do not assume a failure exists because the
final answer was wrong, and do not rule one out because it was right.

Reply with exactly this JSON and nothing else:
{{"verdict": "yes" or "no", "why": "<one sentence>"}}"""


def render(trace, max_chars: int) -> str:
    parts = []
    for st in trace.steps:
        parts.append(f"[{st.step_id}] {st.agent_uid} ({st.phase})\n"
                     f"{(st.content or '')[:1500]}")
    text = "\n\n".join(parts)
    if len(text) > max_chars:
        head, tail = max_chars // 3, max_chars - max_chars // 3
        text = text[:head] + "\n\n[... truncated ...]\n\n" + text[-tail:]
    return text


def render_taxonomy(trace, tax) -> str:
    """Only the codes this trace's structure could exhibit, as Stage 1 does.

    Filtering by `requires` matters as much here as in the pipeline: offering
    a dylan trace a code that needs an aggregator invites a verdict on
    something the architecture cannot do.
    """
    lines = []
    for m in tax.modes:
        if all(trace.capabilities.get(r, False) for r in m.requires):
            lines.append(f"- {m.code} {m.name}: {m.definition}")
    return TAXONOMY_BLOCK.format(codes="\n".join(lines))


def build_tasks(traces, level: str, max_steps: int):
    """One task per slot, carrying its injection label."""
    tax = Taxonomy()
    out = []
    for t in traces:
        inj_a = set(getattr(t, "injected_agents", None) or ())
        inj_s = set(getattr(t, "injected_steps", None) or ())
        if not inj_a and not inj_s:
            continue
        plan = build_slot_plan(t, tax)
        # the first injected step, for the upstream/downstream split
        order = {s.step_id: s.idx for s in t.steps}
        first = min((order[s] for s in inj_s if s in order), default=None)
        for slot in plan.slots:
            if slot.kind != level:
                continue
            if level == "agent":
                uid = slot.key.split("::", 1)[1]
                card = t.agent(uid)
                idxs = [order[s] for s in (card.step_ids if card else [])
                        if s in order]
                pos = uid in inj_a
                region = ("injected" if pos else
                          "upstream" if (first is None or
                                         (idxs and max(idxs) < first))
                          else "downstream")
            else:
                sid = slot.key.split("::", 1)[1]
                pos = sid in inj_s
                region = ("injected" if pos else
                          "upstream" if (first is None or order.get(sid, 0) < first)
                          else "downstream")
            out.append({"trace_id": t.trace_id, "framework": t.framework,
                        "slot_key": slot.key, "level": level,
                        "question": slot.question, "label": int(pos),
                        "region": region})
    if level == "step":
        # Step slots are overwhelmingly negative and there are ~20 per trace.
        # Keep every positive and a matched sample of negatives per trace, so
        # the run is affordable without discarding the signal.
        by_trace = collections.defaultdict(list)
        for r in out:
            by_trace[r["trace_id"]].append(r)
        import random
        rng = random.Random(0)
        kept = []
        for rows in by_trace.values():
            pos = [r for r in rows if r["label"] == 1]
            neg = [r for r in rows if r["label"] == 0]
            rng.shuffle(neg)
            kept.extend(pos[:max_steps] + neg[:max_steps])
        out = kept
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/simulated")
    ap.add_argument("--work", default="/home/claude/work/runs/consistency")
    ap.add_argument("--model", default="glm-5.3-flash")
    ap.add_argument("--level", choices=["agent", "step"], required=True)
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--n-traces", type=int, default=40)
    ap.add_argument("--max-steps", type=int, default=3)
    ap.add_argument("--concurrency", type=int, default=14)
    ap.add_argument("--max-chars", type=int, default=20000)
    #: glm-5.3-flash always reasons, and the chain of thought is billed
    #: against max_tokens. At 3000 it consumed 2993 and returned an empty
    #: string -- finish_reason "length", content "", JSONDecodeError. The
    #: failure rate climbed from 32% to 66% as the run reached mdagents,
    #: whose longer transcripts and fuller taxonomy block make the reasoning
    #: longer still, so it read as an endpoint degrading rather than as a
    #: budget being exhausted.
    #:
    #: Identical to the deepseek-flash `model_empty_output` failure, fixed
    #: there with --reasoner-max-tokens 24000. That lesson was not carried
    #: into this script.
    #: A ladder, not a number. The chain of thought is billed against
    #: max_tokens and the model expands to fill whatever it is given: at 3000
    #: it truncated (reasoning 2993, content ""), and at 32000 a single
    #: successful call spent 8006 tokens and 73 seconds, collapsing throughput
    #: to under 2 votes a minute. Neither a small budget nor a large one is
    #: right for every slot, because the reasoning scales with the transcript
    #: and the taxonomy block while the answer is eleven tokens of JSON.
    #:
    #: So start cheap and escalate only on the calls that actually truncate.
    #: `budget_used` is recorded per vote, which turns the ladder into a
    #: measurement of how much reasoning this task really needs instead of
    #: another unablated constant.
    ap.add_argument("--token-ladder", default="10000,20000,40000")
    ap.add_argument("--temperature", type=float, default=1.0)
    a = ap.parse_args()

    from openai import OpenAI
    base, key = ENDPOINTS[a.model]
    # 0.7.34: was timeout=300, max_retries=3. Worst case per vote was then
    # 3 rungs x 4 attempts x 300s = one hour with nothing written, which is
    # indistinguishable from a dead process from the outside -- and that is
    # exactly what it looked like after glm rate-limited the account. A vote
    # that has not returned in 120s is not about to; fail it, write it, and
    # let the slot be redrawn.
    client = OpenAI(base_url=base, api_key=key, timeout=120, max_retries=1)
    Path(a.work).mkdir(parents=True, exist_ok=True)
    out = Path(a.work) / f"votes_{a.level}_{a.model}.jsonl"

    traces = load_all_traces(argparse.Namespace(
        data=a.data, limit=None, framework=None, split=None, trace_ids=None))
    # balanced across frameworks, deterministic
    by_fw = collections.defaultdict(list)
    for t in traces:
        by_fw[t.framework].append(t)
    per = max(1, a.n_traces // max(len(by_fw), 1))
    chosen = [t for fw in sorted(by_fw) for t in sorted(
        by_fw[fw], key=lambda x: x.trace_id)[:per]]
    tasks = build_tasks(chosen, a.level, a.max_steps)
    text = {t.trace_id: render(t, a.max_chars) for t in chosen}
    _tax = Taxonomy()
    taxo = {t.trace_id: render_taxonomy(t, _tax) for t in chosen}
    print(f"[{a.level}] {len(chosen)} traces -> {len(tasks)} slots "
          f"({sum(r['label'] for r in tasks)} positive), k={a.k}")

    have: collections.Counter = collections.Counter()
    if out.exists():
        for line in open(out, encoding="utf-8"):
            try:
                r = json.loads(line)
                if r.get("vote") is not None:
                    have[(r["trace_id"], r["slot_key"])] += 1
            except Exception:
                pass
    todo = []
    for r in tasks:
        for _ in range(a.k - have[(r["trace_id"], r["slot_key"])]):
            todo.append(r)
    print(f"[{a.level}] {sum(have.values())} votes on file, {len(todo)} to draw")

    lock, done = threading.Lock(), [0]

    def one(r):
        ladder = [int(x) for x in a.token_ladder.split(",") if x.strip()]
        last_err = None
        for rung, budget in enumerate(ladder):
            try:
                kw = {"model": a.model,
                      "messages": [{"role": "system", "content": SYSTEM},
                                   {"role": "user", "content": TEMPLATE.format(
                                       transcript=text[r["trace_id"]],
                                       taxonomy=taxo[r["trace_id"]],
                                       question=r["question"])}],
                      "response_format": {"type": "json_object"},
                      "max_tokens": budget, "temperature": a.temperature}
                if a.model.startswith("glm"):
                    kw["extra_body"] = {"thinking": {"type": "enabled"}}
                resp = client.chat.completions.create(**kw)
                ch = resp.choices[0]
                raw = (ch.message.content or "").strip()
                # Truncation is diagnosable before parsing, and diagnosing it
                # is what makes the ladder worth having: `length` with an
                # empty body means the reasoning ate the budget, which is a
                # reason to climb. A malformed but complete answer is not --
                # retrying that at a larger budget just costs more.
                if ch.finish_reason == "length" or not raw:
                    last_err = f"truncated@{budget}"
                    if rung + 1 < len(ladder):
                        continue
                    rec = dict(r, vote=None, error=last_err,
                               budget_used=budget)
                    break
                if raw.startswith("```"):
                    raw = raw.split("```")[1].removeprefix("json").strip()
                v = str(json.loads(raw).get("verdict", "")).strip().lower()
                rec = dict(r, vote=1 if v == "yes" else 0 if v == "no" else None,
                           budget_used=budget, rung=rung)
                break
            except json.JSONDecodeError:
                # Complete but unparseable: a bigger budget will not help.
                rec = dict(r, vote=None, error="JSONDecodeError",
                           budget_used=budget)
                break
            except Exception as e:                           # noqa: BLE001
                name = type(e).__name__
                # A rate limit is not a budget problem, and climbing the
                # ladder on one is exactly wrong: a larger max_tokens does not
                # lift a quota, it just burns all three rungs in quick
                # succession and records a failure. The first time this
                # endpoint throttled, 77% of the last 60 calls failed that
                # way while the call counter kept rising -- errors return
                # fast, so attempts outran successes and the counter read as
                # progress. Wait and retry at the SAME rung instead.
                if name == "RateLimitError":
                    import random
                    import time
                    for wait in (8, 20, 45):
                        time.sleep(wait + random.uniform(0, wait / 2))
                        try:
                            resp = client.chat.completions.create(**kw)
                            break
                        except Exception as e2:              # noqa: BLE001
                            if type(e2).__name__ != "RateLimitError":
                                raise
                    else:
                        rec = dict(r, vote=None, error="RateLimitError",
                                   budget_used=budget)
                        break
                    ch = resp.choices[0]
                    raw = (ch.message.content or "").strip()
                    if ch.finish_reason == "length" or not raw:
                        last_err = f"truncated@{budget}"
                        if rung + 1 < len(ladder):
                            continue
                        rec = dict(r, vote=None, error=last_err,
                                   budget_used=budget)
                        break
                    if raw.startswith("```"):
                        raw = raw.split("```")[1].removeprefix("json").strip()
                    try:
                        v = str(json.loads(raw).get("verdict", "")).strip().lower()
                    except json.JSONDecodeError:
                        rec = dict(r, vote=None, error="JSONDecodeError",
                                   budget_used=budget)
                        break
                    rec = dict(r, vote=1 if v == "yes" else 0 if v == "no"
                               else None, budget_used=budget, rung=rung,
                               rate_limited=True)
                    break
                last_err = name
                if rung + 1 < len(ladder):
                    continue
                rec = dict(r, vote=None, error=last_err, budget_used=budget)
                break
        rec.pop("question", None)
        with lock:
            with open(out, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec) + "\n")
            done[0] += 1
            if done[0] % 100 == 0:
                print(f"[{a.level}] {done[0]}/{len(todo)}", flush=True)

    with cf.ThreadPoolExecutor(max_workers=a.concurrency) as ex:
        list(ex.map(one, todo))
    print(f"[{a.level}] finished -> {out}")


if __name__ == "__main__":
    sys.exit(main())
