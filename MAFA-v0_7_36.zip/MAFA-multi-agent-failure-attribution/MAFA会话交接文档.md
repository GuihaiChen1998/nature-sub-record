# MAFA 会话交接文档（续接用）

**版本：** v0.7.31 · **自检：** 150 passed / 0 failed · **交接时间：** 2026-09-22
**上一会话完整记录：** `RUN.md`（§1–§19，§19 是交接状态）

> 新会话开场请先读本文，再读 `RUN.md` 的 §12–§19。项目规则：**每轮对话之后更新 RUN.md**。

---

## 一、恢复环境（新会话容器是空的，必须按此重建）

### 需要重新上传的文件

| 文件 | 解压到 | 内容 |
|---|---|---|
| `MAFA-v0_7_31.zip` | `/home/claude/work/mafa/` | 代码 + 所有结果 + **进行中的运行快照** |
| `AEGIS-custom-clean-dataset.zip` | `/home/claude/work/data/clean/` | 440 条 |
| `AEGIS-custom-real-faults-dataset.zip` | `/home/claude/work/data/faulty/` | 1,112 条 |
| `AEGIS-custom-simulated-faults-dataset-副本.zip` | `/home/claude/work/data/simulated/` | 3,519 条，带注入日志 |
| `medxpertqa_images.zip` | `/home/claude/work/img/medxpertqa_images/` | 2,858 张 |
| `MedAgentAudit.zip` | `/home/claude/work/maa/` | 9.2 版，人工评测集（400 条金标） |
| `MedAgentAudit-datasets_and_logs.zip` | `/home/claude/work/maa2/` | 14,370 条 audit_results，6 个框架 |

### 恢复命令

```bash
mkdir -p /home/claude/work/{mafa,data,img,maa,maa2,runs}
cd /home/claude/work
unzip -q MAFA-v0_7_31.zip -d mafa
R=/home/claude/work/mafa/MAFA-multi-agent-failure-attribution
ln -sfn /home/claude/work/data $R/data          # 仓库 data/ 是软链接
# 三个 AEGIS 数据集分别解压进 data/clean、data/faulty、data/simulated
# 图像、MedAgentAudit 两个包按上表解压
cp -r $R/results/runs_snapshot/. /home/claude/work/runs/
cp $R/results/runs_snapshot/ab4_180_ids.txt /home/claude/work/
cp $R/scripts/keepalive_ds_armb.sh   /home/claude/work/ka11.sh
cp $R/scripts/keepalive_consistency.sh /home/claude/work/ka12.sh
chmod +x /home/claude/work/ka1*.sh
cd $R && python scripts/selfcheck_offline.py | tail -3   # 期望 150 passed / 0 failed
```

API 密钥在项目文件 `api端点` 里（aiberm/claude-opus-5、aihubmix/gpt-5.6-sol-disc、deepseek 官方、阿里 qwen、智谱 glm-5.3-flash）。

---

## 二、进行中的两个任务（可续跑，数据都在快照里）

| 任务 | 进度 | 续跑方式 |
|---|---|---|
| **deepseek-flash Arm B**（六码消融） | **137/180**，已进入最后的 MDAgents 段 | `/home/claude/work/ka11.sh`，脚本会从已完成的轨迹续跑 |
| **step 层一致性校准验证**（glm，k=5） | 206 个槽位中还有 45 个不足 5 票 | `/home/claude/work/ka12.sh`，并发已降到 5（glm 限流） |

**关键运维教训：这两个任务只在持续轮询时才会前进。** 环境会在长时间没有 bash 活动时回收后台进程；deepseek 的 Stage 1 **只在整条轨迹完成时才写盘**，一批 dylan/mdagents 轨迹要十几分钟，被回收就整批丢失、原地打转。做长时间的画图写文档时，必须在工具调用之间穿插 `ka11.sh` / `ka12.sh`。判断是否卡住要看**文件修改时间**，不要看完成计数（槽位要攒满 5 票才计数，计数器会滞后）。

---

## 三、已批准的下一步（按顺序执行）

1. **持续轮询直到 deepseek Arm B 跑完**，然后：
   - `scripts/ablate_seed.py` 跑 Stage 4（聚类 + 分诊）
   - `scripts/run_gate.py --min-cluster-size 5` 检查候选码 **c3**
     （*Role-Scope Violation: Unsolicited Answer Emission by a Coordination Agent*，全部在 `recruitment` 阶段，只有 MDAgents 有）
   - glm 的 Arm B 里 c3 是 support **9 vs 要求 10**，差一个。中途检查时 deepseek 的 novel 率是 0.65/条（glm 0.41），**但 recruitment 阶段的残差只可能出现在最后 45 条 MDAgents 里**，过门概率大约一半一半
2. **按路线 A 修改同伴可见的定义**（已与用户商定）：
   - `2.2.2` 仍然每条轨迹一个槽位，但只有当**至少一个智能体按记录确实看到了同伴**时才出现，问题范围限定到这些智能体
   - 把 `trace_spec.STAGE0_SEMANTICS` 升到 `"stage0-v2"`
3. **用跳过模式重新加载所有存档**：`load_stage1(..., on_mismatch="skip")`，得到 `PLAN_MISMATCHES` 清单
4. **重新标注清单里的轨迹**：先 glm 的两个 Arm（各约 1 小时），gpt/deepseek 的 Arm 重标或在论文里标为「修正前」
5. 同时收尾 step 层验证，把结果写进 RUN.md（§16 的补充）

**预期代价：** 每个 180 条的 Arm 约 143 条需要重标（Clinical 90 条新增槽位 + MDAgents 45 条问题范围变化 + DyLAN 单轮约 8 条失去槽位）。**但只有 `2.2.2` 的计数会变**，§15/§16 的一致性校准、`2.2.1`/`3.2.1` 的结构集中、17% 天花板机制都不受影响。

---

## 四、本会话的主要结论（写论文时要用）

### 校准（Stage 2）

| 层级 | 数据 | 单次采样 ECE | 5 次采样一致率 ECE |
|---|---|---|---|
| mode | MedAgentAudit 394 条，临床医生金标 | 0.2298 | **0.0604** |
| agent | 注入日志 220 个槽位 | 0.3227 | **0.1292** |
| step | 进行中 | — | — |

- 有监督头在伪锚点上是 0.046。**不能只报池化数字**：mode 层逐码 ECE 从 0.071 到 0.199（`1.1.1` 一致度 0.942、准确率只有 0.650）；agent 层逐框架从 0.098 到 0.304
- **自一致度对「哪些码更可靠」几乎不携带信息**：十个码一致度挤在 0.885–0.955，准确率跨 0.650–0.895，相关 −0.118
- DyLAN 的 agent 层数字不能按面值读：多轮同伴可见让注入的断言传给所有人，注入日志在那里不再是干净真值
- 七个可替换校准后端（logistic / venn_abers / logistic_va / lascal / sample_consistency / daca / consistency_distill），四个不需要标签
- DACA 的参考模型按对人类金标实测排序：glm 最好（但当时是硬判定，ECE ≡ 1−准确率）

### 路由（Stage 3）

- **`router_backend` 在 0.7.25 是死配置**，画 Stage 3 图时才发现，已接通并加行为自检
- 二元层永远不出 REVIEW；一条轨迹问题超过 6 个升级 REVIEW；队列优先级取最大值不是求和
- **空集 → Stage 4 的通道接通了但是空心的**：空集残差没有定义和引用，而且所有实验调用时 `routes=None`，从未被使用

### Stage 4

- 分诊新增 `min_code_agreement`：三次复审**吸收率稳定但指认了不同的码**，就不算被已有码覆盖（在四个归档簇上只改变了 c3）
- 合格框架在没有声明阶段时退回到**观测到的阶段分布**
- `min_support` 与聚类下限挂钩：`max(6, ⌈0.05×池⌉, 2×min_cluster_size)`，原来的 12 没有推导依据

### Stage 0（重写）

- 四个手写适配器改成四份声明式映射文件（`mafa/specs/*.json`），**在全部 5,071 条轨迹上逐字段完全一致**
- **ColaCare（未见框架）2,395 条零验证问题接入**；它有显式轮次，**70 条多轮** → `2.2.1`/`3.2.1` 不再只在一个框架合格，§8 的「结构上不可恢复」只在四框架语料下成立
- 每个能力标注来源（声明/推导/推断）。**立刻发现 `has_peer_exposure` 的声明自相矛盾**：MDAgents 声明 True，但 1734 条里没有一条出现非汇总者看到同伴；ClinicalAgent 在同样的结构理由下声明 False。结果是 MDAgents 的专家都被问了 `2.2.2`，ClinicalAgent 的合成者从没被问过
- `has_multi_round` 在 DyLAN 上是启发式恢复的：「`2.2.1`/`3.2.1` 只在 dylan」**对标注器稳健、对适配器敏感**
- 两道防护：按框架的 Stage 0 签名（拟合时记录、路由时检查）；`load_stage1` 比对存档里的槽位 key 和**问题原文**。在六个存档上零不匹配；模拟改动时精确拦住受影响的 90 条
- **修正了之前的一个解释**：分类体系签名不含问题措辞，我曾说这是有意设计，但对已归档标注不成立

### 现成统一格式的调研

- 核实过：**ATIF**（Harbor，NVIDIA/Phoenix 已采用，有 `subagent_trajectories`；RFC 里是 v1.7，grok 说的 v1.8 可能混淆了工具包版本）、**ADP**（ICLR 2026 Oral，但是单智能体 SFT 数据，「以 ATIF 为交换层」查不到依据）、OTel GenAI、Who&When、TraceElephant、IET（LLM 从纯文本恢复说话人 token 准确率 < 0.33）
- **结论：这些格式统一的是执行层（工具调用、委托树），没有一个建模协作协议层（阶段、轮次、谁看到了谁）**，而 `2.2.x` 这类故障恰恰是用后者定义的。它们适合作接入来源，不能替代 MAFA 的 Trace
- 可借鉴的高价值项：逐步的可见性边（OTel 的 input messages）、`case_id` 与 `trace_id` 分离（ATIF 的 session/trajectory）、格式版本字段、统一的归因标签块

---

## 五、已交付的文档和图（都在 zip 里）

- `figures/stage0.pdf`–`stage3.pdf`（TikZ，另有 svg/png/灰度版/源码），`framework.pdf` 已把「13 features」改为 26
- `Stage0_模块详解.md`、`Stage1_Stage2_模块详解.md`、`Stage3_模块详解.md`
- **Stage 4 的图还没画**

---

## 六、待办清单（按优先级）

**正确性相关**
- 上面第三节的路线 A 修改
- 空集残差通道：给空集残差附上该槽位的 Stage 1 finding 或步骤原文，并在实验里真正传入 `routes`
- DyLAN 轮次启发式的验证（用有显式轮次的 ColaCare 做对照）
- `run_stage1.py` 和 `panel_vs_humans.py` 还是固定 token 预算，应改成阶梯（10k→20k→40k，截断升档、限流原地退避、格式错误不重试）

**能力扩展**
- MedAgentAudit 另外 4 个新框架的映射文件（healthcareagent、mac、medagent、reconcile）
- ATIF 导入器（L2）；模型提议映射文件 + 程序化验证（L3）
- `case_id`、统一归因标签块、把病例输入作为第 0 步
- Stage 4 细化图和模块文档

**实验**
- gpt Arm B（未跑）
- 400 道人工锚点题仍未作答（模式层有监督校准和 Head B 被它卡住）
- 未消融的常数：`gamma=0.05`、`warmup=50`、`target_novel_rate=0.05`、`min_det=0.02`、`bins=10`、`k=5`、`laplace=1.0`、`max_verify_set=3`、`max_questions=6`、`support_multiple=2.0`、`min_code_agreement=0.67`、`_PHASE_INFER_MIN_SHARE=0.8`

---

## 七、端点使用要点

| 端点 | 要点 |
|---|---|
| glm-5.3-flash（智谱） | **强制思考，不能关闭**；思维链计入 `max_tokens`，用阶梯 10k/20k/40k；高并发会限流，并发 5 |
| deepseek-flash（官方） | 必须 `--reasoner-effort low --reasoner-max-tokens 24000`；**Responses 后端有 20 个 logprob 候选**（chat 后端是空的）；Stage 1 约 0.35 条/分 |
| gpt-5.6-sol-disc（aihubmix） | logprobs 只有 1 个候选（单侧、会饱和）；并发 45 会报 `cannot be served`，12 稳定 |
| claude-opus-5（aiberm） | Stage 4 的 judge，跨家族 |
| doubao/baidu-deepseek-v4.1-flash（aihubmix） | **不可用**：Stage 1 约 0.2 条/分或零产出（空输出） |

**单次调用延迟预测不了 Stage 1 吞吐**（短提示 2 秒的模型在 Stage 1 上可能最慢），选标注器必须用真实 Stage 1 冒烟测。

---

## 八、这个项目反复出现的错误模式

**「用一个便宜的代理量替代真实量，却从没在它会失效的边界上检查过」**，本会话又出现了若干次：用总票数代替逐槽位完成条件、用完成计数的增速估计剩余时间、用「成批完成」解释一个其实已经死掉的进程、单次调用延迟代替吞吐、把空字符串和格式错误都记成 `JSONDecodeError`、分类体系签名当成全部下游的保护。

**新会话里做任何状态判断之前，先确认计数器量的到底是什么。**
