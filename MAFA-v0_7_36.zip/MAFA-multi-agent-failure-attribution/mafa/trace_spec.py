"""
trace_spec.py
=============
Stage 0, rebuilt so that a new multi-agent framework is a mapping file, not a
Python adapter -- and so that every structural judgement says where it came
from.

Why the rewrite
---------------
The original Stage 0 (trace_adapter.py) has four hand-written adapters, one
per framework. It cannot ingest anything else: run on a ColaCare record from
the MedAgentAudit release, all four raise KeyError, `infer_framework` raises
ValueError, and `load_all_traces` catches that and prints `[skip]` -- so a
file from an unseen framework is dropped and the run carries on smaller.

Its design note says applicability is expressed "over structure rather than
over MAS names, so the taxonomy transfers". That is true of the taxonomy and
not of the adapters. The cost of a new framework moved from per-code (the
MedAgentAudit `applicable_mas` mask) to per-framework, which is the real
contribution -- but per-framework still meant writing and debugging code.

What prior work suggests, and what this takes from it
-----------------------------------------------------
* OpenTelemetry GenAI semantic conventions (and OpenInference, which TRAIL is
  recorded in) are the emerging interchange format: `invoke_agent` /
  `invoke_workflow` / `chat` spans in a parent-child tree, messages as
  role + parts. Anything instrumented that way needs no mapping at all. That
  importer is designed below and not yet built: there is no real OTel trace
  in this project to test it against, and writing one against a
  specification alone is how the last six silent defaults got in.
* Who&When stores a flat `history` list per task and still shows schema
  variation between its own two subsets. TraceElephant keeps trace metadata
  plus ordered step records with raw inputs and outputs. Both say the same
  thing: formats vary even inside one benchmark, so the mapping must be data,
  not code, and must fail loudly on what it does not recognise.
* Implicit Execution Tracing (arXiv 2603.17445) measured LLMs recovering who
  spoke and where turns start from plain text: token accuracy below 0.33 and
  IoU 0.11-0.19, falling as agents are added, where a plain HMM reached 0.6.
  So a model may be allowed to *propose which JSON field holds the speaker*,
  and must never be asked to *infer the speaker from the prose*. That line is
  the one this module is built along.

The layers, cheapest and most reliable first
--------------------------------------------
  L1  a declarative MappingSpec (this module). Covers any JSON dump whose
      turns can be addressed by a path, including nested per-phase layouts
      like ColaCare's. The four AEGIS adapters are re-expressed as four specs
      and reproduce the old output exactly on all 5,071 traces.
  L2  an OTel / OpenInference importer. Designed, not built -- see above.
  L3  a model proposes a MappingSpec from a few sample records; the spec is
      then validated by `validate_trace` with no model in the loop. Not built.
  L4  a hand-written adapter, as before. Last resort.

Capabilities now carry provenance
---------------------------------
Every capability records whether it was DECLARED (asserted in the spec),
DERIVED (computed from an explicit field) or INFERRED (read off the recorded
interaction), and by what method. Where a spec declares a value and inference
disagrees, both are kept and the disagreement is reported. This is the direct
answer to the finding in RUN.md: the project's most annotator-robust result
-- 2.2.1 and 3.2.1 eligible in dylan only -- rests on `has_multi_round`,
which for DyLAN comes from a re-appearance heuristic and for three other
frameworks from a constant. That is now visible on every trace instead of
buried in an adapter.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator, Optional

from .trace_adapter import (CANONICAL_PHASES, CAPABILITY_KEYS, AgentCard,
                            Step, Trace, _base_fields, _extract_context,
                            _parse_injections, verify_span)

# --------------------------------------------------------------------------- #
# Path expansion
# --------------------------------------------------------------------------- #

_TOK = re.compile(r"^([^\[\]]+)(\[\*\])?$")


def expand(obj: Any, path: str) -> Iterator[tuple[Any, list[Any]]]:
    """Yield (value, ancestors) for a dotted path with `[*]` wildcards.

    ``case_history.rounds[*].opinions[*]`` yields every opinion together with
    the chain of objects above it, so a turn can read a field from its round
    (see `get`, the `^` prefix) without the spec knowing how deep it sits.
    """
    parts = [p for p in path.split(".") if p]

    def walk(cur, i, anc):
        if i == len(parts):
            yield cur, anc
            return
        m = _TOK.match(parts[i])
        if not m or not isinstance(cur, dict):
            return
        key, star = m.group(1), m.group(2)
        nxt = cur.get(key)
        if nxt is None:
            return
        if star:
            if isinstance(nxt, list):
                for el in nxt:
                    yield from walk(el, i + 1, anc + [cur])
        else:
            yield from walk(nxt, i + 1, anc + [cur])

    yield from walk(obj, 0, [])


def get(obj: Any, path: Optional[str], ancestors: Optional[list] = None,
        default: Any = None) -> Any:
    """Read a dotted path. A leading ``^`` searches the ancestors, nearest
    first -- so ``^round`` finds the round number an opinion sits under."""
    if path is None:
        return default
    if path.startswith("^"):
        key = path[1:]
        for a in reversed(ancestors or []):
            if isinstance(a, dict):
                v = get(a, key)
                if v is not None:
                    return v
        return default
    if "[*]" in path:
        # 0.7.32: relative paths with [*] used to return None silently, so a
        # proposed `llm_input.user_message.content[*].text` -- correct against
        # the data -- produced empty inputs on every step and passed every
        # inventory-level check. Now expanded; text leaves are joined.
        head, _, tail = path.partition("[*]")
        lst = get(obj, head) if head else obj
        if not isinstance(lst, list):
            return default
        tail = tail.lstrip(".")
        vals = [get(x, tail) if tail else x for x in lst]
        vals = [v for v in vals if v is not None]
        if not vals:
            return default
        if all(isinstance(v, str) for v in vals):
            return "\n".join(vals)
        return vals
    cur = obj
    for p in path.split("."):
        if not isinstance(cur, dict):
            return default
        cur = cur.get(p)
        if cur is None:
            return default
    return cur


def _resolve(spec_val: Any, turn: Any, anc: list) -> Any:
    """A spec value is a field path, or {"const": v}."""
    if isinstance(spec_val, dict) and "const" in spec_val:
        return spec_val["const"]
    if isinstance(spec_val, str):
        return get(turn, spec_val, anc)
    return None


# --------------------------------------------------------------------------- #
# The spec
# --------------------------------------------------------------------------- #

@dataclass
class TurnSource:
    """One place in a record that turns come from.

    A flat log has one source. ColaCare has four per round -- opinions,
    synthesis, reviews, decision -- each with its own phase.
    """
    path: str
    agent: Any                               # field path or {"const": ...}
    content: list[str]                       # candidates, first non-empty wins
    phase: dict                              # see _phase
    role: Any = None
    role_index: Any = None
    round: dict = field(default_factory=lambda: {"const": 1})
    #: what the agent was shown, for inferring peer exposure
    input: Optional[str] = None
    #: order key within a round; sources are interleaved by (round, order)
    order: int = 0
    #: AEGIS turns carry their context in a known shape -- reuse the old
    #: extractor so the regression is exact rather than approximately equal
    aegis_context: bool = False
    #: DyLAN writes roles as Medical_Researcher and the old adapter turned the
    #: underscores into spaces; ClinicalAgent's did not. Kept per source so the
    #: regression against the old adapters is exact.
    role_underscores: bool = True


@dataclass
class MappingSpec:
    framework: str
    turns: list[TurnSource]
    #: filename substrings that select this spec
    match_filename: list[str] = field(default_factory=list)
    #: top-level keys that must all be present -- content-based detection, so
    #: a renamed file is still recognised
    match_keys: list[str] = field(default_factory=list)
    #: AEGIS records: take trace-level fields via the original _base_fields
    aegis_base: bool = False
    base_fields: dict = field(default_factory=dict)
    #: asserted capabilities; anything not listed is derived or inferred
    declared: dict = field(default_factory=dict)
    #: why each declaration is believed, so it can be argued with
    declared_why: dict = field(default_factory=dict)
    injections: bool = False
    #: phase used when a raw label is not in the map. Recorded, never silent.
    phase_default: str = "independent_analysis"


def _phase(rule: dict, raw: str, rnd: int) -> tuple[str, Optional[str], bool]:
    """-> (canonical phase, role recovered from the label, was_mapped)."""
    if "const" in rule:
        return rule["const"], None, True
    if "by_round" in rule:
        br = rule["by_round"]
        return br.get(str(rnd), br.get("default", "discussion")), None, True
    for pref, (ph, takes_role) in (rule.get("prefix") or {}).items():
        if raw.startswith(pref):
            rest = raw[len(pref):].strip() or None
            return ph, (rest if takes_role else None), True
    m = rule.get("map") or {}
    if raw in m:
        return m[raw], None, True
    return rule.get("default", "independent_analysis"), None, False


# --------------------------------------------------------------------------- #
# Ingestion
# --------------------------------------------------------------------------- #

def _generic_base(rec: dict, spec: MappingSpec, src: str, idx: int) -> dict:
    b = spec.base_fields
    stem = Path(src).stem
    rid = str(_resolve(b.get("id"), rec, []) or idx)
    correct = _resolve(b.get("is_correct"), rec, [])
    if correct is None and b.get("predicted") and b.get("ground_truth_answer"):
        p = _resolve(b["predicted"], rec, [])
        g = _resolve(b["ground_truth_answer"], rec, [])
        correct = (None if p is None or g is None
                   else str(p).strip() == str(g).strip())
    return dict(
        trace_id=f"{spec.framework}::{stem}#{idx:05d}#{rid}",
        framework=spec.framework, source_file=src,
        question=_resolve(b.get("question"), rec, []) or "",
        options=_resolve(b.get("options"), rec, []),
        images=[x for x in ([_resolve(b.get("images"), rec, [])] if isinstance(
            _resolve(b.get("images"), rec, []), str) else
            (_resolve(b.get("images"), rec, []) or [])) if x],
        ground_truth=_resolve(b.get("ground_truth"), rec, []),
        final_answer=_resolve(b.get("final_answer"), rec, []),
        is_correct=correct,
        outcome_split=("faulty" if correct is False else
                       "clean" if correct is True else "unknown"),
        meta={"record_id": rid, "source_stem": stem, "line_index": idx},
    )


def ingest(rec: dict, spec: MappingSpec, src: str, idx: int) -> Trace:
    base = (_base_fields(rec, spec.framework, src, idx) if spec.aegis_base
            else _generic_base(rec, spec, src, idx))

    raw_turns = []                            # (round, order, seq, turn, anc, ts)
    seq = 0
    round_sources = set()
    for ts in spec.turns:
        for turn, anc in expand(rec, ts.path):
            r = ts.round
            if "field" in r:
                v = _resolve(r["field"], turn, anc)
                try:
                    rnd = int(v)
                except (TypeError, ValueError):
                    rnd = 1
                round_sources.add("field")
            else:
                rnd = int(r.get("const", 1))
                round_sources.add("heuristic" if r.get("heuristic")
                                  else "constant")
            raw_turns.append([rnd, ts.order, seq, turn, anc, ts])
            seq += 1
    # Flat logs keep record order; nested ones interleave by round then source
    if len(spec.turns) > 1:
        raw_turns.sort(key=lambda x: (x[0], x[1], x[2]))

    steps: list[Step] = []
    seen_ctx: set[str] = set()
    unmapped: Counter = Counter()
    # the DyLAN heuristic: a new round starts when a speaker reappears
    heur = any(ts.round.get("heuristic") == "reappearance" for ts in spec.turns)
    h_round, h_seen = 1, set()
    for i, (rnd, _o, _s, turn, anc, ts) in enumerate(raw_turns, start=1):
        name = str(_resolve(ts.agent, turn, anc) or "agent")
        ri = _resolve(ts.role_index, turn, anc)
        try:
            ri = int(ri) if ri is not None else 0
        except (TypeError, ValueError):
            ri = 0
        uid = f"{name}-{ri}"
        if heur:
            if uid in h_seen:
                h_round += 1
                h_seen = set()
            h_seen.add(uid)
            rnd = h_round
        raw_phase = str(get(turn, ts.phase.get("field"), anc, "") or "") \
            if isinstance(ts.phase, dict) and ts.phase.get("field") else ""
        phase, role_from_label, mapped = _phase(ts.phase, raw_phase, rnd)
        if not mapped:
            unmapped[raw_phase] += 1
        role = role_from_label
        if role is None and ts.role is not None:
            rv = _resolve(ts.role, turn, anc)
            if rv in (None, ""):
                role = None
            else:
                role = str(rv).replace("_", " ") if ts.role_underscores else str(rv)
        content = ""
        for c in ts.content:
            v = get(turn, c, anc)
            if isinstance(v, (dict, list)):
                v = json.dumps(v, ensure_ascii=False)
            if v not in (None, ""):
                content = str(v)
                break
        if ts.aegis_context:
            ctx = _extract_context(turn, seen_ctx)
        else:
            iv = get(turn, ts.input, anc) if ts.input else None
            ctx = (json.dumps(iv, ensure_ascii=False)
                   if isinstance(iv, (dict, list)) else str(iv or ""))
        steps.append(Step(step_id=f"s{i:02d}", idx=i, round=rnd,
                          agent_uid=uid, agent_name=name, role_index=ri,
                          role=role, phase=phase, phase_raw=raw_phase,
                          content=content, context=ctx))

    trace = _assemble_with_provenance(base, steps, spec, rec, round_sources)
    trace.meta["stage0_signature"] = stage0_signature(spec)
    if unmapped:
        trace.meta["unmapped_phases"] = dict(unmapped)
    return trace


# --------------------------------------------------------------------------- #
# Capabilities, with provenance
# --------------------------------------------------------------------------- #

def _infer_peer_exposure(steps: list[Step], min_chars: int = 40) -> bool:
    """True if some step's recorded input contains an earlier step's output
    by a different agent. Read off what was actually shown, not assumed."""
    for j, s in enumerate(steps):
        if not s.context:
            continue
        for p in steps[:j]:
            if p.agent_uid == s.agent_uid or len(p.content) < min_chars:
                continue
            probe = p.content[len(p.content) // 3: len(p.content) // 3 + min_chars]
            if probe and probe in s.context:
                return True
    return False


def _infer_aggregator(steps: list[Step]) -> bool:
    """True if a synthesis or decision step comes from an agent distinct from
    at least two others who spoke before it."""
    for j, s in enumerate(steps):
        if s.phase not in ("synthesis", "decision"):
            continue
        before = {p.agent_uid for p in steps[:j] if p.agent_uid != s.agent_uid}
        if len(before) >= 2:
            return True
    return False


def _assemble_with_provenance(base: dict, steps: list[Step],
                              spec: MappingSpec, rec: dict,
                              round_sources: set) -> Trace:
    cards: dict[str, AgentCard] = {}
    for s in steps:
        c = cards.setdefault(s.agent_uid, AgentCard(
            s.agent_uid, s.agent_name, s.role_index, s.role))
        if s.role and not c.role:
            c.role = s.role
        c.step_ids.append(s.step_id)
        c.phases.append(s.phase)
    n_rounds = max((s.round for s in steps), default=0)

    method_round = ("reappearance_heuristic"
                    if any(ts.round.get("heuristic") for ts in spec.turns)
                    else "explicit_field" if "field" in round_sources
                    else "constant")
    derived = {
        "has_multi_round": (n_rounds > 1, method_round),
        "has_image": (bool(base.get("images")), "images_field"),
        "has_explicit_roles": (any(s.role for s in steps), "any_role"),
    }
    inferred = {
        "has_recruitment": (any(s.phase == "recruitment" for s in steps),
                            "a_recruitment_phase_step"),
        "has_aggregator": (_infer_aggregator(steps),
                           "synthesis_or_decision_after_two_agents"),
        "has_peer_exposure": (_infer_peer_exposure(steps),
                              "earlier_output_found_in_later_input"),
    }

    caps, prov = {}, {}
    for k in CAPABILITY_KEYS:
        if k in spec.declared:
            v = bool(spec.declared[k])
            inf = inferred.get(k) or derived.get(k)
            prov[k] = {"value": v, "source": "declared",
                       "why": spec.declared_why.get(k)}
            if inf is not None:
                prov[k]["inferred"] = inf[0]
                prov[k]["agrees"] = (inf[0] == v)
        elif k in derived:
            v, how = derived[k]
            prov[k] = {"value": v, "source": "derived", "method": how}
        else:
            v, how = inferred[k]
            prov[k] = {"value": v, "source": "inferred", "method": how}
        caps[k] = v

    tr = Trace(steps=steps, agents=list(cards.values()), n_rounds=n_rounds,
               capabilities=caps,
               injections=(_parse_injections(rec, steps)
                           if spec.injections else []),
               **base)
    tr.meta["capability_provenance"] = prov
    return tr


# --------------------------------------------------------------------------- #
# Validation contract -- no model in the loop
# --------------------------------------------------------------------------- #

def validate_trace(tr: Trace, n_probe: int = 3) -> list[str]:
    """Programmatic checks that any ingested trace must pass.

    This is what makes a model-proposed spec (L3) safe to accept, and it is
    worth running on the hand-written ones too.
    """
    bad: list[str] = []
    if not tr.steps:
        return ["no steps"]
    ids = [s.step_id for s in tr.steps]
    if len(set(ids)) != len(ids):
        bad.append("duplicate step ids")
    names: dict[str, str] = {}
    for s in tr.steps:
        if names.setdefault(s.agent_uid, s.agent_name) != s.agent_name:
            bad.append(f"uid {s.agent_uid} maps to two names")
            break
    empty = sum(1 for s in tr.steps if not s.content.strip())
    if empty:
        bad.append(f"{empty}/{len(tr.steps)} steps with empty content")
    off = [s.phase for s in tr.steps if s.phase not in CANONICAL_PHASES]
    if off:
        bad.append(f"non-canonical phases {sorted(set(off))}")
    if tr.meta.get("unmapped_phases"):
        bad.append(f"unmapped raw phases {tr.meta['unmapped_phases']}")
    # round-trip: a slice of each probed step must be found at that step
    probed = [s for s in tr.steps if len(s.content) >= 80][:n_probe]
    for s in probed:
        q = s.content[len(s.content) // 2: len(s.content) // 2 + 40]
        m = verify_span(tr, s.step_id, q)
        if not m.found or m.step_id != s.step_id:
            bad.append(f"span round-trip failed on {s.step_id}")
    prov = tr.meta.get("capability_provenance") or {}
    dis = [k for k, v in prov.items() if v.get("agrees") is False]
    if dis:
        bad.append(f"declared capability contradicted by the record: {dis}")
    return bad


# --------------------------------------------------------------------------- #
# Registry and loading
# --------------------------------------------------------------------------- #

SPECS: dict[str, MappingSpec] = {}


def register(spec: MappingSpec) -> MappingSpec:
    SPECS[spec.framework] = spec
    return spec


def detect(path: str | Path, first_record: Optional[dict] = None
           ) -> MappingSpec:
    """Filename only. Unknown is an error, never a skip -- and never a guess.

    Record shape used to be a fallback (`match_keys`). It was removed in
    0.7.32 after it mapped all four unseen MedAgentAudit frameworks
    (reconcile, mac, medagent, healthcareagent; 9,580 traces) onto the
    ColaCare spec: the release gives every framework the same envelope
    (`qid`, `case_history.rounds[*].{opinions,synthesis,reviews,decision}`),
    so "the keys match" said nothing about which framework it was. Two of
    the four then passed `validate_trace` with zero problems while labelled
    `colacare`, with peer exposure wrong and whole stages dropped. A shape
    match is now reported as a candidate in the error, never acted on.
    """
    name = Path(path).name.lower()
    # longest match first: clinical_agent5 must win over clinical_agent
    hits = [(len(f), s) for s in SPECS.values() for f in s.match_filename
            if f in name]
    if hits:
        spec = max(hits, key=lambda x: x[0])[1]
        if first_record is not None and spec.match_keys:
            missing = [k for k in spec.match_keys if k not in first_record]
            if missing:
                raise ValueError(
                    f"{name!r} matches spec {spec.framework!r} by filename but "
                    f"the record lacks its keys {missing}: same name, "
                    f"different format.")
        return spec
    cands = ([s.framework for s in SPECS.values()
              if s.match_keys and all(k in first_record for k in s.match_keys)]
             if first_record is not None else [])
    raise ValueError(
        f"no MappingSpec recognises {name!r}"
        + (f" (top-level keys {sorted(first_record)[:8]})"
           if first_record else "")
        + (f"; its shape resembles {cands}, which is NOT evidence it is that "
           f"framework -- pass spec= explicitly if it really is"
           if cands else "")
        + ". Write a spec for it -- see mafa/specs/ -- rather than letting the "
          "file be skipped or guessed.")


def load_file(path: str | Path, spec: Optional[MappingSpec] = None,
              limit: Optional[int] = None) -> list[Trace]:
    path = Path(path)
    out: list[Trace] = []
    with path.open(encoding="utf-8") as fh:
        for i, line in enumerate(fh):
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            if spec is None:
                spec = detect(path, rec)
            tr = ingest(rec, spec, path.name, i)
            if not tr.steps:
                # MedAgentAudit's mdagents_* matches the AEGIS mdagents spec by
                # name and yields zero steps per trace: a format the spec was
                # not written for. An empty trace is never a valid ingest.
                raise ValueError(
                    f"{path.name} record {i}: spec {spec.framework!r} extracted "
                    f"no steps -- the spec does not fit this file's format")
            out.append(tr)
            if limit and len(out) >= limit:
                break
    return out


def spec_from_json(d: dict) -> MappingSpec:
    d = dict(d)
    d["turns"] = [TurnSource(**t) for t in d["turns"]]
    return MappingSpec(**d)


# --------------------------------------------------------------------------- #
# Stage 0 signature
# --------------------------------------------------------------------------- #

#: Bump when the RULES change -- how capabilities are inferred, how rounds are
#: recovered, what a phase maps to -- even if no spec file changed. A spec edit
#: already changes the signature on its own.
STAGE0_SEMANTICS = "stage0-v1"


def stage0_signature(spec: MappingSpec) -> str:
    """What Stage 0 decided about one framework, as a short hash.

    Why it exists: the calibrator and router are bound to the TAXONOMY
    signature, which hashes each code's phases, requirements and
    ground-truth flag -- and nothing from Stage 0. So if a capability
    definition changes, the slot plans change, the feature distribution
    changes, and every existing signature check still passes. The
    calibrator would score the new plans by silent extrapolation, which is
    precisely what the taxonomy signature was built to stop, arriving from a
    side it cannot see.

    Per framework, not per corpus: adding a spec for ColaCare must not
    invalidate a calibrator fitted on MDAgents.
    """
    import hashlib
    d = {
        "framework": spec.framework,
        "turns": [vars(t) for t in spec.turns],
        "declared": spec.declared,
        "phase_default": spec.phase_default,
        "injections": spec.injections,
        "semantics": STAGE0_SEMANTICS,
    }
    blob = json.dumps(d, sort_keys=True, ensure_ascii=False, default=str)
    return f"S0:{spec.framework}:{hashlib.sha256(blob.encode()).hexdigest()[:10]}"


def check_stage0(fitted: dict[str, str], traces) -> list[str]:
    """Refuse traces whose framework was fitted under a different Stage 0.

    Returns the frameworks seen now but absent at fit time -- those are not
    refused, because scoring an unseen framework is what the pooled
    fallback already does today, and making it an error here would change
    results rather than protect them. A CHANGED signature is refused.
    """
    unseen: set[str] = set()
    for t in traces:
        now = (t.meta or {}).get("stage0_signature")
        was = fitted.get(t.framework)
        if was is None:
            unseen.add(t.framework)
            continue
        if now is not None and now != was:
            raise RuntimeError(
                f"Stage 0 changed for {t.framework}: calibrated under {was}, "
                f"this trace was ingested under {now}. A capability, phase or "
                f"round rule differs, so slot plans and features differ, and "
                f"the calibrator and conformal thresholds would extrapolate "
                f"silently. Re-anchor, or re-ingest under the spec the "
                f"calibration was fitted on.")
    return sorted(unseen)


def load_specs(directory: str | Path) -> int:
    n = 0
    for p in sorted(Path(directory).glob("*.json")):
        register(spec_from_json(json.loads(p.read_text(encoding="utf-8"))))
        n += 1
    return n
