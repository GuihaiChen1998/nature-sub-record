"""
mafa -- Multi-Agent Failure Attribution
=======================================
An uncertainty-aware, cost-bounded, self-evolving annotation pipeline for
multi-point failure attribution in medical multi-agent systems.

Stage 0  trace_adapter        heterogeneous traces -> unified schema + capability mask
         mast                 MAST reference taxonomy (ground truth only, never prompted)
Stage 1  annotator_client     two-call annotation (reasoner + token scorer)
         stage1_schema        slot plan, JSON contract, consistency checks
         stage1_prompt        prompt construction, outcome-blind by default
Stage 2  uncertainty          hybrid features, two-head calibration
         anchor_sampler       which slots to send to humans, and how to ask
Stage 3  conformal_router     prediction sets with coverage guarantees
Stage 4  taxonomy_evolution   residual pool -> clusters -> A/B triage -> gates
         reaudit_llm          the LLM adapters those callables need
         embeddings           OpenAI / vLLM / offline embedding backends

pipeline.Pipeline wires Stages 1-3; scripts/ drives the whole thing.
"""

from .taxonomy import (Taxonomy, FailureMode, SEED_MODES, NOVEL_CODE,
                       discovered_code, slugify)
from .trace_adapter import (Trace, Step, AgentCard, Injection, load_traces,
                            load_dir, verify_span)
from .stage1_schema import build_slot_plan, Stage1Annotation, SlotPlan, Slot
from .annotator_client import (OpenAICompatClient, ReasonerConfig, ScorerConfig,
                               annotate_trace, probe_logprob_support)
from .uncertainty import (SlotFeatures, TwoHeadCalibrator, extract_features,
                          FAMILIES, expected_agreement_gain)
from .anchor_sampler import AnchorSampler, SamplerConfig, merge_annotators
from .conformal_router import ConformalRouter, RouterConfig
from .pipeline import Pipeline, PipelineConfig, AnchorSlot, AnchorPool
from .taxonomy_evolution import (TriageConfig, GateConfig, GATE_STRICT,
                                 eligible_frameworks,
                                 ResidualFilter,
                                 normalise_code, triage_sensitivity,
                                 GATE_EXPLORATORY, GATE_CHEAP_ONLY,
                                 cluster_residuals, triage_clusters,
                                 evaluate_gate, admit, revise_scope,
                                 collect_residuals, evolution_report)
from .embeddings import make_embedder, code_centroids, suggest_distinctness_threshold
from .mast import MAST, MAST_STAGES, PRIOR_MAPPING

from .calibration_backends import (Belief, EvolutionPolicy,  # noqa: E402,F401
                                   make_calibrator, CALIBRATORS)
from .routing_backends import (make_router, ROUTERS,        # noqa: E402,F401
                               check_compatible, describe_pairing)

__version__ = "0.7.36"
