"""
anchor_sampler.py
=================
Chooses which slots to send for human adjudication after Stage 1, and packages
them as closed-form questions.

This is the bridge between Stage 1 and Stage 2, and it is the step where human
effort is either spent well or wasted.

Do NOT sample by uncertainty
----------------------------
The instinct from active learning is to annotate the slots the model is least
sure about. That is the wrong objective here, for two reasons.

*Calibration.* A calibrator fitted only on uncertain slots has never seen a
confident prediction and cannot tell you whether confident predictions are
right. Head A would be well discriminating and badly calibrated, which is the
opposite of what this pipeline needs -- the whole point is a probability you
can put a threshold on.

*Conformal validity.* Split conformal guarantees coverage only when the
calibration set and the test set are exchangeable. Uncertainty sampling makes
the calibration set a biased subsample of the slot population, the nonconformity
quantiles come out wrong, and the 1-alpha guarantee silently stops holding --
the sets still look reasonable, they just no longer certify anything.

So the default strategy is *stratified coverage*: bins across the predicted
probability range, within strata defined by the Mondrian grouping, sampled to
match the population. ``strategy="uncertainty"`` and ``"hybrid"`` exist for the
ablation, and both print a warning about what they cost.

Step slots are one question, not N
----------------------------------
The step head is multiclass -- its label is "which step is earliest" -- and
conformal needs that label for WHOLE traces, not scattered step slots. Asking
an expert N independent yes/no questions over a trace's steps is both more
expensive and worse: independent answers can name two earliest steps, or none,
and neither is a usable label.

So step slots are packaged as a single multiple-choice question per trace,
over the trace's step_ids plus "no failure". One question replaces N, the
answer is well-formed by construction, and it matches how the router will
present a step set to a human at inference time.

Budget
------
Measured on the MedAgentAudit anchor: per-group coverage becomes stable at
roughly 100 adjudicated slots per Mondrian group. With ``group_by=("kind",)``
that is ~300; with ``("kind", "framework")`` it is ~1200, which is why the
two-dimensional grouping is usually not affordable. ``plan_budget`` prints the
arithmetic so the choice is made deliberately.
"""

from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Literal, Optional, Sequence

import numpy as np

from .stage1_schema import Stage1Annotation
from .trace_adapter import Trace
from .uncertainty import SlotFeatures

Strategy = Literal["coverage", "uncertainty", "hybrid"]

#: slots per Mondrian group below which per-group coverage was unstable
RECOMMENDED_PER_GROUP = 100

#: label used when a trace contains no failure at all; must match pipeline
NONE_STEP = "__none__"


@dataclass
class AnchorTask:
    """One closed-form question for an expert."""
    trace_id: str
    framework: str
    split: str
    slot_key: str
    slot_kind: str
    code: Optional[str]
    question: str
    model_verdict: int
    model_p: Optional[float]
    stratum: str
    #: the quoted lines the expert reads instead of the whole trace
    evidence: list[dict[str, Any]] = field(default_factory=list)
    rationale: str = ""
    #: filled by the expert; kept here so one file round-trips
    human_votes: list[int] = field(default_factory=list)

    def to_json(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace_id, "framework": self.framework,
            "split": self.split, "slot_key": self.slot_key, "slot_kind": self.slot_kind,
            "code": self.code, "question": self.question,
            "stratum": self.stratum,
            "model_verdict": self.model_verdict,
            "model_p": (None if self.model_p is None
                        else round(self.model_p, 4)),
            "evidence": self.evidence, "rationale": self.rationale,
            "human_votes": self.human_votes,
            # step tasks are answered here instead of in human_votes
            **({"human_choice": None} if self.slot_kind == "step" else {}),
        }


@dataclass
class SamplerConfig:
    budget: int = 400
    strategy: Strategy = "coverage"
    #: Mondrian grouping. Include "split" whenever the corpus mixes correct
    #: and incorrect runs: measured on 92 real traces, the agent flag rate
    #: differs between them by +0.272 on dylan and by +0.02 on ClinicalAgent5,
    #: so a calibrator pooled across the two is wrong for both.
    group_by: tuple[str, ...] = ("kind",)
    #: probability bins used for coverage sampling
    n_bins: int = 5
    #: share of TRACES reserved for the frozen anti-regression pool
    frozen_share: float = 0.3
    #: cap on BINARY slots drawn from any one trace, so the pool is not
    #: dominated by a few long traces whose slots share every confound
    max_per_trace: int = 4
    #: how many traces get the one-question step task. The step head needs
    #: whole-trace labels, so this is a separate quota, not a share of budget.
    n_step_traces: int = 120
    seed: int = 0


def plan_budget(n_groups: int, budget: int) -> dict[str, Any]:
    per = budget // max(n_groups, 1)
    return {
        "n_groups": n_groups, "budget": budget, "per_group": per,
        "recommended_per_group": RECOMMENDED_PER_GROUP,
        "sufficient": per >= RECOMMENDED_PER_GROUP,
        "budget_for_recommended": n_groups * RECOMMENDED_PER_GROUP,
    }


class AnchorSampler:
    def __init__(self, cfg: SamplerConfig = SamplerConfig()) -> None:
        self.cfg = cfg

    # -- strata ----------------------------------------------------------- #
    def _group(self, f: SlotFeatures, framework: str,
               split: str = "-") -> str:
        parts = []
        for g in self.cfg.group_by:
            parts.append({"kind": f.slot_kind, "framework": framework,
                          "code": f.code or "-", "split": split}[g])
        return "|".join(parts)

    @staticmethod
    def _score_for_binning(f: SlotFeatures) -> Optional[float]:
        """What to stratify on.

        Prefer the verbalised score when it exists. On every endpoint tried so
        far `top_logprobs` comes back empty, which leaves p_token as a
        one-sided estimate that saturates -- stratifying on it produced 189 of
        247 slots at the extremes and 9 across the middle three bins, so the
        calibrator would be fitted almost entirely on confident slots and
        would have nearly nothing to learn from where routing actually
        happens.
        """
        if f.p_verbal_score is not None:
            return f.p_verbal_score
        return f.p_token

    def _bin(self, p: Optional[float]) -> str:
        if p is None:
            return "p:na"
        i = min(int(p * self.cfg.n_bins), self.cfg.n_bins - 1)
        return f"p:{i}/{self.cfg.n_bins}"

    # -- selection -------------------------------------------------------- #
    def select(
        self,
        annotations: dict[str, Stage1Annotation],
        features: dict[str, dict[str, SlotFeatures]],
        traces: Sequence[Trace],
    ) -> list[AnchorTask]:
        cfg = self.cfg
        rng = np.random.default_rng(cfg.seed)
        by_id = {t.trace_id: t for t in traces}

        if cfg.strategy != "coverage":
            print(f"[sampler] strategy={cfg.strategy!r}: this biases the "
                  "calibration set. Head A will discriminate well but "
                  "calibrate badly at the extremes, and the conformal coverage "
                  "guarantee will not hold. Use it for the ablation, not for "
                  "the anchors you report against.")

        pool: list[tuple[str, str, AnchorTask]] = []      # (group, bin, task)
        for tid, slot_feats in features.items():
            ann = annotations.get(tid)
            t = by_id.get(tid)
            if ann is None or t is None:
                continue
            slot_by_key = {s.key: s for s in ann.plan.slots}
            cards = _evidence_by_slot(ann)
            for key, f in slot_feats.items():
                slot = slot_by_key.get(key)
                if slot is None or f.slot_kind == "step":
                    continue          # step slots are handled as one task
                p = self._score_for_binning(f)
                g, b = self._group(f, t.framework, t.outcome_split), self._bin(p)
                pool.append((g, b, AnchorTask(
                    trace_id=tid, framework=t.framework,
                    split=t.outcome_split, slot_key=key,
                    slot_kind=f.slot_kind, code=f.code,
                    question=slot.question,
                    model_verdict=int(f.verdict), model_p=p,
                    stratum=f"{g}|{b}",
                    evidence=cards.get(slot.index, []),
                    rationale=_rationale(ann, slot.index),
                )))

        groups = sorted({g for g, _, _ in pool})
        plan = plan_budget(len(groups), cfg.budget)
        print(f"[sampler] {plan}")
        if not plan["sufficient"]:
            print(f"[sampler] WARNING {plan['per_group']} slots per group is "
                  f"below the ~{RECOMMENDED_PER_GROUP} at which per-group "
                  "coverage was stable. Either raise the budget to "
                  f"{plan['budget_for_recommended']} or drop a dimension from "
                  "group_by; do not report pooled coverage as if it held "
                  "per group.")

        chosen: list[AnchorTask] = []
        per_trace: Counter = Counter()
        for g in groups:
            quota = cfg.budget // len(groups)
            in_group = [(b, t) for gg, b, t in pool if gg == g]
            if cfg.strategy == "uncertainty":
                order = sorted(in_group,
                               key=lambda bt: -_informativeness(bt[1]))
                picks = [t for _, t in order]
            else:
                picks = self._coverage_picks(in_group, quota, rng)
                if cfg.strategy == "hybrid":
                    rest = sorted((t for _, t in in_group
                                   if t not in picks),
                                  key=lambda t: -_informativeness(t))
                    picks = picks[: quota // 2] + rest[: quota - quota // 2]
            taken = 0
            for t in picks:
                if taken >= quota:
                    break
                if per_trace[t.trace_id] >= cfg.max_per_trace:
                    continue
                per_trace[t.trace_id] += 1
                chosen.append(t)
                taken += 1

        chosen.extend(self._step_tasks(annotations, features, by_id, rng))
        rng.shuffle(chosen)          # so annotators do not see it sorted
        n_step = sum(1 for t in chosen if t.slot_kind == "step")
        print(f"[sampler] selected {len(chosen) - n_step} binary slots from "
              f"{len(per_trace)} traces, plus {n_step} whole-trace step "
              f"questions; strata filled: {len({t.stratum for t in chosen})}")
        return chosen

    def _step_tasks(self, annotations, features, by_id, rng) -> list[AnchorTask]:
        """One multiple-choice question per trace for the earliest fault step."""
        tids = sorted(features)
        idx = rng.permutation(len(tids))[: self.cfg.n_step_traces]
        out = []
        for i in idx:
            tid = tids[i]
            t, ann = by_id.get(tid), annotations.get(tid)
            if t is None or ann is None:
                continue
            sf = features[tid]
            probs = {k.split("::", 1)[1]: f.p_token
                     for k, f in sf.items() if f.slot_kind == "step"}
            if not probs:
                continue
            options = [{"step_id": s.step_id, "agent": s.agent_uid,
                        "phase": s.phase,
                        "preview": s.content.strip()[:160]}
                       for s in t.steps]
            options.append({"step_id": NONE_STEP, "agent": "-", "phase": "-",
                            "preview": "No failure occurs anywhere in this trace"})
            out.append(AnchorTask(
                trace_id=tid, framework=t.framework, split=t.outcome_split,
                slot_key="step::__earliest__", slot_kind="step", code=None,
                question=("At which step does a failure first appear in this "
                          "trace? Choose exactly one option, or 'no failure'."),
                model_verdict=-1,
                model_p=None,
                stratum=f"step|{t.framework}|{t.outcome_split}",
                evidence=[{"options": options,
                           "model_choice": ann.earliest_fault_step_id
                           or NONE_STEP}],
                rationale="",
            ))
        return out

    def _coverage_picks(self, in_group, quota, rng) -> list[AnchorTask]:
        """Fill probability bins proportionally to the population.

        Proportional rather than uniform: the calibration set has to look like
        the slot population, otherwise the conformal quantiles are computed on
        a distribution the test data does not follow.
        """
        by_bin: dict[str, list[AnchorTask]] = defaultdict(list)
        for b, t in in_group:
            by_bin[b].append(t)
        n = sum(len(v) for v in by_bin.values()) or 1
        out: list[AnchorTask] = []
        for b, items in sorted(by_bin.items()):
            want = max(1, int(round(quota * len(items) / n)))
            idx = rng.permutation(len(items))[:want]
            out.extend(items[i] for i in idx)
        rng.shuffle(out)
        return out

    # -- export ----------------------------------------------------------- #
    def export(self, tasks: Sequence[AnchorTask], path: str | Path,
               n_annotators: int = 3) -> dict[str, Any]:
        """Write the annotation task file.

        Each line is one closed-form question with its quoted evidence. The
        expert reads a few lines and answers yes/no; they do not re-read the
        trace. Head B needs at least two independent verdicts per slot, so the
        same file should be given to ``n_annotators`` people and merged.
        """
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as fh:
            fh.write(json.dumps({
                "_meta": {
                    "n_tasks": len(tasks), "n_annotators": n_annotators,
                    "instructions":
                        "For binary tasks answer 1 (the failure described by "
                        "the question is present) or 0 (it is not), using the "
                        "quoted evidence, and append your verdict to "
                        "human_votes. For step tasks (slot_kind='step') put "
                        "the chosen step_id in human_choice. "
                        "Do not consult model_verdict or model_p before "
                        "deciding; they are recorded for analysis only.",
                    "strata": dict(Counter(t.stratum for t in tasks)),
                }}, ensure_ascii=False) + "\n")
            for t in tasks:
                fh.write(json.dumps(t.to_json(), ensure_ascii=False) + "\n")
        if n_annotators < 2:
            print("[sampler] n_annotators=1: Head B (resolvability) cannot be "
                  "fitted from single verdicts and the queue will fall back to "
                  "ranking by model risk.")
        return {"path": str(p), "n_tasks": len(tasks),
                "n_with_evidence": sum(1 for t in tasks if t.evidence)}

    def reserve_frozen(self, tasks: Sequence[AnchorTask]) -> dict[str, set[str]]:
        """Decide, by trace, which tasks will become the frozen G4 pool.

        Decided here rather than after annotation so the split cannot be made
        to flatter the results, and recorded so it survives across taxonomy
        versions.
        """
        rng = np.random.default_rng(self.cfg.seed + 7)
        tids = sorted({t.trace_id for t in tasks})
        idx = rng.permutation(len(tids))
        n = max(1, int(round(len(tids) * self.cfg.frozen_share)))
        frozen = {tids[i] for i in idx[:n]}
        return {"frozen_trace_ids": frozen,
                "calibration_trace_ids": set(tids) - frozen}


# --------------------------------------------------------------------------- #

def _evidence_by_slot(ann: Stage1Annotation) -> dict[int, list[dict[str, Any]]]:
    out: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for f in ann.findings:
        for e in f.evidence:
            out[f.slot_index].append({
                "step_id": e.match.step_id if e.match else e.step_id,
                "quote": e.quote,
                "grounded": e.grounded,
                "match": e.match.match_kind if e.match else "none",
            })
    return out


def _rationale(ann: Stage1Annotation, slot_index: int) -> str:
    for f in ann.findings:
        if f.slot_index == slot_index:
            return f.rationale
    return ""


def _informativeness(t: AnchorTask) -> float:
    p = 0.5 if t.model_p is None else t.model_p
    return 1.0 - abs(2 * p - 1)


def load_completed(path: str | Path, min_votes: int = 1):
    """Read back an annotated task file as ``AnchorSlot`` objects."""
    from .pipeline import AnchorSlot

    out = []
    for line in Path(path).open(encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        d = json.loads(line)
        if "_meta" in d:
            continue
        if d.get("slot_kind") == "step":
            # a multiple-choice answer expands into per-step binary labels,
            # which is the form the calibrator and the step conformal both want
            chosen = d.get("human_choice")
            opts = (d.get("evidence") or [{}])[0].get("options") or []
            if not chosen or not opts:
                continue
            for o in opts:
                sid = o["step_id"]
                if sid == NONE_STEP:
                    continue
                out.append(AnchorSlot(d["trace_id"], f"step::{sid}",
                                      [1 if sid == chosen else 0]))
            continue
        votes = [int(v) for v in (d.get("human_votes") or [])]
        if len(votes) >= min_votes:
            out.append(AnchorSlot(d["trace_id"], d["slot_key"], votes))
    return out


def merge_annotators(paths: Sequence[str | Path]):
    """Merge per-annotator files into one vote list per slot."""
    from .pipeline import AnchorSlot

    votes: dict[tuple[str, str], list[int]] = defaultdict(list)
    for p in paths:
        for a in load_completed(p):
            votes[a.uid].extend(a.votes)
    slots = [AnchorSlot(tid, key, v) for (tid, key), v in votes.items()]
    n_multi = sum(1 for s in slots if len(s.votes) >= 2)
    print(f"[merge] {len(slots)} slots, {n_multi} with >=2 votes "
          f"({n_multi / max(len(slots), 1):.0%} usable for Head B)")
    return slots
