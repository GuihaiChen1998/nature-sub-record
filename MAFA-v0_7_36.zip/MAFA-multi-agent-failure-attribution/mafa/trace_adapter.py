"""
trace_adapter.py
================
Normalises raw AEGIS-custom trajectories (MDAgents / DyLAN / ClinicalAgent /
ClinicalAgent5) into a single ``Trace`` object that every downstream stage
(annotation, uncertainty estimation, conformal routing, taxonomy evolution)
can consume without knowing which framework produced it.

Design notes
------------
* ``agent_uid`` is ALWAYS ``f"{agent_name}-{role_index}"``.  Verified unique
  within a trace for all four frameworks in the AEGIS-custom dumps.
* ``role`` (medical specialty) lives in different places per framework:
    - MDAgents : encoded in ``phase`` as ``expert_answer/<Specialty>``
    - DyLAN    : IS the ``agent_name`` (Physician / Pathologist / ...)
    - Clinical*: functional role, IS the ``agent_name`` (SafetyAgent / ...)
* ``phase`` is mapped onto a *canonical* phase vocabulary so that failure-mode
  applicability can be expressed structurally instead of by MAS name (which is
  what MedAgentAudit's ``applicable_mas`` mask does, and why it does not
  transfer to DyLAN / ClinicalAgent).
* DyLAN has no explicit round marker; rounds are recovered by detecting the
  re-appearance of an already-seen ``agent_uid``.
* Every step gets a stable ``step_id`` (``s01``, ``s02``, ...).  All evidence
  spans produced in Stage 1 are anchored to ``(step_id, char_start, char_end)``
  so that groundedness can be verified programmatically.

Usage
-----
    from .trace_adapter import load_traces, ADAPTERS
    traces = load_traces("real/mdagents_fm_clean_none_none-allfalse.jsonl",
                         framework="mdagents")
    print(traces[0].render(max_chars_per_step=1200))
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass, field, asdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Optional

# --------------------------------------------------------------------------- #
# Canonical vocabulary
# --------------------------------------------------------------------------- #

#: Canonical collaboration phases.  Keep this list small and structural.
CANONICAL_PHASES = (
    "recruitment",           # roles / panel are being chosen
    "planning",              # task decomposition, orchestration
    "independent_analysis",  # an agent gives its own first opinion
    "discussion",            # agent responds to / revises after peers
    "review",                # explicit critique of another agent's output
    "synthesis",             # aggregation of several opinions
    "decision",              # final answer is emitted
)

#: Structural capabilities of a trace.  Failure-mode applicability is expressed
#: over these rather than over MAS names, so the taxonomy transfers.
CAPABILITY_KEYS = (
    "has_recruitment",       # roles are dynamically assigned  -> 2.1.1 applies
    "has_explicit_roles",    # agents carry a medical specialty -> 2.1.2 applies
    "has_multi_round",       # >1 round                        -> 2.2.x, 3.2.1
    "has_peer_exposure",     # an agent can see peers' outputs  -> 2.2.1, 2.2.2
    "has_aggregator",        # a distinct synthesiser/decider   -> 3.1.x
    "has_image",             # multimodal input                 -> 1.1.1 visual, 1.2.1
)


# --------------------------------------------------------------------------- #
# Core data model
# --------------------------------------------------------------------------- #

@dataclass
class Step:
    step_id: str                 # "s03"
    idx: int                     # 1-based position in the trace
    round: int                   # 1-based collaboration round
    agent_uid: str               # "Expert-2"
    agent_name: str              # "Expert"
    role_index: int
    role: Optional[str]          # "Musculoskeletal Radiologist"
    phase: str                   # canonical phase
    phase_raw: str               # framework-native phase string
    content: str
    #: material handed TO this agent that does not appear elsewhere in the
    #: transcript -- tool outputs, retrieved records, eligibility criteria
    context: str = ""
    n_chars: int = 0

    def __post_init__(self) -> None:
        self.n_chars = len(self.content)

    @property
    def label(self) -> str:
        who = self.agent_uid if not self.role else f"{self.agent_uid} / {self.role}"
        return f"[{self.step_id}] round {self.round} | {who} | {self.phase}"


@dataclass
class Injection:
    """One deliberately injected fault -- free ground truth.

    Present only in the simulated split. ``fm_error_type`` is a MAST code,
    NOT a MedAgentAudit one: the two taxonomies are different label spaces and
    must never be conflated. In particular this must never be shown to the
    annotator, which sees only the MedAgentAudit seed; injecting a fault by a
    MAST definition and then asking a model holding that same definition to
    find it would be circular.
    """
    agent_uid: str
    step_id: str
    step_idx: int
    fm_error_type: str                 # MAST code, e.g. "FM-2.6"
    strategy: str                      # response_corruption | prompt_injection
    description: str = ""
    #: the same agent's uncorrupted output, when the strategy preserved it
    clean_response: Optional[str] = None


@dataclass
class AgentCard:
    agent_uid: str
    agent_name: str
    role_index: int
    role: Optional[str]
    step_ids: list[str] = field(default_factory=list)
    phases: list[str] = field(default_factory=list)

    @property
    def label(self) -> str:
        return self.agent_uid if not self.role else f"{self.agent_uid} ({self.role})"


@dataclass
class Trace:
    trace_id: str
    framework: str
    source_file: str
    question: str
    options: Optional[dict[str, str]]
    images: list[str]
    ground_truth: Any
    final_answer: Any
    is_correct: Optional[bool]
    outcome_split: str                       # "faulty" | "clean" | "unknown"
    steps: list[Step]
    agents: list[AgentCard]
    n_rounds: int
    capabilities: dict[str, bool]
    meta: dict[str, Any] = field(default_factory=dict)
    #: deliberately injected faults; empty for naturally occurring traces
    injections: list[Injection] = field(default_factory=list)

    # -- free ground truth (simulated split only) ------------------------- #
    @property
    def is_simulated(self) -> bool:
        return bool(self.injections)

    @property
    def injected_agents(self) -> set[str]:
        return {i.agent_uid for i in self.injections}

    @property
    def clean_agents(self) -> set[str]:
        """Agents confirmed NOT to carry an injected fault.

        These are the known negatives, and they are what makes specificity
        measurable at all -- naturally occurring traces give you no confirmed
        negatives anywhere. Measured on AEGIS-custom-simulated: every one of
        the 3,519 traces retains at least one clean agent (injected fraction
        maxes out at 0.86), so the negatives are never empty.

        The label is 'no fault was injected here', not 'nothing went wrong
        here': a clean agent can still propagate a corrupted upstream claim.
        So this bounds specificity rather than measuring it exactly.
        """
        return set(self.agent_uids) - self.injected_agents

    @property
    def injected_steps(self) -> set[str]:
        return {i.step_id for i in self.injections}

    @property
    def earliest_injected_step(self) -> Optional[str]:
        if not self.injections:
            return None
        return min(self.injections, key=lambda i: i.step_idx).step_id

    @property
    def injected_fm_types(self) -> set[str]:
        return {i.fm_error_type for i in self.injections}

    @property
    def first_injection_idx(self) -> int:
        order = {s.step_id: s.idx for s in self.steps}
        return min((order[i.step_id] for i in self.injections
                    if i.step_id in order), default=10 ** 9)

    @property
    def upstream_clean_agents(self) -> set[str]:
        """Clean agents that finish speaking BEFORE the first injection.

        These are the only uncontestable negatives. A clean agent that speaks
        after an injection can be carried off course by the corrupted claim it
        was handed, and then genuinely fails -- so flagging it is correct
        behaviour that the injection label scores as a false positive.

        Measured on 63 simulated traces: specificity is 0.905 on upstream
        agents against 0.634 on downstream ones (z = 2.48, p = 0.013). Pooling
        them understates specificity by roughly 0.27.
        """
        cut = self.first_injection_idx
        order = {s.step_id: s.idx for s in self.steps}
        out = set()
        for uid in self.clean_agents:
            card = self.agent(uid)
            if card and all(order.get(s, 0) < cut for s in card.step_ids):
                out.add(uid)
        return out

    @property
    def downstream_clean_agents(self) -> set[str]:
        """Clean agents exposed to an upstream injection. NOT clean negatives."""
        return self.clean_agents - self.upstream_clean_agents

    # -- lookups ---------------------------------------------------------- #
    def step(self, step_id: str) -> Optional[Step]:
        return self._step_index.get(step_id)

    def agent(self, agent_uid: str) -> Optional[AgentCard]:
        return self._agent_index.get(agent_uid)

    @property
    def _step_index(self) -> dict[str, Step]:
        if not hasattr(self, "__si"):
            object.__setattr__(self, "__si", {s.step_id: s for s in self.steps})
        return getattr(self, "__si")

    @property
    def _agent_index(self) -> dict[str, AgentCard]:
        if not hasattr(self, "__ai"):
            object.__setattr__(self, "__ai", {a.agent_uid: a for a in self.agents})
        return getattr(self, "__ai")

    @property
    def step_ids(self) -> list[str]:
        return [s.step_id for s in self.steps]

    @property
    def agent_uids(self) -> list[str]:
        return [a.agent_uid for a in self.agents]

    # -- rendering -------------------------------------------------------- #
    def render(
        self,
        max_chars_per_step: int = 4000,
        include_header: bool = True,
        outcome_blind: bool = False,
    ) -> str:
        """Render the trace as the numbered transcript shown to the annotator.

        ``outcome_blind=True`` hides ground truth AND the system's final answer.
        Use it for *process-level* failure modes to avoid the confirmation bias
        that (we believe) drives MedAgentAudit's low specificity.
        """
        out: list[str] = []
        if include_header:
            out.append(f"### FRAMEWORK\n{self.framework}")
            caps = ", ".join(k for k, v in self.capabilities.items() if v) or "none"
            out.append(f"### STRUCTURAL CAPABILITIES\n{caps}")
            out.append(f"### QUESTION\n{self.question.strip()}")
            if self.options:
                opts = "\n".join(f"{k}: {v}" for k, v in self.options.items())
                out.append(f"### OPTIONS\n{opts}")
            if self.images:
                out.append(f"### IMAGE PROVIDED\nYes ({len(self.images)})")
            if not outcome_blind:
                out.append(f"### GROUND TRUTH\n{_gt_str(self.ground_truth)}")
                out.append(f"### SYSTEM FINAL ANSWER\n{self.final_answer}")
                out.append(f"### SYSTEM ANSWER CORRECT\n{self.is_correct}")
            out.append(
                "### AGENTS\n"
                + "\n".join(
                    f"- {a.agent_uid}"
                    + (f" | role: {a.role}" if a.role else "")
                    + f" | steps: {', '.join(a.step_ids)}"
                    for a in self.agents
                )
            )
        out.append("### TRANSCRIPT")
        for s in self.steps:
            body = s.content.strip()
            if len(body) > max_chars_per_step:
                body = body[:max_chars_per_step] + "\n[... TRUNCATED ...]"
            block = s.label
            if s.context:
                ctx = s.context.strip()
                if len(ctx) > max_chars_per_step:
                    ctx = ctx[:max_chars_per_step] + "\n[... TRUNCATED ...]"
                block += ("\n  [INPUT PROVIDED TO THIS AGENT -- tool outputs "
                          "and case material it was given, not its own claims]\n"
                          + "\n".join("  | " + ln for ln in ctx.splitlines()))
            out.append(f"{block}\n{body}")
        return "\n\n".join(out)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d


def _gt_str(gt: Any) -> str:
    if isinstance(gt, dict):
        if "correct_answer" in gt:
            txt = gt.get("answer_text")
            return f"{gt['correct_answer']}" + (f" ({txt})" if txt else "")
        return json.dumps(gt, ensure_ascii=False)
    return str(gt)


# --------------------------------------------------------------------------- #
# Evidence-span verification (feeds the "groundedness" uncertainty signal)
# --------------------------------------------------------------------------- #

_WS = re.compile(r"\s+")


def _norm(t: str) -> str:
    t = unicodedata.normalize("NFKC", t)
    t = t.replace("\u201c", '"').replace("\u201d", '"')
    t = t.replace("\u2018", "'").replace("\u2019", "'")
    t = t.replace("\u2014", "-").replace("\u2013", "-")
    return _WS.sub(" ", t).strip().lower()


@dataclass
class SpanMatch:
    found: bool
    step_id: Optional[str]
    char_start: int = -1
    char_end: int = -1
    score: float = 0.0            # 1.0 exact, [0,1) fuzzy
    match_kind: str = "none"      # exact | normalised | fuzzy | none
    relocated: bool = False       # quote was real but in a DIFFERENT step


def verify_span(
    trace: Trace,
    step_id: Optional[str],
    quote: str,
    fuzzy_floor: float = 0.82,
    search_all_steps: bool = True,
) -> SpanMatch:
    """Locate ``quote`` inside the trace and report how well it is grounded.

    Returns ``match_kind == "none"`` when the annotator fabricated the quote --
    in our experience by far the strongest single hallucination signal for this
    task, and it costs zero extra API calls.
    """
    if not quote or not quote.strip():
        return SpanMatch(False, step_id)

    order = []
    if step_id and trace.step(step_id):
        order.append(trace.step(step_id))
    if search_all_steps:
        order += [s for s in trace.steps if s.step_id != step_id]

    q_raw, q_norm = quote.strip(), _norm(quote)
    if not q_norm:
        return SpanMatch(False, step_id)

    for kind in ("exact", "normalised"):
        for s in order:
            hay = s.content if kind == "exact" else _norm(s.content)
            needle = q_raw if kind == "exact" else q_norm
            pos = hay.find(needle)
            if pos >= 0:
                return SpanMatch(
                    True, s.step_id, pos, pos + len(needle),
                    1.0, kind, relocated=(s.step_id != step_id),
                )

    best = SpanMatch(False, step_id)
    for s in order:
        hay = _norm(s.content)
        if not hay:
            continue
        sm = SequenceMatcher(None, q_norm, hay, autojunk=False)
        blocks = sm.get_matching_blocks()
        if not blocks:
            continue
        b = max(blocks, key=lambda x: x.size)
        cover = b.size / max(len(q_norm), 1)
        if cover > best.score:
            best = SpanMatch(
                cover >= fuzzy_floor, s.step_id, b.b, b.b + b.size,
                cover, "fuzzy" if cover >= fuzzy_floor else "none",
                relocated=(s.step_id != step_id),
            )
    return best


# --------------------------------------------------------------------------- #
# Framework adapters
# --------------------------------------------------------------------------- #

_CTX_MIN_LINE = 24


def _extract_context(turn: dict, seen: set[str]) -> str:
    """Novel material from ``input_messages`` that the transcript does not show.

    Sub-agents in retrieval-style pipelines are handed tool outputs -- historical
    failure rates, DrugBank records, eligibility criteria -- in their prompt.
    Those numbers then appear in the agent's answer while appearing nowhere in
    the transcript, so an auditor reading only the outputs scores them as
    fabrications. Measured before this was added: on ClinicalAgent5, upstream
    sub-agents doing retrieval analysis were flagged at 0.44-0.50 specificity
    against 0.82 for the planner, and 1.1.1 (factual hallucination) was the code
    cited 13 times out of 32. Every one of those was a number the system had
    supplied.

    Only the *user* message is used, and only lines not already seen: in debate
    frameworks the prompt restates the whole prior conversation, and echoing it
    back would double the transcript for no information.
    """
    msgs = turn.get("input_messages")
    if not isinstance(msgs, list):
        return ""
    out: list[str] = []
    for m in msgs:
        if not isinstance(m, dict) or m.get("role") != "user":
            continue
        for line in str(m.get("content") or "").splitlines():
            t = line.strip()
            if len(t) < _CTX_MIN_LINE:
                continue
            key = _norm(t)
            if key in seen:
                continue
            seen.add(key)
            out.append(t)
    return "\n".join(out)


def _base_fields(rec: dict, framework: str, src: str, idx: int) -> dict:
    ilog = rec.get("injection_log", {}) or {}
    # The record ``id`` is NOT unique. Measured on AEGIS-custom: 10 ids repeat
    # inside a single faulty file, and 3 more appear in both the faulty and the
    # clean file for the same framework. Keying on ``framework::id`` alone
    # silently overwrites 13 traces -- silently, because they land in a dict.
    # The source file and line index make the key unique by construction; the
    # original id is preserved in meta so records can still be traced back.
    raw_id = rec.get("id")
    stem = Path(src).stem
    tid = f"{stem}#{idx:05d}" + (f"#{raw_id}" if raw_id else "")
    return dict(
        trace_id=f"{framework}::{tid}",
        framework=framework,
        source_file=src,
        question=rec.get("query", "") or "",
        options=rec.get("options"),
        images=list(rec.get("images") or []),
        ground_truth=rec.get("ground_truth"),
        final_answer=rec.get("answer"),
        is_correct=rec.get("is_correct"),
        outcome_split=(
            "simulated" if (ilog.get("multi_injection_info") or [])
            else "faulty" if rec.get("is_correct") is False
            else "clean" if rec.get("is_correct") is True
            else "unknown"
        ),
        meta={
            "record_id": raw_id,
            "source_stem": stem,
            "line_index": idx,
            "difficulty": ilog.get("difficulty"),
            "run_mode": rec.get("run_mode"),
            "medical_task": rec.get("medical_task"),
            "body_system": rec.get("body_system"),
            "question_type": rec.get("question_type"),
            "num_injected_agents": ilog.get("num_injected_agents"),
            "fm_error_types": rec.get("fm_error_types"),
            "source_config_label": rec.get("_source_config_label"),
            "round_settings": ilog.get("round_settings"),
            "status": rec.get("status"),
            "final_response": rec.get("response"),
        },
    )


def _agent_uid(turn: dict) -> str:
    """The universal identity rule: ``agent_name-role_index``."""
    return f"{turn.get('agent_name', 'agent')}-{turn.get('role_index', 0)}"


def _parse_injections(rec: dict, steps: list[Step]) -> list[Injection]:
    """Recover ground truth from the per-step injection markers.

    ``multi_injection_info`` names the agent and MAST code but not the step;
    the step comes from the ``injection_applied`` flag that the injector wrote
    onto each affected turn, which is more precise -- an agent injected once
    may speak in several rounds, and only some of those turns are corrupted.
    """
    ilog = rec.get("injection_log") or {}
    turns = ilog.get("conversation_history") or []
    declared = {
        f"{d.get('injected_role')}-{d.get('injected_role_index')}":
            (d.get("fm_error_type"), d.get("injection_strategy"))
        for d in (ilog.get("multi_injection_info") or [])
    }
    out: list[Injection] = []
    for st, turn in zip(steps, turns):
        if not turn.get("injection_applied"):
            continue
        fm, strat = declared.get(st.agent_uid, (None, None))
        out.append(Injection(
            agent_uid=st.agent_uid, step_id=st.step_id, step_idx=st.idx,
            fm_error_type=turn.get("fm_error_type") or fm or "UNKNOWN",
            strategy=turn.get("injection_strategy") or strat or "unknown",
            description=str(turn.get("injection_description") or "")[:2000],
            clean_response=turn.get("clean_response_before_corruption"),
        ))
    # an agent declared injected whose turns carry no marker still counts,
    # attributed to its first turn, so recall is not silently inflated
    marked = {i.agent_uid for i in out}
    for uid, (fm, strat) in declared.items():
        if uid in marked:
            continue
        first = next((s for s in steps if s.agent_uid == uid), None)
        if first is not None:
            out.append(Injection(uid, first.step_id, first.idx,
                                 fm or "UNKNOWN", strat or "unknown",
                                 "declared but no per-turn marker"))
    return sorted(out, key=lambda i: (i.step_idx, i.agent_uid))


def _assemble(base: dict, steps: list[Step], caps: dict[str, bool],
              rec: Optional[dict] = None) -> Trace:
    cards: dict[str, AgentCard] = {}
    for s in steps:
        c = cards.setdefault(
            s.agent_uid,
            AgentCard(s.agent_uid, s.agent_name, s.role_index, s.role),
        )
        if s.role and not c.role:
            c.role = s.role
        c.step_ids.append(s.step_id)
        c.phases.append(s.phase)
    n_rounds = max((s.round for s in steps), default=0)
    caps = dict(caps)
    caps["has_multi_round"] = n_rounds > 1
    caps["has_image"] = bool(base["images"])
    caps.setdefault("has_explicit_roles", any(s.role for s in steps))
    for k in CAPABILITY_KEYS:
        caps.setdefault(k, False)
    return Trace(
        steps=steps,
        agents=list(cards.values()),
        n_rounds=n_rounds,
        capabilities=caps,
        injections=_parse_injections(rec, steps) if rec else [],
        **base,
    )


# ---- MDAgents -------------------------------------------------------------- #

_MD_PHASE = {
    "recruitment": "recruitment",
    "aggregation": "decision",
}


def adapt_mdagents(rec: dict, src: str, idx: int) -> Trace:
    base = _base_fields(rec, "mdagents", src, idx)
    steps: list[Step] = []
    seen: set[str] = set()
    for i, t in enumerate(rec["injection_log"]["conversation_history"], start=1):
        raw = t.get("phase") or ""
        role = None
        if raw.startswith("expert_answer/"):
            role = raw.split("/", 1)[1].strip() or None
            phase = "independent_analysis"
        else:
            phase = _MD_PHASE.get(raw, "independent_analysis")
        steps.append(Step(
            step_id=f"s{i:02d}", idx=i, round=1,
            agent_uid=_agent_uid(t), agent_name=t.get("agent_name", "agent"),
            role_index=int(t.get("role_index", 0)), role=role,
            phase=phase, phase_raw=raw,
            content=t.get("content") or t.get("response") or "",
            context=_extract_context(t, seen),
        ))
    return _assemble(base, steps, {
        "has_recruitment": True,
        "has_peer_exposure": True,     # the Aggregator sees all expert answers
        "has_aggregator": True,
    }, rec)


# ---- DyLAN ----------------------------------------------------------------- #

def adapt_dylan(rec: dict, src: str, idx: int) -> Trace:
    """DyLAN emits a flat list of ``reasoning`` turns; rounds are recovered by
    detecting when an already-seen agent speaks again."""
    base = _base_fields(rec, "dylan", src, idx)
    steps: list[Step] = []
    ctx_seen: set[str] = set()
    rnd, seen = 1, set()
    for i, t in enumerate(rec["injection_log"]["conversation_history"], start=1):
        uid = _agent_uid(t)
        if uid in seen:
            rnd += 1
            seen = set()
        seen.add(uid)
        steps.append(Step(
            step_id=f"s{i:02d}", idx=i, round=rnd,
            agent_uid=uid, agent_name=t.get("agent_name", "agent"),
            role_index=int(t.get("role_index", 0)),
            role=str(t.get("agent_name", "")).replace("_", " ") or None,
            # round 1 = own opinion; later rounds = the agent has seen its peers
            phase="independent_analysis" if rnd == 1 else "discussion",
            phase_raw=t.get("phase") or "",
            content=t.get("content") or t.get("response") or "",
            context=_extract_context(t, ctx_seen),
        ))
    return _assemble(base, steps, {
        "has_recruitment": False,      # roles are fixed a priori
        "has_peer_exposure": True,
        "has_aggregator": False,       # no distinct synthesiser -> 3.1.x is weak
    }, rec)


# ---- ClinicalAgent / ClinicalAgent5 ---------------------------------------- #

_CLIN_PHASE = {
    "decomposition": "planning",
    "decomposition_coordination": "planning",
    "orchestration": "planning",
    "safety_analysis": "independent_analysis",
    "efficacy_analysis": "independent_analysis",
    "enrollment_analysis": "independent_analysis",
    "final_synthesis": "decision",
}


def _adapt_clinical(rec: dict, src: str, idx: int, framework: str) -> Trace:
    base = _base_fields(rec, framework, src, idx)
    steps: list[Step] = []
    seen: set[str] = set()
    for i, t in enumerate(rec["injection_log"]["conversation_history"], start=1):
        raw = t.get("phase") or ""
        steps.append(Step(
            step_id=f"s{i:02d}", idx=i, round=1,
            agent_uid=_agent_uid(t), agent_name=t.get("agent_name", "agent"),
            role_index=int(t.get("role_index", 0)),
            role=t.get("agent_name") or None,
            phase=_CLIN_PHASE.get(raw, "independent_analysis"), phase_raw=raw,
            content=t.get("content") or t.get("response") or "",
            context=_extract_context(t, seen),
        ))
    return _assemble(base, steps, {
        "has_recruitment": False,
        # pipeline: sub-agents work in parallel and never see each other, only
        # the synthesiser does -> 2.2.1 / 2.2.2 (debate modes) do NOT apply.
        "has_peer_exposure": False,
        "has_aggregator": True,
    }, rec)


def adapt_clinical_agent(rec, src, idx):   # noqa: D103
    return _adapt_clinical(rec, src, idx, "clinical_agent")


def adapt_clinical_agent5(rec, src, idx):  # noqa: D103
    return _adapt_clinical(rec, src, idx, "clinical_agent5")


ADAPTERS: dict[str, Callable[[dict, str, int], Trace]] = {
    "mdagents": adapt_mdagents,
    "dylan": adapt_dylan,
    "clinical_agent": adapt_clinical_agent,
    "clinical_agent5": adapt_clinical_agent5,
}


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #

def infer_framework(path: str | Path) -> str:
    name = Path(path).name.lower()
    # order matters: clinical_agent5 before clinical_agent
    for fw in ("clinical_agent5", "clinical_agent", "mdagents", "dylan"):
        if fw in name:
            return fw
    raise ValueError(f"cannot infer framework from filename: {name}")


def load_traces(
    path: str | Path,
    framework: Optional[str] = None,
    limit: Optional[int] = None,
) -> list[Trace]:
    path = Path(path)
    fw = framework or infer_framework(path)
    adapt = ADAPTERS[fw]
    out: list[Trace] = []
    with path.open(encoding="utf-8") as fh:
        for i, line in enumerate(fh):
            line = line.strip()
            if not line:
                continue
            out.append(adapt(json.loads(line), path.name, i))
            if limit and len(out) >= limit:
                break
    return out


def load_dir(root: str | Path, limit_per_file: Optional[int] = None) -> Iterator[Trace]:
    for p in sorted(Path(root).rglob("*.jsonl")):
        try:
            fw = infer_framework(p)
        except ValueError:
            continue
        yield from load_traces(p, fw, limit_per_file)
