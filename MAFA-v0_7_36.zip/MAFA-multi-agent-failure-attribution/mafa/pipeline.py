"""
pipeline.py
===========
Wires Stage 1 (annotation), Stage 2 (two-head calibration) and Stage 3
(conformal routing) into one runnable flow, and persists everything at each
boundary so a crashed run resumes instead of re-billing.

    from .pipeline import Pipeline, PipelineConfig
    pl = Pipeline(client, taxonomy, PipelineConfig(work_dir="run01"))
    pl.annotate(traces)                     # Stage 1  -> stage1.jsonl
    pl.fit(anchors)                         # Stage 2+3 -> calibrator + router
    routes = pl.route(traces)               # Stage 3  -> routes.jsonl
    pl.export_buckets(traces, routes)       # corpus / queue / residual pool

Order of operations matters and is easy to get wrong
----------------------------------------------------
The calibrator and the conformal router must be fitted on DISJOINT anchor
subsets.  If the router calibrates on the same slots the calibrator was fitted
on, the nonconformity scores are optimistically small and the coverage
guarantee silently evaporates -- the sets come out too tight and the automation
rate looks great right up until you check it against held-out humans.
``fit()`` enforces the split.

Head B needs multiple annotators
--------------------------------
``AnchorSlot.votes`` carries every human verdict for that slot.  With one
annotator, Head B cannot be fitted; the pipeline says so and falls back to
ranking the queue by ``model_risk`` alone, rather than pretending to have a
resolvability estimate it does not have.
"""

from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

from .annotator_client import (OpenAICompatClient, ReasonerConfig, ScorerConfig,
                              Stage1Result, annotate_trace,
                              probe_logprob_support)
from .conformal_router import (ConformalRouter, RouterConfig, TraceRoute,
                              evaluate_binary_coverage)
from .stage1_schema import (Slot, SlotPlan, Stage1Annotation, build_slot_plan,
                           parse_reasoner_output)
from .taxonomy import Taxonomy
from .trace_adapter import Trace
from .uncertainty import (SlotFeatures, TwoHeadCalibrator, expected_agreement_gain,
                         extract_features, model_risk, risk_coverage)

NONE_STEP = "__none__"


# --------------------------------------------------------------------------- #
# Anchors
# --------------------------------------------------------------------------- #

@dataclass
class AnchorSlot:
    """One human-adjudicated slot."""
    trace_id: str
    slot_key: str
    votes: list[int]                    # one entry per annotator

    @property
    def label(self) -> int:
        return 1 if sum(self.votes) >= len(self.votes) / 2 else 0

    @property
    def unanimous(self) -> Optional[int]:
        if len(self.votes) < 2:
            return None
        return 1 if sum(self.votes) in (0, len(self.votes)) else 0

    @property
    def uid(self) -> tuple[str, str]:
        return (self.trace_id, self.slot_key)

    @classmethod
    def load(cls, path: str | Path) -> list["AnchorSlot"]:
        out = []
        for line in Path(path).open(encoding="utf-8"):
            line = line.strip()
            if line:
                d = json.loads(line)
                out.append(cls(d["trace_id"], d["slot_key"],
                               [int(v) for v in d["votes"]]))
        return out


class AnchorPool:
    """The two anchor sets, kept structurally apart.

    ``calibration`` fits Head A, Head B and the conformal quantiles. It SHOULD
    grow as more slots are adjudicated; refitting on a larger pool is normal
    and desirable.

    ``frozen`` is the anti-regression set that gate G4 measures against, and it
    MUST NOT change between taxonomy versions. If it is refreshed each round,
    "the candidate did not degrade the anchor set" compares two different
    rulers, and the taxonomy can drift for several versions while every step
    looks locally like an improvement. That is the only thing G4 exists to
    catch, so the pool carries a fingerprint and ``check_frozen`` raises if it
    has moved.

    The two pools must be disjoint: scoring G4 on slots the calibrator was
    fitted on measures memorisation, not generalisation.
    """

    def __init__(self, calibration: Sequence[AnchorSlot],
                 frozen: Sequence[AnchorSlot]) -> None:
        self.calibration = list(calibration)
        self.frozen = list(frozen)
        overlap = {a.uid for a in self.calibration} & {a.uid for a in self.frozen}
        if overlap:
            raise ValueError(
                f"{len(overlap)} slots appear in both pools, e.g. "
                f"{sorted(overlap)[:3]}. G4 measured on calibration slots is "
                "not an anti-regression test.")
        self._fingerprint = self.fingerprint()

    # -- integrity -------------------------------------------------------- #
    def fingerprint(self) -> str:
        import hashlib
        h = hashlib.sha256()
        for a in sorted(self.frozen, key=lambda x: x.uid):
            h.update(f"{a.trace_id}\x00{a.slot_key}\x00"
                     f"{','.join(map(str, a.votes))}\n".encode())
        return h.hexdigest()[:16]

    def check_frozen(self) -> None:
        now = self.fingerprint()
        if now != self._fingerprint:
            raise RuntimeError(
                f"the frozen anchor pool changed ({self._fingerprint} -> {now}). "
                "G4 results before and after this point are not comparable; "
                "either restore the pool or start a new taxonomy lineage.")

    @property
    def frozen_labels(self) -> dict[tuple[str, str], int]:
        return {a.uid: a.label for a in self.frozen}

    # -- construction ----------------------------------------------------- #
    @classmethod
    def split(cls, anchors: Sequence[AnchorSlot], frozen_share: float = 0.3,
              seed: int = 0) -> "AnchorPool":
        """Split by TRACE, not by slot.

        Slots from one trace share an annotator, a transcript and a set of
        violations, so splitting at slot level leaks the frozen pool into the
        calibration pool.
        """
        import numpy as np

        tids = sorted({a.trace_id for a in anchors})
        rng = np.random.default_rng(seed)
        idx = rng.permutation(len(tids))
        n_frozen = max(1, int(round(len(tids) * frozen_share)))
        frozen_ids = {tids[i] for i in idx[:n_frozen]}
        return cls([a for a in anchors if a.trace_id not in frozen_ids],
                   [a for a in anchors if a.trace_id in frozen_ids])

    def save(self, path: str | Path) -> None:
        with Path(path).open("w", encoding="utf-8") as fh:
            fh.write(json.dumps({"_fingerprint": self._fingerprint}) + "\n")
            for pool, items in (("calibration", self.calibration),
                                ("frozen", self.frozen)):
                for a in items:
                    fh.write(json.dumps({"pool": pool, "trace_id": a.trace_id,
                                         "slot_key": a.slot_key,
                                         "votes": a.votes}) + "\n")

    @classmethod
    def load(cls, path: str | Path) -> "AnchorPool":
        cal, frz, want = [], [], None
        for line in Path(path).open(encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            if "_fingerprint" in d:
                want = d["_fingerprint"]
                continue
            a = AnchorSlot(d["trace_id"], d["slot_key"],
                           [int(v) for v in d["votes"]])
            (frz if d["pool"] == "frozen" else cal).append(a)
        pool = cls(cal, frz)
        if want and pool._fingerprint != want:
            raise RuntimeError(
                f"frozen pool fingerprint mismatch on load: file says {want}, "
                f"contents hash to {pool._fingerprint}")
        return pool

    def __repr__(self) -> str:
        return (f"AnchorPool(calibration={len(self.calibration)}, "
                f"frozen={len(self.frozen)}, fp={self._fingerprint})")


@dataclass
class PipelineConfig:
    work_dir: str = "run"
    mode_granularity: str = "trace"
    alpha: float = 0.10
    #: fraction of anchors used to FIT the calibrator; the rest calibrates
    #: the conformal quantiles
    calibrator_share: float = 0.5
    group_by: tuple[str, ...] = ("kind", "framework")
    seed: int = 0
    max_verify_set: int = 3
    max_questions: int = 6
    #: Stage 2 / Stage 3 backends. The pair decides whether the loop can turn
    #: a second time without re-anchoring -- see routing_backends.
    #: describe_pairing. Defaults reproduce the pre-0.7.25 behaviour exactly.
    calibrator_backend: str = "logistic"
    router_backend: str = "split"
    #: Stage 4 (residual clustering, triage, taxonomy growth). Off unless the
    #: user asks: it changes the label space and voids prior calibration.
    enable_evolution: bool = False
    #: ACI only
    aci_gamma: float = 0.05
    aci_warmup: int = 50


# --------------------------------------------------------------------------- #

class Pipeline:
    def __init__(self, client: OpenAICompatClient, taxonomy: Taxonomy,
                 cfg: PipelineConfig = PipelineConfig(),
                 rcfg: ReasonerConfig = ReasonerConfig(),
                 scfg: ScorerConfig = ScorerConfig(),
                 image_store=None) -> None:
        #: optional ImageStore. When set, a trace's own images are attached to
        #: the annotator's prompt. Off by default: turning it on makes the
        #: annotations a new measurement that cannot be pooled with any
        #: text-only run, so the only sound use is a paired comparison.
        self.image_store = image_store
        self.client = client
        self.tax = taxonomy
        self.cfg = cfg
        self.rcfg = ReasonerConfig(**{**asdict(rcfg),
                                      "mode_granularity": cfg.mode_granularity})
        self.scfg = scfg
        self.dir = Path(cfg.work_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.calibrator: Optional[TwoHeadCalibrator] = None
        self.router: Optional[ConformalRouter] = None
        self.annotations: dict[str, Stage1Annotation] = {}
        self.fit_report: dict[str, Any] = {}
        self.anchor_pool: Optional[AnchorPool] = None
        #: slot index -> outcome split, filled by features(); only needed when
        #: "split" is one of the Mondrian grouping dimensions
        self._split_of: dict[int, str] = {}

    # -- Stage 1 ---------------------------------------------------------- #
    def annotate(self, traces: Sequence[Trace], resume: bool = True,
                 retry_failed: bool = True
                 ) -> dict[str, Stage1Annotation]:
        out_path = self.dir / "stage1.jsonl"
        done: set[str] = set()
        failed: set[str] = set()
        if resume and out_path.exists():
            for line in out_path.open(encoding="utf-8"):
                d = json.loads(line)
                if d.get("status") == "failed" or d.get("annotation") is None:
                    failed.add(d["trace_id"])
                else:
                    done.add(d["trace_id"])
                    failed.discard(d["trace_id"])
            # Recorded failures are retried by default. Some are intermittent
            # and a second attempt gets them; the ones that are not will be
            # re-recorded, which costs one call and keeps the gap honest.
            # Pass retry_failed=False to freeze a run's coverage instead.
            if not retry_failed:
                done |= failed
            print(f"[stage1] resuming, {len(done)} annotated"
                  + (f", {len(failed)} failed"
                     + (" (will retry)" if retry_failed else " (frozen)")
                     if failed else ""))

        available = probe_logprob_support(self.client, self.scfg)
        print(f"[stage1] logprobs on {self.scfg.model}: {available}")
        if not available:
            print("[stage1] WARNING falling back to verbalised 0-100 scoring; "
                  "p_token_missing will be set on every slot")

        with out_path.open("a", encoding="utf-8") as fh:
            for i, t in enumerate(traces, 1):
                if t.trace_id in done:
                    continue
                blocks, img_dropped = ([], [])
                if self.image_store is not None:
                    blocks, img_dropped = self.image_store.blocks(t)
                r: Stage1Result = annotate_trace(
                    t, self.tax, self.client, self.rcfg, self.scfg, available,
                    image_blocks=blocks or None)
                if r.annotation is None:
                    # Record the failure instead of only printing it. A trace
                    # that vanishes here leaves no trace_id in the file, so a
                    # paired comparison downstream cannot tell "annotated and
                    # found nothing" from "never annotated", and `resume`
                    # retries it forever.
                    #
                    # `error_class` matters more than it looks. A run that hits
                    # a spent API key records dozens of failures that look
                    # exactly like the model returning empty content, and
                    # pooling them inflates the per-framework failure rate --
                    # a 41% figure for mdagents turned out to be mostly a
                    # billing outage. Infrastructure failures are waited out
                    # and retried; model failures mean the trace is dropped and
                    # the gap reported. Only the second kind is a finding.
                    err = str(r.error or "")
                    if "402" in err or "Insufficient Balance" in err:
                        klass = "infra_quota"
                    elif "429" in err or "Too many requests" in err:
                        klass = "infra_rate_limit"
                    elif "timeout" in err.lower() or "Connection" in err:
                        klass = "infra_network"
                    elif "Expecting value" in err or "JSONDecode" in err:
                        # the model spent its whole output budget on reasoning
                        # and emitted nothing; see RUN.md on deepseek-flash
                        klass = "model_empty_output"
                    else:
                        klass = "other"
                    print(f"[stage1] {t.trace_id}: [{klass}] {r.error}")
                    fh.write(json.dumps({
                        "trace_id": t.trace_id,
                        "framework": t.framework,
                        "status": "failed",
                        "error_class": klass,
                        "error": r.error,
                        "annotation": None,
                    }, ensure_ascii=False) + "\n")
                    fh.flush()
                    continue
                fh.write(json.dumps({
                    "trace_id": t.trace_id,
                    "framework": t.framework,
                    "status": "ok",
                    # what the annotator actually saw. Without this a file
                    # cannot be told apart from a text-only run of the same
                    # traces, and the paired comparison this feature exists
                    # for would have no way to verify its own arms.
                    "n_images_sent": len(blocks),
                    "images_dropped": img_dropped or None,
                    "outcome_shown": r.outcome_shown,
                    "scorer_regime": r.scorer_regime,
                    "n_scorer_calls": r.n_scorer_calls,
                    "violations": r.annotation.violations,
                    "annotation": r.annotation.to_dict(),
                }, ensure_ascii=False) + "\n")
                fh.flush()
                self.annotations[t.trace_id] = r.annotation
                if i % 25 == 0:
                    print(f"[stage1] {i}/{len(traces)}")
        return self.annotations

    # -- features --------------------------------------------------------- #
    def features(self, traces: Sequence[Trace]
                 ) -> dict[str, dict[str, SlotFeatures]]:
        """trace_id -> slot_key -> features."""
        by_id = {t.trace_id: t for t in traces}
        out: dict[str, dict[str, SlotFeatures]] = {}
        for tid, ann in self.annotations.items():
            t = by_id.get(tid)
            if t is None:
                continue
            feats = extract_features(ann, t)
            split_of = getattr(self, "_split_of", None)
            if split_of is None:
                split_of = self._split_of = {}
            for f in feats:
                split_of[f.slot_index] = t.outcome_split
            out[tid] = {ann.plan.slots[f.slot_index].key: f for f in feats}
        return out

    # -- Stage 2 + 3 ------------------------------------------------------ #
    def fit(self, anchors: "Sequence[AnchorSlot] | AnchorPool",
            traces: Sequence[Trace]) -> dict[str, Any]:
        import numpy as np

        if isinstance(anchors, AnchorPool):
            anchors.check_frozen()
            self.anchor_pool = anchors
            anchors_cal: Sequence[AnchorSlot] = anchors.calibration
        else:
            print("[fit] NOTE a bare anchor list was given, so there is no "
                  "frozen pool and gate G4 cannot be evaluated. Use "
                  "AnchorPool.split(anchors) to reserve one.")
            self.anchor_pool = None
            anchors_cal = anchors
        anchors = anchors_cal

        sig = self.tax.signature()
        # Record the Stage 0 each framework was calibrated under. Only the
        # taxonomy signature was bound before, and it hashes nothing from
        # Stage 0 -- see trace_spec.stage0_signature.
        self.stage0_signatures = {}
        for t in traces:
            s0 = (t.meta or {}).get("stage0_signature")
            if s0 is not None:
                self.stage0_signatures.setdefault(t.framework, s0)
        feats = self.features(traces)
        fw = {t.trace_id: t.framework for t in traces}
        rows: list[tuple[AnchorSlot, SlotFeatures, str]] = []
        missing = 0
        for a in anchors:
            f = feats.get(a.trace_id, {}).get(a.slot_key)
            if f is None:
                missing += 1
                continue
            rows.append((a, f, fw.get(a.trace_id, "unknown")))
        if missing:
            print(f"[fit] {missing} anchors had no matching annotated slot")
        if len(rows) < 60:
            raise ValueError(
                f"only {len(rows)} usable anchors; the calibrator/conformal "
                "split needs far more. Aim for >=100 per Mondrian group.")

        rng = np.random.default_rng(self.cfg.seed)
        idx = rng.permutation(len(rows))
        cut = int(len(rows) * self.cfg.calibrator_share)
        cal_idx, conf_idx = idx[:cut], idx[cut:]

        has_votes = all(len(a.votes) >= 2 for a, _, _ in rows)
        if not has_votes:
            print("[fit] single-annotator anchors: Head B disabled, the queue "
                  "will be ranked by model risk alone")

        cal = [rows[i] for i in cal_idx]
        if self.cfg.calibrator_backend == "logistic":
            self.calibrator = TwoHeadCalibrator(taxonomy_signature=sig).fit(
                [f for _, f, _ in cal],
                [a.label for a, _, _ in cal],
                [a.unanimous for a, _, _ in cal] if has_votes else None,
            )
            self.calibrator_backend = None
        else:
            from .calibration_backends import make_calibrator
            self.calibrator_backend = make_calibrator(
                self.cfg.calibrator_backend).fit(
                [f for _, f, _ in cal],
                [a.label for a, _, _ in cal],
                [a.unanimous for a, _, _ in cal] if has_votes else None,
                signature=sig)
            self.calibrator = self.calibrator_backend
            print(f"[fit] calibrator backend "
                  f"{self.calibrator_backend.report().summary()}")

        conf = [rows[i] for i in conf_idx]
        p_conf = self._p([f for _, f, _ in conf])
        y_conf = [a.label for a, _, _ in conf]
        g_conf = [self._group(f, framework) for _, f, framework in conf]

        # The step head is multiclass and must be calibrated on whole traces:
        # its label is "which step is earliest", which only exists at trace
        # level. Splitting step slots individually, as the binary head does,
        # would leak the answer across the split.
        self.router = ConformalRouter(RouterConfig(
            alpha=self.cfg.alpha, group_by=self.cfg.group_by,
            max_verify_set=self.cfg.max_verify_set,
            max_questions=self.cfg.max_questions,
        ), taxonomy_signature=sig)
        sp, st, sg = self._step_calibration_data(anchors, traces, feats,
                                                 conf_share=self.cfg.calibrator_share)
        self.router.fit(p_conf, y_conf, g_conf, sp, st, sg)

        # Pluggable binary router. Before this, `router_backend` was declared
        # in the config, exposed on the CLI, described in RUN.md §12 and read
        # by nothing: route() called split conformal unconditionally. The
        # backend is fitted on the SAME conformal half as split conformal, so
        # the choice of router is the only thing that changes between arms.
        if self.cfg.router_backend != "split":
            from .routing_backends import (check_compatible, describe_pairing,
                                           make_router)
            kw = {"alpha": self.cfg.alpha}
            if self.cfg.router_backend == "aci":
                kw.update(gamma=self.cfg.aci_gamma, warmup=self.cfg.aci_warmup)
            if self.cfg.router_backend == "venn_abers":
                kw = {}
            backend = make_router(self.cfg.router_backend, **kw)
            cal_obj = getattr(self, "calibrator_backend", None)
            if cal_obj is not None:
                bad = check_compatible(cal_obj, backend)
                if bad:
                    raise RuntimeError(f"incompatible backends: {bad}")
                print(f"[fit] pairing "
                      f"{describe_pairing(cal_obj, backend)['loop_policy']}")
            elif backend.requires_interval:
                raise RuntimeError(
                    f"router {self.cfg.router_backend!r} reads interval width "
                    f"and the default logistic calibrator emits points; width "
                    f"would be 0 everywhere and NOVEL would never fire. Set "
                    f"calibrator_backend='logistic_va'.")
            b_conf = self._beliefs([f for _, f, _ in conf])
            backend.fit(b_conf, y_conf, g_conf)
            self.router.binary_backend = backend
            print(f"[fit] router backend {backend.report().summary()}")
        if not sp:
            print("[fit] WARNING no trace had complete step-level anchors; the "
                  "step head is uncalibrated and every step set will be the "
                  "full candidate list, forcing REVIEW. Annotate the step "
                  "slots of at least ~100 anchor traces.")

        cov = evaluate_binary_coverage(self.router.binary, p_conf, y_conf, g_conf)
        rc = risk_coverage(p_conf, y_conf)
        self.fit_report = {
            "taxonomy_signature": sig,
            "stage0_signatures": dict(getattr(self, "stage0_signatures", {})),
            "frozen_pool": (None if self.anchor_pool is None else
                            {"n": len(self.anchor_pool.frozen),
                             "fingerprint": self.anchor_pool.fingerprint()}),
            "n_anchors_used": len(rows),
            "n_calibrator": len(cal),
            "n_conformal": len(conf),
            "head_b_fitted": has_votes,
            "head_a": asdict(TwoHeadCalibrator.report(p_conf, y_conf)),
            "coverage": cov,
            "selective_error": {
                f"{c:.0%}": round(next(e for k, e in rc if abs(k - c) < 1e-6
                                       or k >= c), 4)
                for c in (0.5, 0.7, 0.9, 1.0)
            },
            "conformal": self.router.calibration_report,
            "step_head": {"n_calibration_traces": len(sp),
                          "q_pooled": (None if self.router.step.q_pooled == float("inf")
                                       else round(self.router.step.q_pooled, 4))},
        }
        (self.dir / "fit_report.json").write_text(
            json.dumps(self.fit_report, indent=2, default=str), encoding="utf-8")

        under = [g for g, r in cov.items()
                 if g != "__all__" and r["coverage"] < 1 - self.cfg.alpha - 0.03]
        if under:
            print(f"[fit] WARNING under-covered groups: {under}. Either drop a "
                  "dimension from group_by or collect more anchors there; do "
                  "not report the pooled figure as if it held per group.")
        return self.fit_report

    def _step_calibration_data(self, anchors, traces, feats, conf_share=0.5):
        """Per-trace (step distribution, true earliest step, group).

        A trace contributes only if every one of its step slots was
        adjudicated; a partially annotated trace cannot tell us that no step
        fired, so treating it as NONE would fabricate calibration points.
        """
        import numpy as np

        by_id = {t.trace_id: t for t in traces}
        votes: dict[str, dict[str, int]] = defaultdict(dict)
        for a in anchors:
            if a.slot_key.startswith("step::"):
                votes[a.trace_id][a.slot_key.split("::", 1)[1]] = a.label

        usable = []
        for tid, marked in votes.items():
            t = by_id.get(tid)
            if t is None or tid not in feats:
                continue
            if set(marked) != set(t.step_ids):
                continue                        # incomplete: skip, do not guess
            positives = [sid for sid, v in marked.items() if v == 1]
            if len(positives) > 1:
                order = {s.step_id: s.idx for s in t.steps}
                positives = [min(positives, key=lambda s: order[s])]
            usable.append((tid, positives[0] if positives else NONE_STEP))

        if not usable:
            return [], [], []
        rng = np.random.default_rng(self.cfg.seed + 1)
        idx = rng.permutation(len(usable))
        conf_part = [usable[i] for i in idx[int(len(usable) * conf_share):]]

        probs, truth, groups = [], [], []
        for tid, true_step in conf_part:
            sf = feats[tid]
            step_items = [(k, f) for k, f in sf.items() if f.slot_kind == "step"]
            if not step_items:
                continue
            p = self._p([f for _, f in step_items])
            d = self._step_distribution(
                {k.split("::", 1)[1]: pi for (k, _), pi in zip(step_items, p)})
            probs.append(d)
            truth.append(true_step)
            groups.append(self.router.group_key("step", by_id[tid].framework)
                          if self.router else "step")
        return probs, truth, groups

    # -- backend normalisation -------------------------------------------- #
    def _p(self, feats):
        """Calibrated scalars, whichever backend is in use.

        A Belief-emitting backend is collapsed with ``Belief.p``; the router
        that wants the interval reads it from ``_beliefs`` instead. Doing this
        in one place is what keeps every downstream consumer -- the step head,
        the queue ranking, the reports -- from having to know which backend
        was selected.
        """
        out = self.calibrator.predict(feats)
        if out and hasattr(out[0], "p"):
            return [b.p for b in out]
        return list(out)

    def _beliefs(self, feats):
        from .calibration_backends import Belief
        out = self.calibrator.predict(feats)
        if out and hasattr(out[0], "p"):
            return list(out)
        return [Belief.point(x) for x in out]

    def _group(self, f: SlotFeatures, framework: str) -> str:
        parts = []
        for g in self.cfg.group_by:
            parts.append({"kind": f.slot_kind, "framework": framework,
                          "code": f.code or "-",
                          "split": getattr(self, "_split_of", {})
                                   .get(f.slot_index, "-")}[g])
        return "|".join(parts)

    # -- Stage 3 ---------------------------------------------------------- #
    def route(self, traces: Sequence[Trace]) -> dict[str, TraceRoute]:
        if self.calibrator is None or self.router is None:
            raise RuntimeError("call fit() before route()")
        sig = self.tax.signature()
        self.calibrator.check_signature(sig)
        self.router.check_signature(sig)
        from .trace_spec import check_stage0
        unseen = check_stage0(getattr(self, "stage0_signatures", {}) or {},
                              traces)
        if unseen:
            print(f"[route] frameworks not seen at calibration: {unseen} -- "
                  f"scored by the pooled fallback, as before")
        if self.anchor_pool is not None:
            self.anchor_pool.check_frozen()
        feats = self.features(traces)
        by_id = {t.trace_id: t for t in traces}
        routes: dict[str, TraceRoute] = {}

        with (self.dir / "routes.jsonl").open("w", encoding="utf-8") as fh:
            for tid, slot_feats in feats.items():
                t = by_id[tid]
                ordered = list(slot_feats.items())
                p = self._p([f for _, f in ordered])
                pa = self.calibrator.predict_agreement([f for _, f in ordered])

                agent_slots, mode_slots, step_p = {}, {}, {}
                agreement = {}
                for (key, f), pi, pai in zip(ordered, p, pa):
                    agreement[key] = pai
                    if f.slot_kind == "agent":
                        agent_slots[key] = (pi, None)
                    elif f.slot_kind == "mode":
                        mode_slots[key] = (pi, f.code)
                    else:
                        step_p[key.split("::", 1)[1]] = pi

                beliefs = None
                if self.router.binary_backend is not None:
                    bl = self._beliefs([f for _, f in ordered])
                    beliefs = {key: b for (key, _f), b in zip(ordered, bl)}
                r = self.router.route(
                    tid, t.framework, agent_slots, mode_slots,
                    self._step_distribution(step_p), agreement,
                    beliefs=beliefs)
                routes[tid] = r
                fh.write(json.dumps({
                    "trace_id": tid, "framework": t.framework,
                    "decision": r.decision, "bucket": r.bucket,
                    "priority": round(r.priority, 4),
                    "n_human_questions": r.n_human_questions,
                    "reasons": r.reasons,
                    "sets": {lv: {k: sorted(map(str, s))
                                  for k, s in ld.sets.items()}
                             for lv, ld in r.levels.items()},
                }, ensure_ascii=False) + "\n")

        counts = Counter(r.decision for r in routes.values())
        n = max(len(routes), 1)
        print("[route] " + "  ".join(
            f"{k}={v} ({v/n:.1%})" for k, v in counts.most_common()))
        print(f"[route] human questions total: "
              f"{sum(r.n_human_questions for r in routes.values())}")
        return routes

    @staticmethod
    def _step_distribution(step_p: dict[str, float]) -> dict[str, float]:
        """Independent per-step p(earliest) -> a distribution over steps + none.

        The reasoner answers each step slot independently, so the values do not
        sum to one. Normalising is a modelling choice, not a fact; the mass on
        NONE_STEP is what is left over once every step has been asked, which is
        the right behaviour for clean traces where no step should fire.
        """
        if not step_p:
            return {}
        tot = sum(step_p.values())
        none_mass = max(0.0, 1.0 - tot)
        z = tot + none_mass
        d = {k: v / z for k, v in step_p.items()}
        d[NONE_STEP] = none_mass / z
        return d

    # -- export ----------------------------------------------------------- #
    def export_buckets(self, traces: Sequence[Trace],
                       routes: dict[str, TraceRoute]) -> dict[str, int]:
        by_id = {t.trace_id: t for t in traces}
        files = {b: (self.dir / f"{b}.jsonl").open("w", encoding="utf-8")
                 for b in ("corpus", "human_queue", "human_queue_full_read",
                           "residual_pool")}
        counts: Counter = Counter()
        try:
            queue = sorted(
                (r for r in routes.values()
                 if r.bucket.startswith("human_queue")),
                key=lambda r: -r.priority)
            rank = {r.trace_id: i for i, r in enumerate(queue)}
            for tid, r in routes.items():
                ann = self.annotations.get(tid)
                t = by_id.get(tid)
                if ann is None or t is None:
                    continue
                rec = {
                    "trace_id": tid, "framework": t.framework,
                    "decision": r.decision,
                    "queue_rank": rank.get(tid),
                    "priority": round(r.priority, 4),
                    "n_questions": r.n_human_questions,
                    "labels": self._labels(ann, r),
                    "evidence": self._evidence_cards(ann),
                    "reasons": r.reasons,
                }
                files[r.bucket].write(
                    json.dumps(rec, ensure_ascii=False) + "\n")
                counts[r.bucket] += 1
        finally:
            for f in files.values():
                f.close()
        print("[export] " + "  ".join(f"{k}={v}" for k, v in counts.items()))
        return dict(counts)

    def export_level_buckets(self, traces: Sequence[Trace],
                             routes: dict[str, TraceRoute]) -> dict[str, int]:
        """Route each LEVEL of a trace, not only the trace.

        Measured on the 85-trace archive (section 23): all 28 REVIEW traces
        were REVIEW because the step level could not localise the earliest
        fault, and in 15 of them the mode level was already fully settled --
        every set a singleton. Folding the trace to its worst level threw
        those settled mode-level labels into a full re-read, which is why
        "can we drop REVIEW" looked like a choice between discarding a third
        of the corpus and reading it all. It is neither: a level whose sets
        are all singletons is admitted, and only the unresolved level queues.

        This does NOT weaken the conformal claim. Coverage is a per-slot
        property of the prediction sets; folding levels together was a
        reporting decision, not part of the guarantee. What it does change is
        that a trace can now appear in the corpus and in the queue at once,
        so `level` is written on every row and the trace id is not unique per
        file.
        """
        by_id = {t.trace_id: t for t in traces}
        files = {b: (self.dir / f"level_{b}.jsonl").open("w", encoding="utf-8")
                 for b in ("corpus", "human_queue", "human_queue_full_read",
                           "residual_pool")}
        counts: Counter = Counter()
        try:
            for tid, r in routes.items():
                ann = self.annotations.get(tid)
                t = by_id.get(tid)
                if ann is None or t is None:
                    continue
                for lvl, ld in r.levels.items():
                    sizes = [len(v) for v in ld.sets.values()]
                    if not sizes:
                        continue
                    if any(n == 0 for n in sizes):
                        bucket = "residual_pool"
                    elif all(n == 1 for n in sizes):
                        bucket = "corpus"
                    elif max(sizes) <= self.router.cfg.max_verify_set:
                        bucket = "human_queue"
                    else:
                        bucket = "human_queue_full_read"
                    rec = {"trace_id": tid, "framework": t.framework,
                           "level": lvl, "decision": ld.decision,
                           "trace_decision": r.decision,
                           "n_slots": len(sizes),
                           "max_set_size": max(sizes),
                           "labels": self._labels(ann, r).get(lvl),
                           "reasons": [x for x in r.reasons
                                       if x.startswith(lvl)]}
                    files[bucket].write(json.dumps(rec, ensure_ascii=False) + "\n")
                    counts[f"{lvl}:{bucket}"] += 1
        finally:
            for f in files.values():
                f.close()
        print("[export-levels] " + "  ".join(f"{k}={v}"
                                             for k, v in sorted(counts.items())))
        return dict(counts)

    @staticmethod
    def _labels(ann: Stage1Annotation, r: TraceRoute) -> dict[str, Any]:
        out: dict[str, Any] = {"agent": [], "mode": [],
                               "earliest_step": ann.earliest_fault_step_id}
        for lvl in ("agent", "mode"):
            ld = r.levels.get(lvl)
            if ld is None:
                continue
            for key, s in ld.sets.items():
                if s == {1}:
                    out[lvl].append(key.split("::", 1)[1])
        return out

    @staticmethod
    def _evidence_cards(ann: Stage1Annotation) -> list[dict[str, Any]]:
        """What the expert actually reads: a few quoted lines, not the trace."""
        cards = []
        for f in ann.findings:
            cards.append({
                "code": f.code, "agent_uid": f.agent_uid, "step_id": f.step_id,
                "quotes": [{"step_id": e.match.step_id if e.match else e.step_id,
                            "quote": e.quote, "grounded": e.grounded}
                           for e in f.evidence],
                "rationale": f.rationale,
                "groundedness": round(f.groundedness, 3),
            })
        return cards


# --------------------------------------------------------------------------- #
# Loading a finished Stage 1 back from disk
# --------------------------------------------------------------------------- #

class PlanMismatch(RuntimeError):
    """An archived annotation was made against a different slot plan."""

    def __init__(self, trace_id: str, diff: dict):
        self.trace_id, self.diff = trace_id, diff
        super().__init__(
            f"{trace_id}: the archived annotation was made against a "
            f"different slot plan -- {diff}. Its verdicts would be read "
            f"against slots they did not answer. Re-annotate this trace, or "
            f"load with on_mismatch='skip' to collect every such trace in "
            f"PLAN_MISMATCHES and re-annotate only those.")


#: trace_id -> diff, filled by load_stage1. With on_mismatch="skip" this is
#: the exact list of traces a Stage 0 or taxonomy change invalidated -- the
#: rest of an archived run stays usable and needs no new API calls.
PLAN_MISMATCHES: dict[str, dict] = {}
_NO_STORED_PLAN_WARNED = [False]


def _plan_diff(stored: Optional[dict], plan) -> Optional[dict]:
    """None if the stored plan matches the rebuilt one slot for slot."""
    if not stored or not stored.get("slots"):
        if not _NO_STORED_PLAN_WARNED[0]:
            _NO_STORED_PLAN_WARNED[0] = True
            print("[load_stage1] an archived record carries no slot plan; it "
                  "cannot be checked against the current Stage 0 and "
                  "taxonomy and is loaded on trust")
        return None
    old = [(x["key"], x.get("question")) for x in stored["slots"]]
    new = [(x.key, x.question) for x in plan.slots]
    if old == new:
        return None
    ok, nk = [k for k, _ in old], [k for k, _ in new]
    out: dict[str, Any] = {}
    if len(old) != len(new):
        out["length"] = [len(old), len(new)]
    if set(ok) - set(nk):
        out["removed"] = sorted(set(ok) - set(nk))
    if set(nk) - set(ok):
        out["added"] = sorted(set(nk) - set(ok))
    oq, nq = dict(old), dict(new)
    changed = sorted(k for k in set(ok) & set(nk) if oq[k] != nq[k])
    if changed:
        out["question_changed"] = changed
    if not out and ok != nk:
        out["reordered"] = True
    return out


def load_stage1(path: str | Path, traces: Sequence[Trace],
                taxonomy: Taxonomy, mode_granularity: str = "trace",
                on_mismatch: str = "raise",
                ) -> dict[str, Stage1Annotation]:
    """Rebuild annotations from stage1.jsonl without re-calling the API.

    The slot plan is rebuilt from the trace rather than trusted from the file,
    so a taxonomy change since the run was written surfaces as a length
    mismatch instead of silently misaligning every verdict.
    """
    by_id = {t.trace_id: t for t in traces}
    out: dict[str, Stage1Annotation] = {}
    # A retried trace appends a second record, so the file can hold both a
    # `failed` line and a later `ok` line for one trace_id. Later wins: read
    # the file in order and let each record overwrite the one before it.
    for line in Path(path).open(encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        d = json.loads(line)
        t = by_id.get(d["trace_id"])
        if t is None:
            continue
        raw = d["annotation"]
        if raw is None or d.get("status") == "failed":
            # a recorded failure, written so the gap is visible downstream
            continue
        plan = build_slot_plan(t, taxonomy, mode_granularity=mode_granularity)
        # Compare the plan the run was annotated against with the plan the
        # current trace and taxonomy produce. Until this check the stored
        # plan was ignored ("rebuilt from the trace rather than trusted from
        # the file") and only a length difference was noticed -- as a
        # violation, not an error. Two failures got through that way:
        #   * a different LENGTH still loaded, with p_positive copied at its
        #     old length -- the same misalignment as the _reseat bug;
        #   * the SAME length with a changed meaning loaded silently. A
        #     capability change that narrows 2.2.2's scope from the whole
        #     trace to the aggregator keeps the slot and changes its
        #     question, and archived verdicts answered under the old scope
        #     would be read as answers to the new one.
        # Keys AND question text are compared, so both are caught.
        diff = _plan_diff(raw.get("plan"), plan)
        if diff is not None:
            PLAN_MISMATCHES[d["trace_id"]] = diff
            if on_mismatch == "raise":
                raise PlanMismatch(d["trace_id"], diff)
            continue
        ann = parse_reasoner_output({
            "verdicts": [str(v) for v in raw["verdicts"]],
            "earliest_fault_step_id": raw.get("earliest_fault_step_id") or "none",
            "findings": [{**f, "evidence": [{"step_id": e["step_id"],
                                             "quote": e["quote"]}
                                            for e in f["evidence"]]}
                         for f in raw.get("findings", [])],
            "novel_modes": [{**n, "evidence": [{"step_id": e["step_id"],
                                                "quote": e["quote"]}
                                               for e in n["evidence"]]}
                            for n in raw.get("novel_modes", [])],
            "self_assessment": raw.get("self_assessment") or {},
        }, t, plan, taxonomy)
        ann.p_positive = list(raw.get("p_positive") or [None] * len(plan.slots))
        ann.p_verbalised = list(raw.get("p_verbalised")
                                or [None] * len(plan.slots))
        out[d["trace_id"]] = ann
    return out
