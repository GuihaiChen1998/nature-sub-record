"""
label_free_calibration.py
=========================
Unsupervised recalibration for Stage 2, so that turning the loop does not
require new labels on the new taxonomy.

The objection this answers
--------------------------
0.7.25 made Stage 2 and Stage 3 pluggable and offered ACI and Venn-Abers as
the backends that let the loop turn. Both are supervised, and saying otherwise
would be wrong:

* **ACI** needs ``err_t``, which needs the realised label. 0.7.25 argued this
  is free because the VERIFY/REVIEW queue already returns human verdicts.
  That argument is weaker than it was stated. Feedback arrives **only on
  routed slots**, which are by construction the uncertain ones, so the
  sequence ACI adapts on is a biased subsample and the long-run guarantee it
  earns is over the *routed* subpopulation, not the corpus. Worse for the
  case that matters: after ``Taxonomy.add()``, the slots of the new code have
  no human verdicts at all, and obtaining them at the mistake-type level is
  exactly the cost the loop was supposed to avoid -- the 400 questions.

* **Venn-Abers** needs a labelled calibration set for its isotonic fits. Its
  width widens honestly on unfamiliar regions, which is useful, but the fits
  themselves are supervised.

So neither is unsupervised, and the honest summary of 0.7.25 is that it made
the *cost* of a turn explicit rather than removing it.

What is actually available
--------------------------
``LaSCal`` (Popordanoska et al., NeurIPS 2024) is a label-free, consistent
calibration-error estimator **under label shift**, paired with a post-hoc
unsupervised recalibration. Label shift means p(Y) moves while p(X|Y) holds.
It needs labels on the *source* and none on the *target*, which is precisely
our situation: anchors exist under T_k and none exist under T_{k+1}.

Whether the assumption holds here is worth stating rather than assuming, and
it holds **partly**:

* For an **existing** code's slots, adding a new code moves p(Y): instances
  that used to be labelled 2.2.1 may now be labelled D1.x instead, so the
  positive rate on 2.2.1 slots falls. p(X|Y) is plausibly stable -- given
  that 2.2.1 genuinely applies, the groundedness, violation and token-margin
  features should look the same. **Label shift is a reasonable model here.**
  One caveat that is not nothing: the annotator's prompt gains a code, so
  ``p_token`` can move even conditional on the label, which is covariate
  shift layered on top and outside what LaSCal corrects.

* For the **new** code's own slots there is no label shift, because there was
  no source class to shift. It is a label-space extension. LaSCal cannot
  speak to it, and neither can importance reweighting of source labels in
  general.

That split is the design: LaSCal recalibrates the old codes without labels,
and the new code's slots are abstained on -- Venn-Abers width or a null
importance weight routes them to a human. The loop turns on the part that can
be corrected and declines on the part that cannot, instead of one mechanism
pretending to cover both.

Why not BaseCal
---------------
``BaseCal`` (Tan et al., ACL 2026) calibrates a post-trained LLM against its
own **base** model -- BaseCal-ReEval re-scores the response with the base LLM,
BaseCal-Proj learns a projection from post-trained final-layer hidden states
into the base model's space. It is genuinely unsupervised and reports large
ECE reductions.

It does not apply to this pipeline, for a reason that is about deployment
rather than merit: every annotator here is reached through a third-party
chat endpoint. There is no access to hidden states, and no access to "the
base model of gpt-5.6-sol-disc" -- the base checkpoints of the models used
are not served. BaseCal-ReEval needs the second; BaseCal-Proj needs both.

If a local open-weights annotator is ever used, BaseCal-ReEval becomes the
cheapest unsupervised option available and should be reconsidered. Noted here
so the decision is recorded rather than silently made.

``PseudoCal`` (source-free, mixup-generated pseudo-target set) is the other
candidate that survives the API constraint, since it needs only unlabelled
target features. It is not implemented here.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Sequence

import numpy as np

from .calibration_backends import (Belief, BackendReport, EvolutionPolicy)


# --------------------------------------------------------------------------- #
# Black-box shift estimation: the label-shift weights, from unlabelled target
# --------------------------------------------------------------------------- #

def bbse_weights(src_pred: np.ndarray, src_true: np.ndarray,
                 tgt_pred: np.ndarray,
                 min_det: float = 0.02) -> tuple[np.ndarray, dict[str, Any]]:
    """Estimate w_y = p_target(y) / p_source(y) with no target labels.

    Black-box shift estimation (Lipton et al. 2018). Under label shift the
    predicted-label marginal on the target satisfies

        q_target(yhat)  =  sum_y  p(yhat | y) * p_target(y)

    and p(yhat | y) is measurable on the *source*, where labels exist. Invert
    the confusion matrix and read off the target label marginal.

    Returns the weights and a diagnostic dict. The determinant is reported
    because a near-singular confusion matrix means the classifier cannot
    separate the classes well enough for the inversion to be trusted, and the
    resulting weights are numerically loud nonsense rather than an estimate.
    Refusing is better than returning them.

    ``min_det`` is on the scale det(C) actually takes here, which is bounded:
    C holds *joint* probabilities summing to 1, so a perfect classifier on
    balanced classes gives det = 0.25 and a coin flip gives 0. The first value
    tried, 1e-3, was far below the sampling noise of a useless classifier --
    a coin flip on 400 points came back at |det| = 0.011 and was inverted
    rather than refused. 0.02 sits above that noise and well below anything a
    classifier worth calibrating produces.
    """
    classes = np.array([0, 1])
    n = len(src_true)
    # C[i, j] = p_source(yhat = i, y = j)
    C = np.zeros((2, 2), float)
    for i in classes:
        for j in classes:
            C[i, j] = np.sum((src_pred == i) & (src_true == j)) / max(n, 1)
    q = np.array([np.mean(tgt_pred == i) for i in classes], float)
    p_src = np.array([np.mean(src_true == j) for j in classes], float)

    det = float(np.linalg.det(C))
    diag: dict[str, Any] = {"confusion": C.tolist(), "det": round(det, 6),
                            "p_source": p_src.tolist(),
                            "q_target_pred": q.tolist()}
    if abs(det) < min_det:
        diag["refused"] = (
            f"confusion matrix is near-singular (|det|={abs(det):.2e} < "
            f"{min_det}); the classifier does not separate the classes well "
            f"enough for BBSE to invert. Weights not estimated.")
        return np.ones(2), diag

    p_tgt = np.linalg.solve(C, q)
    p_tgt = np.clip(p_tgt, 1e-6, None)
    p_tgt = p_tgt / p_tgt.sum()
    w = p_tgt / np.clip(p_src, 1e-6, None)
    diag["p_target_est"] = p_tgt.tolist()
    diag["weights"] = w.tolist()
    return w, diag


# --------------------------------------------------------------------------- #
# The label-free calibration-error estimate
# --------------------------------------------------------------------------- #

def label_free_ce(p_target: Sequence[float], src_p: Sequence[float],
                  src_y: Sequence[int], w: np.ndarray,
                  bins: int = 10) -> float:
    """Importance-reweighted CE on the target, computed without target labels.

    Inside a confidence bin, the accuracy that would be observed on the target
    is estimated by reweighting the *source* labels in that bin by w_y. The
    estimator is consistent under label shift; under violations it is biased,
    and the bias is not estimated here, so the number is a monitor rather than
    a certificate.
    """
    p_target = np.asarray(list(p_target), float)
    src_p = np.asarray(list(src_p), float)
    src_y = np.asarray(list(src_y), int)
    if len(p_target) == 0 or len(src_p) == 0:
        return float("nan")

    total = 0.0
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        t_idx = np.where((p_target > lo) & (p_target <= hi)
                         if b else (p_target <= hi))[0]
        if len(t_idx) == 0:
            continue
        s_idx = np.where((src_p > lo) & (src_p <= hi)
                         if b else (src_p <= hi))[0]
        if len(s_idx) == 0:
            continue                      # no source evidence for this bin
        ws = w[src_y[s_idx]]
        acc_hat = float(np.sum(ws * src_y[s_idx]) / max(np.sum(ws), 1e-9))
        conf = float(np.mean(p_target[t_idx]))
        total += (len(t_idx) / len(p_target)) * abs(conf - acc_hat)
    return total


# --------------------------------------------------------------------------- #
# The backend
# --------------------------------------------------------------------------- #

@dataclass
class _Src:
    p: np.ndarray
    y: np.ndarray


class LaSCalBackend:
    """Label-free recalibration under label shift.

    Usage differs from the supervised backends by one call:

        cal = LaSCalBackend().fit(src_feats, src_labels, signature="T0:...")
        cal.adapt_unlabelled(new_feats)        # <- no labels
        beliefs = cal.predict(new_feats)

    ``adapt_unlabelled`` is where the work happens: estimate the label-shift
    weights from the unlabelled target predictions, recalibrate the source
    mapping under those weights, and record the label-free CE estimate so the
    backend can report how miscalibrated it believes it now is.

    Abstention is part of the contract. A slot whose code did not exist under
    the source taxonomy gets no weight -- it is a new class, not a reweighted
    old one -- and is returned as a maximally wide belief so the router sends
    it to a human instead of scoring it. Pass ``known_codes`` to enable this;
    without it the backend cannot tell a new code from an old one and says so.
    """

    name = "lascal"

    def __init__(self, inner: str = "logistic", bins: int = 10,
                 fit_temperature: bool = False, **kw: Any) -> None:
        #: Temperature is OFF by default, and the default is the measured one.
        #: Swept against the label-free CE it pinned to the edge of the grid
        #: (T = 0.3) at every shift magnitude tried, and made the TRUE ECE
        #: worse than prior correction alone in all five:
        #:
        #:   target rate   before   prior+T   prior only
        #:        0.10     0.0646    0.0235       0.0196
        #:        0.15     0.0547    0.0315       0.0252
        #:        0.25     0.0347    0.0360       0.0260
        #:        0.40     0.0336    0.0451       0.0306   <- no shift at all
        #:        0.60     0.0595    0.0407       0.0406
        #:
        #: The 0.40 row is the damning one: source and target have the same
        #: base rate, there is nothing to correct, and fitting a temperature
        #: to a noisy label-free objective invented a correction and lost
        #: 0.012 ECE. Prior correction alone never did worse than doing
        #: nothing. Left switchable for the ablation.
        self.fit_temperature = fit_temperature
        from .uncertainty import TwoHeadCalibrator
        self._inner = TwoHeadCalibrator(**kw)
        self.bins = bins
        self._src: Optional[_Src] = None
        self._w = np.ones(2)
        self._temp = 1.0
        self._sig: Optional[str] = None
        self._known: Optional[set[str]] = None
        self._diag: dict[str, Any] = {}
        self._ce: Optional[float] = None
        self._adapted = False

    # -- supervised part, on the source ----------------------------------- #
    def fit(self, feats, labels, agreed=None, signature=None,
            known_codes: Optional[Sequence[str]] = None):
        y = np.asarray(list(labels), int)
        n = len(y)
        cut = max(1, n // 2)
        self._inner.fit(feats[:cut], y[:cut],
                        None if agreed is None else agreed[:cut])
        p = np.asarray(self._inner.predict(feats[cut:]), float)
        self._src = _Src(p, y[cut:])
        self._sig = signature
        self._known = set(known_codes) if known_codes is not None else None
        return self

    # -- unsupervised part, on the target --------------------------------- #
    def adapt_unlabelled(self, feats) -> dict[str, Any]:
        """Recalibrate using unlabelled target slots only."""
        if self._src is None:
            raise RuntimeError("fit() on the source before adapting")
        p_t = np.asarray(self._inner.predict(feats), float)
        w, diag = bbse_weights((self._src.p > 0.5).astype(int), self._src.y,
                               (p_t > 0.5).astype(int))
        self._w, self._diag = w, diag
        ce_before = label_free_ce(p_t, self._src.p, self._src.y,
                                  np.ones(2), self.bins)
        self._temp = 1.0
        ce_prior = label_free_ce(self._apply(p_t), self._src.p,
                                 self._src.y, w, self.bins)
        if self.fit_temperature:
            self._temp = self._fit_temperature_grid(p_t)
        ce_after = label_free_ce(self._apply(p_t), self._src.p,
                                 self._src.y, w, self.bins)
        self._ce = ce_after
        self._adapted = True
        out = {"ce_label_free_before": round(ce_before, 4),
               "ce_label_free_prior_only": round(ce_prior, 4),
               "ce_label_free_after": round(ce_after, 4),
               "temperature": round(self._temp, 4),
               "n_target": int(len(p_t)), **diag}
        if diag.get("refused"):
            out["effect"] = ("weights refused; temperature left at 1.0 and "
                             "the source mapping used unchanged")
            self._temp = 1.0
        return out

    def _apply(self, p: np.ndarray) -> np.ndarray:
        """Prior correction first, then temperature.

        The order matters and the first step is the one that does the work.
        Under label shift the exact correction is on the *odds*::

            p_target(y=1|x)  proportional to  w_1 * p_source(y=1|x)

        so the odds are multiplied by w_1 / w_0. A temperature cannot express
        this: dividing the logit by T sharpens or flattens symmetrically about
        0.5 and cannot move a prior. Fitting a temperature alone on a
        base-rate change drove T to the edge of the grid (0.35, i.e. sharpen
        by ~2.9x) and improved the true ECE only from 0.055 to 0.042, because
        it was compensating for a prior shift with the wrong instrument.

        Temperature is kept as a second, smaller correction for residual
        over- or under-confidence that is not a prior effect.
        """
        p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)
        w1, w0 = float(self._w[1]), float(self._w[0])
        if w0 > 0 and w1 > 0:
            odds = (p / (1 - p)) * (w1 / w0)
            p = odds / (1.0 + odds)
            p = np.clip(p, 1e-6, 1 - 1e-6)
        logit = np.log(p / (1 - p)) / max(self._temp, 1e-3)
        return 1.0 / (1.0 + np.exp(-logit))

    #: kept so older call sites and the ablation arm still resolve
    _apply_temp = _apply

    def _fit_temperature_grid(self, p_t: np.ndarray) -> float:
        """Pick T minimising the label-free CE on the target.

        A one-dimensional sweep rather than a gradient step: the objective is
        an estimate built from binned counts, not a smooth likelihood, and at
        this scale a sweep is both cheaper and harder to get wrong.
        """
        if self._src is None or self._diag.get("refused"):
            return 1.0
        grid = np.concatenate([np.linspace(0.3, 1.0, 15),
                               np.linspace(1.05, 4.0, 30)])
        best, best_ce = 1.0, float("inf")
        for t in grid:
            self._temp = float(t)
            ce = label_free_ce(self._apply(p_t), self._src.p,
                               self._src.y, self._w, self.bins)
            if ce == ce and ce < best_ce:
                best, best_ce = float(t), ce
        return best

    # -- prediction -------------------------------------------------------- #
    def predict(self, feats) -> list[Belief]:
        p = self._apply(np.asarray(self._inner.predict(feats), float))
        out: list[Belief] = []
        for f, v in zip(feats, p):
            code = getattr(f, "code", None)
            if (self._known is not None and code is not None
                    and code not in self._known):
                # A class that did not exist in the source. Label shift has
                # nothing to say about it; abstain rather than extrapolate.
                out.append(Belief(0.0, 1.0))
            else:
                out.append(Belief.point(float(v)))
        return out

    def predict_agreement(self, feats) -> list[float]:
        try:
            return list(self._inner.predict_agreement(feats))
        except Exception:                                  # noqa: BLE001
            return [0.5] * len(feats)

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.ADAPTS_UNSUPERVISED

    def report(self) -> BackendReport:
        det = {"adapted": self._adapted, "temperature": round(self._temp, 4),
               "weights": self._w.tolist(),
               "ce_label_free": (None if self._ce is None
                                 else round(self._ce, 4)),
               "known_codes": (None if self._known is None
                               else sorted(self._known)),
               **self._diag}
        if self._known is None:
            det["warning"] = (
                "known_codes not supplied: the backend cannot tell a newly "
                "added code from an existing one, so slots of a new code are "
                "scored by extrapolation instead of abstained on. Pass the "
                "source taxonomy's codes.")
        return BackendReport(self.name, self.policy(),
                             0 if self._src is None else len(self._src.y),
                             self._sig, det)

    def on_taxonomy_change(self, new_signature: str) -> str:
        self._adapted = False
        return (
            f"source calibration is from {self._sig}, taxonomy is now "
            f"{new_signature}. Call adapt_unlabelled() on the new taxonomy's "
            f"slots -- no labels needed. Valid to the extent the change is "
            f"label shift on the existing codes; slots of the newly added "
            f"code are abstained on when known_codes was supplied, because a "
            f"new class is not a reweighting of an old one.")
