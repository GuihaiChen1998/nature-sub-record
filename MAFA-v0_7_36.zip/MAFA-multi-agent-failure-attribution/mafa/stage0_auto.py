"""
stage0_auto.py
==============
Making a wrong mapping fail, so that an unseen framework can be proposed for
rather than hand-written.

0.7.32 showed the problem is not "cannot map an unseen framework" but "maps
it wrongly and validates": the ColaCare spec, applied to mac and medagent,
passed `validate_trace` with zero problems. `validate_trace` checks that what
was extracted exists in the record. It cannot see what was NOT extracted, or
what the spec expected and the record never had. Both are checked here, with
no model in the loop:

* **Text conservation.** Every JSON path carrying real text is either consumed
  by the spec (turn content, turn input, base field) or listed in the spec's
  `ignore`. Unaccounted text mass is a failure.
* **Expectation.** Every path the spec reads must be present in most records.
  A path that is never there (`log.llm_input` on mac) means a capability is
  being inferred from nothing.
* **Fingerprint.** A framework's identity is the set of paths it records, not
  its filename. Two files with the same fingerprint may share a spec and a
  calibrator; a new fingerprint is a new framework until someone says
  otherwise.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

#: a string shorter than this is a label, id or option letter, not text
TEXT_MIN = 40
#: share of a record's text that may go unaccounted before coverage fails
MAX_UNCOVERED = 0.02
#: a spec path must be present in at least this share of its parent turns
MIN_PRESENT = 0.9


def _walk(obj: Any, path: str, out: dict, seen_here: set) -> None:
    if isinstance(obj, dict):
        for k, v in obj.items():
            _walk(v, f"{path}.{k}" if path else k, out, seen_here)
    elif isinstance(obj, list):
        for v in obj:
            _walk(v, f"{path}[*]", out, seen_here)
    else:
        st = out[path]
        st["n"] += 1
        if isinstance(obj, str):
            if len(obj) >= TEXT_MIN:
                st["text_chars"] += len(obj)
                st["n_text"] += 1
            if len(st["values"]) < 50:
                st["values"].add(obj[:60])
        seen_here.add(path)


def inventory(records: Iterable[dict]) -> dict[str, dict]:
    """Per wildcarded leaf path: occurrences, records present in, text mass,
    and up to 50 distinct short values (so a speaker field is recognisable
    as a small vocabulary)."""
    out: dict[str, dict] = defaultdict(
        lambda: {"n": 0, "records": 0, "text_chars": 0, "n_text": 0,
                 "values": set()})
    n = 0
    for r in records:
        n += 1
        here: set = set()
        _walk(r, "", out, here)
        for p in here:
            out[p]["records"] += 1
    for st in out.values():
        st["presence"] = st["records"] / max(n, 1)
        st["distinct"] = len(st["values"])
    out = dict(out)
    out["__n_records__"] = {"n": n}
    return out


def fingerprint(inv: dict, min_presence: float = 0.5) -> str:
    """Hash of the paths most records carry. Filename-free identity."""
    paths = sorted(p for p, st in inv.items()
                   if p != "__n_records__" and st["presence"] >= min_presence)
    return "F:" + hashlib.sha1("\n".join(paths).encode()).hexdigest()[:10]


# --------------------------------------------------------------------------- #
# What a spec reads
# --------------------------------------------------------------------------- #

def _join(base: str, sub: str) -> str:
    return f"{base}.{sub}" if base else sub


def spec_reads(spec) -> dict[str, str]:
    """-> {absolute wildcarded leaf-path prefix: what it is used for}."""
    reads: dict[str, str] = {}
    for f, p in (spec.base_fields or {}).items():
        if isinstance(p, str):
            reads[p] = f"base:{f}"
    for ts in spec.turns:
        for c in ts.content:
            reads[_join(ts.path, c)] = "content"
        if ts.input:
            reads[_join(ts.path, ts.input)] = "input"
        for name in ("agent", "role", "role_index"):
            v = getattr(ts, name)
            if isinstance(v, str):
                reads[_join(ts.path, v)] = name
        rf = (ts.round or {}).get("field")
        if isinstance(rf, str) and not rf.startswith("^"):
            reads[_join(ts.path, rf)] = "round"
    for p in getattr(spec, "ignore", None) or []:
        reads[p] = "ignored"
    return reads


def _covered(path: str, reads: dict[str, str]) -> Optional[str]:
    """A leaf is covered by a read of itself or of any ancestor (a content
    read of `log.parsed_output` consumes everything beneath it)."""
    for r, why in reads.items():
        if path == r or path.startswith(r + ".") or path.startswith(r + "["):
            return why
    return None


@dataclass
class Coverage:
    total_text: int
    uncovered_text: int
    uncovered: list[tuple[str, int, float]]      # path, chars, presence
    absent_reads: list[tuple[str, str, float]]   # path, use, presence
    problems: list[str] = field(default_factory=list)

    @property
    def uncovered_share(self) -> float:
        return self.uncovered_text / max(self.total_text, 1)

    @property
    def ok(self) -> bool:
        return not self.problems


def coverage(spec, inv: dict) -> Coverage:
    reads = spec_reads(spec)
    total = unc = 0
    uncovered = []
    for p, st in inv.items():
        if p == "__n_records__" or not st["text_chars"]:
            continue
        total += st["text_chars"]
        if _covered(p, reads) is None:
            unc += st["text_chars"]
            uncovered.append((p, st["text_chars"], round(st["presence"], 3)))
    uncovered.sort(key=lambda x: -x[1])

    # expectation, in two tiers. A turn source that never occurs is reported
    # once as such (an optional stage is not a missing field); a field read
    # inside turns that DO occur is measured against how often they occur.
    def pres_under(prefix):
        return max((st["presence"] for p, st in inv.items()
                    if p != "__n_records__" and
                    (p == prefix or p.startswith(prefix + ".")
                     or p.startswith(prefix + "["))), default=0.0)
    absent = []
    turn_pres = {ts.path: pres_under(ts.path) for ts in spec.turns}
    for tp, pr in turn_pres.items():
        if pr == 0:
            absent.append((tp, "turn source", 0.0))
    for r, why in reads.items():
        if why in ("ignored", "content") or why.startswith("base:"):
            continue          # content candidates are judged as a union, below
        owner = max((tp for tp in turn_pres if r.startswith(tp + ".")),
                    key=len, default=None)
        if owner is None or turn_pres[owner] == 0:
            continue
        rel = pres_under(r) / turn_pres[owner]
        if rel < MIN_PRESENT:
            absent.append((r, why, round(rel, 3)))

    cov = Coverage(total, unc, uncovered, absent)
    if cov.uncovered_share > MAX_UNCOVERED:
        cov.problems.append(
            f"{cov.uncovered_share:.1%} of text unaccounted for; largest: "
            + ", ".join(f"{p} ({c:,} chars)" for p, c, _ in uncovered[:3]))
    for r, why, rel in absent:
        if why == "turn source":
            cov.problems.append(f"turn source {r!r} never occurs in this file")
            continue
        cov.problems.append(
            f"spec reads {r!r} as {why} but it is present in only {rel:.0%} "
            f"of the turns it belongs to")
    return cov


# --------------------------------------------------------------------------- #
# Per-record conservation: lost vs duplicated
# --------------------------------------------------------------------------- #

def _leaves(obj, path=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _leaves(v, f"{path}.{k}" if path else k)
    elif isinstance(obj, list):
        for v in obj:
            yield from _leaves(v, f"{path}[*]")
    elif isinstance(obj, str) and len(obj) >= TEXT_MIN:
        yield path, obj


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def conservation(spec, records: Iterable[dict], probe: int = 120) -> dict:
    """Split unconsumed text into DUPLICATE (a copy of something the spec
    does read, in the same record) and LOST (nowhere in the trace). Only
    LOST is a failure; a duplicate is recorded so it can be ignored on
    purpose rather than by accident."""
    reads = spec_reads(spec)
    lost = defaultdict(int)
    dup = defaultdict(int)
    total = consumed = 0
    for r in records:
        leaves = list(_leaves(r))
        seen = " ".join(_norm(t) for p, t in leaves
                        if _covered(p, reads) not in (None, "ignored"))
        for p, t in leaves:
            total += len(t)
            why = _covered(p, reads)
            if why == "ignored":
                continue
            if why is not None:
                consumed += len(t)
                continue
            n = _norm(t)
            mid = n[len(n) // 3: len(n) // 3 + probe] if len(n) > probe else n
            (dup if mid and mid in seen else lost)[p] += len(t)
    return {
        "total": total, "consumed": consumed,
        "lost": sorted(lost.items(), key=lambda x: -x[1]),
        "duplicate": sorted(dup.items(), key=lambda x: -x[1]),
        "lost_share": sum(lost.values()) / max(total, 1),
    }


def lost_paths(cons: dict, inv: dict, min_presence: float = 0.1,
               min_lost_share: float = 0.5) -> list[str]:
    """Per-path rule. A global threshold passed medagent (0.2% lost overall)
    while it dropped every review's `answer`: a common path whose text is
    mostly lost fails regardless of its share of the corpus."""
    out = []
    for p, n in cons["lost"]:
        st = inv.get(p)
        if not st or st["presence"] < min_presence or not st["text_chars"]:
            continue
        if n / st["text_chars"] >= min_lost_share:
            out.append(f"text at {p!r} ({n:,} chars, in {st['presence']:.0%} "
                       f"of records) is neither mapped, ignored, nor a copy "
                       f"of mapped text")
    return out


# --------------------------------------------------------------------------- #
# Phase vs recorded data flow
# --------------------------------------------------------------------------- #

def _sees_peer(steps, j, min_chars=40):
    s = steps[j]
    if not s.context:
        return None                           # unobservable, not False
    for p in steps[:j]:
        if p.agent_uid == s.agent_uid or len(p.content) < min_chars:
            continue
        if p.phase in ("planning", "recruitment"):
            continue          # an orchestrator's plan or questions is not a peer's opinion
        probe = p.content[len(p.content) // 3: len(p.content) // 3 + min_chars]
        if probe and probe in s.context:
            return True
    return False


def phase_dataflow(traces) -> dict:
    """Where inputs are recorded, a phase label makes a checkable claim:
    `independent_analysis` saw no peer; `discussion`/`review`/`synthesis`
    saw at least one. Counts per phase: consistent / contradicted /
    unobservable. The label came from a field name; this is the only test of
    it that does not trust a name."""
    c = defaultdict(lambda: {"consistent": 0, "contradicted": 0,
                             "unobservable": 0})
    for t in traces:
        for j, s in enumerate(t.steps):
            seen = _sees_peer(t.steps, j)
            k = c[s.phase]
            if seen is None:
                k["unobservable"] += 1
            elif s.phase == "independent_analysis":
                k["contradicted" if seen else "consistent"] += 1
            elif s.phase in ("discussion", "review", "synthesis"):
                k["consistent" if seen else "contradicted"] += 1
            else:
                k["consistent"] += 1
    return dict(c)


def dataflow_problems(df: dict, max_contra: float = 0.2) -> list[str]:
    out = []
    for ph, k in df.items():
        obs = k["consistent"] + k["contradicted"]
        if obs and k["contradicted"] / obs > max_contra:
            want = ("saw no peer" if ph == "independent_analysis"
                    else "saw at least one peer")
            out.append(f"phase {ph!r}: {k['contradicted']}/{obs} observable "
                       f"steps contradict it (a {ph} step should have {want} "
                       f"per its recorded input)")
    return out


# --------------------------------------------------------------------------- #
# L3: a model proposes, the checks above dispose
# --------------------------------------------------------------------------- #

SPEC_DOC = """A MappingSpec is JSON:
{
 "framework": str,
 "match_filename": [substring of the file name],
 "base_fields": {"id": path, "question": path, "options": path,
                 "images": path, "ground_truth": path, "final_answer": path,
                 "predicted": path, "ground_truth_answer": path},
 "turns": [ one object per PLACE in the record that turns come from:
   {"path": "a.b[*].c[*]"      -- [*] iterates a list; each match is one turn,
    "agent": relative path OR {"const": "Name"},
    "role": relative path or null,
    "content": [relative paths, first non-empty wins],
    "input": relative path of what this agent was SHOWN, or null if absent,
    "phase": {"const": P} or {"map": {raw: P}, "default": P} with a raw
             label read from... (use const unless a field holds the label),
    "round": {"field": "^round"} to read the nearest enclosing `round`
             key, or {"const": 1},
    "order": int, the position of this source within a round}
 ],
 "ignore": [paths deliberately not ingested, each with a reason in
            ignore_why],
 "ignore_why": {path: reason},
 "declared": {capability: bool} -- ONLY if the records cannot show it and
             the framework's protocol is known,
 "declared_why": {capability: reason},
 "unobservable": [capabilities the records cannot show and you cannot
                  justify declaring],
 "notes": [free-text observations about the format]
}
Capabilities (the ONLY valid keys for declared/unobservable):
has_recruitment, has_multi_round, has_peer_exposure, has_aggregator,
has_image, has_explicit_roles. Everything else goes in notes.
Canonical phases P: recruitment, planning, independent_analysis, discussion,
review, synthesis, decision.
Relative paths are relative to one turn object. Leading ^ searches ancestors.
"""

PROPOSE_SYS = """You map a multi-agent system's JSON logs onto a fixed trace
format. You choose JSON PATHS. You never infer who spoke from the prose: if no
field names the speaker, use a const and say so. Every path carrying real
text must end up either inside a turn (content or input) or in "ignore" with
a reason. Anything that is an evaluation of the run (audits, labels, judge
verdicts, error annotations) is NOT part of the run and must be ignored --
ingesting it would leak labels into the trace. Copies of text already mapped
elsewhere may be ignored as copies."""


def describe_inventory(inv: dict, max_paths: int = 160) -> str:
    rows = []
    for p, st in sorted(inv.items()):
        if p == "__n_records__":
            continue
        vals = ""
        if not st["text_chars"] and 0 < st["distinct"] <= 12:
            vals = " values=" + json.dumps(sorted(st["values"])[:8],
                                           ensure_ascii=False)
        rows.append(f"{p} | presence {st['presence']:.2f} | per-record "
                    f"{st['n'] / max(st['records'], 1):.1f} | text "
                    f"{st['text_chars'] // max(st['records'], 1):,} ch/rec{vals}")
    if len(rows) > max_paths:
        rows = rows[:max_paths] + [f"... {len(rows) - max_paths} more"]
    return "\n".join(rows)


def _truncate(o, n=160):
    if isinstance(o, dict):
        return {k: _truncate(v, n) for k, v in o.items()}
    if isinstance(o, list):
        return [_truncate(v, n) for v in o[:2]] + (["..."] if len(o) > 2 else [])
    if isinstance(o, str) and len(o) > n:
        return o[:n] + f"...<{len(o)} chars>"
    return o


def effective_reads(spec, records, ts_mod) -> list[str]:
    """Resolve every declared read through the REAL resolver, per turn, and
    compare with how often the inventory says the value exists. The
    inventory checks ask whether a path is present and referenced; only this
    asks whether the spec actually gets it. A read that exists in the data
    but resolves empty is the silent failure the inventory cannot see."""
    out = []
    for ts in spec.turns:
        fields = {"content": ts.content, "input": [ts.input] if ts.input else [],
                  "agent": [ts.agent] if isinstance(ts.agent, str) else []}
        n = 0
        got = defaultdict(int)
        content_any = 0
        for r in records:
            for turn, anc in ts_mod.expand(r, ts.path):
                n += 1
                hit = False
                for use, paths in fields.items():
                    for fp in paths:
                        v = ts_mod.get(turn, fp, anc)
                        if v not in (None, "", [], {}):
                            got[(use, fp)] += 1
                            hit = hit or use == "content"
                content_any += hit
        if not n:
            continue
        for use, paths in fields.items():
            if use == "content":
                continue
            for fp in paths:
                share = got[(use, fp)] / n
                if share < MIN_PRESENT:
                    out.append(f"{ts.path} -> {use} {fp!r} resolves to a value "
                               f"in only {share:.0%} of {n} turns")
        if ts.content and content_any / n < MIN_PRESENT:
            out.append(f"{ts.path} -> content resolves (any candidate) in only "
                       f"{content_any / n:.0%} of {n} turns")
    return out


def duplicate_steps(traces, min_chars: int = 80) -> list[str]:
    """Two steps with the same content in one trace: the same turn ingested
    from two places (a per-round decision and a final_decision_log copy)."""
    n = bad = 0
    for t in traces:
        seen = set()
        for s in t.steps:
            c = re.sub(r"\s+", " ", s.content).strip()
            if len(c) < min_chars:
                continue
            n += 1
            if c in seen:
                bad += 1
            seen.add(c)
    return ([f"{bad} of {n} steps duplicate another step's content in the "
             f"same trace -- the same turn is ingested from two places"]
            if n and bad / n > 0.01 else [])


def verify(spec_json: dict, records: list[dict], ts_mod) -> tuple[list[str], dict]:
    """Model-free. -> (problems, report)."""
    d = dict(spec_json)
    ignore = d.pop("ignore", []) or []
    d.pop("ignore_why", None)
    d.pop("notes", None)
    unobs = set(d.pop("unobservable", []) or [])
    from .trace_adapter import CAPABILITY_KEYS
    pre = []
    bad = [k for k in (d.get("declared") or {}) if k not in CAPABILITY_KEYS]
    if bad:
        # _assemble reads only CAPABILITY_KEYS: anything else was dropped
        # without a word, however good its reason
        pre.append(f"declared keys {bad} are not capabilities and would be "
                   f"silently ignored; valid: {list(CAPABILITY_KEYS)}. Put "
                   f"other observations in \"notes\".")
    bad_u = [k for k in unobs if k not in CAPABILITY_KEYS]
    if bad_u:
        pre.append(f"unobservable keys {bad_u} are not capabilities")
    try:
        spec = ts_mod.spec_from_json(d)
    except Exception as e:                          # malformed spec
        return [f"spec does not load: {type(e).__name__}: {e}"], {}
    spec.ignore = ignore
    probs: list[str] = list(pre)
    traces = []
    for i, r in enumerate(records):
        try:
            t = ts_mod.ingest(r, spec, "probe.jsonl", i)
        except Exception as e:
            probs.append(f"record {i} fails to ingest: {type(e).__name__}: {e}")
            break
        if not t.steps:
            probs.append(f"record {i}: no steps extracted")
            break
        traces.append(t)
    if not traces:
        return probs, {}
    vt = [p for t in traces for p in ts_mod.validate_trace(t)]
    if vt:
        probs.append(f"validate_trace: {len(vt)} problems, e.g. {vt[:2]}")
    inv = inventory(records)
    cov = coverage(spec, inv)
    probs += [p for p in cov.problems if "unaccounted" not in p]
    cons = conservation(spec, records)
    probs += lost_paths(cons, inv)
    probs += effective_reads(spec, records, ts_mod)
    probs += duplicate_steps(traces)
    df = phase_dataflow(traces)
    probs += dataflow_problems(df)
    # (c) a capability read off inputs that were never recorded is unknown,
    # not False. Make the spec say which.
    peer_decl = "has_peer_exposure" in (d.get("declared") or {})
    if not peer_decl and "has_peer_exposure" not in unobs:
        steps_n = sum(len(t.steps) for t in traces)
        blind = sum(1 for t in traces for s in t.steps if not s.context)
        if steps_n and blind / steps_n > 0.95:
            probs.append(
                f"has_peer_exposure would be inferred from inputs, but "
                f"{blind}/{steps_n} steps have no recorded input: that is "
                f"UNKNOWN, not False. Either declare it (with declared_why "
                f"from the framework's documented protocol) or list it in "
                f"\"unobservable\".")
    empty = sum(1 for t in traces for s in t.steps if not s.content.strip())
    if empty:
        probs.append(f"{empty} steps have empty content")
    return probs, {"spec": spec, "traces": traces, "dataflow": df,
                   "lost_share": cons["lost_share"],
                   "fingerprint": fingerprint(inv)}


def propose(records: list[dict], ask, framework: str, filename_hint: str,
            ts_mod, rounds: int = 3, log=print) -> dict:
    """`ask(system, user) -> str`. Returns the accepted spec JSON and its
    verification history; `accepted` is False if no round verified."""
    inv = inventory(records)
    user = (f"{SPEC_DOC}\nFramework name to use: {framework}\n"
            f"File name example: {filename_hint}\n\n"
            f"PATH INVENTORY over {len(records)} records:\n"
            f"{describe_inventory(inv)}\n\nONE RECORD (truncated):\n"
            f"{json.dumps(_truncate(records[0]), ensure_ascii=False)[:9000]}\n\n"
            "Reply with the MappingSpec JSON only.")
    hist = []
    for k in range(rounds):
        txt = ask(PROPOSE_SYS, user)
        m = re.search(r"\{.*\}", txt, re.S)
        try:
            sj = json.loads(m.group(0)) if m else {}
        except json.JSONDecodeError as e:
            sj, probs = {}, [f"reply is not JSON: {e}"]
        else:
            probs, rep = verify(sj, records, ts_mod)
        hist.append({"round": k, "problems": probs})
        log(f"[propose {framework}] round {k}: {len(probs)} problems"
            + ("".join(f"\n    - {p[:200]}" for p in probs[:6])))
        if not probs:
            return {"accepted": True, "spec": sj, "history": hist,
                    "report": rep}
        user += (f"\n\nYour previous spec:\n{json.dumps(sj)[:6000]}\n"
                 "It FAILED these model-free checks; fix every one:\n- "
                 + "\n- ".join(probs[:12]))
    return {"accepted": False, "spec": sj, "history": hist}
