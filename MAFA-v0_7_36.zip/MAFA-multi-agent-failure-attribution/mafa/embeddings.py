"""
embeddings.py
=============
``EmbedFn`` implementations for the residual-pool clustering, behind one
interface so the backend can be swapped without touching
``taxonomy_evolution``.

    from .embeddings import make_embedder
    embed = make_embedder("openai", model="text-embedding-3-small",
                          cache_path="run01/emb.jsonl")
    embed = make_embedder("vllm", model="Qwen/Qwen3-Embedding-0.6B",
                          base_url="http://localhost:8000/v1")

Two things that will bite if ignored
------------------------------------
*The gate threshold is backend-specific.*  ``GateConfig.max_centroid_cos`` was
set at 0.82 against ``text-embedding-3-small``.  Cosine similarity is not
comparable across embedding models -- open-weight retrieval models in
particular tend to sit in a much narrower, higher band, so 0.82 there will
admit almost nothing or reject almost everything.  Call
``suggest_distinctness_threshold`` on your own data before trusting it.

*Some open-weight models want an instruction prefix.*  The Qwen3-Embedding and
E5 families expect ``Instruct: ...\\nQuery: ...`` or ``query:`` / ``passage:``
prefixes and lose real accuracy without them.  ``text_prefix`` handles this;
leave it empty for BGE-M3, GTE, and the OpenAI models.

vLLM 0.10.2 serving
-------------------
    vllm serve Qwen/Qwen3-Embedding-0.6B --task embed --port 8000

The endpoint is OpenAI-compatible, so the same client code works, but it does
NOT implement the ``dimensions`` parameter (that is an OpenAI Matryoshka
feature). ``VLLMEmbedder`` therefore ignores ``dimensions`` and truncates
locally if you ask for one, which is only meaningful for models actually
trained with Matryoshka loss.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

import numpy as np

EmbedFn = Callable[[Sequence[str]], np.ndarray]


def _key(text: str, model: str) -> str:
    return hashlib.sha256(f"{model}\x00{text}".encode()).hexdigest()[:32]


class EmbeddingCache:
    """Append-only JSONL cache. Embeddings are billed and deterministic; not
    caching them means every re-cluster during development costs money and
    changes nothing."""

    def __init__(self, path: Optional[str | Path]) -> None:
        self.path = Path(path) if path else None
        self.mem: dict[str, list[float]] = {}
        if self.path and self.path.exists():
            for line in self.path.open(encoding="utf-8"):
                line = line.strip()
                if line:
                    d = json.loads(line)
                    self.mem[d["k"]] = d["v"]

    def get(self, k: str) -> Optional[list[float]]:
        return self.mem.get(k)

    def put(self, k: str, v: list[float]) -> None:
        self.mem[k] = v
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps({"k": k, "v": v}) + "\n")


@dataclass
class EmbedderConfig:
    model: str = "text-embedding-3-small"
    base_url: Optional[str] = None
    api_key_env: str = "OPENAI_API_KEY"
    batch_size: int = 64
    dimensions: Optional[int] = None      # OpenAI Matryoshka only
    text_prefix: str = ""                 # e.g. "query: " for E5
    max_chars: int = 6000
    normalise: bool = True
    max_retries: int = 4
    cache_path: Optional[str] = None


class BaseEmbedder:
    def __init__(self, cfg: EmbedderConfig) -> None:
        self.cfg = cfg
        self.cache = EmbeddingCache(cfg.cache_path)
        self._client = None

    # -- backend hook ----------------------------------------------------- #
    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        raise NotImplementedError

    # -- public ----------------------------------------------------------- #
    def __call__(self, texts: Sequence[str]) -> np.ndarray:
        prepared = [self.cfg.text_prefix + t[: self.cfg.max_chars]
                    for t in texts]
        keys = [_key(t, self.cfg.model) for t in prepared]

        # de-duplicate within the call as well as against the cache: residual
        # items often repeat verbatim, and paying twice for the same vector is
        # pure waste
        todo: list[int] = []
        seen: set[str] = set()
        for i, k in enumerate(keys):
            if self.cache.get(k) is None and k not in seen:
                seen.add(k)
                todo.append(i)
        for s in range(0, len(todo), self.cfg.batch_size):
            chunk = todo[s: s + self.cfg.batch_size]
            vecs = self._with_retry([prepared[i] for i in chunk])
            for i, v in zip(chunk, vecs):
                self.cache.put(keys[i], v)

        E = np.asarray([self.cache.get(k) for k in keys], dtype=np.float32)
        if self.cfg.dimensions and E.shape[1] > self.cfg.dimensions:
            E = E[:, : self.cfg.dimensions]
        if self.cfg.normalise:
            n = np.linalg.norm(E, axis=1, keepdims=True)
            E = E / np.maximum(n, 1e-9)
        return E

    def _with_retry(self, batch: list[str]) -> list[list[float]]:
        for attempt in range(self.cfg.max_retries):
            try:
                return self._embed_batch(batch)
            except Exception as e:                        # noqa: BLE001
                if attempt == self.cfg.max_retries - 1:
                    raise
                wait = 2 ** attempt
                print(f"[embed] {type(e).__name__}, retry in {wait}s")
                time.sleep(wait)
        return []


class OpenAIEmbedder(BaseEmbedder):
    def _ensure(self):
        if self._client is None:
            from openai import OpenAI
            self._client = OpenAI(
                api_key=os.environ.get(self.cfg.api_key_env),
                base_url=self.cfg.base_url,
            )
        return self._client

    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        kw: dict[str, Any] = {"model": self.cfg.model, "input": texts}
        if self.cfg.dimensions:
            kw["dimensions"] = self.cfg.dimensions     # native Matryoshka
        r = self._ensure().embeddings.create(**kw)
        return [d.embedding for d in sorted(r.data, key=lambda d: d.index)]


class VLLMEmbedder(BaseEmbedder):
    """vLLM 0.10.2 ``--task embed`` server, OpenAI-compatible endpoint."""

    def _ensure(self):
        if self._client is None:
            from openai import OpenAI
            self._client = OpenAI(
                api_key=os.environ.get(self.cfg.api_key_env, "EMPTY"),
                base_url=self.cfg.base_url or "http://localhost:8000/v1",
            )
        return self._client

    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        # no `dimensions`: vLLM does not implement it. Truncation, if any,
        # happens locally in __call__.
        r = self._ensure().embeddings.create(model=self.cfg.model, input=texts)
        return [d.embedding for d in sorted(r.data, key=lambda d: d.index)]


class HashEmbedder(BaseEmbedder):
    """Offline stand-in: feature hashing over word uni/bi-grams.

    Crude but not fake -- it gives real lexical similarity, so the evolution
    pipeline can be exercised and debugged without a server and the clusters
    it produces are at least word-overlap-coherent. It has no semantics beyond
    that: paraphrases land far apart. Never report results from this backend.
    """

    _WORD = None

    def __init__(self, cfg: EmbedderConfig, dim: int = 512) -> None:
        super().__init__(cfg)
        self.dim = dim
        import re as _re
        HashEmbedder._WORD = _re.compile(r"[a-z0-9]+")

    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        out = []
        for t in texts:
            toks = HashEmbedder._WORD.findall(t.lower())
            grams = toks + [f"{a}_{b}" for a, b in zip(toks, toks[1:])]
            v = np.zeros(self.dim, dtype=np.float64)
            for g in grams:
                h = hashlib.blake2b(g.encode(), digest_size=8).digest()
                i = int.from_bytes(h, "little")
                v[i % self.dim] += 1.0 if (i >> 63) & 1 else -1.0
            n = np.linalg.norm(v)
            out.append((v / n if n > 0 else v).tolist())
        return out


BACKENDS = {"openai": OpenAIEmbedder, "vllm": VLLMEmbedder, "hash": HashEmbedder}


def make_embedder(backend: str = "openai", **kw) -> BaseEmbedder:
    if backend not in BACKENDS:
        raise ValueError(f"unknown backend {backend!r}; "
                         f"choose from {sorted(BACKENDS)}")
    cfg_fields = EmbedderConfig.__dataclass_fields__
    cfg = EmbedderConfig(**{k: v for k, v in kw.items() if k in cfg_fields})
    extra = {k: v for k, v in kw.items() if k not in cfg_fields}
    if backend == "vllm" and cfg.model == "text-embedding-3-small":
        raise ValueError("set model= to the open-weight model you are serving")
    if backend == "vllm" and cfg.dimensions:
        print("[embed] vLLM ignores `dimensions`; truncating locally, which "
              "only makes sense for Matryoshka-trained models")
    return BACKENDS[backend](cfg, **extra)


# --------------------------------------------------------------------------- #
# Calibrating the distinctness threshold to the chosen backend
# --------------------------------------------------------------------------- #

def code_centroids(embed: EmbedFn, taxonomy) -> dict[str, np.ndarray]:
    """Embed each existing code as name + definition, for gate G2."""
    codes = [m.code for m in taxonomy.modes]
    texts = [f"FAILURE: {m.name}\nDEFINITION: {m.definition}"
             for m in taxonomy.modes]
    E = embed(texts)
    return dict(zip(codes, E))


def suggest_distinctness_threshold(
    embed: EmbedFn, taxonomy, quantile: float = 0.95
) -> dict[str, float]:
    """Pick ``max_centroid_cos`` from the taxonomy's own geometry.

    The seed codes are, by construction, distinct failure types that experts
    chose to keep separate. So the largest cosine observed *between* two seed
    codes is an empirical upper bound on "still distinct" in this embedding
    space. A candidate cluster closer than that to an existing code is not
    distinct by the taxonomy's own standard.
    """
    cent = code_centroids(embed, taxonomy)
    codes = sorted(cent)
    sims = []
    for i, a in enumerate(codes):
        for b in codes[i + 1:]:
            va, vb = cent[a], cent[b]
            sims.append(float(np.dot(va, vb) /
                              (np.linalg.norm(va) * np.linalg.norm(vb) + 1e-9)))
    sims_arr = np.asarray(sims)
    return {
        "n_pairs": len(sims),
        "min": float(sims_arr.min()),
        "median": float(np.median(sims_arr)),
        "q95": float(np.quantile(sims_arr, quantile)),
        "max": float(sims_arr.max()),
        "suggested_max_centroid_cos": float(np.quantile(sims_arr, quantile)),
    }
