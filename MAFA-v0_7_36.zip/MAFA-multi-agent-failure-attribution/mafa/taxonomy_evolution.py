"""
taxonomy_evolution.py
=====================
T_k -> T_{k+1}.  Collect what the seed taxonomy could not absorb, cluster it,
decide whether each cluster is a genuinely new failure type or merely an old
code whose scope was wrong, and admit only what survives the admission gate.

The A/B triage is the part that matters
---------------------------------------
Applicability masking and novelty are different things and they contaminate
each other.  ClinicalAgent is a pipeline, so 2.2.2 "unresolved conflict" is
masked out for it (no peer exposure).  If SafetyAgent and EfficacyAgent return
mutually exclusive conclusions and the Reasoner concatenates them, the
annotator will emit NOVEL -- but semantically that IS 2.2.2, carried by a
different structure.  Admitting it as a new code would be a false discovery,
and the easiest kind for a reviewer to reproduce and reject.

So every candidate cluster is re-audited with **every mask removed and all
seed codes offered**:

    A  scope revision   an existing code absorbs the cluster once unmasked.
                        Output is a revision to that code's `requires` /
                        `allowed_phases`, NOT a new code.  Still publishable --
                        it is direct evidence that the seed taxonomy is
                        framework-bound -- but it is not a new failure type.
    B  true novelty     no seed code absorbs it even unmasked.  Only B is
                        eligible for admission to T_{k+1}, and only B may be
                        claimed as a newly discovered failure type.

Admission gate
--------------
Four criteria, in two tiers. The tiers are not decorative: the screening tier
costs nothing, the validation tier costs roughly ``2 x |held-out| + |anchor|``
reasoner calls per candidate, so screening runs first and short-circuits.

    screening   G1 support       enough items, spanning enough frameworks
                G2 distinctness  separated from every existing code in
                                 embedding space AND judged non-redundant
    validation  G3 utility       re-auditing held-out data with T_k + the
                                 candidate lowers the residual rate
                G4 anti-regression  no drop beyond tolerance on the FROZEN
                                 human anchor set

Which criteria are gates is configurable (``GateConfig.enabled``); the rest are
still computed and reported, just not binding. That matters because the right
setting genuinely differs by stage of the project -- an exploratory pass wants
G1 and G2 off so it can see the long tail, a pass that will be written up wants
all four on. Every admitted code records which criteria were binding when it
passed, so a permissive run cannot later be mistaken for a strict one.

G4 is the one people skip. Without it a taxonomy can drift for several
versions while every individual step looked locally like an improvement.

On loosening G1
---------------
Support is not a bureaucratic hurdle; it is the only thing standing between a
taxonomy and a list of one-off incidents. A cluster of three is
indistinguishable from three correlated annotator mistakes, and cross-framework
spread is what separates a failure *type* from one framework's implementation
bug. But the right threshold depends on the residual pool, not on a constant:
12 out of a pool of 80 is a real mode, 12 out of 20,000 is noise. So
``min_support`` now has a proportional partner, ``min_support_frac``, and the
effective threshold is the larger of the two. Turning G1 off entirely is
supported and is the right call while exploring; it is not the right call in
anything you report, and ``evaluate_gate`` will say so once per session.
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Iterable, Optional, Sequence

import numpy as np

from .taxonomy import NOVEL_CODE, FailureMode, Taxonomy

# --------------------------------------------------------------------------- #
# Residual pool
# --------------------------------------------------------------------------- #

# --------------------------------------------------------------------------- #
# The self-evolution switch
# --------------------------------------------------------------------------- #

#: Stage 4 -- residual collection, clustering, triage and any taxonomy change --
#: is OFF unless the user turns it on. A run that only annotates and routes
#: against a fixed taxonomy is the default product; growing the taxonomy is an
#: opt-in research mode, because it changes the label space under the user and
#: voids the conformal guarantee of anything calibrated before it (see
#: ConformalRouter.check_signature).
#:
#: Before 0.7.36 this was true only by accident: Stage 4 lived in scripts that
#: the pipeline never called, so nothing was ever enabled OR disabled, no
#: output said which, and a future caller wiring `run_evolution` into the
#: pipeline would have turned it on silently.
EVOLUTION_DEFAULT = False


class EvolutionDisabled(RuntimeError):
    """Raised when Stage 4 is reached without the user enabling it."""


def evolution_enabled(cfg: Any = None) -> bool:
    """Single source of truth. `cfg` is any object with `enable_evolution`."""
    if cfg is None:
        return EVOLUTION_DEFAULT
    return bool(getattr(cfg, "enable_evolution", EVOLUTION_DEFAULT))


def require_evolution(cfg: Any = None, what: str = "Stage 4") -> None:
    if not evolution_enabled(cfg):
        raise EvolutionDisabled(
            f"{what} is off by default. It changes the label space, which "
            f"voids the coverage guarantee of anything calibrated before it. "
            f"Pass --enable-evolution (or PipelineConfig(enable_evolution="
            f"True)) if that is what you want.")


@dataclass
class ResidualItem:
    """One thing T_k failed to place."""
    trace_id: str
    framework: str
    agent_uid: str
    step_id: str
    phase: str
    source: str                  # "novel_proposal" | "empty_set" | "low_conf"
    proposed_name: str
    definition: str
    rationale: str
    evidence: list[str]
    why_not_existing: str = ""
    grounded: bool = True
    p_calibrated: Optional[float] = None
    #: structural capabilities of the source trace, carried so the Stage-4
    #: re-audit can apply the same `requires` constraint Stage 1 applies
    capabilities: dict[str, bool] = field(default_factory=dict)

    def text_for_embedding(self) -> str:
        """Name + definition + evidence.  Evidence is included deliberately:
        clustering on the proposed name alone collapses different failures that
        the annotator happened to describe with the same stock phrase."""
        ev = " || ".join(self.evidence[:2])
        return (f"FAILURE: {self.proposed_name}\n"
                f"DEFINITION: {self.definition}\n"
                f"WHY NOT EXISTING: {self.why_not_existing}\n"
                f"PHASE: {self.phase}\n"
                f"EVIDENCE: {ev}")


@dataclass
class ResidualFilter:
    """The bar a proposal has to clear before it can seed a category.

    This was added on a hypothesis that turned out to be wrong, and is kept for
    a different reason. Telling the annotator that silence is not the safe
    answer when no code fits roughly doubled the number of proposals; structural
    self-check failures per trace doubled alongside, and the obvious suspect was
    thin, hastily written proposals. Measured on both runs, the gate rejects
    **nothing**: every proposal carries a name, a definition and a reason of
    adequate length. The extra self-check failures come from the additional
    findings, not from the proposals.

    It stays because it is free insurance at a point where the cost of a bad
    entry is high -- a category seeded from an unquotable or three-word
    proposal propagates into the taxonomy -- and because it reports what it
    rejects. A pool that silently ate half its input looks exactly like a
    corpus with nothing in it, which is the failure mode that cost a real
    cluster one version ago.
    """
    require_grounded: bool = True
    #: a definition shorter than this says nothing a second annotator could act on
    min_definition_words: int = 8
    #: without a reason, the re-audit has nothing to argue against
    require_justification: bool = True
    min_justification_words: int = 4
    #: a name this short is a label, not a description
    min_name_words: int = 2


_NAME_SEP = re.compile(r"[\s_\-:./]+|(?<=[a-z0-9])(?=[A-Z])")


def _name_words(name: Any) -> int:
    """Words in a proposed name, counting across the separators models use.

    The rule being enforced is "a name of one word is a label, not a
    description". Counting `str.split()` enforces something else: "a name
    containing a space". Whether a model writes
    ``ungrounded aggregate inference`` or
    ``ungrounded_aggregate_inference`` is a formatting habit of that model,
    and the first was kept while the second was discarded as a label.

    The cost is annotator-dependent and was badly misjudged from one sample.
    On gpt-5.6-sol-disc the filter rejected 3 of 460 proposals (0.7%) and
    looked like a rounding error. On glm-5.3-flash, which names in snake_case
    almost exclusively, it rejected **52 of 74 (70%)** and reduced a usable
    residual pool to 21 items -- below `min_cluster_size` for most of the
    corpus, so Stage 4 would have found nothing and the run would have read as
    "this annotator proposes nothing worth clustering".

    camelCase is split too, on the same reasoning.
    """
    return len([w for w in _NAME_SEP.split(str(name or "")) if w])


def collect_residuals(
    annotations: Iterable[Any],
    routes: Optional[dict[str, Any]] = None,
    traces: Optional[dict[str, Any]] = None,
    require_grounded: bool = True,
    filt: Optional["ResidualFilter"] = None,
    report: Optional[dict] = None,
) -> list[ResidualItem]:
    """Harvest the residual pool from Stage-1 annotations and router output.

    Proposals that cannot clear ``filt`` are dropped here rather than later: an
    ungrounded quote is a hallucinated failure type, and a definition of three
    words can neither be argued with by the re-audit nor applied by a second
    annotator. Pass ``report`` to receive the rejection counts by reason.
    """
    filt = filt or ResidualFilter(require_grounded=require_grounded)
    rej: Counter = Counter()
    out: list[ResidualItem] = []
    for ann in annotations:
        trace = traces.get(ann.trace_id) if traces else None
        fw = getattr(trace, "framework", "unknown")
        for n in ann.novel_modes:
            grounded = any(e.grounded for e in n.evidence)
            if filt.require_grounded and not grounded:
                rej["quote not found in the transcript"] += 1
                continue
            if len(str(n.definition or "").split()) < filt.min_definition_words:
                rej["definition too thin to apply"] += 1
                continue
            if _name_words(n.proposed_name) < filt.min_name_words:
                rej["name is a label, not a description"] += 1
                continue
            if (filt.require_justification and
                    len(str(n.why_not_existing_code or "").split())
                    < filt.min_justification_words):
                rej["no reason given why existing codes do not fit"] += 1
                continue
            step = trace.step(n.step_id) if trace else None
            out.append(ResidualItem(
                trace_id=ann.trace_id, framework=fw,
                agent_uid=n.agent_uid, step_id=n.step_id,
                phase=getattr(step, "phase", "unknown"),
                source="novel_proposal",
                proposed_name=n.proposed_name, definition=n.definition,
                rationale=n.why_not_existing_code,
                evidence=[e.quote for e in n.evidence],
                why_not_existing=n.why_not_existing_code, grounded=grounded,
                capabilities=dict(getattr(trace, "capabilities", {}) or {}),
            ))
        route = routes.get(ann.trace_id) if routes else None
        if route is not None and route.decision == "NOVEL":
            for lvl in route.levels.values():
                for key in lvl.empty_keys:
                    out.append(ResidualItem(
                        trace_id=ann.trace_id, framework=fw,
                        agent_uid="", step_id="", phase="unknown",
                        source="empty_set", proposed_name=f"unplaced::{key}",
                        definition="", rationale="conformal set was empty",
                        evidence=[],
                    ))
    if rej:
        total = sum(rej.values())
        print(f"[residual] kept {len(out)}, rejected {total}: "
              + ", ".join(f"{v} {k}" for k, v in rej.most_common()))
    if report is not None:
        report["kept"] = len(out)
        report["rejected"] = dict(rej)
    return out


# --------------------------------------------------------------------------- #
# Clustering
# --------------------------------------------------------------------------- #

EmbedFn = Callable[[Sequence[str]], np.ndarray]


@dataclass
class Cluster:
    cluster_id: int
    items: list[ResidualItem]
    centroid: np.ndarray
    frameworks: Counter = field(default_factory=Counter)
    phases: Counter = field(default_factory=Counter)
    #: filled by summarise()
    name: str = ""
    definition: str = ""
    allowed_phases: frozenset[str] = frozenset()
    #: filled by triage()
    triage: str = ""                 # "A" | "B" | "AB?" | "noise"
    triage_reason: str = ""
    summarise_detail: dict = field(default_factory=dict)
    absorbing_code: Optional[str] = None
    absorb_rate: float = 0.0
    reaudit_detail: dict = field(default_factory=dict)

    @property
    def support(self) -> int:
        return len(self.items)

    @property
    def n_frameworks(self) -> int:
        return len(self.frameworks)


def cluster_residuals(
    items: Sequence[ResidualItem],
    embed: EmbedFn,
    min_cluster_size: int = 8,
    min_samples: Optional[int] = None,
) -> tuple[list[Cluster], list[ResidualItem]]:
    """HDBSCAN over residual embeddings.

    HDBSCAN rather than DBSCAN on purpose: DBSCAN needs eps, and eps is not
    transferable across embedding models, across frameworks, or across
    taxonomy versions -- which is precisely the brittleness that makes
    cluster-derived pseudo-labels drift.  HDBSCAN varies density locally and
    hands back an explicit noise label instead of forcing every point into a
    cluster.
    """
    from sklearn.cluster import HDBSCAN
    from sklearn.preprocessing import normalize

    if len(items) < min_cluster_size:
        return [], list(items)

    E = normalize(np.asarray(embed([i.text_for_embedding() for i in items])))
    labels = HDBSCAN(
        min_cluster_size=min_cluster_size,
        min_samples=min_samples,
        metric="euclidean",              # on L2-normalised vectors == cosine
        copy=True,
        cluster_selection_method="leaf",  # finer clusters; merge later via G2
    ).fit_predict(E)

    clusters: list[Cluster] = []
    noise: list[ResidualItem] = []
    for lab in sorted(set(labels)):
        idx = [i for i, l in enumerate(labels) if l == lab]
        if lab == -1:
            noise = [items[i] for i in idx]
            continue
        members = [items[i] for i in idx]
        clusters.append(Cluster(
            cluster_id=int(lab), items=members,
            centroid=E[idx].mean(axis=0),
            frameworks=Counter(m.framework for m in members),
            phases=Counter(m.phase for m in members),
        ))
    clusters.sort(key=lambda c: -c.support)
    return clusters, noise


# --------------------------------------------------------------------------- #
# Summarisation and A/B triage
# --------------------------------------------------------------------------- #

SummariseFn = Callable[[Cluster], dict[str, Any]]
#: (cluster, taxonomy) -> {"absorbed_by": code|None, "absorb_rate": float}
UnmaskedReauditFn = Callable[[Cluster, Taxonomy], dict[str, Any]]

SUMMARISE_PROMPT = """\
You are consolidating an open-coding pass over failures in medical multi-agent
consultations. Below are {n} independently written descriptions of failures
that a fixed taxonomy could not classify. They were grouped automatically
because their embeddings are close.

Your job is to decide whether they describe ONE coherent failure type, and if
so to name and define it.

{items}

Return JSON:
{{
  "coherent": true or false,
  "name": "a short noun phrase, in the register of a taxonomy code",
  "definition": "2-3 sentences; state what must be observable in a transcript
                 for this to apply, and what would NOT count",
  "allowed_phases": ["one or more of: recruitment, planning,
                     independent_analysis, discussion, review, synthesis,
                     decision"],
  "requires": ["structural capabilities the framework must have, from:
               has_recruitment, has_explicit_roles, has_multi_round,
               has_peer_exposure, has_aggregator, has_image"],
  "outliers": [indices of items that do not belong to this type]
}}
If the items describe more than one distinct failure, set coherent=false.
"""

UNMASKED_REAUDIT_PROMPT = """\
Below is a failure observed in a medical multi-agent consultation, and the FULL
list of failure-mode definitions from an existing taxonomy. Applicability
constraints have been deliberately removed: consider every code, even ones
normally restricted to other collaboration structures.

FAILURE:
{item}

EXISTING CODES:
{codes}

Question: does any existing code already cover this failure SEMANTICALLY, even
if the collaboration structure differs from the one the code was written for?
A code covers it if a domain expert would say "this is that failure, just
happening in a different kind of system".

Return JSON:
{{
  "absorbed_by": "the code, or null if no code covers it",
  "confidence": "low" | "medium" | "high",
  "reasoning": "one or two sentences",
  "structural_difference": "if absorbed, how the manifestation differs from the
                            code's original setting"
}}
"""


@dataclass
class TriageConfig:
    """How the A/B split is decided.

    ``absorb_threshold`` is the fraction of a cluster's items that an existing
    code must absorb under unmasked re-audit before the cluster counts as A.
    0.5 rather than something small on purpose: a couple of absorbed items in a
    cluster of thirty is ordinary noise, not evidence that the whole cluster is
    an old code wearing a new structure.

    ``ambiguous_band`` is the part that matters. A cluster whose absorb rate
    lands within +/- this of the threshold is not forced to a side; it is marked
    ``AB?`` and goes to a human. The entire premise of this project is that
    uncertain automated judgements should be routed rather than rounded, and
    the A/B call is exactly such a judgement -- arguably the highest-stakes one
    in the pipeline, since it decides whether something gets claimed as a newly
    discovered failure type. Set the band to 0.0 to restore a hard cut.

    ``min_votes`` guards against deciding from too few re-audit samples: with
    three items sampled, an absorb rate of 0.33 versus 0.67 is one opinion.
    """
    absorb_threshold: float = 0.5
    ambiguous_band: float = 0.15
    min_votes: int = 5
    #: re-audit confidences that count as a vote for absorption
    accept_confidence: tuple[str, ...] = ("medium", "high")
    sample_per_cluster: int = 12
    #: how many independent re-audits to run per cluster.
    #:
    #: One vote is not enough. Measured on the same mechanism twice, a cluster
    #: of 5 came back 0/5 absorbed -- novel -- and a cluster of 28 describing
    #: the same thing came back 5/5 absorbed, unanimously. The ambiguous band
    #: cannot catch that: it watches for rates near the threshold, and these
    #: sat at the two ends. Repeating the whole re-audit and looking at the
    #: spread is the only thing that would have shown the instability at the
    #: time rather than a version later.
    repeats: int = 3
    #: how many times to ask the summariser to name a cluster.
    #:
    #: The same instability that made the re-audit unreliable sits one step
    #: earlier. The same 39-item cluster was given a precise definition and
    #: judged A on one run, and on the next the summariser declined to name it
    #: at all. A single naming call is a single point of failure for everything
    #: downstream: without a name and a definition there is nothing for the
    #: re-audit to argue about, so the cluster cannot be A or B whatever it
    #: actually is.
    summarise_repeats: int = 3
    #: when every naming attempt refuses, split the cluster and try again.
    #:
    #: A refusal to name is not a failure of the summariser, it is a report
    #: about the cluster. Asked to name a 39-item group it declined twice and
    #: on the third attempt wrote a definition that ends by listing the four
    #: *other* error types in the same group that it does not cover. The group
    #: held five distinct failures; the correct response is to cut it, not to
    #: ask again louder. Re-clustering only its own members is more precise
    #: than lowering min_cluster_size globally, and the refusal is a reliable
    #: signal of exactly where to do it.
    resplit_unnameable: bool = True
    #: don't bother splitting a group this small -- it is unnameable because
    #: it is noise, not because it is mixed
    resplit_min_size: int = 12
    #: how many times to cut before giving up and routing to a human
    resplit_depth: int = 1
    #: if the repeats disagree by more than this, the cluster goes to a human
    #: regardless of where the mean falls
    max_rate_spread: float = 0.34
    #: the share of repeats that must name the SAME absorbing code.
    #:
    #: Added after run_ab5, where a cluster returned rates [0.625, 0.5, 0.5]
    #: -- spread 0.125, stable by the rate test -- while naming 2.1.1 twice
    #: and 1.2.1 once. It then had its absorb_rate compared against the band
    #: as though "an existing code" had been identified, when the repeats had
    #: named two. At the default three repeats 2/3 = 0.667 < 0.67, so the
    #: check fires on ANY dissent about the code. That is strict, and it is
    #: the strictness this file already argues for elsewhere: "uncertain
    #: automated judgements should be routed rather than rounded, and the A/B
    #: call is arguably the highest-stakes one in the pipeline". A 2-1 split
    #: over which code covers a cluster is uncertainty, and rounding it into
    #: "2.1.1 absorbs it at 0.54" is the rounding that argument forbids.
    #:
    #: The alternative -- admitting 2-of-3 -- would make the check inert at
    #: repeats=3, since only a three-way split could then trigger it.
    #: Raise `repeats` if a less brittle reading is wanted; the threshold is
    #: a share, so it scales.
    min_code_agreement: float = 0.67
    #: whether the unmasked re-audit may offer a code to an item whose phase
    #: that code forbids, or whose trace lacks a capability the code requires.
    #:
    #: Stage 1 has always enforced both: `stage1_schema.py` builds no slot for
    #: a code the step's phase excludes, and records `phase_illegal` if one
    #: appears anyway. The Stage-4 re-audit did not, and on run_ab2 that let
    #: 1.2.1 -- allowed only in discussion / independent_analysis / review --
    #: absorb a 22-item cluster that was 20/22 at `recruitment`. The asymmetry
    #: runs one way: absorption is the "nothing new here" verdict, so the
    #: missing filter biases the loop away from discovery.
    #:
    #: **Default False, deliberately.** Measured in run_ab2/filter_arms.json on
    #: four fixed groups, three repeats each: switching this on never changed
    #: which code won -- it only lowered the rate. c0 chose 2.1.1 with six
    #: codes offered and still chose 2.1.1 with 2.1.1 as the only candidate,
    #: but its rate fell 1.00 -> 0.25. The filter collapses the candidate set
    #: to a single code for almost every item on this taxonomy, turning the
    #: judge's task from a six-way choice into a yes/no, and a yes/no draws
    #: more refusals. That is a framing effect, not a correction.
    #:
    #: So its rates cannot be read against `absorb_threshold` and
    #: `ambiguous_band`, which were calibrated without it: everything drifts
    #: toward "B", i.e. toward claiming discoveries. Recalibrate first.
    reaudit_respects_structure: bool = False
    #: what to do with a cluster the summariser calls incoherent.
    #: "route"  -> mark AB? and put it in front of a human (default)
    #: "drop"   -> discard it, the old behaviour
    #: "ignore" -> triage it anyway, as if coherent
    #:
    #: The default changed because "drop" silently lost a correct result. In
    #: the held-out-code ablation, eight residuals that were plainly one thing
    #: -- an overall trial failure rate reported as a safety failure rate, a
    #: single-drug figure attributed to a combination -- clustered together
    #: correctly and were then discarded on one summariser call, never reaching
    #: the re-audit and never appearing in any queue. A single LLM judgement
    #: should not hold a veto that leaves no trace.
    incoherent: str = "route"
    #: deprecated alias; True maps to "route", False to "ignore"
    require_coherent: Optional[bool] = None

    def __post_init__(self) -> None:
        if self.require_coherent is not None:
            self.incoherent = "route" if self.require_coherent else "ignore"
        if self.incoherent not in ("route", "drop", "ignore"):
            raise ValueError("incoherent must be one of route, drop, ignore")
        if self.sample_per_cluster < self.min_votes:
            raise ValueError(
                f"sample_per_cluster={self.sample_per_cluster} is below "
                f"min_votes={self.min_votes}: every cluster would fall through "
                "to 'AB?' on the vote-count check before the threshold is ever "
                "consulted, which silently disables the A/B split. Raise the "
                "sample or lower min_votes deliberately.")
        if not 0.0 <= self.absorb_threshold <= 1.0:
            raise ValueError("absorb_threshold must be in [0, 1]")
        if not 0.0 <= self.ambiguous_band < 0.5:
            raise ValueError("ambiguous_band must be in [0, 0.5)")
        if self.repeats < 1:
            raise ValueError("repeats must be at least 1")


#: hard-cut preset, for the ablation that shows what the band buys
TRIAGE_HARD_CUT = TriageConfig(ambiguous_band=0.0, min_votes=1)


def resplit(cluster: Cluster, embed, min_cluster_size: int = 4
            ) -> tuple[list[Cluster], Optional[Cluster]]:
    """Re-cluster one group's own members, tighter.

    Used when every attempt to name a group refuses. A refusal is not a
    failure of the summariser, it is a report about the group: asked to name a
    39-item cluster it declined twice, and on the third attempt produced a
    definition ending with a list of the four *other* error types in the same
    group that it does not cover. The group held five distinct failures.

    Splitting locally leaves the rest of the pool untouched, which lowering
    ``min_cluster_size`` globally would not, and the refusal says exactly where
    to cut.

    Returns ``(parts, remainder)``. **The remainder is not optional to handle.**
    Re-clustering 37 items on the first real run returned parts of 16 and 4 and
    left 17 at label -1 -- 46% of the group. Before 0.7.15 those were simply
    absent from the return value: no queue, no count, no line of output. That is
    the 0.7.7 silent drop at a finer granularity, and it is why this returns a
    tuple rather than a list. The caller must route the remainder.
    """
    from sklearn.cluster import HDBSCAN
    from sklearn.preprocessing import normalize

    items = cluster.items
    if len(items) < max(min_cluster_size * 2, 8):
        return [], None
    E = normalize(np.asarray(embed([i.text_for_embedding() for i in items])))
    # copy=True to match cluster_residuals. E is reused below for the part
    # centroids, which feed gate G2, so it must not be modified in place --
    # and sklearn's default flips in 1.10.
    labels = HDBSCAN(min_cluster_size=min_cluster_size, metric="euclidean",
                     copy=True,
                     cluster_selection_method="leaf").fit_predict(E)

    def _build(cid: int, idx: list[int]) -> Cluster:
        members = [items[i] for i in idx]
        return Cluster(cluster_id=cid, items=members,
                       centroid=E[idx].mean(axis=0),
                       frameworks=Counter(m.framework for m in members),
                       phases=Counter(m.phase for m in members))

    out = [_build(cluster.cluster_id * 100 + int(lab),
                  [i for i, l in enumerate(labels) if l == lab])
           for lab in sorted({l for l in labels if l != -1})]
    if len(out) <= 1:
        return [], None

    left = [i for i, l in enumerate(labels) if l == -1]
    remainder = _build(cluster.cluster_id * 100 + 99, left) if left else None
    return out, remainder


def triage_clusters(
    clusters: Sequence[Cluster],
    taxonomy: Taxonomy,
    summarise: SummariseFn,
    unmasked_reaudit: UnmaskedReauditFn,
    cfg: TriageConfig = TriageConfig(),
    embed=None,
    _depth: int = 0,
) -> list[Cluster]:
    """Name each cluster, then split A (scope revision) from B (true novelty).

    Sets ``cluster.triage`` to one of:
        "A"     an existing code absorbs it once unmasked -> scope revision
        "B"     nothing absorbs it even unmasked -> eligible for admission
        "AB?"   the absorb rate is too close to call, or too few votes ->
                needs a human before it can be claimed either way
        "noise" the summariser judged the cluster incoherent
    """
    import copy

    lo = cfg.absorb_threshold - cfg.ambiguous_band
    hi = cfg.absorb_threshold + cfg.ambiguous_band
    out = []
    for original in clusters:
        # Return fresh objects. Running this twice with different configs -- an
        # ablation you will want -- must not clobber the first result, and a
        # silently mutated input is a nasty way to find that out.
        c = copy.copy(original)
        c.items = list(original.items)
        # Ask more than once. Take the first coherent answer; only call the
        # cluster unnameable when every attempt refuses, which distinguishes
        # "these items have nothing in common" from "one call had an off day".
        attempts = [summarise(c) for _ in range(max(1, cfg.summarise_repeats))]
        coherent = [x for x in attempts if x.get("coherent")]
        s = coherent[0] if coherent else attempts[0]
        c.summarise_detail = {
            "attempts": len(attempts),
            "coherent": len(coherent),
            "names": [x.get("name") for x in attempts if x.get("name")],
        }
        if not s.get("coherent", False) and cfg.incoherent != "ignore":
            # A unanimous refusal on a large group is a report about the group,
            # not a failure of the summariser: it is mixed. Cut it and try the
            # pieces, which is more precise than lowering min_cluster_size for
            # the whole pool.
            would_resplit = (cfg.resplit_unnameable and not coherent
                             and len(c.items) >= cfg.resplit_min_size
                             and _depth < cfg.resplit_depth)
            if would_resplit and embed is None:
                # Say so. A feature that is configured on and silently does
                # nothing is the shape of bug this pipeline keeps paying for:
                # the run looks normal and the result is the old behaviour.
                print(f"[triage] cluster {c.cluster_id}: resplit_unnameable is "
                      f"on and {len(c.items)} items went unnamed, but no "
                      f"embedder was passed to triage_clusters(embed=...), so "
                      f"the cluster is being routed instead of split")
                c.summarise_detail["resplit_skipped"] = "no embedder passed"
            if would_resplit and embed is not None:
                parts, remainder = resplit(c, embed)
                if parts:
                    n_left = remainder.support if remainder else 0
                    print(f"[triage] cluster {c.cluster_id}: all "
                          f"{len(attempts)} naming attempts refused on "
                          f"{len(c.items)} items; split into {len(parts)} of "
                          f"{[p.support for p in parts]}"
                          + (f", {n_left} left unassigned -> routed as "
                             f"cluster {remainder.cluster_id}" if remainder
                             else ""))
                    out.extend(triage_clusters(parts, taxonomy, summarise,
                                               unmasked_reaudit, cfg,
                                               embed=embed, _depth=_depth + 1))
                    if remainder is not None:
                        # Route, do not recurse. These items were too sparse to
                        # join any part, so asking the summariser to name them
                        # as a group would be asking the wrong question. They
                        # are individually real residue and a human should see
                        # them; the one thing they must not do is vanish.
                        remainder.name = (f"unassigned remainder of cluster "
                                          f"{c.cluster_id}")
                        remainder.triage = "AB?"
                        remainder.triage_reason = (
                            f"{n_left} of {len(c.items)} items joined no part "
                            f"when cluster {c.cluster_id} was split into "
                            f"{[p.support for p in parts]}; too sparse to "
                            f"cluster, not covered by any part")
                        out.append(remainder)
                    continue
            if cfg.incoherent == "drop":
                c.triage = "noise"
                c.triage_reason = "summariser judged the cluster incoherent"
            else:
                # keep whatever name it managed, so a human has something to
                # read, and send it on rather than losing it
                c.name = s.get("name") or (c.items[0].proposed_name if c.items else "")
                c.definition = s.get("definition") or ""
                c.triage = "AB?"
                c.triage_reason = (
                    "the summariser could not state one failure type for these "
                    f"{len(c.items)} items; a human should look before they are "
                    "discarded")
            out.append(c)
            continue
        c.name = s.get("name", "")
        c.definition = s.get("definition", "")
        c.allowed_phases = frozenset(s.get("allowed_phases") or [])
        outliers = set(s.get("outliers") or [])
        if outliers:
            c.items = [it for i, it in enumerate(c.items) if i not in outliers]
            c.frameworks = Counter(m.framework for m in c.items)

        runs = [unmasked_reaudit(c, taxonomy) for _ in range(cfg.repeats)]
        rates = [float(x.get("absorb_rate", 0.0)) for x in runs]
        spread = max(rates) - min(rates)
        # the winning code is the one most runs settle on, not the last one
        code_votes: Counter = Counter(
            x.get("absorbed_by") for x in runs if x.get("absorbed_by"))
        r = dict(runs[0])
        r["repeats"] = cfg.repeats
        r["rates"] = [round(x, 3) for x in rates]
        r["rate_spread"] = round(spread, 3)
        r["code_votes"] = dict(code_votes)
        # Rate stability without CODE stability is not stability.
        #
        # `rate_spread` asks whether the repeats agree on *how much* of the
        # cluster an existing code absorbs. It never asked whether they agree
        # on *which* code. A real case from run_ab5: three re-audits returned
        # rates [0.625, 0.5, 0.5] -- spread 0.125, comfortably stable -- while
        # naming 2.1.1 twice and 1.2.1 once. The cluster passed the stability
        # check and was then judged against an "absorbing code" that only two
        # of three runs agreed on.
        #
        # The A/B question is per code: "is this cluster an existing code" is
        # really "is this cluster code X" for some specific X. If the repeats
        # cannot agree on X, no single code has been shown to cover the
        # cluster, whatever the pooled rate says.
        n_coded = sum(code_votes.values())
        r["code_agreement"] = (round(code_votes.most_common(1)[0][1] / n_coded, 3)
                               if n_coded else None)
        r["codes_named"] = len(code_votes)
        c.absorb_rate = sum(rates) / len(rates)
        c.absorbing_code = (code_votes.most_common(1)[0][0]
                            if code_votes else None)
        c.reaudit_detail = r

        n = int(r.get("n_sampled", 0) or 0)
        agree = r.get("code_agreement")
        if (cfg.repeats > 1 and agree is not None
                and agree < cfg.min_code_agreement and r["codes_named"] > 1):
            # Disagreement about the absorbing code. Which way this cuts
            # depends on how much was absorbed at all: a cluster that absorbs
            # heavily into several different codes is impure and wants
            # splitting, while one that absorbs moderately into several is
            # simply not covered by any of them.
            if c.absorb_rate >= hi:
                c.triage = "AB?"
                c.triage_reason = (
                    f"{cfg.repeats} re-audits named {r['codes_named']} "
                    f"different absorbing codes {dict(code_votes)} at a high "
                    f"absorb_rate {c.absorb_rate:.2f}: the cluster looks "
                    f"impure rather than novel, and wants splitting before "
                    f"it is judged.")
            else:
                c.triage = "B"
                c.triage_reason = (
                    f"{cfg.repeats} re-audits named {r['codes_named']} "
                    f"different absorbing codes {dict(code_votes)} "
                    f"(agreement {agree:.2f} < {cfg.min_code_agreement:.2f}); "
                    f"no single existing code was shown to cover this "
                    f"cluster, whatever the pooled absorb_rate "
                    f"{c.absorb_rate:.2f} suggests.")
            out.append(c)
            continue
        if cfg.repeats > 1 and spread > cfg.max_rate_spread:
            c.triage = "AB?"
            c.triage_reason = (
                f"{cfg.repeats} independent re-audits disagreed: rates "
                f"{r['rates']}, spread {spread:.2f} > {cfg.max_rate_spread:.2f}. "
                "A verdict this unstable is not one to act on.")
            out.append(c)
            continue
        if n < cfg.min_votes:
            c.triage = "AB?"
            c.triage_reason = f"only {n} re-audit votes (< {cfg.min_votes})"
        elif not c.absorbing_code:
            c.triage = "B"
            c.triage_reason = "no existing code absorbed any item"
        elif c.absorb_rate >= hi:
            c.triage = "A"
            c.triage_reason = (f"absorb_rate {c.absorb_rate:.2f} >= {hi:.2f} "
                               f"by {c.absorbing_code}")
        elif c.absorb_rate <= lo:
            c.triage = "B"
            c.triage_reason = f"absorb_rate {c.absorb_rate:.2f} <= {lo:.2f}"
        else:
            c.triage = "AB?"
            c.triage_reason = (f"absorb_rate {c.absorb_rate:.2f} inside the "
                               f"ambiguous band [{lo:.2f}, {hi:.2f}] "
                               f"(nearest: {c.absorbing_code})")
        out.append(c)
    return out


def triage_sensitivity(clusters: Sequence[Cluster],
                       thresholds: Sequence[float] = (0.2, 0.3, 0.4, 0.5,
                                                      0.6, 0.7, 0.8)
                       ) -> list[dict[str, Any]]:
    """How the A/B counts move as the threshold moves.

    Report this. A novelty claim that only survives at one particular
    threshold is not a finding, and this table is what shows whether the split
    is stable or is sitting on a knife edge.
    """
    rows = []
    scored = [c for c in clusters if c.triage != "noise"]
    for t in thresholds:
        a = sum(1 for c in scored if c.absorbing_code and c.absorb_rate >= t)
        rows.append({"threshold": t, "A": a, "B": len(scored) - a,
                     "n_scored": len(scored)})
    return rows


_CODE_RE = re.compile(
    r"^\s*([0-9]+(?:\.[0-9]+)+|FM-[0-9.]+|D[0-9]+\.[a-z0-9-]+|T[0-9]+\.[0-9]+)")


def normalise_code(value: Any, taxonomy: "Taxonomy") -> Optional[str]:
    """Pull a bare code out of whatever the judge returned.

    Judges routinely answer ``"2.2.1 Repetition of initial views (echo
    chamber)"`` rather than ``"2.2.1"``. Matching that against the code set
    fails, the vote is silently dropped, absorb_rate comes out 0.0, and every
    cluster is triaged B -- i.e. the pipeline reports maximal novelty precisely
    because the judge was being helpful. Observed on claude-opus-5, so this is
    not hypothetical.
    """
    if not value:
        return None
    text = str(value).strip()
    known = {m.code for m in taxonomy.modes}
    if text in known:
        return text
    m = _CODE_RE.match(text)
    if m and m.group(1) in known:
        return m.group(1)
    for code in sorted(known, key=len, reverse=True):
        if code in text:
            return code
    return None


def make_llm_reaudit(call_json: Callable[[str], dict],
                     sample_per_cluster: int = 12,
                     accept_confidence: tuple[str, ...] = ("medium", "high")
                     ) -> UnmaskedReauditFn:
    """Build an ``UnmaskedReauditFn`` from a JSON-returning LLM callable."""
    def fn(cluster: Cluster, taxonomy: Taxonomy) -> dict[str, Any]:
        codes = "\n".join(f"- {m.code} {m.name}: {m.definition}"
                          for m in taxonomy.modes)
        votes: Counter = Counter()
        n = 0
        for item in cluster.items[:sample_per_cluster]:
            try:
                r = call_json(UNMASKED_REAUDIT_PROMPT.format(
                    item=item.text_for_embedding(), codes=codes))
            except Exception:                              # noqa: BLE001
                continue
            n += 1
            code = normalise_code(r.get("absorbed_by"), taxonomy)
            if code and r.get("confidence") in set(accept_confidence):
                votes[code] += 1
        if not n or not votes:
            return {"absorbed_by": None, "absorb_rate": 0.0, "n_sampled": n}
        code, k = votes.most_common(1)[0]
        return {"absorbed_by": code, "absorb_rate": k / n, "n_sampled": n,
                "votes": dict(votes)}
    return fn


# --------------------------------------------------------------------------- #
# Admission gate
# --------------------------------------------------------------------------- #

GATE_NAMES = ("G1", "G2", "G3", "G4")
GATE_TIER = {"G1": "screening", "G2": "screening",
             "G3": "validation", "G4": "validation"}
GATE_LABEL = {"G1": "support", "G2": "distinctness",
              "G3": "utility", "G4": "anti_regression"}

_WARNED: set[str] = set()


def _warn_once(key: str, message: str) -> None:
    if key not in _WARNED:
        _WARNED.add(key)
        print(message)


@dataclass
class GateResult:
    passed: bool
    #: gate -> "pass" | "fail" | "skipped" (not enabled) | "not_run"
    status: dict[str, str] = field(default_factory=dict)
    enabled: tuple[str, ...] = GATE_NAMES
    detail: dict[str, Any] = field(default_factory=dict)

    # -- back-compatible accessors ---------------------------------------- #
    @property
    def g1_support(self) -> bool: return self.status.get("G1") != "fail"

    @property
    def g2_distinct(self) -> bool: return self.status.get("G2") != "fail"

    @property
    def g3_utility(self) -> bool: return self.status.get("G3") != "fail"

    @property
    def g4_no_regression(self) -> bool: return self.status.get("G4") != "fail"

    @property
    def binding(self) -> list[str]:
        """The criteria that actually had to hold for this to pass."""
        return [g for g in self.enabled if self.status.get(g) == "pass"]

    def summary(self) -> str:
        return " ".join(
            f"{g}:{GATE_LABEL[g]}={self.status.get(g, 'not_run')}"
            for g in GATE_NAMES)


@dataclass
class GateConfig:
    #: which criteria bind. Disabled ones are still computed where cheap, and
    #: always reported, but cannot block admission.
    enabled: tuple[str, ...] = GATE_NAMES
    #: skip the expensive validation tier when screening has already failed
    short_circuit: bool = True

    # G1
    #: absolute floor, and only a floor. It exists to stop a degenerate
    #: configuration (`min_cluster_size = 2`, say) from making the support
    #: criterion vacuous, not to set the operating point. 6 rather than the
    #: old 12 because the argument this file makes for support -- "a cluster
    #: of three is indistinguishable from three correlated annotator
    #: mistakes" -- runs out somewhere around there and has nothing to say
    #: about 12 in particular. 12 was a number calibrated by eye against a
    #: pool of about 80 and then shipped as a constant, in a module whose own
    #: docstring argues that the threshold should not be a constant.
    min_support: int = 6
    #: of the residual pool. Now non-zero by default: the module has always
    #: recommended a proportional term and then shipped it disabled, so the
    #: absolute floor bound in every run ever made.
    min_support_frac: float = 0.05
    #: the clusterer's own floor, and the term that should usually bind.
    #:
    #: HDBSCAN will not emit a group smaller than `min_cluster_size`, so a
    #: support requirement AT that value is satisfied by construction and
    #: carries no information. The requirement has to sit above it to mean
    #: anything, and `support_multiple` says by how much.
    #:
    #: These two were never reconciled. run_ab5 clustered at
    #: min_cluster_size = 5 and produced clusters of 11, 9, 5 and 4, while the
    #: gate asked for 12 -- so no cluster the clusterer could produce at that
    #: setting had a realistic chance of passing, and the gate was not
    #: measuring support so much as measuring the mismatch.
    min_cluster_size: Optional[int] = None
    #: 2.0 is an argument, not a preference: a cluster at twice the
    #: clusterer's floor would still have been found as a cluster if the
    #: corpus were cut in half. A mode that survives halving the data is a
    #: mode; one sitting at the floor is whatever the floor admits.
    support_multiple: float = 2.0
    #: how many frameworks must show the failure -- counted against the ones
    #: that *could* show it, not against the corpus. See eligible_frameworks.
    min_frameworks: int = 2
    #: cap min_frameworks at this share of the eligible set, so the rule stays
    #: meaningful as the corpus grows or shrinks. 0 disables.
    min_framework_fraction: float = 0.0
    # G2
    max_centroid_cos: float = 0.82     # backend-specific: recalibrate it
    # G3
    min_utility_gain: float = 0.02
    # G4
    max_anchor_drop: float = 0.01

    def __post_init__(self) -> None:
        bad = [g for g in self.enabled if g not in GATE_NAMES]
        if bad:
            raise ValueError(f"unknown gate(s) {bad}; choose from {GATE_NAMES}")

    def is_on(self, gate: str) -> bool:
        return gate in self.enabled

    @property
    def screening_on(self) -> tuple[str, ...]:
        return tuple(g for g in self.enabled if GATE_TIER[g] == "screening")

    @property
    def validation_on(self) -> tuple[str, ...]:
        return tuple(g for g in self.enabled if GATE_TIER[g] == "validation")


#: convenience presets
GATE_EXPLORATORY = GateConfig(enabled=("G2",), min_support=3, min_frameworks=1)
GATE_STRICT = GateConfig()
GATE_CHEAP_ONLY = GateConfig(enabled=("G1", "G2"))


#: how concentrated the observed phases must be before they are used as a
#: stand-in for a declared `allowed_phases`, and how many members are needed
#: for that concentration to carry information. A phase holding 80% of a
#: cluster of 8 is a structural fact about where the failure occurs; the same
#: share of a cluster of 3 is two coincidences.
_PHASE_INFER_MIN_SHARE = 0.8
_PHASE_INFER_MIN_ITEMS = 6


def eligible_frameworks(cluster: Cluster,
                        framework_caps: dict[str, dict[str, bool]]) -> list[str]:
    """Frameworks that could exhibit this failure at all.

    Requiring a candidate to appear in two frameworks sounds like ordinary
    prudence and is sometimes a demand for the impossible. The ablation threw
    up a cluster of 22 describing a recruiter breaking its output contract, 20
    of them from MDAgents -- which is the only one of the four frameworks that
    *has* a recruitment stage. No amount of further data would ever have
    produced a second framework for it, and under a flat ``min_frameworks >= 2``
    it could never be admitted.

    Different coordination designs really do have failures the others cannot
    have. So the count is taken against the frameworks whose structure permits
    the cluster's phases, and a failure confined to the only framework that
    could show it is not penalised for it.
    """
    phases = cluster.allowed_phases or frozenset()
    if not phases:
        # The summariser is not obliged to declare allowed_phases and often
        # leaves it empty. Falling back to "every framework" then defeats this
        # function on precisely the clusters it was written for: the run_ab5
        # candidate had `phases = {"recruitment": 9}` -- every member in the
        # one phase only MDAgents has -- an empty `allowed_phases`, and was
        # therefore judged as though four frameworks could have shown it and
        # only one did.
        #
        # So fall back to what was *observed* rather than to no constraint at
        # all. Observation is weaker evidence than a declaration and is
        # treated as such: it is used only when the members concentrate in a
        # small set of phases and there are enough of them for that
        # concentration to mean something. Below either bar the old
        # permissive fallback stands, because a scattered or tiny cluster
        # genuinely does not tell us where the failure can occur.
        obs = cluster.phases or Counter()
        total = sum(obs.values())
        if total >= _PHASE_INFER_MIN_ITEMS:
            top = {p for p, n in obs.items()
                   if n / total >= _PHASE_INFER_MIN_SHARE}
            if top:
                phases = frozenset(top)
        if not phases:
            return sorted(framework_caps)
    need = {
        "recruitment": "has_recruitment",
        "discussion": "has_peer_exposure",
        "review": "has_peer_exposure",
        "synthesis": "has_aggregator",
        "decision": "has_aggregator",
    }
    out = []
    for fw, caps in framework_caps.items():
        if any(need.get(p) is None or caps.get(need[p], False) for p in phases):
            out.append(fw)
    return sorted(out) or sorted(framework_caps)


def evaluate_gate(
    cluster: Cluster,
    taxonomy: Taxonomy,
    code_centroids: dict[str, np.ndarray],
    utility_fn: Optional[Callable[[Cluster, Taxonomy], dict[str, float]]] = None,
    anchor_fn: Optional[Callable[[Cluster, Taxonomy], dict[str, float]]] = None,
    llm_distinctness: Optional[Callable[[Cluster, FailureMode], bool]] = None,
    cfg: GateConfig = GateConfig(),
    pool_size: Optional[int] = None,
    framework_caps: Optional[dict[str, dict[str, bool]]] = None,
) -> GateResult:
    """Evaluate the admission criteria, honouring ``cfg.enabled``.

    ``pool_size`` is the size of the residual pool the cluster came from; it is
    what makes ``min_support_frac`` meaningful. Omit it and only the absolute
    ``min_support`` applies.
    """
    detail: dict[str, Any] = {}
    status: dict[str, str] = {g: "skipped" for g in GATE_NAMES}

    if "G1" not in cfg.enabled and "G1" not in _WARNED:
        _WARNED.add("G1")
        print("[gate] G1 (support) is disabled. Fine while exploring; a "
              "taxonomy admitted without it is a list of incidents, and that "
              "should not be reported as a discovered failure type.")

    # ---- screening tier -------------------------------------------------- #
    terms = {"absolute_floor": cfg.min_support}
    need = cfg.min_support
    if pool_size and cfg.min_support_frac > 0:
        t = int(math.ceil(cfg.min_support_frac * pool_size))
        terms["share_of_pool"] = t
        need = max(need, t)
    if cfg.min_cluster_size:
        t = int(math.ceil(cfg.support_multiple * cfg.min_cluster_size))
        terms["above_clusterer_floor"] = t
        need = max(need, t)
    else:
        terms["above_clusterer_floor"] = None
        _warn_once(
            "gate_no_min_cluster_size",
            "[gate] min_cluster_size not supplied, so the support "
            "requirement is not coupled to the clusterer's floor. A "
            "requirement at or below min_cluster_size is satisfied by "
            "construction; pass it so the two can be reconciled.")
    detail["support"] = cluster.support
    detail["support_required"] = need
    detail["support_terms"] = terms
    detail["support_binding_term"] = max(
        ((k, v) for k, v in terms.items() if v is not None),
        key=lambda kv: kv[1])[0]
    detail["frameworks"] = dict(cluster.frameworks)
    detail["pool_size"] = pool_size

    elig = (eligible_frameworks(cluster, framework_caps)
            if framework_caps else None)
    fw_need = cfg.min_frameworks
    if elig is not None:
        # never ask for more frameworks than could possibly show it
        fw_need = min(fw_need, len(elig))
        if cfg.min_framework_fraction > 0:
            fw_need = min(fw_need,
                          max(1, int(round(cfg.min_framework_fraction * len(elig)))))
        detail["eligible_frameworks"] = elig
        detail["frameworks_required"] = fw_need
        if len(elig) == 1:
            detail["framework_note"] = (
                f"only {elig[0]} can exhibit this at all, so the "
                "cross-framework requirement is vacuous and was relaxed to 1")
    else:
        detail["frameworks_required"] = fw_need
        detail["framework_note"] = ("no capability map given, so the count ran "
                                    "against all frameworks in the cluster")
    if cfg.is_on("G1"):
        status["G1"] = "pass" if (cluster.support >= need and
                                  cluster.n_frameworks >= fw_need) else "fail"

    sims = {}
    for code, cen in code_centroids.items():
        d = float(np.dot(cluster.centroid, cen) /
                  (np.linalg.norm(cluster.centroid) * np.linalg.norm(cen) + 1e-9))
        sims[code] = round(d, 4)
    nearest = max(sims, key=sims.get) if sims else None
    detail["nearest_code"] = nearest
    detail["nearest_cos"] = sims.get(nearest) if nearest else None
    if cfg.is_on("G2"):
        ok = (not sims) or sims[nearest] < cfg.max_centroid_cos
        if ok and llm_distinctness and nearest:
            m = taxonomy.get(nearest)
            if m is not None:
                ok = bool(llm_distinctness(cluster, m))
                detail["llm_distinct"] = ok
        status["G2"] = "pass" if ok else "fail"

    screening_failed = any(status[g] == "fail" for g in cfg.screening_on)
    if screening_failed and cfg.short_circuit:
        for g in cfg.validation_on:
            status[g] = "not_run"
        detail["short_circuited"] = True
        return GateResult(False, status, cfg.enabled, detail)

    # ---- validation tier ------------------------------------------------- #
    if cfg.is_on("G3"):
        if utility_fn is None:
            status["G3"] = "not_run"
            detail["utility"] = {"error": "G3 enabled but no utility_fn given"}
        else:
            u = utility_fn(cluster, taxonomy)
            detail["utility"] = u
            status["G3"] = "pass" if u.get("gain", 0.0) >= cfg.min_utility_gain \
                else "fail"

    if cfg.is_on("G4"):
        if anchor_fn is None:
            status["G4"] = "not_run"
            detail["anchor"] = {"error": "G4 enabled but no anchor_fn given"}
        else:
            a = anchor_fn(cluster, taxonomy)
            detail["anchor"] = a
            status["G4"] = "pass" if a.get("drop", 0.0) <= cfg.max_anchor_drop \
                else "fail"

    passed = all(status[g] == "pass" for g in cfg.enabled)
    return GateResult(passed, status, cfg.enabled, detail)


_STAGE_BY_PHASE = {
    "recruitment": "specification", "planning": "specification",
    "independent_analysis": "interpretation", "discussion": "interaction",
    "review": "interaction", "synthesis": "decision", "decision": "decision",
}


def _stage_of(phases) -> Optional[str]:
    """Where a discovered code sits structurally, recorded instead of numbered."""
    votes = Counter(_STAGE_BY_PHASE.get(p) for p in (phases or ()) if p)
    return votes.most_common(1)[0][0] if votes else None


def admit(
    taxonomy: Taxonomy,
    cluster: Cluster,
    gate: GateResult,
    code: Optional[str] = None,
) -> Taxonomy:
    """Promote a gated cluster into a new taxonomy version."""
    if cluster.triage == "AB?":
        raise ValueError(
            f"cluster {cluster.cluster_id} is triage 'AB?' ({cluster.triage_reason}). "
            "The A/B call was too close to make automatically; a human must "
            "decide before this can be claimed as a new failure type. "
            "Resolve it, set cluster.triage explicitly, then re-run admit()."
        )
    if cluster.triage != "B":
        raise ValueError(
            f"cluster {cluster.cluster_id} is triage '{cluster.triage}'; only "
            "B (true novelty) may be admitted as a new code. A clusters "
            "produce a scope revision to code "
            f"{cluster.absorbing_code}, not a new one."
        )
    if not gate.passed:
        raise ValueError(
            f"cluster {cluster.cluster_id} did not pass: {gate.summary()}")

    from .taxonomy import discovered_code

    v = taxonomy.version + 1
    code = code or discovered_code(cluster.name or "unnamed", v,
                                   {m.code for m in taxonomy.modes})
    mode = FailureMode(
        code=code,
        name=cluster.name,
        definition=cluster.definition,
        allowed_phases=cluster.allowed_phases or frozenset({
            "independent_analysis", "discussion", "synthesis", "decision"}),
        requires=frozenset(),
        needs_ground_truth=False,
        anchor_question=f"Does this trace exhibit: {cluster.name}?",
        provenance=f"T{v}:discovered",
        version_added=v,
        stage=_stage_of(cluster.allowed_phases),
    )
    return taxonomy.add(mode, evidence={
        "support": cluster.support,
        "frameworks": dict(cluster.frameworks),
        # which criteria actually had to hold; a permissive run must not be
        # mistakable for a strict one after the fact
        "gates_enabled": list(gate.enabled),
        "gates_binding": gate.binding,
        "gate_status": gate.status,
        "gate": asdict(gate),
        "example_traces": [i.trace_id for i in cluster.items[:5]],
    })


def revise_scope(
    taxonomy: Taxonomy,
    cluster: Cluster,
    add_phases: Iterable[str] = (),
    drop_requires: Iterable[str] = (),
) -> Taxonomy:
    """Apply an A-cluster's finding: widen an existing code instead of adding one."""
    if cluster.triage != "A" or not cluster.absorbing_code:
        raise ValueError("revise_scope is only for triage-A clusters")
    old = taxonomy.get(cluster.absorbing_code)
    if old is None:
        raise ValueError(f"unknown code {cluster.absorbing_code}")
    new = FailureMode(
        **{**asdict(old),
           "allowed_phases": old.allowed_phases | frozenset(add_phases),
           "requires": old.requires - frozenset(drop_requires),
           "provenance": old.provenance + f" +scope@T{taxonomy.version + 1}"}
    )
    modes = [new if m.code == old.code else m for m in taxonomy.modes]
    return Taxonomy(
        version=taxonomy.version + 1, modes=modes,
        changelog=taxonomy.changelog + [{
            "version": taxonomy.version + 1, "action": "revise_scope",
            "code": old.code,
            "added_phases": sorted(add_phases),
            "dropped_requires": sorted(drop_requires),
            "support": cluster.support,
            "frameworks": dict(cluster.frameworks),
            "note": "cluster absorbed by this code under unmasked re-audit; "
                    "reported as a scope correction, NOT a new failure type",
        }],
    )


# --------------------------------------------------------------------------- #
# Reporting: alignment against the seed taxonomy
# --------------------------------------------------------------------------- #

def hungarian_alignment(
    pred_labels: Sequence[str],
    true_labels: Sequence[str],
) -> tuple[dict[str, str], float, dict[str, Any]]:
    """Optimal one-to-one map from discovered labels to seed codes.

    Report this alongside the novelty claim, not instead of it. Two numbers
    matter and they say different things:
      * how much of the seed taxonomy the pipeline recovers unaided
        (matched accuracy) -- evidence the discovery process is sound;
      * what is left over on both sides -- the discovered types with no seed
        counterpart are the actual claim.
    """
    from scipy.optimize import linear_sum_assignment

    P = sorted(set(pred_labels))
    T = sorted(set(true_labels))
    M = np.zeros((len(P), len(T)))
    pi = {p: i for i, p in enumerate(P)}
    ti = {t: i for i, t in enumerate(T)}
    for p, t in zip(pred_labels, true_labels):
        M[pi[p], ti[t]] += 1
    r, c = linear_sum_assignment(-M)
    mapping = {P[i]: T[j] for i, j in zip(r, c)}
    matched = M[r, c].sum()
    return mapping, float(matched / max(len(pred_labels), 1)), {
        "unmatched_discovered": [p for p in P if p not in mapping],
        "unmatched_seed": [t for t in T if t not in set(mapping.values())],
        "contingency": M.tolist(), "pred_labels": P, "seed_labels": T,
    }


def evolution_report(taxonomy: Taxonomy, clusters: Sequence[Cluster],
                     noise: Sequence[ResidualItem]) -> dict[str, Any]:
    a = [c for c in clusters if c.triage == "A"]
    b = [c for c in clusters if c.triage == "B"]
    amb = [c for c in clusters if c.triage == "AB?"]
    incoh = [c for c in amb if "incoherent" in (c.triage_reason or "")]
    return {
        "taxonomy_version": taxonomy.version,
        "n_codes": len(taxonomy.modes),
        "residual_clusters": len(clusters),
        "noise_items": len(noise),
        "scope_revisions_A": [
            {"cluster": c.cluster_id, "name": c.name,
             "absorbed_by": c.absorbing_code,
             "absorb_rate": round(c.absorb_rate, 3),
             "support": c.support, "frameworks": dict(c.frameworks)}
            for c in a
        ],
        "novel_candidates_B": [
            {"cluster": c.cluster_id, "name": c.name,
             "support": c.support, "frameworks": dict(c.frameworks),
             "phases": dict(c.phases)}
            for c in b
        ],
        "needs_human_AB_decision": [
            {"cluster": c.cluster_id, "name": c.name,
             "absorb_rate": round(c.absorb_rate, 3),
             "nearest_code": c.absorbing_code,
             "reason": c.triage_reason,
             "support": c.support, "frameworks": dict(c.frameworks),
             "example_traces": [i.trace_id for i in c.items[:3]]}
            for c in amb
        ],
        "incoherent_but_kept": [
            {"cluster": c.cluster_id, "support": c.support,
             "frameworks": dict(c.frameworks),
             "members": [i.proposed_name for i in c.items[:8]]}
            for c in incoh
        ],
        "triage_sensitivity": triage_sensitivity(clusters),
        "changelog": taxonomy.changelog,
    }
