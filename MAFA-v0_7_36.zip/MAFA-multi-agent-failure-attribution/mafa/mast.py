"""
mast.py
=======
The MAST taxonomy (Cemri et al., "Why Do Multi-Agent LLM Systems Fail?",
NeurIPS 2025), recovered verbatim from the ``mast_taxonomy_used`` field of the
simulated split rather than retyped, so the definitions are exactly the ones
the injector worked from.

**This must never reach the annotator.** The simulated faults were generated
*from* these definitions. Showing them to a model and then asking it to find
the faults would be circular, and the resulting recall would measure nothing.
The annotator sees the MedAgentAudit seed only; MAST lives here purely as
ground truth and as one axis of the coverage matrix.

The two are different label spaces and the mapping between them is an
empirical question, not a lookup table. That question -- how much of MAST does
a medical-domain taxonomy actually cover, and what falls outside it -- is worth
answering directly, because MedAgentAudit's premise is that general-purpose
taxonomies do not fit medical multi-agent systems, and so far that premise
rests on assertion rather than measurement.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

MAST_STAGES = {
    "1": "Specification and system design",
    "2": "Inter-agent misalignment",
    "3": "Task verification and termination",
}

MAST: dict[str, str] = {
    "FM-1.1": "Task specification deviation: the agent ignored details of the "
              "task spec.",
    "FM-1.2": "Role specification deviation: the agent strayed from its "
              "assigned role/persona.",
    "FM-1.3": "Redundant looping / re-stating instead of progressing the "
              "reasoning.",
    "FM-1.4": "Context omission / forgetting prior context.",
    "FM-1.5": "Multiple answers / refusal to commit to a single final choice.",
    "FM-2.1": "Restarting reasoning from scratch and discarding prior progress.",
    "FM-2.2": "Hedging and uncertainty, refusal to commit.",
    "FM-2.3": "Deviating from the main goal - producing a wrong answer on "
              "purpose.",
    "FM-2.4": "Withholding key information, giving a low-information answer.",
    "FM-2.5": "Ignoring or contradicting other agents in the discussion.",
    "FM-2.6": "Reasoning-conclusion mismatch: the reasoning supports one "
              "answer but the final letter is different.",
    "FM-3.1": "Premature termination: ending without analysis, often a bare "
              "letter.",
    "FM-3.2": "Skipping verification / committing without checking.",
    "FM-3.3": "Evaluator approval failure: rubber-stamping an answer instead "
              "of evaluating it.",
}


def stage_of(code: str) -> Optional[str]:
    return MAST_STAGES.get(code.split("-")[-1].split(".")[0])


#: A hypothesis, not a fact. Written from the two sets of definitions, to be
#: CHECKED against the unmasked re-audit rather than assumed. Where the value
#: is None the expectation is that no MedAgentAudit code covers it, which is
#: the interesting cell: it predicts where genuinely new medical codes are
#: needed, and where the coverage matrix should show NOVEL.
PRIOR_MAPPING: dict[str, Optional[str]] = {
    "FM-1.1": "1.2.1",   # ignoring the task spec ~ evading the question asked
    "FM-1.2": "2.1.2",   # straying from the role ~ not activating specialty
    "FM-1.3": "2.2.1",   # looping / restating ~ repetition of initial views
    "FM-1.4": None,      # context omission has no medical-stage counterpart
    "FM-1.5": None,      # refusal to commit is not in the seed taxonomy
    "FM-2.1": None,      # restarting from scratch has no counterpart
    "FM-2.2": None,      # hedging has no counterpart
    "FM-2.3": None,      # deliberate wrong answer is an injection artefact
    "FM-2.4": "2.1.2",   # withholding ~ low-information, no specialist content
    "FM-2.5": "2.2.2",   # ignoring peers ~ unresolved conflict
    "FM-2.6": "3.1.3",   # reasoning-conclusion mismatch ~ neglected contradiction
    "FM-3.1": None,      # premature termination has no counterpart
    "FM-3.2": "3.2.1",   # skipping verification, weakly
    "FM-3.3": "3.1.2",   # rubber-stamping ~ authority bias, weakly
}
