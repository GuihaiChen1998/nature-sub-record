"""
routing_backends.py
===================
Pluggable Stage-3 backends behind one interface, plus the compatibility rules
that say which calibrator can feed which router.

The three are not interchangeable variants of one idea; they disagree about
where the guarantee comes from.

``split`` -- split conformal, the current behaviour
    Guarantee: marginal coverage >= 1 - alpha, finite sample, distribution
    free, **conditional on exchangeability** between calibration and test.
    A taxonomy change breaks exchangeability and the failure is silent: the
    sets still look reasonable and certify nothing. Hence REFIT_REQUIRED.

``aci`` -- adaptive conformal inference
    Guarantee: long-run coverage, |mean(err) - alpha| -> 0, under **arbitrary**
    distribution shift, with no exchangeability assumption. The price is that
    it holds over a horizon rather than at any single step, and only while
    feedback keeps arriving. Here feedback is not hypothetical: every VERIFY
    and REVIEW decision goes to a human and comes back with a label. The
    routing loop already produces exactly the sequential signal ACI needs,
    which is why this is the backend that makes a second turn coherent.

``venn_abers`` -- interval-native
    Needs no calibration set of its own; the interval already carries the
    uncertainty. Its distinctive move is on the NOVEL channel: a Venn-Abers
    interval is never empty, so empty-set can no longer mean "no known label
    fits". Width replaces it, and arguably improves on it -- width measures
    "the calibration data does not cover this region", which is what the
    NOVEL channel was trying to detect through the empty set all along.

Compatibility is checked rather than assumed: ``venn_abers`` routing on a
point-estimate calibrator would read width 0 everywhere and silently never
emit NOVEL.
"""
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Optional, Protocol, Sequence, runtime_checkable

from .calibration_backends import Belief, BackendReport, EvolutionPolicy
from .conformal_router import MIN_CAL, conformal_quantile


@runtime_checkable
class RoutingBackend(Protocol):
    name: str
    #: True if this backend reads Belief.lo/hi rather than only Belief.p
    requires_interval: bool

    def fit(self, beliefs: Sequence[Belief], truths: Sequence[int],
            groups: Optional[Sequence[str]] = None) -> "RoutingBackend": ...

    def predict_set(self, belief: Belief,
                    group: Optional[str] = None) -> set[int]: ...

    def is_novel(self, belief: Belief, group: Optional[str] = None) -> bool: ...

    def observe(self, group: Optional[str], covered: bool) -> None:
        """Feedback from a human verdict. A no-op for offline backends."""
        ...

    def policy(self) -> EvolutionPolicy: ...

    def report(self) -> BackendReport: ...


# --------------------------------------------------------------------------- #
# Backend 1: split conformal (the existing behaviour)
# --------------------------------------------------------------------------- #

class SplitConformalBackend:
    name = "split"
    requires_interval = False

    def __init__(self, alpha: float = 0.10) -> None:
        from .conformal_router import BinaryConformal
        self.alpha = alpha
        self._c = BinaryConformal(alpha=alpha)

    def fit(self, beliefs, truths, groups=None):
        self._c.fit([b.p for b in beliefs], truths, groups)
        return self

    def predict_set(self, belief, group=None) -> set[int]:
        return self._c.predict_set(belief.p, group)

    def is_novel(self, belief, group=None) -> bool:
        return len(self.predict_set(belief, group)) == 0

    def observe(self, group, covered) -> None:
        return None                      # offline: feedback changes nothing

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.REFIT_REQUIRED

    def report(self) -> BackendReport:
        return BackendReport(self.name, self.policy(),
                             sum(self._c.n_cal.values()), None,
                             {"alpha": self.alpha, "q": dict(self._c.q),
                              "q_pooled": self._c.q_pooled,
                              "fell_back": sorted(self._c.fell_back)})


# --------------------------------------------------------------------------- #
# Backend 2: adaptive conformal inference
# --------------------------------------------------------------------------- #

@dataclass
class _ACIState:
    alpha_t: float
    q: float
    n_seen: int = 0
    n_miss: int = 0
    recent: deque = field(default_factory=lambda: deque(maxlen=200))
    scores: list[float] = field(default_factory=list)


class ACIBackend:
    """Gibbs & Candes adaptive conformal inference, per Mondrian group.

    The update is one line::

        alpha_{t+1} = alpha_t + gamma * (alpha_target - err_t)

    with ``err_t = 1`` when the realised label was not in the set. Miss too
    often and ``alpha_t`` falls, which raises the quantile and widens the
    sets; over-cover and it rises and they tighten. The long-run bound is

        |(1/T) sum_t err_t - alpha| <= (alpha_1 + gamma) / (T * gamma)

    which holds for **any** sequence, adversarial included, with no
    exchangeability and no distribution assumption. That is the property that
    matters after ``Taxonomy.add()``: the calibration set is stale, and rather
    than refusing to score or pretending nothing happened, the router
    re-earns its coverage from the feedback the human queue is already
    producing.

    What it does not give: coverage at any particular step, or any guarantee
    at all if feedback stops. ``warming_up`` is true until a group has seen
    enough feedback for the bound to be worth anything, and it should be
    reported, not hidden.

    ``gamma`` trades adaptation speed against variance. 0.01 is slow and
    steady, 0.1 chases noise. The default 0.05 is a guess, not a calibrated
    value; it has not been ablated here and should be.
    """

    name = "aci"
    requires_interval = False

    def __init__(self, alpha: float = 0.10, gamma: float = 0.05,
                 warmup: int = 50) -> None:
        self.alpha = alpha
        self.gamma = gamma
        self.warmup = warmup
        self._g: dict[str, _ACIState] = {}
        self._pooled: Optional[_ACIState] = None

    # -- helpers ---------------------------------------------------------- #
    @staticmethod
    def _score(p: float, y: int) -> float:
        return 1.0 - p if y == 1 else p

    def _state(self, group: Optional[str]) -> _ACIState:
        if group is not None and group in self._g:
            return self._g[group]
        if self._pooled is None:
            self._pooled = _ACIState(self.alpha, float("inf"))
        return self._pooled

    def fit(self, beliefs, truths, groups=None):
        """Seed alpha_t and the quantile from whatever calibration data exists.

        ACI does not need this -- it converges from any start -- but starting
        from the split-conformal answer means the first turn behaves exactly
        like the current pipeline, and only subsequent drift is adapted away.
        """
        s = [self._score(b.p, y) for b, y in zip(beliefs, truths)]
        self._pooled = _ACIState(self.alpha, conformal_quantile(s, self.alpha),
                                 scores=list(s))
        if groups is None:
            return self
        by = defaultdict(list)
        for g, sc in zip(groups, s):
            by[g].append(sc)
        for g, sc in by.items():
            q = (self._pooled.q if len(sc) < MIN_CAL
                 else conformal_quantile(sc, self.alpha))
            self._g[g] = _ACIState(self.alpha, q, scores=list(sc))
        return self

    def predict_set(self, belief, group=None) -> set[int]:
        st = self._state(group)
        p = belief.p
        out: set[int] = set()
        if 1.0 - p <= st.q:
            out.add(1)
        if p <= st.q:
            out.add(0)
        return out

    def is_novel(self, belief, group=None) -> bool:
        return len(self.predict_set(belief, group)) == 0

    # -- the online update ------------------------------------------------ #
    def observe(self, group: Optional[str], covered: bool) -> None:
        st = self._state(group)
        err = 0.0 if covered else 1.0
        st.n_seen += 1
        st.n_miss += int(not covered)
        st.recent.append(err)
        st.alpha_t = float(min(0.999, max(1e-4,
                                          st.alpha_t + self.gamma * (self.alpha - err))))
        if st.scores:
            st.q = conformal_quantile(st.scores, st.alpha_t)

    def warming_up(self, group: Optional[str] = None) -> bool:
        return self._state(group).n_seen < self.warmup

    def empirical_coverage(self, group: Optional[str] = None) -> Optional[float]:
        st = self._state(group)
        if st.n_seen == 0:
            return None
        return 1.0 - st.n_miss / st.n_seen

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.ADAPTS_ONLINE

    def report(self) -> BackendReport:
        det = {"alpha_target": self.alpha, "gamma": self.gamma,
               "groups": {}}
        for g, st in self._g.items():
            det["groups"][g] = {
                "alpha_t": round(st.alpha_t, 4), "q": round(st.q, 4),
                "n_feedback": st.n_seen,
                "empirical_coverage": (None if st.n_seen == 0
                                       else round(1 - st.n_miss / st.n_seen, 4)),
                "warming_up": st.n_seen < self.warmup}
        return BackendReport(self.name, self.policy(),
                             sum(s.n_seen for s in self._g.values()), None, det)

    def on_taxonomy_change(self, new_signature: str) -> str:
        for st in list(self._g.values()) + ([self._pooled] if self._pooled else []):
            st.n_seen = 0
            st.n_miss = 0
            st.recent.clear()
        return ("ACI continues scoring across the change and re-earns coverage "
                "from feedback. Feedback counters reset, so every group is "
                "warming_up until it has seen `warmup` human verdicts; until "
                "then report the sets without the long-run claim.")


# --------------------------------------------------------------------------- #
# Backend 3: interval-native
# --------------------------------------------------------------------------- #

class VennAbersRoutingBackend:
    """Route from the interval directly; no calibration set of its own.

    A label stays in the set while the interval leaves the decision boundary
    open::

        1 in C  iff  hi > 0.5        it is still possible that P(y=1) > 0.5
        0 in C  iff  lo < 0.5        it is still possible that P(y=1) < 0.5

    so a narrow interval on one side of 0.5 gives a singleton and a wide one
    straddling it gives both.

    The consequence that has to be handled rather than discovered: since
    ``lo <= hi``, **this set is never empty**, and empty-set is how Stage 3
    hands work to Stage 4. Width takes over that job. ``novel_width`` is the
    threshold above which the calibration data is judged not to cover the
    slot at all. That is a more direct statement of what the NOVEL channel
    was always approximating -- an empty conformal set means no label is
    conformal, which is evidence about coverage arrived at indirectly.

    ``novel_width`` 0.4 is a starting value chosen so that a slot whose
    interval spans most of [0,1] routes to the residual pool. It is not
    calibrated and should be swept against the residual rate the old
    empty-set rule produced.
    """

    name = "venn_abers"
    requires_interval = True

    def __init__(self, novel_width: float | str = "auto",
                 target_novel_rate: float = 0.05,
                 boundary: float = 0.5) -> None:
        #: "auto" picks the threshold from the observed width distribution at
        #: fit time so the NOVEL channel fires at `target_novel_rate`. A fixed
        #: number is a guess about a scale that depends on the calibration set
        #: size and the scorer, and a guess on the wrong side of the observed
        #: range silently disables the channel -- which is what 0.4 did on the
        #: first data it met (widest interval 0.303).
        self.novel_width = novel_width
        self.target_novel_rate = target_novel_rate
        self.boundary = boundary
        self._resolved: Optional[float] = (None if novel_width == "auto"
                                           else float(novel_width))
        self._n = 0
        self._widths: list[float] = []
        self._note: Optional[str] = None

    def fit(self, beliefs, truths, groups=None):
        self._widths = [b.width for b in beliefs]
        self._n = len(self._widths)
        if not self._widths:
            self._note = "no beliefs seen; NOVEL threshold unresolved"
            return self
        if self.novel_width == "auto":
            k = max(0, int(round((1.0 - self.target_novel_rate)
                                 * len(self._widths))) - 1)
            self._resolved = sorted(self._widths)[min(k, len(self._widths) - 1)]
            self._note = (f"novel_width auto-set to {self._resolved:.4f}, the "
                          f"{1 - self.target_novel_rate:.0%} width quantile, "
                          f"so the NOVEL channel fires on about "
                          f"{self.target_novel_rate:.0%} of slots")
        elif max(self._widths) < self._resolved:
            self._note = (f"novel_width={self._resolved} exceeds the widest "
                          f"interval seen ({max(self._widths):.3f}); the NOVEL "
                          f"channel will never fire. Use 'auto' or lower it.")
        else:
            self._note = None
        return self

    def predict_set(self, belief, group=None) -> set[int]:
        if belief.is_point:
            raise TypeError(
                "venn_abers routing needs an interval and was handed a point "
                "estimate. Width would be 0 everywhere and NOVEL would never "
                "fire. Pair it with the venn_abers or logistic_va calibrator, "
                "or route with split/aci instead.")
        out: set[int] = set()
        if belief.hi > self.boundary:
            out.add(1)
        if belief.lo < self.boundary:
            out.add(0)
        return out or {1 if belief.p >= self.boundary else 0}

    def is_novel(self, belief, group=None) -> bool:
        if self._resolved is None:
            raise RuntimeError(
                "NOVEL threshold unresolved: call fit() before routing, or "
                "pass an explicit novel_width. Defaulting it silently would "
                "put the Stage 3 -> Stage 4 hand-off on an unexamined "
                "constant.")
        return belief.width >= self._resolved

    def observe(self, group, covered) -> None:
        return None

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.DEGRADES_VISIBLY

    def report(self) -> BackendReport:
        import statistics
        det: dict[str, Any] = {"novel_width": self.novel_width,
                               "novel_width_resolved": self._resolved,
                               "target_novel_rate": self.target_novel_rate,
                               "boundary": self.boundary,
                               "note": self._note}
        if self._widths:
            det["width_mean"] = round(statistics.fmean(self._widths), 4)
            det["width_p90"] = round(sorted(self._widths)[int(.9 * len(self._widths))], 4)
            if self._resolved is not None:
                det["novel_rate"] = round(
                    sum(1 for w in self._widths if w >= self._resolved)
                    / len(self._widths), 4)
        return BackendReport(self.name, self.policy(), self._n, None, det)

    def on_taxonomy_change(self, new_signature: str) -> str:
        return ("Venn-Abers routing continues. Its NOVEL channel is width, so "
                "slots under a newly added code -- which the calibration set "
                "does not cover -- route to the residual pool rather than "
                "being scored confidently. Coverage is not guaranteed across "
                "the change; the degradation is visible as width.")


# --------------------------------------------------------------------------- #
# Compatibility
# --------------------------------------------------------------------------- #

ROUTERS: dict[str, Any] = {
    "split": SplitConformalBackend,
    "aci": ACIBackend,
    "venn_abers": VennAbersRoutingBackend,
}


def make_router(name: str, **kw: Any) -> RoutingBackend:
    if name not in ROUTERS:
        raise ValueError(f"unknown router {name!r}; choose from {sorted(ROUTERS)}")
    return ROUTERS[name](**kw)


#: (calibrator, router) -> None if fine, else why not.
def check_compatible(calibrator: Any, router: Any) -> Optional[str]:
    """Reject pairings that would fail silently rather than loudly."""
    from .calibration_backends import LogisticBackend

    if getattr(router, "requires_interval", False):
        if isinstance(calibrator, LogisticBackend):
            return (f"router {router.name!r} reads interval width and "
                    f"calibrator {calibrator.name!r} emits point estimates; "
                    f"width would be 0 for every slot and the NOVEL channel "
                    f"would never fire. Use calibrator 'logistic_va' to keep "
                    f"the logistic scores and gain the interval.")
    return None


def describe_pairing(calibrator: Any, router: Any) -> dict[str, Any]:
    """What this pairing claims when the taxonomy changes under it.

    Consulted before a second turn of the loop, so the claim is chosen rather
    than inherited.
    """
    cp, rp = calibrator.policy(), router.policy()
    worst = min([cp, rp], key=lambda p: _RANK[p])
    return {
        "calibrator": calibrator.name, "calibrator_policy": cp.value,
        "router": router.name, "router_policy": rp.value,
        "loop_policy": worst.value,
        "can_turn_without_reanchoring": worst is not EvolutionPolicy.REFIT_REQUIRED,
        "claim": _CLAIM[worst],
    }


_RANK = {EvolutionPolicy.REFIT_REQUIRED: 0,
         EvolutionPolicy.DEGRADES_VISIBLY: 1,
         EvolutionPolicy.ADAPTS_ONLINE: 2,
         #: ranked above ADAPTS_ONLINE on cost, not on strength of guarantee:
         #: it is the only one that turns the loop without new annotation.
         #: Its guarantee is weaker -- consistency under label shift, not a
         #: coverage bound -- and describe_pairing says so.
         EvolutionPolicy.ADAPTS_UNSUPERVISED: 3}

_CLAIM = {
    EvolutionPolicy.REFIT_REQUIRED:
        "The loop cannot turn without new anchors under the new taxonomy. "
        "Marginal coverage 1-alpha holds on T_k and is void on T_{k+1}.",
    EvolutionPolicy.DEGRADES_VISIBLY:
        "The loop turns. No coverage guarantee survives the change; what "
        "survives is that slots the old calibration data does not cover come "
        "back wide and route to a human or to the residual pool instead of "
        "being scored confidently. Report mean interval width on the new "
        "code's slots as the degradation measure.",
    EvolutionPolicy.ADAPTS_UNSUPERVISED:
        "The loop turns with NO new annotation: the calibrator re-fits on the "
        "new taxonomy's unlabelled slots. What is given up is the coverage "
        "bound -- this is consistency under label shift, not a finite-sample "
        "guarantee, and it holds only insofar as the change behaves like "
        "label shift on the existing codes. The newly added code is a new "
        "class, not a reweighted old one, and is abstained on rather than "
        "scored. Report the label-free CE estimate and the BBSE determinant; "
        "a near-singular confusion matrix means the weights are not usable.",
    EvolutionPolicy.ADAPTS_ONLINE:
        "The loop turns and coverage is re-earned from human feedback. The "
        "guarantee is long-run, not per-step, and lapses if feedback stops. "
        "Report warming_up and empirical coverage per group alongside the "
        "sets, never the nominal 1-alpha alone. Note the feedback arrives "
        "only on ROUTED slots, which are the uncertain ones by construction, "
        "so the long-run guarantee is over the routed subpopulation rather "
        "than the corpus -- and slots of a newly added code receive no "
        "feedback at all until someone annotates them.",
}


# --------------------------------------------------------------------------- #
# Backend 4: thresholds the user sets
# --------------------------------------------------------------------------- #

@dataclass
class Band:
    """One segment of a user-specified routing rule: p in [lo, hi) -> decision.

    `decision` is the prediction set to emit, written as the routing outcome
    it produces: "one" (a singleton -> AUTO), "both" (the two-element set ->
    VERIFY), "none" (the empty set -> NOVEL). The label of a singleton is 1
    above the midpoint and 0 below it, which is what a threshold rule means.
    """
    lo: float
    hi: float
    decision: str                        # one | both | none

    def contains(self, p: float) -> bool:
        return self.lo <= p < self.hi or (self.hi >= 1.0 and p == 1.0)


def bands_from_thresholds(t_zero: float, t_auto: float,
                          novel: Optional[tuple[float, float]] = None
                          ) -> list[Band]:
    """The common case: two cuts. Below t_zero the slot is settled negative,
    above t_auto settled positive, between them a human picks."""
    bands = [Band(0.0, t_zero, "one"), Band(t_zero, t_auto, "both"),
             Band(t_auto, 1.0000001, "one")]
    if novel:
        bands.append(Band(novel[0], novel[1], "none"))
    return bands


class ThresholdBackend:
    """Routing by thresholds the user chooses, per group if they want.

    This exists because "alpha" is not always the knob a user has. A site with
    a fixed reviewer budget, or a regulator's error ceiling on what may enter
    a corpus unreviewed, states its constraint in those terms, and forcing it
    through alpha hides the mapping.

    What it does NOT do is inherit the conformal guarantee. A threshold says
    nothing about coverage by itself; it is a decision rule whose error rate
    is an empirical quantity. So `fit` does not fit anything -- it MEASURES
    the rule on whatever labelled calibration data exists (error inside each
    singleton band, share routed each way, per group) and puts the numbers in
    the report, with a Clopper-Pearson upper bound so a small group cannot
    look safe by having few points. Unmeasured groups are named, not omitted.

    For the user who wants a guarantee AND a threshold, `calibrate_bands`
    below picks the most permissive thresholds whose error upper bound meets
    a target -- the threshold is then an output with a claim attached, rather
    than an input with none.
    """

    name = "threshold"
    requires_interval = False

    def __init__(self, bands: Optional[Sequence[Band]] = None,
                 per_group: Optional[dict[str, Sequence[Band]]] = None,
                 t_zero: float = 0.1, t_auto: float = 0.9) -> None:
        self.bands = list(bands) if bands else bands_from_thresholds(t_zero, t_auto)
        self.per_group = {g: list(b) for g, b in (per_group or {}).items()}
        self.measured: dict[str, Any] = {}
        self._n_fit = 0

    # -- the rule --------------------------------------------------------- #
    def _bands(self, group: Optional[str]) -> list[Band]:
        return self.per_group.get(group, self.bands) if group else self.bands

    def predict_set(self, belief, group=None) -> set[int]:
        p = belief.p
        for b in self._bands(group):
            if b.contains(p):
                if b.decision == "none":
                    return set()
                if b.decision == "both":
                    return {0, 1}
                return {1} if p >= 0.5 else {0}
        # a gap in the user's bands is not a silent AUTO
        raise ValueError(
            f"p={p:.4f} (group {group!r}) falls in no band; the bands must "
            f"cover [0, 1]: {[(b.lo, b.hi, b.decision) for b in self._bands(group)]}")

    def is_novel(self, belief, group=None) -> bool:
        return len(self.predict_set(belief, group)) == 0

    def observe(self, group, covered) -> None:
        return None

    def policy(self) -> EvolutionPolicy:
        # a fixed threshold keeps scoring across a taxonomy change, but it
        # never had a guarantee to lose or re-earn; say so rather than
        # borrowing either of the other two claims
        return EvolutionPolicy.REFIT_REQUIRED

    # -- measurement, not fitting ----------------------------------------- #
    def fit(self, beliefs, truths, groups=None):
        groups = list(groups) if groups is not None else [None] * len(beliefs)
        acc: dict[Optional[str], dict[str, int]] = defaultdict(
            lambda: {"n": 0, "auto": 0, "auto_wrong": 0, "verify": 0, "novel": 0})
        for b, y, g in zip(beliefs, truths, groups):
            s = self.predict_set(b, g)
            for key in (g, "__pooled__"):
                a = acc[key]
                a["n"] += 1
                if len(s) == 1:
                    a["auto"] += 1
                    a["auto_wrong"] += int(next(iter(s)) != int(y))
                elif len(s) == 2:
                    a["verify"] += 1
                else:
                    a["novel"] += 1
        self._n_fit = sum(1 for _ in beliefs)
        self.measured = {
            str(k): {**v,
                     "auto_error": (v["auto_wrong"] / v["auto"]) if v["auto"] else None,
                     "auto_error_upper95": clopper_pearson_upper(
                         v["auto_wrong"], v["auto"], 0.05) if v["auto"] else None,
                     "thin": v["n"] < MIN_CAL}
            for k, v in acc.items()}
        return self

    def report(self) -> BackendReport:
        thin = sorted(k for k, v in self.measured.items() if v.get("thin"))
        return BackendReport(
            self.name, self.policy(), self._n_fit, None,
            {"bands": [(b.lo, b.hi, b.decision) for b in self.bands],
             "per_group": {g: [(b.lo, b.hi, b.decision) for b in bs]
                           for g, bs in self.per_group.items()},
             "measured": self.measured,
             "groups_too_thin_to_measure": thin,
             "guarantee": "none by construction; auto_error_upper95 is a "
                          "measurement on the calibration data, not coverage"})


def clopper_pearson_upper(k: int, n: int, alpha: float = 0.05) -> float:
    """Exact upper confidence bound on a binomial rate. Used so a band with
    0 errors in 7 points does not read as error 0."""
    from scipy.stats import beta as _beta
    if n == 0:
        return 1.0
    if k >= n:
        return 1.0
    return float(_beta.ppf(1 - alpha, k + 1, n - k))


def calibrate_bands(beliefs, truths, groups=None, target_error: float = 0.05,
                    confidence: float = 0.05, grid: int = 50,
                    min_n: int = MIN_CAL) -> dict[str, Any]:
    """Pick thresholds from a user's ERROR budget instead of an alpha.

    Scans symmetric cuts (t_zero = 1 - t_auto) from permissive to strict and
    returns the most permissive whose Clopper-Pearson upper bound on the error
    among auto-routed slots is <= target_error. This is the one-parameter case
    of Learn-then-Test: one monotone family, one bound, so no multiplicity
    correction is needed. Groups with fewer than `min_n` calibration points
    get no threshold of their own and are listed, because a threshold chosen
    on 9 points is the failure this whole file exists to avoid.
    """
    groups = list(groups) if groups is not None else [None] * len(beliefs)
    by: dict[Optional[str], list[tuple[float, int]]] = defaultdict(list)
    for b, y, g in zip(beliefs, truths, groups):
        by[g].append((b.p, int(y)))
        by["__pooled__"].append((b.p, int(y)))
    out: dict[str, Any] = {"target_error": target_error, "per_group": {},
                           "too_thin": []}
    for g, rows in by.items():
        if g != "__pooled__" and len(rows) < min_n:
            out["too_thin"].append(str(g))
            continue
        best = None
        for i in range(grid, 0, -1):            # permissive -> strict
            t_auto = 0.5 + 0.5 * (i / grid)
            t_zero = 1.0 - t_auto
            k = n = 0
            for p, y in rows:
                if p >= t_auto or p <= t_zero:
                    n += 1
                    k += int((1 if p >= 0.5 else 0) != y)
            if n == 0:
                continue
            if clopper_pearson_upper(k, n, confidence) <= target_error:
                best = {"t_auto": round(t_auto, 4), "t_zero": round(t_zero, 4),
                        "auto_share": round(n / len(rows), 4),
                        "auto_errors": k, "auto_n": n,
                        "auto_error_upper95": round(
                            clopper_pearson_upper(k, n, confidence), 4)}
                break
        out["per_group"][str(g)] = best      # None = no threshold meets it
    return out


ROUTERS["threshold"] = ThresholdBackend
