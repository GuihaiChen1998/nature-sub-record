"""
taxonomy.py
===========
Seed failure-mode taxonomy (T0) plus the machinery for versioned evolution.

Two deliberate departures from MedAgentAudit
--------------------------------------------
1. **Applicability is structural, not nominal.**  MedAgentAudit gates each code
   with ``applicable_mas={"colacare","mac",...}``.  That mask cannot be
   evaluated for DyLAN or ClinicalAgent, which are not in its list.  Here each
   code declares ``requires`` over ``Trace.capabilities`` and ``allowed_phases``
   over the canonical phase vocabulary, so applicability is *derived* for any
   framework, including ones that did not exist when T0 was written.

2. **Every code carries an ``anchor_question``** -- a single yes/no question in
   the exact wording used by the token-level scorer (Stage 1b).  Keeping the
   scorer question textually identical to the audit rubric is what makes the
   black-box (verbalised) and white-box (logprob) signals comparable.

Provenance is tracked so a T1 code born from residual clustering is never
silently confused with an expert-derived T0 code.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Optional


@dataclass(frozen=True)
class FailureMode:
    code: str
    name: str
    definition: str
    #: canonical phases in which this failure can be *located*
    allowed_phases: frozenset[str]
    #: structural capabilities the trace must have for the code to be scoreable
    requires: frozenset[str] = frozenset()
    #: the code is defined relative to the correct answer, so ground truth must
    #: be shown to the annotator (everything else is audited outcome-blind)
    needs_ground_truth: bool = False
    #: single yes/no question used verbatim by the Stage-1b token scorer
    anchor_question: str = ""
    #: T0 = MedAgentAudit seed, MAST = general seed, T1+ = discovered
    provenance: str = "T0:MedAgentAudit"
    version_added: int = 0
    #: which canonical stage this belongs to, for grouping in reports. Kept
    #: separate from the code precisely so a discovered code can be filed
    #: alongside the seed without being numbered into it.
    stage: Optional[str] = None
    #: set when this code is a narrowing or widening of an existing one
    parent: Optional[str] = None

    def applies_to(self, capabilities: dict[str, bool]) -> bool:
        return all(capabilities.get(r, False) for r in self.requires)


# --------------------------------------------------------------------------- #
# T0 -- MedAgentAudit's ten expert-validated codes, re-expressed structurally
# --------------------------------------------------------------------------- #

SEED_MODES: tuple[FailureMode, ...] = (
    FailureMode(
        code="1.1.1",
        name="Factual hallucination during input interpretation",
        definition=(
            "The agent asserts findings that are objectively false given the "
            "input: contradicting explicit case facts, fabricating visual "
            "features absent from the image, or confusing laterality / body "
            "part / modality."
        ),
        # a fabricated fact can be emitted at any generative step, including
        # while a planner is restating the case, so no phase is excluded here
        allowed_phases=frozenset({"recruitment", "planning",
                                  "independent_analysis", "discussion",
                                  "review", "synthesis", "decision"}),
        anchor_question=(
            "Does this agent's output assert a patient fact or image finding "
            "that contradicts, or is absent from, the provided input?"
        ),
    ),
    FailureMode(
        code="1.2.1",
        name="Neglect or misinterpretation of modality information",
        definition=(
            "The agent ignores the required input modality (answers an image "
            "question from text priors alone, or states it cannot see the "
            "image) or evades the specific clinical question asked, offering a "
            "generic description instead."
        ),
        allowed_phases=frozenset({"independent_analysis", "discussion", "review"}),
        anchor_question=(
            "Does this agent fail to engage the required input modality, or "
            "answer something other than the specific question asked?"
        ),
    ),
    FailureMode(
        code="2.1.1",
        name="Mismatch between assigned role and clinical task",
        definition=(
            "The specialty assigned to an agent lacks either the domain "
            "knowledge or the modality competence the case demands."
        ),
        allowed_phases=frozenset({"recruitment", "planning"}),
        requires=frozenset({"has_recruitment"}),
        anchor_question=(
            "Is the specialty assigned in this step clinically inappropriate "
            "for the case, in domain or in modality competence?"
        ),
    ),
    FailureMode(
        code="2.1.2",
        name="Failure to activate specialist knowledge",
        definition=(
            "The agent produces layperson-level content with no specialty "
            "specific terminology, differential, or observation, or refuses "
            "the task on a rigid reading of its own job title."
        ),
        allowed_phases=frozenset({"independent_analysis", "discussion", "review"}),
        requires=frozenset({"has_explicit_roles"}),
        anchor_question=(
            "Does this agent's output lack the specialty-specific reasoning "
            "its assigned role should have contributed?"
        ),
    ),
    FailureMode(
        code="2.2.1",
        name="Repetition of initial views (echo chamber)",
        definition=(
            "The agent's turn adds no net clinical information: bare agreement, "
            "verbatim self-restatement, or ignoring evidence raised by peers."
        ),
        allowed_phases=frozenset({"discussion", "review"}),
        requires=frozenset({"has_peer_exposure", "has_multi_round"}),
        anchor_question=(
            "Does this agent's turn add no new evidence or reasoning beyond "
            "what was already stated in the discussion?"
        ),
    ),
    FailureMode(
        code="2.2.2",
        name="Unresolved conflict during collaboration",
        definition=(
            "Mutually exclusive factual claims exist in the history and this "
            "agent proceeds without acknowledging or attempting to resolve them."
        ),
        allowed_phases=frozenset({"discussion", "review", "synthesis"}),
        requires=frozenset({"has_peer_exposure"}),
        anchor_question=(
            "Does a mutually exclusive factual disagreement exist earlier in "
            "the trace that this agent proceeds past without addressing?"
        ),
    ),
    FailureMode(
        code="3.1.1",
        name="Suppression of correct minority view by incorrect consensus",
        definition=(
            "Opinions were split, the minority view was the clinically correct "
            "one, and the aggregating agent adopted the incorrect majority."
        ),
        allowed_phases=frozenset({"synthesis", "decision"}),
        requires=frozenset({"has_aggregator"}),
        needs_ground_truth=True,
        anchor_question=(
            "Did the deciding agent discard a minority view that matched the "
            "correct answer, in favour of an incorrect majority?"
        ),
    ),
    FailureMode(
        code="3.1.2",
        name="Reasoning distorted by authority bias",
        definition=(
            "The decision rests on who said it, or on the length/format of "
            "their text, rather than on verification of the claim itself."
        ),
        allowed_phases=frozenset({"synthesis", "decision"}),
        requires=frozenset({"has_aggregator", "has_explicit_roles"}),
        anchor_question=(
            "Does the deciding agent justify its choice by the speaker's role "
            "or presentation rather than by verifying the clinical content?"
        ),
    ),
    FailureMode(
        code="3.1.3",
        name="Neglect of contradictions in the reasoning process",
        definition=(
            "The decision claims the team agrees on the label while the "
            "supporting reasons cited by those agents are incompatible."
        ),
        allowed_phases=frozenset({"synthesis", "decision"}),
        requires=frozenset({"has_aggregator"}),
        anchor_question=(
            "Does the deciding agent claim agreement while the underlying "
            "reasons given by the agents are mutually incompatible?"
        ),
    ),
    FailureMode(
        code="3.2.1",
        name="Self-contradiction across rounds",
        definition=(
            "A meta-agent reverses its own conclusion or factual observation "
            "between rounds with no new information to justify the change."
        ),
        allowed_phases=frozenset({"synthesis", "decision", "discussion"}),
        requires=frozenset({"has_multi_round"}),
        anchor_question=(
            "Does this agent reverse a conclusion it stated earlier without "
            "citing any new evidence introduced in between?"
        ),
    ),
)


# --------------------------------------------------------------------------- #
# Versioned taxonomy container
# --------------------------------------------------------------------------- #

@dataclass
class Taxonomy:
    version: int = 0
    modes: list[FailureMode] = field(default_factory=lambda: list(SEED_MODES))
    changelog: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        self._by_code = {m.code: m for m in self.modes}

    def get(self, code: str) -> Optional[FailureMode]:
        return self._by_code.get(code)

    def applicable(self, capabilities: dict[str, bool]) -> list[FailureMode]:
        """The codes that are *structurally scoreable* for this trace.

        Scoring a code the framework cannot exhibit is not merely wasteful --
        it manufactures false positives, which is the failure direction the
        MedAgentAudit specificity numbers already show.
        """
        return [m for m in self.modes if m.applies_to(capabilities)]

    def signature(self) -> str:
        """Short hash of everything that can change the slot plan.

        Version number alone is not enough: a scope revision bumps the version
        but so does an addition, and the two affect the slot plan differently.
        Hashing the codes with their phases and requirements makes the check
        exact.
        """
        import hashlib

        h = hashlib.sha256()
        for m in sorted(self.modes, key=lambda x: x.code):
            h.update(f"{m.code}|{sorted(m.allowed_phases)}|"
                     f"{sorted(m.requires)}|{m.needs_ground_truth}\n".encode())
        return f"T{self.version}:{h.hexdigest()[:10]}"

    def subset(self, predicate) -> "Taxonomy":
        """A view containing only the codes matching ``predicate``.

        Used to split the audit into an outcome-blind pass and an
        outcome-visible one; the version and changelog are carried over
        unchanged because a view is not a new taxonomy version.
        """
        return Taxonomy(version=self.version,
                        modes=[m for m in self.modes if predicate(m)],
                        changelog=self.changelog)

    def add(self, mode: FailureMode, evidence: dict[str, Any]) -> "Taxonomy":
        """Admit a discovered code.  Call only after the dual gate passes."""
        if mode.code in self._by_code:
            raise ValueError(f"code {mode.code} already exists")
        new = Taxonomy(
            version=self.version + 1,
            modes=self.modes + [mode],
            changelog=self.changelog + [{
                "version": self.version + 1,
                "action": "add",
                "code": mode.code,
                "name": mode.name,
                "provenance": mode.provenance,
                "gate_evidence": evidence,
            }],
        )
        return new

    # -- persistence ------------------------------------------------------ #
    def save(self, path: str | Path) -> None:
        payload = {
            "version": self.version,
            "changelog": self.changelog,
            "modes": [
                {**asdict(m),
                 "allowed_phases": sorted(m.allowed_phases),
                 "requires": sorted(m.requires)}
                for m in self.modes
            ],
        }
        Path(path).write_text(json.dumps(payload, indent=2, ensure_ascii=False),
                              encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "Taxonomy":
        p = json.loads(Path(path).read_text(encoding="utf-8"))
        modes = [
            FailureMode(
                **{**m,
                   "allowed_phases": frozenset(m["allowed_phases"]),
                   "requires": frozenset(m["requires"])}
            )
            for m in p["modes"]
        ]
        return cls(version=p["version"], modes=modes, changelog=p["changelog"])


#: escape hatch emitted by the annotator when nothing in T_k fits.
NOVEL_CODE = "NOVEL"

_SLUG = re.compile(r"[^a-z0-9]+")


def slugify(name: str, max_words: int = 4) -> str:
    words = [w for w in _SLUG.sub(" ", name.lower()).split() if len(w) > 2]
    return "-".join(words[:max_words]) or "unnamed"


def discovered_code(name: str, version: int, taken: set[str]) -> str:
    """Identifier for a code the pipeline found rather than inherited.

    Deliberately NOT a number in the seed scheme. Those numbers are
    MedAgentAudit's and encode its three-stage structure; giving a discovered
    code `2.1.3` quietly asserts membership in that structure and a position in
    its ordering, neither of which has been shown. Two runs discovering
    different things would also both land on `2.1.3` and become incomparable.

    The form is ``D<version>.<slug>``: the version says when it entered, the
    slug says what it is, and nothing says where it sits in someone else's
    taxonomy. Where it belongs structurally is recorded in ``stage`` instead,
    which is enough to group it with the seed codes in a report without
    renumbering anything.
    """
    base = f"D{version}.{slugify(name)}"
    if base not in taken:
        return base
    for i in range(2, 99):
        if f"{base}-{i}" not in taken:
            return f"{base}-{i}"
    raise ValueError(f"cannot allocate a code for {name!r}")
