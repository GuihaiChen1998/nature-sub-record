"""
blackbox_calibration.py
=======================
Calibration backends that need nothing from an endpoint except what a chat
API already returns: sampled text, and optionally a top-k logprob. No hidden
states, no base checkpoint, no gradients, no target labels.

This is the third attempt at the same problem and the constraints have been
narrowing each time:

* 0.7.25 made Stage 2 pluggable and offered ACI and Venn-Abers. Both are
  **supervised**.
* 0.7.26 added LaSCal, which is label-free on the target but needs source
  labels and only models **label shift** -- it can recalibrate the existing
  codes after a taxonomy change and must abstain on the new one.
* Here: methods that need **no labels at all**, and so can in principle cover
  the new code too.

What survives the API constraint
--------------------------------
Assessed against this pipeline, where every annotator is a third-party chat
endpoint:

===========================  =========  =======================================
method                       usable     why
===========================  =========  =======================================
Sample Consistency           **yes**    k samples, agreement rate. Nothing else.
DACA                         **partly** needs a reference model believed to be
                                        better calibrated. We have no base
                                        checkpoints, but we do have four
                                        endpoints and 400 human-labelled
                                        instances to *measure* which is best
                                        calibrated rather than assume it.
Consistency distillation     **yes**    consistency targets offline, one call
                                        at inference. Fits our existing
                                        feature vector exactly.
BaseCal                      no         no served base checkpoint, no hidden
                                        states through a chat API.
ATS                          no         needs token-level hidden states.
CFT / RCFT, bilevel          no         fine-tuning; we cannot touch weights.
===========================  =========  =======================================

The caveat this project can state and the papers cannot
-------------------------------------------------------
Every consistency-based method estimates **how much a model agrees with
itself**, and then uses that as a proxy for **how often it is right**. §10
measured that proxy directly, in this domain, against clinicians:

* four LLM annotators agreed with each other at mean pairwise kappa **0.477**
  and with the expert gold at **0.504** -- so in aggregate self-agreement was
  not inflated,
* but across the ten codes the correlation between panel self-agreement and
  panel validity was only **+0.35**, and per code it ran both ways: `1.2.1`
  self-agreement 0.701 against validity 0.346, `2.1.1` self-agreement 0.256
  against validity 0.589.

So consistency is a usable signal and a **weak** proxy, and it is weak in a
code-dependent way. A consistency-calibrated confidence will be systematically
too high on codes like `1.2.1` and too low on codes like `2.1.1`. That is not
a reason to avoid these methods -- they are the only label-free option that
can speak to a newly added code -- but it is a reason to report per-code
behaviour rather than a pooled ECE, and to keep the human queue on the codes
where the gap is largest.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence

import numpy as np

from .calibration_backends import Belief, BackendReport, EvolutionPolicy


# --------------------------------------------------------------------------- #
# 1. Sample consistency
# --------------------------------------------------------------------------- #

def consistency_features(votes: Sequence[int]) -> dict[str, float]:
    """The three signals from Calibrating LLMs with Sample Consistency.

    ``votes`` are k independent binary verdicts for one slot.

    agreement  fraction voting for the majority label. The estimate of the
               model's own probability, and the one used as the confidence.
    entropy    normalised Shannon entropy of the vote distribution; 0 when
               unanimous, 1 at a dead split.
    fsd        first-second distance, the gap between the top two vote shares.
               Equal to |2*agreement - 1| in the binary case, kept because it
               generalises to the multiclass step head.
    """
    k = len(votes)
    if k == 0:
        return {"agreement": 0.5, "entropy": 1.0, "fsd": 0.0, "k": 0}
    n1 = sum(1 for v in votes if v == 1)
    p1 = n1 / k
    top = max(p1, 1 - p1)
    ent = 0.0
    for q in (p1, 1 - p1):
        if q > 0:
            ent -= q * math.log(q)
    return {"agreement": top, "p1": p1, "entropy": ent / math.log(2),
            "fsd": abs(2 * p1 - 1), "k": k}


class SampleConsistencyBackend:
    """Confidence from the agreement rate over k independent samples.

    Label-free in the strongest sense: it never sees a label, at fit time or
    at adapt time. It is therefore the only backend here that can produce a
    confidence for a **newly added code**, where LaSCal must abstain.

    Two things it fixes that are specific to this pipeline:

    1. **Saturation.** `p_token` is one-sided on every endpoint tried -- the
       top-k logprobs come back with a single alternative, so the estimate
       pins to 0 or 1. Stratifying on it put 189 of 247 slots at the extremes
       and 9 across the middle three bins. A k-sample agreement rate is
       graded by construction: with k = 10 it takes eleven distinct values
       spread across the range.
    2. **Endpoint independence.** It works identically on endpoints that
       return no logprobs at all, which is three of the four in use.

    What it costs: k scorer calls per slot instead of one. At 20 slots per
    trace and k = 10 that is 200 extra calls per trace, which is why the
    distillation variant below exists.

    What it does not measure: correctness. See the module docstring -- in this
    domain the correlation between self-agreement and validity was +0.35
    across codes.

    ``laplace`` adds a pseudo-count to each side so that a unanimous vote is
    not reported as probability 1.0. k unanimous samples are evidence for a
    high probability, not proof of certainty, and an uncalibrated 1.0 breaks
    every downstream log and odds computation.
    """

    name = "sample_consistency"

    def __init__(self, k: int = 10, laplace: float = 1.0,
                 sample_fn: Optional[Callable[[Any], Sequence[int]]] = None
                 ) -> None:
        self.k = k
        self.laplace = laplace
        self.sample_fn = sample_fn
        self._sig: Optional[str] = None
        self._n = 0
        self._stats: dict[str, Any] = {}

    def _votes(self, f: Any) -> Sequence[int]:
        v = getattr(f, "consistency_votes", None)
        if v:
            return list(v)
        if self.sample_fn is not None:
            return list(self.sample_fn(f))
        raise RuntimeError(
            "no votes available: attach `consistency_votes` to the features "
            "or pass sample_fn. This backend cannot fall back on p_token -- "
            "that is the saturating estimate it exists to replace.")

    def fit(self, feats, labels=None, agreed=None, signature=None, **kw):
        """Labels are accepted and ignored, so the call site stays uniform.

        Recording that they were ignored matters: a reader comparing fit
        reports should be able to see that this backend's numbers owe nothing
        to the anchors.
        """
        self._sig = signature
        self._n = len(feats)
        ps = [self._p1(self._votes(f)) for f in feats]
        self._stats = {
            "labels_ignored": labels is not None,
            "mean_p1": round(float(np.mean(ps)), 4) if ps else None,
            "frac_extreme": (round(float(np.mean([p < 0.05 or p > 0.95
                                                  for p in ps])), 4)
                             if ps else None),
        }
        return self

    def _p1(self, votes: Sequence[int]) -> float:
        k = len(votes)
        n1 = sum(1 for v in votes if v == 1)
        return (n1 + self.laplace) / (k + 2 * self.laplace)

    def predict(self, feats) -> list[Belief]:
        out = []
        for f in feats:
            votes = self._votes(f)
            p = self._p1(votes)
            # A Wilson-style interval on the vote proportion. Width falls as
            # k rises, so the Belief carries "how many samples is this built
            # on" rather than hiding a k = 3 estimate behind a point.
            k = max(len(votes), 1)
            half = 1.96 * math.sqrt(max(p * (1 - p), 1e-9) / k)
            out.append(Belief(max(0.0, p - half), min(1.0, p + half)))
        return out

    def predict_agreement(self, feats) -> list[float]:
        # Self-agreement is the natural stand-in for annotator agreement, and
        # is reported as such rather than asserted to be the same thing.
        return [consistency_features(self._votes(f))["agreement"]
                for f in feats]

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.ADAPTS_UNSUPERVISED

    def report(self) -> BackendReport:
        return BackendReport(self.name, self.policy(), self._n, self._sig,
                             {"k": self.k, "laplace": self.laplace,
                              **self._stats,
                              "caveat": "measures self-agreement, not "
                                        "correctness; +0.35 correlation with "
                                        "validity across the ten codes (§10)"})

    def on_taxonomy_change(self, new_signature: str) -> str:
        self._sig = new_signature
        return ("sample consistency is unaffected by a taxonomy change: it "
                "never fitted anything on the old one. It is the only backend "
                "here that produces a confidence for a NEWLY ADDED code "
                "rather than abstaining. The standing caveat applies -- this "
                "is self-agreement, and on a new code nothing has checked "
                "whether self-agreement tracks correctness there.")


# --------------------------------------------------------------------------- #
# 2. DACA, with the assumption made testable
# --------------------------------------------------------------------------- #

class DACABackend:
    """Align one annotator's confidence to a reference, on agreement slots only.

    DACA optimises a temperature so the target model's probabilities match a
    reference model's, using **only the slots where the two agree**. The
    restriction is the whole idea: on a disagreement slot the reference's
    confidence describes the correctness of *its own* prediction, not the
    target's, so including those slots pushes the temperature up and produces
    under-confidence.

    The paper's justification is that a pre-trained base model is better
    calibrated than its post-trained descendant. **That justification does not
    transfer here** -- there is no served base checkpoint for any of the four
    endpoints, so the reference cannot be "the base model of the target".

    What replaces it is better than an assumption: this project has 400
    MedAgentAudit instances with three clinicians each, and §10 already
    measured every endpoint against that gold. So the reference is **chosen by
    measurement** -- ``fit_reference_from_gold`` ranks candidate annotators by
    their ECE against the human majority and picks the best. If that has not
    been run, the backend says the reference is unverified rather than
    presenting it as the paper's PLM.

    Note what this is and is not: with a measured reference it is a defensible
    cross-annotator alignment. Without one it is temperature scaling toward an
    arbitrary second opinion, and §10 is the reason to be suspicious of that
    -- the four endpoints agreed with each other at kappa 0.477 while their
    agreement with experts was 0.504, so "another endpoint agrees" carries
    much less information here than the DACA setting assumes.
    """

    name = "daca"

    def __init__(self, reference_key: str = "reference_p",
                 grid: Optional[Sequence[float]] = None) -> None:
        self.reference_key = reference_key
        self.grid = list(grid) if grid is not None else list(
            np.concatenate([np.linspace(0.5, 1.0, 11),
                            np.linspace(1.1, 5.0, 40)]))
        self._temp = 1.0
        self._sig: Optional[str] = None
        self._n_agree = 0
        self._n_total = 0
        self._ref_verified: Optional[dict[str, Any]] = None
        self._inner = None

    # -- making the reference an evidence-backed choice -------------------- #
    @staticmethod
    def rank_references_by_gold(
        endpoint_probs: dict[str, Sequence[float]],
        gold: Sequence[int],
    ) -> list[tuple[str, float, float]]:
        """Rank candidate reference annotators by measured calibration.

        ``endpoint_probs`` maps an endpoint name to its probabilities on a set
        of instances for which ``gold`` holds human labels -- in practice the
        400 MedAgentAudit audit instances, three clinicians each, majority
        vote. Returns (name, ECE, accuracy) sorted by ECE.

        This is the step that turns DACA's untestable premise into a fact
        about the endpoints actually in use.
        """
        from .uncertainty import expected_calibration_error
        out = []
        y = list(gold)
        for name, p in endpoint_probs.items():
            p = list(p)
            ece = expected_calibration_error(p, y)
            acc = float(np.mean([(q > 0.5) == bool(t) for q, t in zip(p, y)]))
            out.append((name, float(ece), acc))
        return sorted(out, key=lambda r: r[1])

    def set_verified_reference(self, name: str, ece: float, acc: float,
                               n: int) -> "DACABackend":
        self._ref_verified = {"endpoint": name, "ece_vs_human_gold": round(ece, 4),
                              "accuracy_vs_human_gold": round(acc, 4), "n": n}
        return self

    # -- the fit ----------------------------------------------------------- #
    def fit(self, feats, labels=None, agreed=None, signature=None, **kw):
        """Labels ignored. The reference probability rides on the features."""
        from .uncertainty import TwoHeadCalibrator
        self._sig = signature
        tgt, ref = [], []
        for f in feats:
            r = getattr(f, self.reference_key, None)
            p = getattr(f, "p_token", None)
            if p is None:
                p = getattr(f, "p_verbal_score", None)
            if r is None or p is None:
                continue
            tgt.append(float(p))
            ref.append(float(r))
        self._n_total = len(tgt)
        if not tgt:
            raise RuntimeError(
                f"no slot carried both a target probability and "
                f"{self.reference_key!r}; DACA needs a second annotator's "
                f"probability on the same slots.")

        t = np.asarray(tgt, float)
        r = np.asarray(ref, float)
        # the agreement filter, which is the method
        keep = (t > 0.5) == (r > 0.5)
        self._n_agree = int(keep.sum())
        if self._n_agree < 20:
            self._temp = 1.0
            return self
        t, r = t[keep], r[keep]

        best, best_kl = 1.0, float("inf")
        for temp in self.grid:
            q = self._scale(t, temp)
            kl = float(np.mean(
                r * np.log(np.clip(r, 1e-9, 1) / np.clip(q, 1e-9, 1))
                + (1 - r) * np.log(np.clip(1 - r, 1e-9, 1)
                                   / np.clip(1 - q, 1e-9, 1))))
            if kl < best_kl:
                best, best_kl = float(temp), kl
        self._temp = best
        return self

    @staticmethod
    def _scale(p: np.ndarray, temp: float) -> np.ndarray:
        p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)
        return 1.0 / (1.0 + np.exp(-np.log(p / (1 - p)) / max(temp, 1e-3)))

    def predict(self, feats) -> list[Belief]:
        out = []
        for f in feats:
            p = getattr(f, "p_token", None)
            if p is None:
                p = getattr(f, "p_verbal_score", None)
            if p is None:
                out.append(Belief(0.0, 1.0))
                continue
            out.append(Belief.point(float(self._scale(np.array([p]),
                                                      self._temp)[0])))
        return out

    def predict_agreement(self, feats) -> list[float]:
        vals = []
        for f in feats:
            r = getattr(f, self.reference_key, None)
            p = getattr(f, "p_token", None)
            if r is None or p is None:
                vals.append(0.5)
            else:
                vals.append(1.0 if (float(p) > 0.5) == (float(r) > 0.5) else 0.0)
        return vals

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.ADAPTS_UNSUPERVISED

    def report(self) -> BackendReport:
        det: dict[str, Any] = {
            "temperature": round(self._temp, 4),
            "n_agreement": self._n_agree, "n_total": self._n_total,
            "agreement_rate": (round(self._n_agree / self._n_total, 4)
                               if self._n_total else None),
            "reference": self._ref_verified,
        }
        if self._ref_verified is None:
            det["warning"] = (
                "reference annotator is UNVERIFIED. DACA's premise is that "
                "the reference is better calibrated than the target; here "
                "there is no base checkpoint to appeal to, so run "
                "rank_references_by_gold on the MedAgentAudit human instances "
                "and call set_verified_reference. Without it this is "
                "temperature scaling toward an arbitrary second opinion, and "
                "§10 measured those four endpoints agreeing with each other "
                "(kappa 0.477) about as well as with experts (0.504).")
        return BackendReport(self.name, self.policy(), self._n_total,
                             self._sig, det)

    def on_taxonomy_change(self, new_signature: str) -> str:
        self._sig = new_signature
        return ("DACA's temperature was fitted on agreement between two "
                "annotators, not on labels, so it carries over. It says "
                "nothing about a newly added code beyond what the reference "
                "annotator says about it.")


# --------------------------------------------------------------------------- #
# 3. Consistency distillation: pay for sampling once, offline
# --------------------------------------------------------------------------- #

class ConsistencyDistillBackend:
    """Fit the existing feature head against consistency-derived targets.

    The move is small and the fit with this codebase is exact. Stage 2 already
    maps a slot's feature vector to a probability with a logistic head; the
    only thing that made it supervised was the target. Replace the human label
    with the k-sample agreement rate and the head becomes label-free, while
    inference stays at **one** call per slot instead of k.

    Two targets are supported. ``soft`` regresses on the agreement rate and
    keeps its gradation; ``hard`` thresholds it at 0.5 and fits a classifier.
    Soft is the default: the whole reason for sampling here was that the
    logprob estimate saturates, and thresholding would throw the gradation
    away again.

    The honest framing: this distils **the annotator's own consistency**, so
    its ceiling is however well self-agreement tracks correctness. It can be
    fitted on the new taxonomy with no annotation, which is the point, and it
    inherits the code-dependent weakness measured in §10.
    """

    name = "consistency_distill"

    def __init__(self, target: str = "soft", k: int = 10, **kw: Any) -> None:
        if target not in ("soft", "hard"):
            raise ValueError("target must be 'soft' or 'hard'")
        self.target = target
        self.k = k
        self._model = None
        self._sig: Optional[str] = None
        self._n = 0
        self._fit_stats: dict[str, Any] = {}

    def fit(self, feats, labels=None, agreed=None, signature=None,
            votes: Optional[Sequence[Sequence[int]]] = None, **kw):
        from sklearn.linear_model import LogisticRegression, Ridge
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler

        self._sig = signature
        vs = votes or [getattr(f, "consistency_votes", None) for f in feats]
        rows = [(f, v) for f, v in zip(feats, vs) if v]
        if not rows:
            raise RuntimeError(
                "consistency distillation needs per-slot votes; attach "
                "`consistency_votes` or pass votes=. No labels are needed, "
                "but the samples are.")
        X = np.asarray([f.vector() for f, _ in rows], float)
        agree = np.asarray([sum(v) / len(v) for _, v in rows], float)
        self._n = len(rows)

        if self.target == "soft":
            self._model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
            self._model.fit(X, agree)
        else:
            y = (agree > 0.5).astype(int)
            if len(set(y)) < 2:
                self._model = ("const", float(y.mean()))
            else:
                self._model = make_pipeline(
                    StandardScaler(),
                    LogisticRegression(max_iter=3000, C=0.5))
                self._model.fit(X, y)

        self._fit_stats = {
            "labels_ignored": labels is not None,
            "target": self.target,
            "mean_agreement_target": round(float(agree.mean()), 4),
            "target_spread": round(float(agree.std()), 4),
        }
        return self

    def predict(self, feats) -> list[Belief]:
        if self._model is None:
            raise RuntimeError("fit() first")
        X = np.asarray([f.vector() for f in feats], float)
        if isinstance(self._model, tuple):
            p = np.full(len(feats), self._model[1], float)
        elif self.target == "soft":
            p = np.clip(self._model.predict(X), 0.0, 1.0)
        else:
            p = self._model.predict_proba(X)[:, 1]
        return [Belief.point(float(v)) for v in p]

    def predict_agreement(self, feats) -> list[float]:
        return [b.p for b in self.predict(feats)]

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.ADAPTS_UNSUPERVISED

    def report(self) -> BackendReport:
        return BackendReport(self.name, self.policy(), self._n, self._sig,
                             {"k": self.k, **self._fit_stats,
                              "inference_cost": "1 call per slot; the k "
                                                "samples are paid once at fit "
                                                "time",
                              "ceiling": "self-agreement, not correctness"})

    def on_taxonomy_change(self, new_signature: str) -> str:
        return ("refit on the new taxonomy's slots with no annotation: sample "
                "each slot k times and fit against the agreement rate. This "
                "is the only backend that can be re-fitted, rather than "
                "carried over or abstained with, after Taxonomy.add().")
