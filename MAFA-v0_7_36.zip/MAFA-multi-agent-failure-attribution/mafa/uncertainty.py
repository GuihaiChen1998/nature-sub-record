"""
uncertainty.py
==============
Turns one Stage-1 annotation into a per-slot feature vector, then into a
calibrated probability.

Signals (none of them require repeated sampling of the reasoner):

    W1  p_token        white-box  p(1) from the Stage-1b scorer's logprobs
    W2  margin         white-box  |2*p_token - 1|
    B1  verbalised     black-box  self_assessment + per-finding low/med/high
    B2  groundedness   black-box  do the quoted spans actually exist
    B3  structural     black-box  count/kind of consistency violations
    B4  rubric_agree   black-box  agreement with a paraphrased-rubric rerun
                                  (one extra cheap call, not N samples)

``rubric_agree`` is the only optional extra call.  Everything else is free once
the two Stage-1 calls have been made.

The calibrator is fitted on an anchor set of human-labelled slots.  Two anchor
sources are available at zero annotation cost:

  * MedAgentAudit's released human evaluation -- 383 instances with three-way
    votes, on their trajectories.  Use it to fit the *shape* of the calibrator
    and to sanity-check features, not as the final anchor (different
    frameworks).
  * 150-200 slots on your own traces, double-annotated.  This is the anchor
    that all reported numbers must ultimately rest on.

Resolvability, not an aleatoric constant
---------------------------------------
An earlier version of this module weighted routing by the per-code human
Fleiss kappa recomputed from MedAgentAudit (.42 for 3.1.3 up to .73 for
2.2.1).  Measurement killed that: on the 383-instance anchor the correlation
between mean model confidence and per-code kappa is 0.141, and kappa-weighted
routing did not beat plain risk ranking.  It is replaced by Head B, an
instance-level model of whether annotators will converge (AUC 0.702).  The
kappa table is retained only as a feature and for the ablation.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, asdict
from typing import Any, Optional, Sequence

from .stage1_schema import Slot, SlotPlan, Stage1Annotation
from .trace_adapter import Trace

# Per-code human inter-rater reliability, recomputed from MedAgentAudit's
# released annotator exports (383 matched instances, 1200 votes).
# Treat these as a prior for the aleatoric floor until you measure your own.
HUMAN_FLEISS_KAPPA: dict[str, float] = {
    "1.1.1": 0.731, "1.2.1": 0.710,
    "2.1.1": 0.723, "2.1.2": 0.707, "2.2.1": 0.731, "2.2.2": 0.650,
    "3.1.1": 0.531, "3.1.2": 0.516, "3.1.3": 0.422, "3.2.1": 0.646,
}
DEFAULT_KAPPA = 0.55  # for NOVEL / newly admitted codes, until measured


# --------------------------------------------------------------------------- #
# Violation families
# --------------------------------------------------------------------------- #
#
# The 19 structural checks are mapped to six families, and each family becomes
# its own feature (globally and locally) rather than being folded into one
# hand-weighted scalar.
#
# The previous design multiplied every violation by a constant I chose --
# ungrounded_quote 1.0 against novel_definition_too_thin 0.3 asserts a 3.3x
# ratio in diagnostic value that nothing measured. Worse, it was not
# identifiable: the calibrator already learns a coefficient on the aggregate,
# so an inner weight and an outer coefficient trade off freely. Exposing the
# families directly makes the calibrator's coefficients *be* the weights,
# learned on the anchor set, with one parameter per family instead of 19.
#
# The families are also independently useful: a high evidence_grounding count
# means the annotator is hallucinating, a high cross_level count means it is
# labelling incoherently. Those are different failures and the old scalar
# averaged them together.

VIOLATION_FAMILY: dict[str, str] = {
    # the annotator invented or misplaced its evidence
    "ungrounded_quote": "evidence",
    "quote_step_misattributed": "evidence",
    "finding_without_evidence": "evidence",
    "novel_without_grounded_evidence": "evidence",
    # it referred to something that does not exist in the trace or taxonomy
    "unknown_agent": "reference",
    "unknown_step": "reference",
    "unknown_code": "reference",
    "unknown_earliest_step": "reference",
    "finding_slot_out_of_range": "reference",
    # it placed a code where the taxonomy does not allow it
    "phase_illegal": "legality",
    # its three levels contradict each other
    "mode_flagged_but_no_agent_flagged": "cross_level",
    "agent_flagged_but_no_mode_flagged": "cross_level",
    "mode_flagged_but_no_earliest_step": "cross_level",
    "earliest_step_without_mode": "cross_level",
    "finding_before_earliest": "cross_level",
    "earliest_step_not_in_flagged_step_slots": "cross_level",
    "earliest_step_owner_not_flagged": "cross_level",
    "agent_flagged_without_local_evidence": "cross_level",
    # a NOVEL proposal that is not fit to enter the residual pool
    "novel_definition_too_thin": "novelty",
    # the output did not follow the schema
    "verdict_length_mismatch": "protocol",
}

FAMILIES: tuple[str, ...] = ("evidence", "reference", "legality",
                             "cross_level", "novelty", "protocol")
UNKNOWN_FAMILY = "cross_level"      # new checks default here until classified

#: The superseded hand-set weights. Kept ONLY so the ablation can show what
#: the learned families buy over them; nothing in the live path reads this.
LEGACY_VIOLATION_WEIGHTS: dict[str, float] = {
    "ungrounded_quote": 1.0, "quote_step_misattributed": 0.6,
    "finding_without_evidence": 1.0, "phase_illegal": 0.8,
    "unknown_agent": 1.0, "unknown_step": 1.0, "unknown_code": 1.0,
    "finding_before_earliest": 0.7, "earliest_step_owner_not_flagged": 0.5,
    "earliest_step_not_in_flagged_step_slots": 0.5,
    "mode_flagged_but_no_agent_flagged": 0.7,
    "agent_flagged_but_no_mode_flagged": 0.4,
    "mode_flagged_but_no_earliest_step": 0.6,
    "earliest_step_without_mode": 0.5,
    "agent_flagged_without_local_evidence": 0.8,
    "novel_without_grounded_evidence": 1.0, "novel_definition_too_thin": 0.3,
    "verdict_length_mismatch": 1.0, "finding_slot_out_of_range": 0.5,
}


def family_of(violation: str) -> str:
    return VIOLATION_FAMILY.get(violation.split(":", 1)[0], UNKNOWN_FAMILY)


def family_counts(violations: Sequence[str],
                  key: Optional[str] = None) -> dict[str, float]:
    """Squashed per-family counts. ``key`` restricts to violations naming it."""
    raw: dict[str, int] = {f: 0 for f in FAMILIES}
    for v in violations:
        if key is not None and key not in v:
            continue
        raw[family_of(v)] += 1
    # 1 - exp(-n): the first occurrence carries most of the signal, a fifth
    # adds little, and the feature stays bounded for the calibrator
    return {f: 1.0 - math.exp(-n) for f, n in raw.items()}


def legacy_violation_penalty(violations: Sequence[str],
                             key: Optional[str] = None) -> float:
    """The superseded scalar, for the ablation arm only."""
    total = 0.0
    for v in violations:
        if key is not None and key not in v:
            continue
        total += LEGACY_VIOLATION_WEIGHTS.get(v.split(":", 1)[0], 0.3)
    return 1.0 - math.exp(-total)


_VERBAL = {"low": 0.25, "medium": 0.6, "high": 0.9}


@dataclass
class SlotFeatures:
    slot_index: int
    slot_kind: str
    code: Optional[str]
    verdict: int
    # white box
    p_token: Optional[float]
    token_margin: Optional[float]
    #: graded 0-100 self-report, present when the scorer ran in verbalised or
    #: both mode. Independent of p_token and does not saturate the way a
    #: one-sided logprob does.
    p_verbal_score: Optional[float]
    # black box
    verbalised: float
    level_confidence: float
    groundedness: float
    n_evidence: int
    #: squashed per-family violation counts, whole annotation and this slot
    violation_global: dict[str, float]
    violation_local: dict[str, float]
    rubric_agree: Optional[float]
    # context
    n_flagged_same_kind: int
    trace_len: int
    aleatoric_kappa: float

    def vector(self) -> list[float]:
        """Fixed-order feature vector for the calibrator."""
        return [
            self.p_token if self.p_token is not None else 0.5,
            self.token_margin if self.token_margin is not None else 0.0,
            1.0 if self.p_token is None else 0.0,      # missingness indicator
            self.p_verbal_score if self.p_verbal_score is not None else 0.5,
            abs(2 * (self.p_verbal_score or 0.5) - 1),
            1.0 if self.p_verbal_score is None else 0.0,
            self.verbalised,
            self.level_confidence,
            self.groundedness,
            min(self.n_evidence, 3) / 3.0,
            *[self.violation_global.get(f, 0.0) for f in FAMILIES],
            *[self.violation_local.get(f, 0.0) for f in FAMILIES],
            self.rubric_agree if self.rubric_agree is not None else 0.5,
            1.0 if self.rubric_agree is None else 0.0,
            self.n_flagged_same_kind / max(self.trace_len, 1),
            self.aleatoric_kappa,
        ]

    @staticmethod
    def names() -> list[str]:
        return (["p_token", "token_margin", "p_token_missing",
                 "p_verbal_score", "verbal_margin", "p_verbal_missing",
                 "verbalised",
                 "level_confidence", "groundedness", "n_evidence"]
                + [f"viol_global_{f}" for f in FAMILIES]
                + [f"viol_local_{f}" for f in FAMILIES]
                + ["rubric_agree", "rubric_missing", "flag_density",
                   "aleatoric_kappa"])


def _violation_penalty(violations: Sequence[str], key: Optional[str] = None) -> float:
    total = 0.0
    for v in violations:
        head = v.split(":", 1)[0]
        if key is not None and key not in v:
            continue
        total += VIOLATION_WEIGHTS.get(head, 0.3)
    return 1.0 - math.exp(-total)          # squashed to [0, 1)


def extract_features(
    ann: Stage1Annotation,
    trace: Trace,
    rubric_rerun: Optional[Stage1Annotation] = None,
) -> list[SlotFeatures]:
    plan = ann.plan
    global_fam = family_counts(ann.violations)
    by_slot = {f.slot_index: f for f in ann.findings}
    sa = ann.self_assessment or {}
    level_conf = {
        "agent": float(sa.get("agent_level", 50)) / 100.0,
        "step": float(sa.get("step_level", 50)) / 100.0,
        "mode": float(sa.get("mode_level", 50)) / 100.0,
    }
    n_flagged = {
        k: sum(1 for s in ann.flagged_slots() if s.kind == k)
        for k in ("agent", "step", "mode")
    }

    out: list[SlotFeatures] = []
    for s in plan.slots:
        verdict = ann.verdicts[s.index]
        f = by_slot.get(s.index)
        p = ann.p_positive[s.index] if s.index < len(ann.p_positive) else None
        pv = (ann.p_verbalised[s.index]
              if s.index < len(ann.p_verbalised) else None)

        rubric = None
        if rubric_rerun is not None and s.index < len(rubric_rerun.verdicts):
            rubric = 1.0 if rubric_rerun.verdicts[s.index] == verdict else 0.0

        key = s.code or s.agent_uid or s.step_id or ""
        out.append(SlotFeatures(
            slot_index=s.index,
            slot_kind=s.kind,
            code=s.code,
            verdict=verdict,
            p_token=p,
            token_margin=None if p is None else abs(2 * p - 1),
            p_verbal_score=pv,
            verbalised=_VERBAL.get(f.confidence, 0.5) if f else 0.5,
            level_confidence=level_conf.get(s.kind, 0.5),
            groundedness=f.groundedness if f else (0.0 if verdict else 1.0),
            n_evidence=len(f.evidence) if f else 0,
            violation_global=global_fam,
            violation_local=(family_counts(ann.violations, key) if key
                             else {f: 0.0 for f in FAMILIES}),
            rubric_agree=rubric,
            n_flagged_same_kind=n_flagged.get(s.kind, 0),
            trace_len=len(trace.steps),
            aleatoric_kappa=HUMAN_FLEISS_KAPPA.get(s.code or "", DEFAULT_KAPPA),
        ))
    return out


# --------------------------------------------------------------------------- #
# Two-head calibration
# --------------------------------------------------------------------------- #
#
# Head A  P(label = 1 | features)          -- the calibrated verdict
# Head B  P(annotators agree | features)   -- the resolvability head
#
# Head B replaces the per-code Fleiss-kappa constant that the first version of
# this module used.  Measured on MedAgentAudit's 383-instance anchor:
#
#     AUC(features -> three annotators unanimous)          0.702
#     corr(mean model confidence, per-code Fleiss kappa)    0.141
#
# The near-zero correlation is the point: at instance level the per-code kappa
# carries almost none of the information that decides whether a human can
# settle this particular case, so the constant had to go.  On that anchor the
# two-head router did NOT reduce selective error (identical at 50% and 70%
# coverage) but it did raise the share of routed cases on which annotators
# would agree, 60.0% -> 63.5%.  So Head B is a queue-quality mechanism, not an
# accuracy mechanism, and should be reported as such.


@dataclass
class HeadReport:
    n: int
    auc: Optional[float]
    ece: float
    brier: float
    accuracy: float


class TwoHeadCalibrator:
    """Per-slot-kind calibration of both heads.

    Slot kinds are fitted separately: an agent-level decision and a mode-level
    decision have different base rates and different informative features, and
    a calibrator pooled across them is well calibrated on neither.
    """

    def __init__(self, method: str = "logistic", C: float = 0.5,
                 min_per_kind: int = 40,
                 taxonomy_signature: Optional[str] = None) -> None:
        self.method = method
        self.C = C
        self.min_per_kind = min_per_kind
        #: the taxonomy this was fitted against; see check_signature
        self.taxonomy_signature = taxonomy_signature
        self.head_a: dict[str, Any] = {}
        self.head_b: dict[str, Any] = {}
        self.fallback_a: Any = None
        self.fallback_b: Any = None

    # -- fitting ---------------------------------------------------------- #
    def _new_model(self):
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        return make_pipeline(StandardScaler(),
                             LogisticRegression(max_iter=3000, C=self.C))

    def _fit_group(self, X, y):
        if len(set(y)) < 2:
            return ("const", float(sum(y)) / max(len(y), 1))
        m = self._new_model()
        m.fit(X, y)
        return ("model", m)

    def fit(
        self,
        feats: Sequence[SlotFeatures],
        labels: Sequence[int],
        agreed: Optional[Sequence[int]] = None,
    ) -> "TwoHeadCalibrator":
        """``agreed[i] == 1`` when the human annotators were unanimous on i.

        With a single annotator per slot, pass ``agreed=None``; Head B then
        degrades to a constant and the router falls back to pure risk ranking.
        """
        import numpy as np

        X = np.asarray([f.vector() for f in feats], float)
        y = np.asarray(list(labels), int)
        kinds = [f.slot_kind for f in feats]

        self.fallback_a = self._fit_group(X, y)
        if agreed is not None:
            self.fallback_b = self._fit_group(X, np.asarray(list(agreed), int))

        for kind in sorted(set(kinds)):
            m = [i for i, k in enumerate(kinds) if k == kind]
            if len(m) < self.min_per_kind:
                continue                      # too thin; use the pooled model
            self.head_a[kind] = self._fit_group(X[m], y[m])
            if agreed is not None:
                a = np.asarray(list(agreed), int)[m]
                self.head_b[kind] = self._fit_group(X[m], a)
        return self

    # -- prediction ------------------------------------------------------- #
    def check_signature(self, signature: Optional[str]) -> None:
        """Refuse to score against a taxonomy this was not fitted on.

        Admitting a code changes the slot plan, the phases a code may legally
        occupy, and therefore the base rates of most violation families. A
        calibrator fitted at T_k is extrapolating on T_{k+1}, and the failure
        is silent: it returns perfectly plausible probabilities that are simply
        wrong. Refit on the calibration pool after every taxonomy change --
        no new human labels are needed for slots that already existed.
        """
        if self.taxonomy_signature is None or signature is None:
            return
        if self.taxonomy_signature != signature:
            raise RuntimeError(
                f"calibrator was fitted on taxonomy {self.taxonomy_signature} "
                f"but is being applied to {signature}. Refit before scoring; "
                "the conformal quantiles need recalibrating too, because "
                "exchangeability does not survive a change of label space.")

    @staticmethod
    def _apply(entry, x) -> float:
        if entry is None:
            return 0.5
        kind, m = entry
        if kind == "const":
            return float(m)
        return float(m.predict_proba([x])[0][1])

    def predict(self, feats: Sequence[SlotFeatures]) -> list[float]:
        return [self._apply(self.head_a.get(f.slot_kind, self.fallback_a),
                            f.vector()) for f in feats]

    def predict_agreement(self, feats: Sequence[SlotFeatures]) -> list[float]:
        if not self.head_b and self.fallback_b is None:
            return [1.0] * len(feats)         # unknown -> assume resolvable
        return [self._apply(self.head_b.get(f.slot_kind, self.fallback_b),
                            f.vector()) for f in feats]

    # -- evaluation -------------------------------------------------------- #
    @staticmethod
    def report(p: Sequence[float], y: Sequence[int]) -> HeadReport:
        from sklearn.metrics import brier_score_loss, roc_auc_score
        try:
            auc = float(roc_auc_score(list(y), list(p)))
        except ValueError:
            auc = None
        pred = [1 if q > 0.5 else 0 for q in p]
        return HeadReport(
            n=len(y), auc=auc, ece=expected_calibration_error(p, y),
            brier=float(brier_score_loss(list(y), list(p))),
            accuracy=sum(int(a == b) for a, b in zip(pred, y)) / max(len(y), 1),
        )


def expected_calibration_error(p: Sequence[float], y: Sequence[int],
                               bins: int = 10) -> float:
    n = len(p)
    if n == 0:
        return float("nan")
    tot = 0.0
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        idx = [i for i in range(n)
               if (lo < p[i] <= hi) or (b == 0 and p[i] <= hi)]
        if not idx:
            continue
        conf = sum(p[i] for i in idx) / len(idx)
        acc = sum(y[i] for i in idx) / len(idx)
        tot += (len(idx) / n) * abs(conf - acc)
    return tot


# --------------------------------------------------------------------------- #
# Routing scores
# --------------------------------------------------------------------------- #

def model_risk(p: float) -> float:
    """P(the calibrated verdict is wrong) under the model's own belief."""
    return min(p, 1.0 - p)


def expected_agreement_gain(p: float, p_agree: float) -> float:
    """Expected amount of error a human review can actually remove.

    ``p`` is Head A's calibrated probability, ``p_agree`` is Head B's estimate
    that annotators will converge on this slot.  Ranking descending gives the
    human queue; the top of that queue is where a review both is likely to be
    needed and is likely to produce a stable label.

    Deliberately NOT a function of the per-code kappa any more -- see the
    module note above for the measurement that killed that version.
    """
    return model_risk(p) * max(0.0, min(1.0, p_agree))


def legacy_kappa_gain(p: float, code: Optional[str]) -> float:
    """The superseded per-code-kappa score, kept for the ablation table."""
    kappa = HUMAN_FLEISS_KAPPA.get(code or "", DEFAULT_KAPPA)
    e = -(p * math.log(max(p, 1e-9)) + (1 - p) * math.log(max(1 - p, 1e-9)))
    return e / math.log(2) * kappa


def risk_coverage(p: Sequence[float], y: Sequence[int],
                  route_score: Optional[Sequence[float]] = None
                  ) -> list[tuple[float, float]]:
    """(coverage, selective error) as the lowest-scoring slots are retained.

    ``route_score`` defaults to :func:`model_risk`; pass
    :func:`expected_agreement_gain` values to compare routers.
    """
    import numpy as np

    p = np.asarray(list(p), float)
    y = np.asarray(list(y), int)
    s = (np.asarray([model_risk(q) for q in p]) if route_score is None
         else np.asarray(list(route_score), float))
    order = np.argsort(s)                       # keep the safest first
    pred = (p > 0.5).astype(int)
    return [(k / len(p), float((pred[order[:k]] != y[order[:k]]).mean()))
            for k in range(1, len(p) + 1)]
