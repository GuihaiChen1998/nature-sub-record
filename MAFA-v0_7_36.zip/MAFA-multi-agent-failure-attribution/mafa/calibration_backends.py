"""
calibration_backends.py
=======================
Pluggable Stage-2 backends behind one interface, so the calibrator can be
swapped without touching Stage 1 or Stage 4, and so the router can be told
what kind of object it is being handed.

Why this exists
---------------
The claim this project makes is self-evolution: the taxonomy grows from the
residue and the loop turns again. It has never turned twice, and the obstacle
was never the admission gate. It is that ``Taxonomy.add()`` changes
``signature()``, and both the calibrator and the conformal router are bound to
that signature and refuse to score across a change (0.3.0). The refusal is
correct -- a calibrator fitted on T_k extrapolates on T_{k+1} and **fails
silently**, returning perfectly plausible wrong probabilities -- but it makes
a second turn cost a full re-anchoring, and at the mistake-type level the
anchors can only be human.

So the fixed-label-space assumption has to become a *choice*, declared per
backend, rather than a property of the pipeline. Three backends, three
positions on that question:

``logistic``
    The current TwoHeadCalibrator. Point estimate, two heads, refuses across a
    signature change. Keeps the existing guarantees exactly; costs a re-anchor
    per turn.

``venn_abers``
    Inductive Venn-Abers. Emits an **interval** [p0, p1] rather than a point.
    Under exchangeability the interval is automatically calibrated with no
    fitted link function. What makes it interesting here is not that property
    but its failure mode: on a test point in a region the calibration set does
    not cover -- which is exactly what a newly added code produces -- the
    interval **widens** instead of lying. Degradation is visible rather than
    silent, and width becomes a usable novelty signal.

``logistic_va``
    Logistic scores wrapped in Venn-Abers. The discriminative model does the
    work; VA supplies the interval. In practice the one to reach for, since
    raw features are not monotone in the label and isotonic regression on them
    alone throws away the feature interactions Head A learns.

None of these makes a taxonomy change free. Stated plainly so nobody reads
more into it: Venn-Abers is valid under exchangeability like split conformal
is, and a taxonomy change breaks exchangeability for both. What VA buys is
that the breakage shows up as width.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, Protocol, Sequence, runtime_checkable

import numpy as np


# --------------------------------------------------------------------------- #
# What a calibrator hands to the router
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Belief:
    """A calibrated belief about one binary slot.

    A point estimator sets ``lo == hi``. An interval estimator sets
    ``lo < hi``, and the width carries information the point cannot: how much
    the calibration data actually constrains this instance.

    Keeping both shapes in one type is what lets the router be written once.
    A router that only understands points can call ``.point``; one that can use
    the interval reads ``.lo`` / ``.hi`` and declares ``requires_interval``.
    """

    lo: float
    hi: float

    def __post_init__(self) -> None:
        if not (0.0 <= self.lo <= self.hi <= 1.0):
            raise ValueError(f"malformed belief [{self.lo}, {self.hi}]")

    @classmethod
    def point(cls, p: float) -> "Belief":
        p = min(max(float(p), 0.0), 1.0)
        return cls(p, p)

    @property
    def width(self) -> float:
        return self.hi - self.lo

    @property
    def is_point(self) -> bool:
        return self.hi <= self.lo + 1e-12

    @property
    def p(self) -> float:
        """The scalar to use where a single number is required.

        For an interval this is the standard Venn-Abers collapse
        ``p1 / (1 - p0 + p1)``, not the midpoint: it is the value that makes
        the reported probability coherent with the two isotonic fits rather
        than an average of two quantities that are not on the same footing.
        """
        if self.is_point:
            return self.lo
        denom = 1.0 - self.lo + self.hi
        return self.hi / denom if denom > 0 else 0.5


# --------------------------------------------------------------------------- #
# How a backend behaves when the taxonomy changes under it
# --------------------------------------------------------------------------- #

class EvolutionPolicy(str, Enum):
    """What a backend claims when the taxonomy signature changes.

    This is the field that decides whether the loop can turn, so it is stated
    per backend rather than assumed pipeline-wide.
    """

    #: refuses to score. Correct and expensive: re-anchor before turning again.
    REFIT_REQUIRED = "refit_required"

    #: keeps scoring, and re-earns its guarantee from feedback over time. Valid
    #: in the long run, not at any single step, and only while feedback arrives.
    ADAPTS_ONLINE = "adapts_online"

    #: keeps scoring, and reports its own degradation rather than hiding it.
    #: NOT a claim of validity across the change.
    DEGRADES_VISIBLY = "degrades_visibly"

    #: re-fits itself on the new taxonomy from UNLABELLED slots. The only
    #: policy under which a turn of the loop costs no annotation. Valid to the
    #: extent the change behaves like label shift on the existing codes, and
    #: explicitly silent about the newly added code, which is a new class
    #: rather than a reweighted old one.
    ADAPTS_UNSUPERVISED = "adapts_unsupervised"


@dataclass
class BackendReport:
    name: str
    policy: EvolutionPolicy
    n_fit: int = 0
    signature: Optional[str] = None
    detail: dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        return (f"{self.name} n={self.n_fit} policy={self.policy.value} "
                f"sig={self.signature}")


@runtime_checkable
class CalibrationBackend(Protocol):
    """Stage 2 in one interface."""

    name: str

    def fit(self, feats: Sequence[Any], labels: Sequence[int],
            agreed: Optional[Sequence[int]] = None,
            signature: Optional[str] = None) -> "CalibrationBackend": ...

    def predict(self, feats: Sequence[Any]) -> list[Belief]: ...

    def predict_agreement(self, feats: Sequence[Any]) -> list[float]: ...

    def policy(self) -> EvolutionPolicy: ...

    def report(self) -> BackendReport: ...

    def on_taxonomy_change(self, new_signature: str) -> str:
        """Called when the signature moves. Returns a human-readable verdict.

        Raising here is a legitimate answer (``REFIT_REQUIRED``); so is
        continuing with a recorded warning.
        """
        ...


# --------------------------------------------------------------------------- #
# Backend 1: the existing logistic two-head
# --------------------------------------------------------------------------- #

class LogisticBackend:
    """Adapter over ``TwoHeadCalibrator``. Behaviour unchanged.

    Here so that the current pipeline is one option among several rather than
    the assumption everything else is written around.
    """

    name = "logistic"

    def __init__(self, **kw: Any) -> None:
        from .uncertainty import TwoHeadCalibrator
        self._c = TwoHeadCalibrator(**kw)
        self._sig: Optional[str] = None
        self._n = 0

    def fit(self, feats, labels, agreed=None, signature=None):
        self._c.fit(feats, labels, agreed)
        self._sig = signature or getattr(self._c, "taxonomy_signature", None)
        self._n = len(labels)
        return self

    def predict(self, feats) -> list[Belief]:
        return [Belief.point(p) for p in self._c.predict(feats)]

    def predict_agreement(self, feats) -> list[float]:
        return list(self._c.predict_agreement(feats))

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.REFIT_REQUIRED

    def report(self) -> BackendReport:
        return BackendReport(self.name, self.policy(), self._n, self._sig,
                             {"heads": "A+B"})

    def on_taxonomy_change(self, new_signature: str) -> str:
        raise RuntimeError(
            f"logistic calibrator was fitted on {self._sig} and the taxonomy "
            f"is now {new_signature}. Refit on anchors drawn under the new "
            f"taxonomy, or select a backend whose policy is not "
            f"{EvolutionPolicy.REFIT_REQUIRED.value} -- see "
            f"calibration_backends.CALIBRATORS.")


# --------------------------------------------------------------------------- #
# Backend 2: inductive Venn-Abers
# --------------------------------------------------------------------------- #

def _ivap(cal_scores: np.ndarray, cal_labels: np.ndarray,
          s: float) -> tuple[float, float]:
    """One inductive Venn-Abers interval.

    Fit isotonic regression twice on the calibration pairs augmented with the
    test score labelled 0 and then labelled 1, and read both fits at the test
    score. p0 <= p1 by construction; the width is how much the calibration
    data fails to pin the point down.
    """
    from sklearn.isotonic import IsotonicRegression

    out = []
    for hypothetical in (0.0, 1.0):
        x = np.append(cal_scores, s)
        y = np.append(cal_labels, hypothetical)
        iso = IsotonicRegression(y_min=0.0, y_max=1.0, out_of_bounds="clip")
        iso.fit(x, y)
        out.append(float(iso.predict([s])[0]))
    p0, p1 = out
    return (min(p0, p1), max(p0, p1))


class VennAbersBackend:
    """Venn-Abers over a scalar score.

    ``inner`` is the scorer whose output is calibrated. ``None`` uses the raw
    ``p_token``-based estimate; ``"logistic"`` fits Head A first and calibrates
    its output, which is the configuration to prefer -- isotonic regression is
    one-dimensional and monotone, so handing it raw features would discard
    every interaction Head A learns.

    The isotonic refit is per test point, so prediction is O(n_cal log n_cal)
    each. At the sizes here (hundreds of anchors) that is irrelevant; at tens
    of thousands it would need the standard precomputed-envelope trick.
    """

    name = "venn_abers"

    def __init__(self, inner: Optional[str] = "logistic", **kw: Any) -> None:
        self.inner_name = inner
        self._inner = None
        if inner == "logistic":
            from .uncertainty import TwoHeadCalibrator
            self._inner = TwoHeadCalibrator(**kw)
        self._cal_s: np.ndarray = np.array([])
        self._cal_y: np.ndarray = np.array([])
        self._sig: Optional[str] = None
        self._warned: Optional[str] = None

    # -- scoring ---------------------------------------------------------- #
    def _score(self, feats) -> np.ndarray:
        if self._inner is not None:
            return np.asarray(self._inner.predict(feats), float)
        out = []
        for f in feats:
            p = getattr(f, "p_token", None)
            if p is None:
                p = getattr(f, "p_verbal_score", None)
            out.append(0.5 if p is None else float(p))
        return np.asarray(out, float)

    def fit(self, feats, labels, agreed=None, signature=None):
        y = np.asarray(list(labels), int)
        if self._inner is not None:
            # Split so the isotonic calibration is not read off the same rows
            # the discriminative model was fitted on -- that is the same
            # mistake split conformal exists to avoid, one layer up.
            n = len(y)
            cut = max(1, n // 2)
            idx = np.arange(n)
            fit_idx, cal_idx = idx[:cut], idx[cut:]
            self._inner.fit([feats[i] for i in fit_idx], y[fit_idx],
                            None if agreed is None else [agreed[i] for i in fit_idx])
            self._cal_s = self._score([feats[i] for i in cal_idx])
            self._cal_y = y[cal_idx]
        else:
            self._cal_s = self._score(feats)
            self._cal_y = y
        self._sig = signature
        return self

    def predict(self, feats) -> list[Belief]:
        s = self._score(feats)
        if len(self._cal_s) == 0:
            return [Belief(0.0, 1.0) for _ in s]        # no data: say so
        return [Belief(*_ivap(self._cal_s, self._cal_y, float(v))) for v in s]

    def predict_agreement(self, feats) -> list[float]:
        if self._inner is not None:
            try:
                return list(self._inner.predict_agreement(feats))
            except Exception:                            # noqa: BLE001
                pass
        # Width is a usable stand-in: a slot the calibration data pins down is
        # one annotators are more likely to agree on. Reported, not asserted.
        return [1.0 - b.width for b in self.predict(feats)]

    def policy(self) -> EvolutionPolicy:
        return EvolutionPolicy.DEGRADES_VISIBLY

    def report(self) -> BackendReport:
        w = [b.width for b in self.predict_cached()] if False else []
        return BackendReport(self.name, self.policy(), len(self._cal_y),
                             self._sig,
                             {"inner": self.inner_name,
                              "n_calibration": int(len(self._cal_y)),
                              "warning": self._warned})

    def predict_cached(self):                            # pragma: no cover
        return []

    def on_taxonomy_change(self, new_signature: str) -> str:
        self._warned = (
            f"calibration set is from {self._sig}, taxonomy is now "
            f"{new_signature}. Scoring continues. The interval is valid under "
            f"exchangeability and a taxonomy change breaks it, so this is NOT "
            f"a validity claim: it is that slots in regions the old "
            f"calibration set does not cover will come back wide, and width "
            f"is reported per slot. Watch mean width on the new code's slots.")
        return self._warned


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #

def _lascal(**kw: Any):
    from .label_free_calibration import LaSCalBackend
    return LaSCalBackend(**kw)


def _blackbox(cls_name: str):
    def make(**kw: Any):
        from . import blackbox_calibration as bb
        return getattr(bb, cls_name)(**kw)
    return make


CALIBRATORS: dict[str, Any] = {
    "logistic": LogisticBackend,
    "venn_abers": lambda **kw: VennAbersBackend(inner=None, **kw),
    "logistic_va": lambda **kw: VennAbersBackend(inner="logistic", **kw),
    #: label-free on the target, but needs source labels and only models
    #: label shift -- abstains on a newly added code
    "lascal": _lascal,
    #: fully label-free, black-box. These are the only ones that can produce
    #: a confidence for a newly added code rather than abstaining. See
    #: blackbox_calibration for what they measure (self-agreement) and the
    #: §10 measurement of how weakly that tracks correctness here (+0.35).
    "sample_consistency": _blackbox("SampleConsistencyBackend"),
    "daca": _blackbox("DACABackend"),
    "consistency_distill": _blackbox("ConsistencyDistillBackend"),
}


def make_calibrator(name: str, **kw: Any) -> CalibrationBackend:
    if name not in CALIBRATORS:
        raise ValueError(f"unknown calibrator {name!r}; "
                         f"choose from {sorted(CALIBRATORS)}")
    return CALIBRATORS[name](**kw)
