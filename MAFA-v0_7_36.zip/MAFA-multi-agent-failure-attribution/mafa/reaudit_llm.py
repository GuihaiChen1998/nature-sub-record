"""
reaudit_llm.py
==============
The concrete LLM adapters that ``taxonomy_evolution`` takes as callables:
cluster summarisation, unmasked re-audit (the A/B triage), the distinctness
judge, and the two gate functions that need real re-annotation.

    from .reaudit_llm import LLMJudge, make_summarise, make_unmasked_reaudit, \\
                            make_distinctness, make_utility_fn, make_anchor_fn

    judge = LLMJudge(client, model="gpt-5.6-sol")
    clusters = triage_clusters(clusters, tax,
                               make_summarise(judge),
                               make_unmasked_reaudit(judge))

Why the re-audit is per-item and voted, not per-cluster
------------------------------------------------------
Handing the LLM a whole cluster and asking "is this new?" invites it to answer
about the cluster's *label* rather than its members.  Clusters are not pure;
a couple of stragglers are normal.  Asking per item and taking a vote gives a
graded ``absorb_rate``, which is what the 0.5 triage threshold operates on, and
it makes a near-miss visible instead of rounding it to a yes or a no.

Why G3 and G4 cost real API calls
---------------------------------
Support and distinctness (G1, G2) are cheap and both are easy to satisfy by
accident.  Utility (G3) and anti-regression (G4) are the gates that actually
bind, and neither can be evaluated without re-running the annotator with the
extended taxonomy.  Budget for that: roughly ``2 x |held-out| + |anchor|``
reasoner calls per candidate code.  If that is unaffordable, evaluate
candidates in one batch against a shared held-out split rather than weakening
the gate.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, replace
from typing import Any, Callable, Optional, Sequence

from .taxonomy import FailureMode, Taxonomy
from .taxonomy_evolution import (Cluster, ResidualItem, SUMMARISE_PROMPT,
                                TriageConfig, UNMASKED_REAUDIT_PROMPT,
                                normalise_code)
from .trace_adapter import Trace

_FENCE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.S)


# --------------------------------------------------------------------------- #
# A thin JSON-returning judge
# --------------------------------------------------------------------------- #

@dataclass
class AnthropicJudge:
    """Judge backed by the Anthropic Messages API.

    Point Stage 4 at a different model family from Stage 1. The A/B triage
    decides whether a failure is already covered by an existing code; having
    that decided by the same model that produced the annotation makes it a
    self-assessment, and "the annotator agreed with itself" is not evidence.
    Cross-family also costs nothing extra, since the triage needs no logprobs.

    Note the response may contain a ``thinking`` block before the text, so the
    text is selected by type rather than by position.
    """
    client: Any                      # anthropic.Anthropic
    model: str = "claude-fable-5-max"
    max_tokens: int = 2000
    max_retries: int = 3

    def __call__(self, prompt: str, system: str = "") -> dict:
        last: Optional[Exception] = None
        for _ in range(self.max_retries):
            try:
                kw: dict[str, Any] = dict(
                    model=self.model, max_tokens=self.max_tokens,
                    messages=[{"role": "user", "content": prompt}])
                if system:
                    kw["system"] = system
                msg = self.client.messages.create(**kw)
                text = next(b.text for b in msg.content
                            if getattr(b, "type", None) == "text")
                return json.loads(_FENCE.sub("", text).strip())
            except Exception as e:                        # noqa: BLE001
                last = e
        raise RuntimeError(f"anthropic judge failed after retries: {last}")


class AnthropicCompatClient:
    """Stage-1 annotator over the Anthropic Messages API.

    Exists because aiberm serves `messages.create` but returns
    `500 not implemented` for the Responses API, so `OpenAICompatClient` cannot
    reach `claude-opus-5` at all -- and because the whole point of attaching
    images is that the annotator can see them, which needs a model that reads
    them well. On the mdagents corpus claude-opus-5 identifies projection and
    tissue composition; deepseek-flash gets as far as the modality name.

    Two differences from the Responses path, both easy to get wrong:

    * Images are `{"type": "image", "source": {"type": "base64", ...}}`, not
      the `input_image` / `image_url` shapes. Passing an OpenAI-shaped block
      here is accepted by the SDK and then ignored.
    * There is no `json_schema` response format. The schema goes in the prompt
      and the reply is parsed, so `structured` may raise on a malformed reply
      the way the Responses path raises on an empty one. Callers already
      handle that: the failure is recorded with an `error_class`.
    """

    def __init__(self, client: Any) -> None:
        self.c = client

    def structured(self, model: str, system: str, user: str,
                   schema: dict, name: str, effort: str,
                   max_output_tokens: int,
                   image_blocks: Optional[list] = None) -> tuple[dict, dict]:
        content: list[dict[str, Any]] = []
        for b in (image_blocks or []):
            src = b.get("source")
            if src is None:                 # tolerate an OpenAI-shaped block
                url = b.get("image_url", {}).get("url", "")
                if url.startswith("data:") and ";base64," in url:
                    head, data = url.split(";base64,", 1)
                    src = {"type": "base64",
                           "media_type": head[len("data:"):], "data": data}
            if src:
                content.append({"type": "image", "source": src})
        content.append({"type": "text", "text": user})
        instr = (f"{system}\n\nReply with a single JSON object matching this "
                 f"schema exactly. No prose, no code fences.\n"
                 f"{json.dumps(schema)}")
        msg = self.c.messages.create(
            model=model, max_tokens=max_output_tokens,
            system=instr, messages=[{"role": "user", "content": content}])
        text = next(b.text for b in msg.content
                    if getattr(b, "type", None) == "text")
        usage = {"input_tokens": getattr(msg.usage, "input_tokens", 0),
                 "output_tokens": getattr(msg.usage, "output_tokens", 0)}
        return json.loads(_FENCE.sub("", text).strip()), usage


def make_anthropic_judge(api_key: str, base_url: str,
                         model: str = "claude-fable-5-max") -> AnthropicJudge:
    from anthropic import Anthropic
    return AnthropicJudge(
        Anthropic(api_key=api_key,
                  base_url=base_url.rstrip("/").replace("/v1", ""),
                  timeout=180),
        model=model)


@dataclass
class LLMJudge:
    """Returns parsed JSON from a chat/responses call.

    Uses reasoning but NOT Structured Outputs: the schemas here are small and
    the prompts state them explicitly, and staying off ``json_schema`` keeps
    this adapter usable against vLLM-served open models too, where strict mode
    support varies.
    """
    client: Any                      # OpenAICompatClient or raw openai.OpenAI
    model: str = "gpt-5.6-sol"
    effort: str = "medium"
    max_output_tokens: int = 2000
    max_retries: int = 3

    def __call__(self, prompt: str, system: str = "") -> dict:
        last: Optional[Exception] = None
        for _ in range(self.max_retries):
            try:
                text = self._raw(prompt, system)
                return json.loads(_FENCE.sub("", text).strip())
            except Exception as e:                        # noqa: BLE001
                last = e
        raise RuntimeError(f"judge failed after retries: {last}")

    def _raw(self, prompt: str, system: str) -> str:
        c = getattr(self.client, "c", self.client)        # unwrap the shim
        r = c.responses.create(
            model=self.model,
            input=([{"role": "system", "content": system}] if system else [])
                  + [{"role": "user", "content": prompt}],
            reasoning={"effort": self.effort},
            max_output_tokens=self.max_output_tokens,
        )
        return r.output_text or ""


SUMMARISE_SYSTEM = (
    "You are consolidating an open-coding pass in a qualitative study of "
    "failures in medical multi-agent systems. You are conservative: you would "
    "rather declare a group incoherent than invent a category that stitches "
    "unrelated observations together. Reply with JSON only."
)

REAUDIT_SYSTEM = (
    "You are a taxonomy reviewer. Your job is to resist novelty, not to find "
    "it: an existing code covers a failure whenever a domain expert would say "
    "'that is the same failure, occurring in a differently structured system'. "
    "Only say nothing covers it when the failure mechanism itself is new. "
    "Reply with JSON only."
)

DISTINCTNESS_PROMPT = """\
Two failure-mode definitions are below. The first is an existing taxonomy code,
the second is a candidate discovered by clustering unexplained observations.

EXISTING  {code}  {name}
{definition}

CANDIDATE  {cand_name}
{cand_definition}

Representative observations assigned to the candidate:
{examples}

Would adding the candidate to the taxonomy create a genuine distinction, or a
near-duplicate that annotators would confuse? Two codes are distinct only if a
transcript can clearly exhibit one without the other.

Return JSON:
{{
  "distinct": true or false,
  "confusable_because": "if not distinct, what an annotator would confuse",
  "discriminating_test": "if distinct, one observable that separates them"
}}
"""


# --------------------------------------------------------------------------- #
# Adapters for taxonomy_evolution
# --------------------------------------------------------------------------- #

def make_summarise(judge: LLMJudge, max_items: int = 25
                   ) -> Callable[[Cluster], dict[str, Any]]:
    def fn(cluster: Cluster) -> dict[str, Any]:
        items = cluster.items[:max_items]
        listing = "\n\n".join(
            f"[{i}] framework={it.framework} phase={it.phase}\n"
            f"{it.text_for_embedding()}"
            for i, it in enumerate(items))
        try:
            r = judge(SUMMARISE_PROMPT.format(n=len(items), items=listing),
                      SUMMARISE_SYSTEM)
        except Exception as e:                            # noqa: BLE001
            print(f"[summarise] cluster {cluster.cluster_id}: {e}")
            return {"coherent": False}
        r.setdefault("coherent", False)
        r["outliers"] = [i for i in (r.get("outliers") or [])
                         if isinstance(i, int) and 0 <= i < len(items)]
        return r
    return fn


def make_unmasked_reaudit(judge: LLMJudge, cfg: Optional[Any] = None,
                          sample: Optional[int] = None
                          ) -> Callable[[Cluster, Taxonomy], dict[str, Any]]:
    """Per-item vote, all masks removed, all seed codes on the table.

    Pass the same ``TriageConfig`` used by ``triage_clusters`` so the sample
    size and the accepted confidence levels cannot drift apart from the
    threshold that consumes their output.
    """
    from .taxonomy_evolution import TriageConfig
    cfg = cfg or TriageConfig()
    sample = sample if sample is not None else cfg.sample_per_cluster
    accept = set(cfg.accept_confidence)
    taxonomy_modes: list = []

    def _candidates(item) -> list:
        """The codes that could legally apply to this item.

        Mirrors what Stage 1 already does when it builds the slot plan. An item
        whose phase every code forbids has no legal absorber, which is a real
        answer -- not a reason to fall back on the whole taxonomy.
        """
        if not getattr(cfg, "reaudit_respects_structure", True):
            return list(taxonomy_modes)
        out = []
        for m in taxonomy_modes:
            if not m.applies_to(getattr(item, "capabilities", {}) or {}):
                continue
            ph = getattr(item, "phase", "") or ""
            # "unknown" means the residual carries no step, not that every
            # phase is permitted; do not filter on it either way
            if ph and ph != "unknown" and m.allowed_phases \
                    and ph not in m.allowed_phases:
                continue
            out.append(m)
        return out

    def fn(cluster: Cluster, taxonomy: Taxonomy) -> dict[str, Any]:
        nonlocal taxonomy_modes
        taxonomy_modes = list(taxonomy.modes)
        votes: Counter = Counter()
        detail: list[dict[str, Any]] = []
        n = 0
        n_filtered = 0
        for item in cluster.items[:sample]:
            cands = _candidates(item)
            n_filtered += len(taxonomy_modes) - len(cands)
            if not cands:
                # no code can legally apply: a non-absorb vote, and no call
                n += 1
                detail.append({"trace_id": item.trace_id, "absorbed_by": None,
                               "confidence": "", "n_candidates": 0,
                               "reasoning": "no code is legal at phase "
                                            f"{item.phase!r} for this trace",
                               "structural_difference": ""})
                continue
            codes = "\n".join(f"- {m.code} {m.name}: {m.definition}"
                              for m in cands)
            try:
                r = judge(UNMASKED_REAUDIT_PROMPT.format(
                    item=item.text_for_embedding(), codes=codes),
                    REAUDIT_SYSTEM)
            except Exception as e:                        # noqa: BLE001
                print(f"[reaudit] {item.trace_id}: {e}")
                continue
            n += 1
            code = normalise_code(r.get("absorbed_by"), taxonomy)
            conf = str(r.get("confidence", "")).lower()
            # judges legitimately return null for optional fields, so coerce
            # before slicing rather than assuming a string came back
            detail.append({"trace_id": item.trace_id, "absorbed_by": code,
                           "confidence": conf, "n_candidates": len(cands),
                           "reasoning": str(r.get("reasoning") or "")[:300],
                           "structural_difference":
                               str(r.get("structural_difference") or "")[:300]})
            if code and conf in accept:
                votes[code] += 1
        base = {"n_sampled": n, "detail": detail,
                "codes_withheld": n_filtered,
                "respects_structure":
                    bool(getattr(cfg, "reaudit_respects_structure", True))}
        if not n or not votes:
            return {"absorbed_by": None, "absorb_rate": 0.0, **base}
        code, k = votes.most_common(1)[0]
        return {"absorbed_by": code, "absorb_rate": k / n,
                "votes": dict(votes), **base}
    return fn


def make_distinctness(judge: LLMJudge, n_examples: int = 3
                      ) -> Callable[[Cluster, FailureMode], bool]:
    def fn(cluster: Cluster, nearest: FailureMode) -> bool:
        ex = "\n".join(f"- {it.proposed_name}: {(it.evidence or [''])[0][:220]}"
                       for it in cluster.items[:n_examples])
        try:
            r = judge(DISTINCTNESS_PROMPT.format(
                code=nearest.code, name=nearest.name,
                definition=nearest.definition,
                cand_name=cluster.name, cand_definition=cluster.definition,
                examples=ex))
        except Exception as e:                            # noqa: BLE001
            print(f"[distinctness] cluster {cluster.cluster_id}: {e}")
            return False                                  # fail closed
        return bool(r.get("distinct", False))
    return fn


# --------------------------------------------------------------------------- #
# Gates that need real re-annotation
# --------------------------------------------------------------------------- #

def candidate_taxonomy(taxonomy: Taxonomy, cluster: Cluster) -> Taxonomy:
    """T_k + the candidate, without committing it to a version."""
    code = f"CAND.{cluster.cluster_id}"
    mode = FailureMode(
        code=code, name=cluster.name or "candidate",
        definition=cluster.definition or "",
        allowed_phases=cluster.allowed_phases or frozenset({
            "planning", "independent_analysis", "discussion",
            "review", "synthesis", "decision"}),
        requires=frozenset(),
        anchor_question=f"Does this trace exhibit: {cluster.name}?",
        provenance="candidate", version_added=-1,
    )
    return Taxonomy(version=taxonomy.version,
                    modes=taxonomy.modes + [mode],
                    changelog=taxonomy.changelog)


def make_utility_fn(annotate_with, held_out: Sequence[Trace],
                    residual_rate_fn=None):
    """G3: does the candidate actually reduce what the taxonomy cannot place?

    ``annotate_with(traces, taxonomy) -> list[Stage1Annotation]`` is normally
    ``functools.partial`` over the Stage-1 runner. ``residual_rate_fn`` lets
    you swap the metric; the default is the fraction of held-out traces that
    still emit a grounded NOVEL proposal.
    """
    def default_rate(anns) -> float:
        if not anns:
            return 0.0
        hits = sum(1 for a in anns
                   if any(any(e.grounded for e in n.evidence)
                          for n in a.novel_modes))
        return hits / len(anns)

    rate = residual_rate_fn or default_rate

    def fn(cluster: Cluster, taxonomy: Taxonomy) -> dict[str, float]:
        before = rate(annotate_with(held_out, taxonomy))
        after = rate(annotate_with(held_out, candidate_taxonomy(taxonomy, cluster)))
        return {"residual_before": round(before, 4),
                "residual_after": round(after, 4),
                "gain": round(before - after, 4),
                "n_held_out": len(held_out)}
    return fn


def make_anchor_fn(annotate_with, anchor_traces: Sequence[Trace],
                   anchor_pool=None, anchor_labels=None, score_fn=None):
    """G4: the candidate must not degrade agreement on the frozen anchor set.

    Pass ``anchor_pool`` (a ``pipeline.AnchorPool``) rather than a bare label
    dict: the pool verifies its own fingerprint on every call, so a frozen set
    that quietly changed between taxonomy versions raises instead of silently
    producing a G4 number that compares two different rulers. ``anchor_labels``
    remains accepted for callers that manage freezing themselves.
    """
    if anchor_pool is None and anchor_labels is None:
        raise ValueError("give G4 either anchor_pool or anchor_labels")
    def default_score(anns, traces) -> float:
        by_id = {t.trace_id: t for t in traces}
        hit = tot = 0
        for a in anns:
            t = by_id.get(a.trace_id)
            if t is None:
                continue
            for slot, v in zip(a.plan.slots, a.verdicts):
                y = anchor_labels.get((a.trace_id, slot.key))
                if y is None:
                    continue
                tot += 1
                hit += int(v == y)
        return hit / tot if tot else float("nan")

    score = score_fn or default_score

    def fn(cluster: Cluster, taxonomy: Taxonomy) -> dict[str, float]:
        nonlocal anchor_labels
        if anchor_pool is not None:
            anchor_pool.check_frozen()
            anchor_labels = anchor_pool.frozen_labels
        base = score(annotate_with(anchor_traces, taxonomy), anchor_traces)
        cand = score(annotate_with(anchor_traces,
                                   candidate_taxonomy(taxonomy, cluster)),
                     anchor_traces)
        return {"anchor_before": round(base, 4), "anchor_after": round(cand, 4),
                "drop": round(base - cand, 4), "n_anchor": len(anchor_traces),
                "frozen_fingerprint": (anchor_pool.fingerprint()
                                       if anchor_pool is not None else None)}
    return fn


def make_annotate_with(client, rcfg, scfg, logprobs_available: bool = True):
    """Adapter turning the Stage-1 runner into the ``annotate_with`` callable."""
    from .annotator_client import annotate_trace

    def fn(traces: Sequence[Trace], taxonomy: Taxonomy):
        out = []
        for t in traces:
            r = annotate_trace(t, taxonomy, client, rcfg, scfg,
                               logprobs_available)
            if r.annotation is not None:
                out.append(r.annotation)
        return out
    return fn
