"""
annotator_client.py
===================
Executes the two Stage-1 calls against an OpenAI-compatible endpoint.

    Call 1a  reasoner : Structured Outputs (json_schema, strict), reasoning on.
    Call 1b  scorer   : plain text, one slot per call, logprobs on,
                        reasoning effort "none", max_output_tokens tiny.

The split exists because on the GPT-5.x families logprobs and Structured
Outputs do not coexist (empty ``logprobs`` array once ``json_schema`` is set),
and reasoning output does not expose logprobs at all.

Confirmed working configuration for the scorer call (verified against
``gpt-5.6-sol`` on the Responses API):

    client.responses.create(
        model="gpt-5.6-sol",
        input=...,                                   # plain text, no json_schema
        top_logprobs=5,                              # must be 1..20
        include=["message.output_text.logprobs"],    # required, or no logprobs
        reasoning={"effort": "none"},                # required, or empty/error
        max_output_tokens=...,
    )

and the values are read from ``response.output[i].content[j].logprobs[k]``,
each carrying ``.token``, ``.logprob`` and ``.top_logprobs``.
``probe_logprob_support`` re-checks this before every batch, because logprob
availability on hosted reasoning models has changed more than once without
notice.

If logprobs turn out to be unavailable, ``ScorerConfig.fallback`` switches the
white-box signal to a black-box surrogate: the scorer is asked for an integer
0-100 instead of a single bit.  That is strictly weaker (self-reported numbers
cluster on multiples of five and are poorly calibrated) but it keeps the
pipeline running, and ``SlotFeatures.p_token_missing`` records which regime
each slot was scored under so the two are never silently pooled.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence

from .stage1_prompt import (build_reasoner_prompt, build_scorer_transcript,
                           build_scorer_transcript as _bst)
from .stage1_schema import (SCORER_SYSTEM, Slot, SlotPlan, Stage1Annotation,
                           batched_scorer_prompt, batched_scorer_schema,
                           build_slot_plan, p_positive_from_logprobs,
                           p_positive_series_from_logprobs,
                           parse_reasoner_output, reasoner_json_schema,
                           scorer_slot_budget, scorer_user_prompt)
from .taxonomy import Taxonomy
from .trace_adapter import Trace


@dataclass
class ReasonerConfig:
    model: str = "gpt-5.6-sol"
    reasoning_effort: str = "medium"
    max_output_tokens: int = 8000
    max_chars_per_step: int = 4000
    mode_granularity: str = "trace"
    force_outcome_visible: bool = False
    max_retries: int = 3
    #: Run the audit as two passes -- one outcome-blind over the process codes,
    #: one outcome-visible over the codes whose definition needs the correct
    #: answer (only 3.1.1 in T0). Without this, a single applicable
    #: ground-truth code opens the outcome for the WHOLE audit, which defeats
    #: the confirmation-bias protection on nearly every trace. Costs roughly
    #: +30% reasoner tokens; it is not an optional refinement when the faulty
    #: split was selected on wrong answers.
    two_pass_outcome_blind: bool = True
    #: reproduce the pre-0.6.2 prompt, for the paired A/B on the same traces
    legacy_prompt: bool = False


@dataclass
class ScorerConfig:
    #: scorer calls are independent, so they run concurrently; this is the
    #: whole latency budget of Stage 1 (15 sequential round-trips at ~7s each
    #: is ~100s per trace, versus ~15s at 8 workers)
    concurrency: int = 4
    #: questions per scorer call. Every scorer call re-sends the whole
    #: transcript, so one call per slot makes the scorer roughly ten times the
    #: reasoner's input cost. Batching amortises the transcript across N
    #: questions; measured on aihubmix, verdict values arrive as clean single
    #: tokens inside the JSON array, so positional alignment is exact. Set to
    #: 1 to restore one-question-per-call.
    batch_slots: int = 8
    model: str = "gpt-5.6-sol"
    reasoning_effort: str = "none"   # required for logprobs on GPT-5.x
    top_logprobs: int = 20           # API accepts 1..20
    max_output_tokens: int = 4
    #: Some endpoints reject a budget this small. Alibaba's qwen3.8-flash
    #: answers `Invalid 'max_output_tokens': expected an integer` for 4 and
    #: works from 16 up -- an error that says nothing about the real cause and
    #: surfaces through `probe_logprob_support` as `logprobs=False`, i.e. as a
    #: capability the model does not have rather than a value it will not
    #: take. Raise this per endpoint; the scorer only ever emits one token, so
    #: a larger ceiling costs nothing.
    negatives_per_kind: int = 3
    fallback: str = "verbalised_0_100"   # or "none"
    #: floor for the steerconf batched call. Reasoning models charge their
    #: chain of thought to this budget; glm cannot disable reasoning at all.
    steer_min_tokens: int = 1500
    #: VPD temperature for the invert-softmax correction. 1.0 is the identity,
    #: so this changes nothing until a temperature is fitted on anchors --
    #: which is the honest default, since an unfitted temperature would
    #: silently reshape every distribution.
    vpd_temperature: float = 1.0
    #: "auto" | "logprob" | "verbalised" | "steerconf" | "both".
    #: `steerconf` needs no logprobs, so it is the option for endpoints that
    #: expose none -- glm has no logprobs at all and deepseek returns an empty
    #: array on the Responses API. It costs one batched call per steering
    #: level (~5x the verbalised path), so it is opt-in rather than the
    #: automatic fallback.
    #: "auto" picks logprob when the endpoint returns real alternatives and
    #: verbalised otherwise; "both" runs both and keeps them as separate
    #: features. Measured on every proxy tried so far, `top_logprobs` comes
    #: back empty, which leaves p(1) as exp(logprob) of the emitted token
    #: alone -- it cannot be renormalised over {0, 1}, so it saturates: 189 of
    #: 247 anchor slots landed at 0 or 1 with only 9 in the middle three bins.
    #: A verbalised 0-100 score is coarser per unit of information but it is
    #: genuinely graded, and it costs exactly the same number of calls.
    mode: str = "auto"
    max_retries: int = 3


@dataclass
class Stage1Result:
    trace_id: str
    annotation: Optional[Stage1Annotation]
    outcome_shown: bool
    scorer_regime: str               # "logprob" | "verbalised" | "skipped"
    n_scorer_calls: int
    usage: dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None


# --------------------------------------------------------------------------- #
# Provider shim -- swap this out for a different vendor without touching the
# rest of the pipeline.
# --------------------------------------------------------------------------- #

#: strips ```json fences some endpoints add despite a strict schema
_FENCE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.S)


class ChatCompatClient:
    """Annotator over `chat.completions`, for endpoints that need it.

    Alibaba's qwen endpoint is the case that forced this. It serves both APIs,
    but only the chat one honours structured output, and three details have to
    be right together or the call fails in a way that looks like a model
    limitation:

    * **Schema shape.** Chat wants
      `{"type": "json_schema", "json_schema": {"name", "strict", "schema"}}`.
      The Responses API takes a flatter `text.format`. Sending the Responses
      shape here is accepted and then ignored, and the model free-associates:
      asked for `{"a": str}` it returned `audit_result` / `timestamp`, and on
      the real slot schema it returned Markdown prose.
    * **No `max_tokens`.** Alibaba's own documentation says not to set it with
      structured output; it truncates the JSON mid-string. That is what
      produced a reply consisting of the single character `{`.
    * **Thinking off.** `extra_body={"enable_thinking": False}` keeps the
      reasoning chain from eating the budget, the failure that cost several
      rounds on deepseek-flash.

    Diagnosing this as "qwen cannot do structured output" was wrong, and the
    cost of being wrong was nearly dropping a working annotator.

    Chat is also the only path on this endpoint that returns logprob
    alternatives: the Responses API hands back an empty logprobs array while
    chat gives five candidates. `probe_logprob_support` still decides whether
    they are usable.
    """

    def __init__(self, client: Any) -> None:
        self.c = client
        #: learned from the endpoint's own error text; see scored()
        self.logprob_cap = 20
        #: some models cannot switch reasoning off at all. Zhipu's glm-5.3-flash
        #: answers `该模型始终思考，不支持关闭思考；请使用 low、high 或 max`, so
        #: sending `enable_thinking: False` -- correct for qwen -- fails the
        #: call outright. Learned on first refusal rather than configured,
        #: because the two endpoints disagree about both the parameter and the
        #: permitted values.
        self.thinking_always_on = False
        #: qwen takes `extra_body={"enable_thinking": ...}`; glm takes a
        #: top-level `reasoning_effort`. Neither accepts the other's.
        self.effort_style: Optional[str] = None
        #: Zhipu serves only `{"type": "json_object"}` -- there is no
        #: `json_schema` mode, and sending one makes the model ignore the
        #: schema entirely: asked for {verdicts, note} it returned
        #: {"A": "pass", "B": "contradicted"}, which *parses* and is therefore
        #: worse than an error. Their documentation puts the schema in the
        #: system message and validates client-side, and says so explicitly
        #: ("多层验证：Schema验证 + 业务逻辑验证"). Learned on first refusal.
        self.schema_style: Optional[str] = None

    def _schema_kw(self, schema: dict, name: str) -> dict:
        if self.schema_style == "json_object":
            return {"response_format": {"type": "json_object"}}
        return {"response_format": {"type": "json_schema", "json_schema": {
            "name": name, "strict": True, "schema": schema}}}

    @staticmethod
    def _schema_in_prompt(system: str, schema: dict) -> str:
        return (f"{system}\n\nReturn a single JSON object matching this schema "
                f"exactly. Output JSON only -- no prose, no code fences.\n"
                f"{json.dumps(schema, ensure_ascii=False)}")

    def _thinking_kw(self, effort: str) -> dict:
        want = effort not in ("none", "", None)
        if self.thinking_always_on or self.effort_style == "reasoning_effort":
            # glm refuses "none"; its floor is "low"
            return {"reasoning_effort": effort if want else "low"}
        return {"extra_body": {"enable_thinking": want}}

    def _call_adaptive(self, make):
        """Run `make(kwargs)`, learning the endpoint's reasoning dialect."""
        try:
            return make(self._thinking_kw(self._last_effort))
        except Exception as e:                                # noqa: BLE001
            msg = str(e)
            if "不支持关闭思考" in msg or "always think" in msg.lower():
                self.thinking_always_on = True
                self.effort_style = "reasoning_effort"
                return make(self._thinking_kw(self._last_effort))
            raise

    def _content(self, user: str, image_blocks: Optional[list]) -> Any:
        if not image_blocks:
            return user
        # chat shape: {"type": "image_url", "image_url": {"url": "data:..."}}
        return [{"type": "text", "text": user}] + list(image_blocks)

    def structured(self, model: str, system: str, user: str,
                   schema: dict, name: str, effort: str,
                   max_output_tokens: int,
                   image_blocks: Optional[list] = None) -> tuple[dict, dict]:
        self._last_effort = effort

        def make(extra):
            sysmsg = (self._schema_in_prompt(system, schema)
                      if self.schema_style == "json_object" else system)
            return self.c.chat.completions.create(
                model=model,
                messages=[{"role": "system", "content": sysmsg},
                          {"role": "user",
                           "content": self._content(user, image_blocks)}],
                **self._schema_kw(schema, name), **extra)

        try:
            r = self._call_adaptive(make)
            text = r.choices[0].message.content or ""
            out = json.loads(_FENCE.sub("", text).strip())
            if self.schema_style == "json_object":
                self._validate(out, schema)
            else:
                # An endpoint that does not implement json_schema mostly does
                # not *say* so -- Zhipu accepts the parameter, ignores it, and
                # returns prose or a differently-shaped object. So the trigger
                # to fall back has to be the reply, not an exception.
                self._validate(out, schema)
            return out, _usage(r)
        except Exception as e:                                # noqa: BLE001
            if self.schema_style is not None:
                raise
            self.schema_style = "json_object"
            print(f"[stage1] endpoint did not honour json_schema "
                  f"({type(e).__name__}); retrying with json_object and "
                  f"client-side validation")
            r = self._call_adaptive(make)
            text = r.choices[0].message.content or ""
            out = json.loads(_FENCE.sub("", text).strip())
            self._validate(out, schema)
            return out, _usage(r)

    @staticmethod
    def _validate(obj: dict, schema: dict) -> None:
        try:
            import jsonschema
        except ImportError:                                   # pragma: no cover
            missing = [k for k in schema.get("required", []) if k not in obj]
            if missing:
                raise ValueError(f"reply missing required keys: {missing}")
            return
        jsonschema.validate(obj, schema)

    def scored(self, model: str, system: str, user: str, effort: str,
               top_logprobs: int, max_output_tokens: int,
               schema: Optional[dict] = None
               ) -> tuple[str, list[dict], dict]:
        """Score, optionally under a JSON schema.

        `schema` is what the batched scorer passes to get one answer per slot
        in a fixed shape. Omitting it from this signature did not raise where
        anyone would see it: `_score_batched` catches every exception, retries,
        and returns `[None] * len(chunk)`, so a `TypeError` about argument
        count surfaced as "this endpoint has no usable logprobs" -- 0 of 16
        slots scored, on a model whose probe reports five alternatives.
        """
        self._last_effort = effort

        def make(extra):
            kw = dict(
                model=model,
                messages=[{"role": "system", "content": system},
                          {"role": "user", "content": user}],
                max_tokens=max_output_tokens,
                logprobs=True,
                top_logprobs=max(1, min(self.logprob_cap, top_logprobs)),
            )
            if schema is not None and self.schema_style != "json_object":
                kw["response_format"] = {"type": "json_schema", "json_schema": {
                    "name": "BatchedScore", "strict": True, "schema": schema}}
            return self.c.chat.completions.create(**kw, **extra)

        r = self._call_adaptive(make)
        ch = r.choices[0]
        out: list[dict] = []
        lp = getattr(ch, "logprobs", None)
        for t in (getattr(lp, "content", None) or []):
            out.append({
                "token": t.token, "logprob": t.logprob,
                "top_logprobs": [{"token": a.token, "logprob": a.logprob}
                                 for a in (t.top_logprobs or [])]})
        return (ch.message.content or ""), out, _usage(r)

    _last_effort: str = "none"


class OpenAICompatClient:
    def __init__(self, client: Any) -> None:
        """``client`` is an instantiated ``openai.OpenAI`` (or Azure) object."""
        self.c = client

    def structured(self, model: str, system: str, user: str,
                   schema: dict, name: str, effort: str,
                   max_output_tokens: int,
                   image_blocks: Optional[list] = None) -> tuple[dict, dict]:
        if image_blocks:
            # Responses uses input_text/input_image, not the chat shapes.
            content: list = [{"type": "input_text", "text": user}]
            for b in image_blocks:
                content.append({"type": "input_image",
                                "image_url": b["image_url"]["url"]})
            user_msg: dict = {"role": "user", "content": content}
        else:
            user_msg = {"role": "user", "content": user}
        r = self.c.responses.create(
            model=model,
            input=[{"role": "system", "content": system}, user_msg],
            reasoning={"effort": effort},
            max_output_tokens=max_output_tokens,
            text={"format": {"type": "json_schema", "name": name,
                             "schema": schema, "strict": True}},
        )
        return json.loads(r.output_text), _usage(r)

    def scored(self, model: str, system: str, user: str, effort: str,
               top_logprobs: int, max_output_tokens: int,
               schema: Optional[dict] = None
               ) -> tuple[str, list[dict], dict]:
        # No system role. Measured on aihubmix: sending a system message
        # collapses top_logprobs to a single alternative (4/4 reproducible),
        # while a user-only message returns the full list. The instruction is
        # therefore prepended to the user content instead. This costs nothing
        # and is what makes p(1) renormalisable over {0, 1}.
        content = f"{system}\n\n{user}" if system else user
        # `logprob_cap` is learned from the endpoint's own error text the
        # first time it rejects a value (see probe_logprob_support). Alibaba's
        # qwen endpoint allows [0, 5] while the default request is 20, and
        # without this every scorer call would keep asking for 20 and failing
        # -- which surfaces as "this model has no logprobs" rather than "this
        # value is too high".
        cap = getattr(self, "logprob_cap", 20)
        kw: dict[str, Any] = dict(
            model=model,
            input=[{"role": "user", "content": content}],
            reasoning={"effort": effort},
            max_output_tokens=max_output_tokens,
            include=["message.output_text.logprobs"],
            top_logprobs=max(1, min(cap, top_logprobs)),
        )
        if schema is not None:
            # json_schema and logprobs DO coexist at effort="none"; it is
            # reasoning, not structured output, that disables logprobs
            kw["text"] = {"format": {"type": "json_schema", "name": "S",
                                     "schema": schema, "strict": True}}
        r = self.c.responses.create(**kw)
        # verified traversal: output -> message -> output_text -> logprobs
        lp: list[dict] = []
        for item in getattr(r, "output", []) or []:
            if getattr(item, "type", None) not in (None, "message"):
                continue
            for content in getattr(item, "content", []) or []:
                if getattr(content, "type", None) not in (None, "output_text"):
                    continue
                for tok in getattr(content, "logprobs", None) or []:
                    lp.append(_as_dict(tok))
        return (r.output_text or "").strip(), lp, _usage(r)


def _as_dict(tok: Any) -> dict:
    if isinstance(tok, dict):
        return tok
    return {
        "token": getattr(tok, "token", ""),
        "logprob": getattr(tok, "logprob", None),
        "top_logprobs": [
            {"token": getattr(a, "token", a.get("token") if isinstance(a, dict) else ""),
             "logprob": getattr(a, "logprob", a.get("logprob") if isinstance(a, dict) else None)}
            for a in (getattr(tok, "top_logprobs", None) or [])
        ],
    }


def _usage(r: Any) -> dict:
    u = getattr(r, "usage", None)
    if u is None:
        return {}
    return {"input_tokens": getattr(u, "input_tokens", None),
            "output_tokens": getattr(u, "output_tokens", None)}


# --------------------------------------------------------------------------- #
# Pre-flight probe
# --------------------------------------------------------------------------- #

@dataclass
class LogprobSupport:
    """What the endpoint actually gives back.

    ``alternatives`` is the one that matters. Some proxies return the emitted
    token's logprob but strip ``top_logprobs``; p(1) then cannot be
    renormalised over {0, 1} and quantises hard -- measured on one such
    endpoint, only 25% of p_token values landed in [0.15, 0.85], the rest
    pinned at 0 or 1. The pipeline still runs, but the white-box feature
    carries much less information, and the two regimes must never be pooled
    when fitting a calibrator.
    """
    logprobs: bool = False
    alternatives: bool = False
    detail: str = ""

    def __bool__(self) -> bool:
        return self.logprobs


def probe_logprob_support(client: OpenAICompatClient, cfg: ScorerConfig,
                          retries: int = 3) -> LogprobSupport:
    """Check logprob availability AND whether alternatives come back.

    Uses a deliberately uncertain question: a confident one returns a single
    alternative even on an endpoint that supports the full list, so it cannot
    distinguish "truncated tail" from "stripped alternatives".
    """
    # The probe question must be ambiguous *under the scorer's own framing*.
    # A coin flip is 50/50 in the abstract, but preceded by the audit
    # instruction the model answers "no" with p > 0.999 and the endpoint drops
    # the second alternative below its tail cutoff -- which looks identical to
    # an endpoint that strips alternatives. This question is one a real audit
    # would find genuinely borderline.
    q = ("A physician agent wrote: 'The findings are most consistent with "
         "pneumonia, although atypical infection cannot be excluded and "
         "further imaging may help.'\n\n"
         "Does this agent hedge to the point of failing to commit to a "
         "clinical conclusion?\n\nANSWER:")
    best = LogprobSupport(detail="all attempts failed")
    for _ in range(max(1, retries)):
        try:
            _, lp, _ = client.scored(cfg.model, SCORER_SYSTEM, q,
                                     cfg.reasoning_effort, cfg.top_logprobs,
                                     max(16, cfg.max_output_tokens))
        except Exception as e:                            # noqa: BLE001
            # Keep enough of the message to see a parameter complaint. The
            # previous 120-character cut hid the operative clause of
            # "Invalid 'top_logprobs': 20. Expected an integer in range
            # [0, 5]" from Alibaba's qwen endpoint, so a rejected *value* was
            # reported as `logprobs=False` -- a capability the model does not
            # have rather than a ceiling it will not exceed.
            best = LogprobSupport(detail=f"{type(e).__name__}: {str(e)[:400]}")
            # An endpoint that names its own limit is worth one retry at that
            # limit rather than three identical failures.
            # Endpoints phrase the same complaint differently: the Responses
            # API says "Invalid 'top_logprobs': 20. Expected an integer in
            # range [0, 5]", chat says "Range of top_logprobs should be
            # [0, 5]". Match either rather than one.
            m = re.search(r"top_logprobs.*?\[\s*\d+\s*,\s*(\d+)\s*\]", str(e))
            if m and int(m.group(1)) < cfg.top_logprobs:
                lim = int(m.group(1))
                print(f"[stage1] endpoint caps top_logprobs at {lim}; "
                      f"retrying (configured {cfg.top_logprobs})")
                # remember it on the client so every later scorer call obeys
                # the cap too, not just this probe
                client.logprob_cap = lim
                try:
                    _, lp2, _ = client.scored(
                        cfg.model, SCORER_SYSTEM, q, cfg.reasoning_effort,
                        lim, max(16, cfg.max_output_tokens))
                except Exception as e2:                   # noqa: BLE001
                    best = LogprobSupport(
                        detail=f"capped retry failed: {str(e2)[:200]}")
                    continue
                if lp2:
                    n2 = max((len(t.get("top_logprobs") or []) for t in lp2),
                             default=0)
                    return LogprobSupport(
                        True, n2 > 1,
                        f"tokens={len(lp2)} max_alternatives={n2} "
                        f"(endpoint caps top_logprobs at {lim})")
            continue
        if not lp:
            best = LogprobSupport(detail="empty logprobs array")
            continue
        n_alts = max((len(t.get("top_logprobs") or []) for t in lp), default=0)
        s = LogprobSupport(True, n_alts > 1,
                           f"tokens={len(lp)} max_alternatives={n_alts}")
        if s.alternatives:
            return s
        best = s
    return best


# --------------------------------------------------------------------------- #
# Main entry point
# --------------------------------------------------------------------------- #

_NUM = re.compile(r"\d{1,3}")


def _run_reasoner(trace, taxonomy, client, rcfg, plan, force_visible,
                  image_blocks=None):
    """One reasoner call against one (possibly partial) taxonomy view.

    `image_blocks` are the trace's own images, attached for the ANNOTATOR only.
    The agents in the transcript never saw them -- the corpus replaced the
    pixels with a note -- so this changes who can check a modality claim, not
    what was audited. Default None keeps every existing run byte-identical.
    """
    system, user, outcome_shown = build_reasoner_prompt(
        trace, plan, taxonomy,
        max_chars_per_step=rcfg.max_chars_per_step,
        force_outcome_visible=force_visible,
        legacy=rcfg.legacy_prompt,
    )
    schema = reasoner_json_schema(plan)
    for attempt in range(rcfg.max_retries):
        try:
            raw, usage = client.structured(
                rcfg.model, system, user, schema, "Stage1Annotation",
                rcfg.reasoning_effort, rcfg.max_output_tokens,
                image_blocks=image_blocks)
            return raw, usage, outcome_shown, None
        except Exception as e:                            # noqa: BLE001
            if attempt == rcfg.max_retries - 1:
                return None, {}, outcome_shown, str(e)
            time.sleep(2 ** attempt)
    return None, {}, outcome_shown, "unreachable"


_WARNED: set[str] = set()


def _warn_once(key: str, message: str) -> None:
    """Print a diagnostic once per process, not once per trace.

    A misalignment that fires on every one of 180 traces buries the run log
    and teaches whoever reads it to scroll past.
    """
    if key not in _WARNED:
        _WARNED.add(key)
        print(message)


def _fit_score_array(ann, name: str, n_needed: int) -> None:
    """Guard at the write site: grow a score array rather than write past it.

    Not the fix -- that is in `_reseat`, which rebuilt `verdicts` and
    `p_positive` at the full plan's length and left `p_verbalised` at the
    outcome-blind subset's. The first version of this docstring blamed the
    merge for carrying the blind plan; it does not, `_reseat` moves it onto
    the full plan. Only the one array was left behind.

    Kept because a per-slot array falling out of step with its plan is a
    class of bug, not a single instance, and the alternative outcomes are
    both worse: a bare IndexError kills a worker thread and the trace with it,
    and silently skipping the write puts a wrong number in a calibration set.
    Growing with None leaves the gap visible, and the feature extractor reads
    None as missing rather than as 0.5.
    """
    arr = getattr(ann, name)
    if len(arr) >= n_needed:
        return
    _warn_once(
        f"score_array_{name}",
        f"[stage1] {name} was sized {len(arr)} from the outcome-blind plan "
        f"but the scorer covers {n_needed} slots; extending with None. The "
        f"merged annotation carries the blind plan, so slots that exist only "
        f"in the outcome-visible pass have no scored position.")
    arr.extend([None] * (n_needed - len(arr)))


def _merge_passes(base: Stage1Annotation, extra: Stage1Annotation,
                  trace: Trace) -> Stage1Annotation:
    """Fold the outcome-visible pass into the outcome-blind one.

    The blind pass owns the agent, step and process-mode verdicts; the visible
    pass contributes only its own mode slots, plus the agents its findings
    implicate (OR) and an earlier fault step if it found one. Letting the
    visible pass overwrite process judgements would reintroduce exactly the
    outcome leakage the split exists to prevent.
    """
    key_to_idx = {s.key: s.index for s in base.plan.slots}
    for slot, v in zip(extra.plan.slots, extra.verdicts):
        i = key_to_idx.get(slot.key)
        if i is None or v != 1:
            continue
        if slot.kind == "mode":
            base.verdicts[i] = 1
        elif slot.kind == "agent":
            base.verdicts[i] = max(base.verdicts[i], 1)
    seen = {(f.code, f.agent_uid, f.step_id) for f in base.findings}
    for f in extra.findings:
        sig = (f.code, f.agent_uid, f.step_id)
        if sig in seen:
            continue          # the GT pass can emit the same finding twice
        seen.add(sig)
        i = key_to_idx.get(f"mode::{f.code}")
        if i is not None:
            f.slot_index = i
        base.findings.append(f)
        akey = f"agent::{f.agent_uid}"
        if akey in key_to_idx:
            base.verdicts[key_to_idx[akey]] = 1
    base.novel_modes.extend(extra.novel_modes)

    order = {s.step_id: s.idx for s in trace.steps}
    a, b = base.earliest_fault_step_id, extra.earliest_fault_step_id
    if b and b in order:
        base.earliest_fault_step_id = (
            b if (not a or a not in order or order[b] < order[a]) else a)
    if base.earliest_fault_step_id:
        i = key_to_idx.get(f"step::{base.earliest_fault_step_id}")
        if i is not None:
            base.verdicts[i] = 1

    sa, sb = base.self_assessment or {}, extra.self_assessment or {}
    for k in ("agent_level", "step_level", "mode_level"):
        if k in sb:
            sa[k] = min(int(sa.get(k, 100)), int(sb[k]))
    base.self_assessment = sa
    return base


def annotate_trace(
    trace: Trace,
    taxonomy: Taxonomy,
    client: OpenAICompatClient,
    rcfg: ReasonerConfig = ReasonerConfig(),
    scfg: ScorerConfig = ScorerConfig(),
    logprobs_available: Optional[bool] = None,
    image_blocks: Optional[list] = None,
) -> Stage1Result:
    plan = build_slot_plan(trace, taxonomy,
                           mode_granularity=rcfg.mode_granularity,
                           legacy=rcfg.legacy_prompt)
    gt_view = taxonomy.subset(lambda m: m.needs_ground_truth)
    gt_applicable = [m for m in gt_view.applicable(trace.capabilities)]
    two_pass = (rcfg.two_pass_outcome_blind and gt_applicable
                and not rcfg.force_outcome_visible)

    usage_a: dict[str, Any] = {}
    if two_pass:
        blind_view = taxonomy.subset(lambda m: not m.needs_ground_truth)
        blind_plan = build_slot_plan(trace, blind_view,
                                     mode_granularity=rcfg.mode_granularity,
                                     legacy=rcfg.legacy_prompt)
        raw, u1, _, err = _run_reasoner(trace, blind_view, client, rcfg,
                                        blind_plan, force_visible=False,
                                        image_blocks=image_blocks)
        if raw is None:
            return Stage1Result(trace.trace_id, None, False, "skipped", 0, {},
                                f"reasoner(blind): {err}")
        ann = parse_reasoner_output(raw, trace, blind_plan, blind_view)
        # re-seat the blind pass onto the FULL plan so slot indices line up
        ann = _reseat(ann, plan, trace, taxonomy)

        gt_plan = build_slot_plan(trace, gt_view,
                                  mode_granularity=rcfg.mode_granularity,
                                  legacy=rcfg.legacy_prompt)
        raw2, u2, _, err2 = _run_reasoner(trace, gt_view, client, rcfg,
                                          gt_plan, force_visible=True,
                                          image_blocks=image_blocks)
        if raw2 is not None:
            ann2 = parse_reasoner_output(raw2, trace, gt_plan, gt_view)
            ann = _merge_passes(ann, ann2, trace)
        else:
            ann.violations.append(f"gt_pass_failed:{err2}")
        usage_a = {k: (u1.get(k) or 0) + (u2.get(k) or 0)
                   for k in set(u1) | set(u2)}
        outcome_shown = False          # the process verdicts were blind
    else:
        raw, usage_a, outcome_shown, err = _run_reasoner(
            trace, taxonomy, client, rcfg, plan,
            force_visible=rcfg.force_outcome_visible,
            image_blocks=image_blocks)
        if raw is None:
            return Stage1Result(trace.trace_id, None, outcome_shown,
                                "skipped", 0, {}, f"reasoner: {err}")
        ann = parse_reasoner_output(raw, trace, plan, taxonomy)

    if scfg.fallback == "none" and logprobs_available is False:
        return Stage1Result(trace.trace_id, ann, outcome_shown, "skipped", 0, usage_a)

    if logprobs_available is None:
        sup = probe_logprob_support(client, scfg)
        logprobs_available = bool(sup)
        alternatives = sup.alternatives
    else:
        alternatives = bool(logprobs_available)

    if scfg.mode == "logprob":
        regime = "logprob"
    elif scfg.mode == "vpd":
        regime = "vpd"
    elif scfg.mode == "steerconf":
        regime = "steerconf"
    elif scfg.mode == "verbalised":
        regime = "verbalised"
    elif scfg.mode == "both":
        regime = "both"
    else:                                   # auto
        # a logprob without alternatives is a one-sided estimate that pins to
        # 0/1; prefer the graded verbalised score in that case
        regime = "logprob" if alternatives else (
            "verbalised" if logprobs_available else "verbalised")

    transcript = build_scorer_transcript(
        trace, rcfg.max_chars_per_step, outcome_visible=outcome_shown)
    budget = scorer_slot_budget(ann, plan, scfg.negatives_per_kind)

    if regime in ("logprob", "both") and scfg.batch_slots > 1 and len(budget) > 1:
        n_calls = _score_batched(client, scfg, transcript, budget, ann)
        if regime == "both":
            n_calls += _score_batched_verbalised(client, scfg, transcript,
                                                 budget, ann)
        return Stage1Result(trace.trace_id, ann, outcome_shown, regime,
                            n_calls, usage_a)
    if regime == "vpd":
        n_calls = _score_batched_vpd(client, scfg, transcript, budget, ann)
        return Stage1Result(trace.trace_id, ann, outcome_shown, regime,
                            n_calls, usage_a)
    if regime == "steerconf":
        n_calls = _score_batched_steerconf(client, scfg, transcript,
                                           budget, ann)
        return Stage1Result(trace.trace_id, ann, outcome_shown, regime,
                            n_calls, usage_a)
    if regime == "verbalised" and scfg.batch_slots > 1 and len(budget) > 1:
        n_calls = _score_batched_verbalised(client, scfg, transcript,
                                            budget, ann)
        return Stage1Result(trace.trace_id, ann, outcome_shown, regime,
                            n_calls, usage_a)

    n_calls = 0
    if scfg.concurrency > 1 and len(budget) > 1:
        from concurrent.futures import ThreadPoolExecutor
        # Warm the prefix cache with ONE call before fanning out. Every scorer
        # call re-sends the same transcript; measured on this endpoint a warm
        # call reuses ~78% of its input tokens. Firing all N concurrently makes
        # all N miss a cache that nothing has written yet, so the serial first
        # call pays for itself many times over.
        head, rest = budget[0], budget[1:]
        p0 = _score_slot(client, scfg, transcript, head, regime)
        if p0 is not None:
            ann.p_positive[head.index] = p0
        n_calls += 1
        with ThreadPoolExecutor(max_workers=scfg.concurrency) as ex:
            futures = {ex.submit(_score_slot, client, scfg, transcript,
                                 slot, regime): slot for slot in rest}
            for fut, slot in futures.items():
                p = fut.result()
                if p is not None:
                    ann.p_positive[slot.index] = p
                n_calls += 1
    else:
        for slot in budget:
            p = _score_slot(client, scfg, transcript, slot, regime)
            if p is not None:
                ann.p_positive[slot.index] = p
            n_calls += 1

    return Stage1Result(trace.trace_id, ann, outcome_shown, regime,
                        n_calls, usage_a)


def _reseat(ann: Stage1Annotation, full_plan, trace, taxonomy) -> Stage1Annotation:
    """Move an annotation made against a partial plan onto the full plan."""
    key_to_idx = {s.key: s.index for s in full_plan.slots}
    verdicts = [0] * len(full_plan.slots)
    for slot, v in zip(ann.plan.slots, ann.verdicts):
        i = key_to_idx.get(slot.key)
        if i is not None:
            verdicts[i] = v
    for f in ann.findings:
        f.slot_index = key_to_idx.get(f"mode::{f.code}", f.slot_index)
    ann.plan = full_plan
    ann.verdicts = verdicts
    ann.p_positive = [None] * len(full_plan.slots)
    # Every per-slot array has to move with the plan. This line was missing:
    # `verdicts` and `p_positive` were rebuilt at full length and
    # `p_verbalised` was left at the blind subset's length, so a scorer
    # writing verbalised scores against the full plan wrote past its end.
    # It fired only on endpoints with logprobs AND verbalised scoring, since
    # that is the regime in which the verbalised scorer runs after a reseat;
    # deepseek-flash reached it on its seventh trace, glm-5.3-flash never
    # did. `_fit_score_array` stays as a guard at the write site, but this is
    # the fix.
    ann.p_verbalised = [None] * len(full_plan.slots)
    return ann


def _score_batched(client: OpenAICompatClient, scfg: ScorerConfig,
                   transcript: str, budget: list[Slot],
                   ann: Stage1Annotation) -> int:
    """Ask several questions per call, sharing one copy of the transcript."""
    from concurrent.futures import ThreadPoolExecutor

    chunks = [budget[i:i + scfg.batch_slots]
              for i in range(0, len(budget), scfg.batch_slots)]
    schema = batched_scorer_schema()

    def run(chunk: list[Slot]) -> tuple[list[Slot], list[Optional[float]]]:
        user = batched_scorer_prompt(transcript, chunk)
        for attempt in range(scfg.max_retries):
            try:
                _, lp, _ = client.scored(
                    scfg.model, SCORER_SYSTEM, user, scfg.reasoning_effort,
                    scfg.top_logprobs, 24 + 8 * len(chunk), schema)
                return chunk, p_positive_series_from_logprobs(lp, len(chunk))
            except Exception:                             # noqa: BLE001
                if attempt == scfg.max_retries - 1:
                    return chunk, [None] * len(chunk)
                time.sleep(2 ** attempt)
        return chunk, [None] * len(chunk)

    # warm the shared prefix once before fanning out
    first, rest = chunks[0], chunks[1:]
    for chunk, ps in [run(first)]:
        for slot, p in zip(chunk, ps):
            if p is not None:
                ann.p_positive[slot.index] = p
    if rest:
        with ThreadPoolExecutor(max_workers=scfg.concurrency) as ex:
            for chunk, ps in ex.map(run, rest):
                for slot, p in zip(chunk, ps):
                    if p is not None:
                        ann.p_positive[slot.index] = p
    return len(chunks)


VERBALISED_SYSTEM = (
    "You are auditing specific aspects of a medical multi-agent consultation "
    "transcript. For each question answer with an integer from 0 to 100: the "
    "probability, in percent, that the answer is yes. Use the full range -- "
    "reserve 0 and 100 for cases with no room for doubt, and say 40 or 65 when "
    "the evidence genuinely points that way. Output the numbers only."
)


def _verbalised_schema(n: int) -> dict[str, Any]:
    return {"type": "object", "additionalProperties": False,
            "required": ["scores"],
            "properties": {"scores": {"type": "array",
                                      "items": {"type": "integer"}}}}


def _score_batched_verbalised(client: OpenAICompatClient, scfg: ScorerConfig,
                              transcript: str, budget: list[Slot],
                              ann: Stage1Annotation) -> int:
    """Graded 0-100 scores, one call per chunk.

    Written to a schema of integers rather than free text so the values line up
    with the slots positionally and cannot drift. Stored in
    ``ann.p_verbalised``; when the regime is "both" this sits alongside
    ``p_positive`` as a separate feature rather than overwriting it, because a
    saturated logprob and a graded self-report fail differently and the
    calibrator can use that.
    """
    from concurrent.futures import ThreadPoolExecutor

    chunks = [budget[i:i + scfg.batch_slots]
              for i in range(0, len(budget), scfg.batch_slots)]

    def run(chunk: list[Slot]):
        qs = "\n".join(f"{i + 1}. {s.question}" for i, s in enumerate(chunk))
        user = (f"{transcript}\n\n### QUESTIONS\n{qs}\n\n"
                f"Return exactly {len(chunk)} integers, in the order asked.\n")
        for attempt in range(scfg.max_retries):
            try:
                text, _, _ = client.scored(
                    scfg.model, VERBALISED_SYSTEM, user, scfg.reasoning_effort,
                    scfg.top_logprobs, 24 + 8 * len(chunk),
                    _verbalised_schema(len(chunk)))
                vals = json.loads(text).get("scores") or []
                out = [min(max(int(v), 0), 100) / 100.0 for v in vals]
                return chunk, (out + [None] * len(chunk))[:len(chunk)]
            except Exception:                             # noqa: BLE001
                if attempt == scfg.max_retries - 1:
                    return chunk, [None] * len(chunk)
                time.sleep(2 ** attempt)
        return chunk, [None] * len(chunk)

    need = max((s.index for c in chunks for s in c), default=-1) + 1
    _fit_score_array(ann, "p_verbalised", need)
    first, rest = chunks[0], chunks[1:]
    for chunk, ps in [run(first)]:
        for slot, p in zip(chunk, ps):
            if p is not None:
                ann.p_verbalised[slot.index] = p
    if rest:
        with ThreadPoolExecutor(max_workers=scfg.concurrency) as ex:
            for chunk, ps in ex.map(run, rest):
                for slot, p in zip(chunk, ps):
                    if p is not None:
                        ann.p_verbalised[slot.index] = p
    return len(chunks)


def _score_batched_vpd(client, scfg, transcript: str,
                       budget: list, ann) -> int:
    """VPD, dispatched by slot kind.

    The slot plan does not hand VPD a candidate set ready-made: each `mode`
    slot asks about **one** code (`mode::1.2.1` -> "does 1.2.1 apply?"), so
    the taxonomy is spread across slots rather than living inside one. Scoring
    them one at a time would be binary VPD N times over -- verbalised
    confidence with normalisation, which is not what VPD is.

    So the mode slots of a trace are merged into a single distribution
    question: the candidates are their codes and `none` is "no code applies".
    That is the shape VPD was designed for, and it also turns N calls into 1.
    The `none` mass is not discarded -- it is the model's belief that the
    taxonomy does not cover this trace, which is exactly the residue Stage 4
    looks for, so it is kept in `ann.vpd_detail`.

    `agent` and `step` slots stay binary and go through the batched
    verbalised-style path, flagged `degenerate_binary` so nobody later reads
    those numbers as evidence about VPD itself.
    """
    from .estimators import VPDEstimator

    est = VPDEstimator(temperature=scfg.vpd_temperature)
    n_calls = 0
    modes = [s for s in budget if s.kind == "mode"]
    binaries = [s for s in budget if s.kind != "mode"]

    if modes:
        codes = [s.code or s.key for s in modes]
        user = (f"{transcript}\n\n### QUESTION\nWhich failure mode applies to "
                f"this consultation?")

        def ask(system, question, want_logprobs=False):
            text, _, _ = client.scored(
                scfg.model, system, question, scfg.reasoning_effort,
                scfg.top_logprobs,
                max(scfg.steer_min_tokens, 40 * (len(codes) + 1)))
            return text, None, {}

        r = est.estimate_distribution(ask, SCORER_SYSTEM, user, codes)
        n_calls += 1
        dist = (r.detail or {}).get("distribution") or {}
        for slot in modes:
            p = dist.get(slot.code or slot.key)
            if p is not None:
                ann.p_positive[slot.index] = p
        ann.vpd_detail = {"distribution": dist,
                          "p_none": dist.get("none"),
                          "missing_options": (r.detail or {}).get(
                              "missing_options"),
                          "codes_asked": codes}

    if binaries:
        n_calls += _score_batched_verbalised(client, scfg, transcript,
                                             binaries, ann)
        for slot in binaries:
            pv = ann.p_verbalised[slot.index]
            if pv is not None and ann.p_positive[slot.index] is None:
                ann.p_positive[slot.index] = pv
    return n_calls


def _score_batched_steerconf(client, scfg, transcript: str,
                             budget: list, ann) -> int:
    """SteerConf over a whole slot budget, batched.

    The naive reading of the paper is 2L+1 calls *per slot*: 16 slots x 5
    levels = 80 calls against the 2 the batched scorer currently spends. That
    is not affordable and not necessary -- the steering level is a property of
    the prompt, not of the slot, so one batched call per level scores every
    slot at that level. 16 slots become ~10 calls, not 80.

    Writes to `ann.p_positive` like the logprob path, since what comes out is
    a calibrated P(verdict = 1) rather than a raw verbalised score. The
    per-level detail goes to `ann.steer_detail` so the spread stays inspectable
    -- `kappa_ans` near 0 means the steering levels disagreed, which is the
    signal worth routing on and is invisible once collapsed into p.
    """
    from concurrent.futures import ThreadPoolExecutor

    from .estimators import STEER_LEVELS

    chunks = [budget[i:i + scfg.batch_slots]
              for i in range(0, len(budget), scfg.batch_slots)]
    n_calls = 0
    # slot index -> list of (verdict, confidence) across steering levels
    per_slot: dict[int, list[tuple[Optional[int], Optional[float]]]] = {
        s.index: [] for s in budget}

    def run(args):
        chunk, steer = args
        user = batched_scorer_prompt(transcript, chunk)
        system = (
            "You are auditing a medical multi-agent consultation transcript. "
            "For each question answer with the verdict then a confidence: "
            "`<0 or 1>, <0-100>`. Output one such pair per question, in "
            "order, one per line, and nothing else.\n\n" + steer)
        for attempt in range(scfg.max_retries):
            try:
                # Budget generously. A reasoning model bills its chain of
                # thought against this, and glm-5.3-flash cannot switch
                # reasoning off at all -- at 16 + 12*n it spent the whole
                # allowance thinking and returned an empty string, which
                # looked like a parse failure rather than a truncation.
                text, _, _ = client.scored(
                    scfg.model, system, user, scfg.reasoning_effort,
                    scfg.top_logprobs,
                    max(scfg.steer_min_tokens, 16 + 12 * len(chunk)))
                return chunk, (text or "")
            except Exception:                             # noqa: BLE001
                if attempt == scfg.max_retries - 1:
                    return chunk, ""
                time.sleep(2 ** attempt)
        return chunk, ""

    from .estimators import _parse_verdict_conf

    def _pairs_from(text: str, n: int) -> list:
        """One (verdict, conf) per slot, or nothing.

        Models number their lines (`1. 0`), add blank lines, or append a
        summary paragraph. Strip a leading `<index>.` so those parse, but if
        the count still does not match the chunk, return nothing: `zip` would
        silently pair slot k with another slot's answer, and a misaligned
        confidence is worse than a missing one because nothing downstream can
        tell it went wrong.
        """
        out = []
        for ln in (text or "").splitlines():
            ln = ln.strip()
            if not ln:
                continue
            ln = re.sub(r"^\s*\d{1,2}\s*[.)]\s*", "", ln)
            v, c = _parse_verdict_conf(ln)
            if v is not None or c is not None:
                out.append((v, c))
        return out if len(out) == n else []

    jobs = [(c, steer) for _, steer in STEER_LEVELS for c in chunks]
    with ThreadPoolExecutor(max_workers=scfg.concurrency) as ex:
        for chunk, text in ex.map(run, jobs):
            n_calls += 1
            pairs = _pairs_from(text, len(chunk))
            for slot, pc in zip(chunk, pairs):
                per_slot[slot.index].append(pc)

    from collections import Counter as _Counter
    detail: dict[int, dict] = {}
    for idx, pairs in per_slot.items():
        good = [(v, c) for v, c in pairs if v is not None and c is not None]
        if not good:
            continue
        confs = [c for _, c in good]
        answers = [v for v, _ in good]
        mu = sum(confs) / len(confs)
        sigma = (sum((c - mu) ** 2 for c in confs) / len(confs)) ** 0.5
        k_conf = 1.0 / (1.0 + (sigma / mu if mu > 0 else 0.0))
        top, n_top = _Counter(answers).most_common(1)[0]
        # binary rescale; see SteerConfEstimator for why the raw fraction is
        # wrong here
        k_ans = max(0.0, 2.0 * (n_top / len(answers)) - 1.0)
        c = mu * k_conf * k_ans
        ann.p_positive[idx] = max(0.0, min(
            1.0, 0.5 + (c / 2.0 if top == 1 else -c / 2.0)))
        detail[idx] = {"mu_c": round(mu, 4), "sigma_c": round(sigma, 4),
                       "kappa_conf": round(k_conf, 4),
                       "kappa_ans": round(k_ans, 4),
                       "n_levels": len(good)}
    ann.steer_detail = detail
    return n_calls


def _score_slot(client: OpenAICompatClient, scfg: ScorerConfig,
                transcript: str, slot: Slot, regime: str) -> Optional[float]:
    if regime == "logprob":
        user = scorer_user_prompt(transcript, slot)
        system = SCORER_SYSTEM
        max_tok = scfg.max_output_tokens
    else:
        system = (
            "You are auditing one specific aspect of a medical multi-agent "
            "consultation transcript. Answer with a single integer from 0 to "
            "100: the probability, in percent, that the answer to the question "
            "is yes. Output the number only."
        )
        user = (f"{transcript}\n\n### QUESTION\n{slot.question}\n\n"
                f"### ANSWER (integer 0-100)\n")
        max_tok = 8

    for attempt in range(scfg.max_retries):
        try:
            text, lp, _ = client.scored(
                scfg.model, system, user, scfg.reasoning_effort,
                scfg.top_logprobs, max_tok,
            )
            if regime == "logprob":
                p = p_positive_from_logprobs(lp)
                if p is not None:
                    return p
                # model answered but logprobs came back empty -> degrade
                return 1.0 if text.strip().startswith("1") else 0.0
            m = _NUM.search(text)
            return min(max(int(m.group()), 0), 100) / 100.0 if m else None
        except Exception:                            # noqa: BLE001
            if attempt == scfg.max_retries - 1:
                return None
            time.sleep(2 ** attempt)
    return None


def annotate_batch(
    traces: Sequence[Trace],
    taxonomy: Taxonomy,
    client: OpenAICompatClient,
    rcfg: ReasonerConfig = ReasonerConfig(),
    scfg: ScorerConfig = ScorerConfig(),
    on_result: Optional[Callable[[Stage1Result], None]] = None,
) -> list[Stage1Result]:
    sup = probe_logprob_support(client, scfg)
    print(f"[pre-flight] {scfg.model}: logprobs={sup.logprobs} "
          f"alternatives={sup.alternatives} ({sup.detail})")
    if sup.logprobs and not sup.alternatives:
        print("[pre-flight] WARNING alternatives are stripped; p_token will "
              "quantise to 0/1 and the white-box signal is much weaker")
    available = bool(sup)
    out = []
    for t in traces:
        r = annotate_trace(t, taxonomy, client, rcfg, scfg, available)
        out.append(r)
        if on_result:
            on_result(r)
    return out
