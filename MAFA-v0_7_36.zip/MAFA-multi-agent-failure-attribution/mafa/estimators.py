"""Pluggable confidence estimators for one binary slot verdict.

Stage 2 reads the scorer's token distribution to build its features. That was
fine when every endpoint returned logprobs and is not fine now: deepseek's
Responses API hands back an empty array, glm has none at all, and qwen only
exposes them on `chat.completions`. Without a way to swap the estimator, the
choice of annotator is decided by an API detail rather than by annotation
quality -- deepseek scored highest on injected-fault recall (0.834 against
qwen's 0.728) and yet would be the one model that cannot feed Stage 2.

So the estimator is a strategy object. Each one declares what it needs and
what it costs, and `SlotFeatures` keeps taking `p_token` whatever produced it.

    LogprobEstimator   1 call, needs logprobs           the existing path
    VerbalisedEstimator 1 call, needs nothing           the existing fallback
    SteerConfEstimator  2L+1 calls, needs nothing       NeurIPS 2025

On DiNCo (ICLR 2026), deliberately not implemented
--------------------------------------------------
DiNCo normalises a verbalised confidence by the confidence its *mutually
exclusive distractors* attract, weighting each distractor by how unique it is
and how strongly it contradicts the chosen answer -- both from an NLI model.
That needs a candidate set. A slot verdict is binary, so the only distractor
is the negation: `w_unique` collapses to a constant, `w_contra` to NLI on a
sentence and its own negation, and the normaliser to a rescaled p. The survey
that benchmarks both marks DiNCo open-ended only, which agrees. It would also
add a deberta-scale dependency the pipeline does not currently carry.

DiNCo would fit the *taxonomy-evolution* side instead, where a residual item
really does compete against several candidate codes. That is a different
integration point and not this one.

Two findings from that survey shaped what is here:

* Sampling-aggregated verbalisation beats single-pass almost everywhere. That
  is what `SteerConfEstimator` does, and it is why the cheap `repeats`
  argument on `VerbalisedEstimator` is worth having on its own.
* SteerConf had the strongest discrimination of 24 methods, and needs no
  auxiliary model -- which is why it is the one implemented first.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Any, Callable, Optional, Protocol

#: SteerConf's five steering levels, from most cautious to most confident.
#: The paper's insight is that a confidence which survives being pushed in
#: both directions is worth more than one elicited neutrally once.
STEER_LEVELS: tuple[tuple[str, str], ...] = (
    ("very_cautious",
     "Be very cautious. Only answer 1 if the evidence is beyond doubt."),
    ("cautious",
     "Be cautious. Prefer 0 unless the evidence is clear."),
    ("neutral",
     "Judge neutrally."),
    ("confident",
     "Be decisive. Answer 1 if the evidence points that way."),
    ("very_confident",
     "Be very decisive. Answer 1 unless the evidence clearly rules it out."),
)

_NUM = re.compile(r"(\d{1,3})(?:\s*%)?")
#: "1, 95" / "verdict 0 confidence 88" -- the verdict is a bare 0 or 1 and the
#: confidence is the other number. Taking "the first number" reads the verdict
#: as the confidence, which silently turned a confident 0 into mu_c = 0.0 and
#: a scattered set of 1s into mu_c = 1.0 -- destroying exactly the spread
#: SteerConf exists to measure. Parse them as separate things.
_VERDICT_THEN_CONF = re.compile(r"^\D*([01])\s*[,;:\s]\s*(\d{1,3})")


def _parse_verdict_conf(text: str) -> tuple[Optional[int], Optional[float]]:
    """Return (verdict, confidence) from a short scorer reply."""
    if not text:
        return None, None
    s = text.strip()
    m = _VERDICT_THEN_CONF.match(s)
    if m:
        v = int(m.group(1))
        c = float(m.group(2))
        return v, max(0.0, min(1.0, c / 100.0 if c > 1.0 else c))
    # no pair: fall back to a lone verdict, or a lone confidence
    nums = _NUM.findall(s)
    if len(nums) == 1:
        n = float(nums[0])
        if n in (0.0, 1.0) and len(s) <= 3:
            return int(n), None
        return None, max(0.0, min(1.0, n / 100.0 if n > 1.0 else n))
    if len(nums) >= 2:
        v = int(nums[0]) if nums[0] in ("0", "1") else None
        c = float(nums[1])
        return v, max(0.0, min(1.0, c / 100.0 if c > 1.0 else c))
    return None, None


@dataclass
class SlotEstimate:
    """What an estimator returns for one slot."""
    p: Optional[float]                      #: P(verdict = 1), or None
    n_calls: int                            #: API calls spent
    regime: str                             #: which estimator produced it
    detail: dict[str, Any]                  #: method-specific diagnostics


class Estimator(Protocol):
    name: str

    def needs_logprobs(self) -> bool: ...

    def calls_per_slot(self) -> int: ...

    def estimate(self, ask: Callable[..., Any], system: str,
                 question: str) -> SlotEstimate: ...


def _parse_score(text: str) -> Optional[float]:
    """Confidence only, for estimators that do not also read a verdict."""
    return _parse_verdict_conf(text)[1]


class LogprobEstimator:
    """p(1) from the scorer's token distribution. One call, cheapest."""

    name = "logprob"

    def needs_logprobs(self) -> bool:
        return True

    def calls_per_slot(self) -> int:
        return 1

    def estimate(self, ask, system, question) -> SlotEstimate:
        text, lp, _ = ask(system, question, want_logprobs=True)
        p = None
        for tok in (lp or []):
            alts = {a["token"].strip(): a["logprob"]
                    for a in (tok.get("top_logprobs") or [])}
            import math
            p1 = math.exp(alts["1"]) if "1" in alts else None
            p0 = math.exp(alts["0"]) if "0" in alts else None
            if p1 is not None and p0 is not None and (p1 + p0) > 0:
                p = p1 / (p1 + p0)       # renormalise over {0,1} only
            elif p1 is not None:
                p = p1
            break
        return SlotEstimate(p, 1, self.name, {"answer": text})


class VerbalisedEstimator:
    """Ask for a 0-100 confidence. Works anywhere; poorly calibrated alone.

    `repeats > 1` averages independent elicitations, which the survey found
    beats single-pass verbalisation in almost every setting it tested.
    """

    name = "verbalised"

    def __init__(self, repeats: int = 1) -> None:
        self.repeats = max(1, repeats)

    def needs_logprobs(self) -> bool:
        return False

    def calls_per_slot(self) -> int:
        return self.repeats

    def estimate(self, ask, system, question) -> SlotEstimate:
        vals: list[float] = []
        for _ in range(self.repeats):
            text, _, _ = ask(system, question, want_logprobs=False)
            v = _parse_score(text)
            if v is not None:
                vals.append(v)
        if not vals:
            return SlotEstimate(None, self.repeats, self.name, {})
        p = sum(vals) / len(vals)
        return SlotEstimate(p, self.repeats, self.name,
                            {"samples": vals})


class SteerConfEstimator:
    """SteerConf (Zhou et al., NeurIPS 2025), for a binary slot verdict.

    Ask the same question under 2L+1 steering levels, then combine

        C = mu_c * kappa_conf * kappa_ans
        kappa_conf = 1 / (1 + sigma_c / mu_c)
        kappa_ans  = frequency of the most common answer

    Here the answer is the verdict itself, so `kappa_ans` is simply how often
    the five steered runs agree on 0 or 1 -- no NLI model, unlike the
    open-ended case the paper targets.

    `kappa_*` shrink the confidence toward zero, which would bias every slot
    downward if applied to p directly. So the shrinkage is applied to the
    *margin* from 0.5 and the majority verdict decides the side: an unstable
    slot lands near 0.5 (maximally uncertain) rather than near 0 (confidently
    negative). Getting this backwards would have made unstable slots look
    confidently negative, which is worse than useless for routing.
    """

    name = "steerconf"

    def __init__(self, levels: tuple[tuple[str, str], ...] = STEER_LEVELS
                 ) -> None:
        self.levels = levels

    def needs_logprobs(self) -> bool:
        return False

    def calls_per_slot(self) -> int:
        return len(self.levels)

    def estimate(self, ask, system, question) -> SlotEstimate:
        confs: list[float] = []
        answers: list[int] = []
        per: dict[str, Any] = {}
        for tag, steer in self.levels:
            text, _, _ = ask(f"{system}\n\n{steer}", question,
                             want_logprobs=False)
            a, v = _parse_verdict_conf(text)
            per[tag] = {"raw": (text or "")[:60], "conf": v, "verdict": a}
            if v is not None and a is not None:
                confs.append(v)
                answers.append(a)
        if not confs:
            return SlotEstimate(None, self.calls_per_slot(), self.name, per)

        mu = sum(confs) / len(confs)
        var = sum((c - mu) ** 2 for c in confs) / len(confs)
        sigma = var ** 0.5
        k_conf = 1.0 / (1.0 + (sigma / mu if mu > 0 else 0.0))
        top, n_top = Counter(answers).most_common(1)[0]
        frac = n_top / len(answers)
        # Rescale agreement for a BINARY verdict. The paper's kappa_ans is the
        # raw majority fraction, which works in open-ended QA where a split
        # vote can fall to 1/M. With two options the majority is always at
        # least 1/2, so raw kappa_ans only ever ranges over [0.5, 1] -- a 3:2
        # split scored 0.6 and produced p = 0.73, i.e. a confident verdict
        # from a near-coin-flip. Map [0.5, 1] onto [0, 1] so a split vote
        # really does mean no information.
        k_ans = max(0.0, 2.0 * frac - 1.0)

        c = mu * k_conf * k_ans
        p = 0.5 + (c / 2.0 if top == 1 else -c / 2.0)
        per.update({"mu_c": round(mu, 4), "sigma_c": round(sigma, 4),
                    "kappa_conf": round(k_conf, 4),
                    "kappa_ans": round(k_ans, 4),
                    "C": round(c, 4), "majority_verdict": top})
        return SlotEstimate(max(0.0, min(1.0, p)), self.calls_per_slot(),
                            self.name, per)


class VPDEstimator:
    """VPD -- Verbalized Probability Distribution (Wang et al.).

    Instead of one confidence for one answer, the model emits a probability
    *distribution* over the candidate answers, constrained to sum to 1, with a
    "none of the above" bucket carrying whatever belief falls outside the
    candidate set. In the survey that benchmarks 24 black-box methods this had
    the best calibration overall, and it was strong even single-pass.

    Two shapes here, because the pipeline has two shapes of slot:

    * **`mode` slots** ask which failure code applies. The taxonomy *is* the
      candidate set and "no code applies" *is* none-of-the-above, so this is
      the setting VPD was designed for. `estimate_distribution` returns the
      full distribution.
    * **`agent` / `step` slots** are binary. VPD degrades here to "two numbers
      that sum to 1", which is verbalised confidence with normalisation and
      not really VPD: its advantage over TopK comes from spreading belief
      across several candidates, and there is nothing to spread over. It is
      still implemented, and still slightly better than a bare score because
      the model must commit to both sides, but do not read a binary VPD number
      as evidence about VPD as a method.

    `invert_softmax` implements the paper's correction. Verbalised
    probabilities are already normalised, so scaling them directly and
    re-normalising applies softmax twice ("re-softmax") and distorts the
    result. Inverting to a pseudo-logit first, `z = log p`, then scaling by a
    temperature, then softmax, applies it once. With T = 1 this is the
    identity, so the default changes nothing until a temperature is fitted on
    anchors.
    """

    name = "vpd"

    def __init__(self, temperature: float = 1.0,
                 none_of_the_above: bool = True) -> None:
        self.temperature = temperature
        self.none_of_the_above = none_of_the_above

    def needs_logprobs(self) -> bool:
        return False

    def calls_per_slot(self) -> int:
        return 1

    @staticmethod
    def invert_softmax(probs: list[float], temperature: float = 1.0
                       ) -> list[float]:
        """Pseudo-logits from verbalised probabilities, then temperature.

        The paper's point: `p` already came out of something softmax-shaped,
        so `softmax(p / T)` is a second softmax over a distribution rather
        than a rescaling of logits. Going back to `log p` first and scaling
        *that* is the correction.
        """
        import math
        eps = 1e-6
        z = [math.log(max(p, eps)) / max(temperature, eps) for p in probs]
        m = max(z)
        ex = [math.exp(v - m) for v in z]
        s = sum(ex)
        return [v / s for v in ex] if s > 0 else [1.0 / len(probs)] * len(probs)

    def estimate(self, ask, system, question) -> SlotEstimate:
        """Binary form. See the class docstring on why this is degenerate."""
        sysmsg = (
            f"{system}\n\nGive a probability distribution over the two "
            "answers. Output exactly `no=<0-100>, yes=<0-100>` with the two "
            "numbers summing to 100, and nothing else.")
        text, _, _ = ask(sysmsg, question, want_logprobs=False)
        m = re.search(r"no\s*=\s*(\d{1,3}).*?yes\s*=\s*(\d{1,3})",
                      text or "", re.S | re.I)
        if not m:
            v, c = _parse_verdict_conf(text)
            if v is None or c is None:
                return SlotEstimate(None, 1, self.name, {"raw": (text or "")[:80]})
            p = c if v == 1 else 1.0 - c
            return SlotEstimate(p, 1, self.name,
                                {"raw": (text or "")[:80], "fallback": True})
        p0, p1 = float(m.group(1)), float(m.group(2))
        tot = p0 + p1
        if tot <= 0:
            return SlotEstimate(None, 1, self.name, {"raw": (text or "")[:80]})
        probs = self.invert_softmax([p0 / tot, p1 / tot], self.temperature)
        return SlotEstimate(probs[1], 1, self.name,
                            {"p_no": round(probs[0], 4),
                             "p_yes": round(probs[1], 4),
                             "summed_to": round(tot, 1),
                             "degenerate_binary": True})

    def estimate_distribution(self, ask, system, question,
                              candidates: list[str]) -> SlotEstimate:
        """The real thing: a distribution over `candidates` plus `none`.

        For a `mode` slot, `candidates` are the taxonomy codes that could
        apply. The `none` bucket is not padding -- it is where VPD puts the
        belief that no listed code fits, which is precisely the residue this
        project's taxonomy evolution is trying to find.
        """
        opts = list(candidates) + (["none"] if self.none_of_the_above else [])
        listing = "\n".join(f"- {c}" for c in opts)
        sysmsg = (
            f"{system}\n\nGive a probability distribution over these options, "
            f"as percentages summing to 100. Output one `<option>=<0-100>` "
            f"per line and nothing else.\n{listing}")
        text, _, _ = ask(sysmsg, question, want_logprobs=False)
        found: dict[str, float] = {}
        for line in (text or "").splitlines():
            m = re.match(r"\s*[-*]?\s*(\S+)\s*[=:]\s*(\d{1,3})", line)
            if m and m.group(1) in opts:
                found[m.group(1)] = float(m.group(2))
        if not found:
            return SlotEstimate(None, 1, self.name, {"raw": (text or "")[:120]})
        tot = sum(found.values())
        if tot <= 0:
            return SlotEstimate(None, 1, self.name, {"raw": (text or "")[:120]})
        keys = list(found)
        cal = self.invert_softmax([found[k] / tot for k in keys],
                                  self.temperature)
        dist = dict(zip(keys, (round(v, 4) for v in cal)))
        p_none = dist.get("none", 0.0)
        return SlotEstimate(1.0 - p_none, 1, self.name,
                            {"distribution": dist, "summed_to": round(tot, 1),
                             "missing_options": [o for o in opts
                                                 if o not in found]})


ESTIMATORS: dict[str, Callable[..., Estimator]] = {
    "logprob": LogprobEstimator,
    "verbalised": VerbalisedEstimator,
    "steerconf": SteerConfEstimator,
    "vpd": VPDEstimator,
}


def make_estimator(name: str, **kw) -> Estimator:
    if name not in ESTIMATORS:
        raise ValueError(f"unknown estimator {name!r}; "
                         f"have {sorted(ESTIMATORS)}")
    return ESTIMATORS[name](**kw)
