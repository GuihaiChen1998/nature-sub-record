"""
conformal_router.py
===================
Turns calibrated probabilities into prediction sets with a distribution-free
coverage guarantee, and turns those sets into the three-way routing decision.

Why sets instead of thresholds
------------------------------
The original routing rule was "all three levels above a threshold -> auto-
accept; mixed -> priority 1; all below -> priority 2".  A reviewer will ask
where the thresholds came from and what coverage they buy, and there is no
answer.  Split conformal answers both: pick a miscoverage rate alpha, and the
prediction set contains the true label with probability at least 1 - alpha,
with no assumption on the model beyond exchangeability of calibration and test
data.

The set size then *is* the routing decision, and it is a better decision than
a threshold because it tells the human what to do:

    |set| == 1        AUTO    the label is settled; admit it to the corpus
    |set| in 2..k     VERIFY  the human picks from the set -- a closed-form
                              judgement, not an open-ended re-read, which is
                              exactly the low-cost human step the design needs
    |set| == 0        NOVEL   nothing was conformal; the seed taxonomy may not
                              cover this trace.  Straight to the residual pool
    |set| > k         REVIEW  the model is uninformative here; full re-read

Exchangeability caveat
----------------------
The guarantee is marginal over the calibration distribution.  Your four
frameworks are structurally very different (MDAgents single-round debate vs
ClinicalAgent pipeline), so a single pooled calibration would give 1 - alpha on
average while badly under-covering one framework.  ``groups`` implements
Mondrian (group-conditional) conformal: calibrate a separate quantile per
group.  Default grouping is (slot kind, framework); add the code when you have
enough calibration points per code.

Sample-size floor
-----------------
For a group to reach 1 - alpha at all you need n_cal >= 1/alpha - 1.  At
alpha = 0.1 that is 9, and 9 is far too few to be stable -- ``MIN_CAL`` is set
to 40 and groups below it fall back to the pooled quantile, with the fallback
recorded so it never happens silently.
"""

from __future__ import annotations

import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Literal, Optional, Sequence

import numpy as np

Decision = Literal["AUTO", "VERIFY", "NOVEL", "REVIEW"]

MIN_CAL = 40


def conformal_quantile(scores: Sequence[float], alpha: float) -> float:
    """The finite-sample-corrected (1-alpha) quantile of calibration scores."""
    n = len(scores)
    if n == 0:
        return float("inf")
    k = math.ceil((n + 1) * (1.0 - alpha))
    if k > n:
        return float("inf")          # too few points to certify at this alpha
    return float(np.sort(np.asarray(scores, float))[k - 1])


# --------------------------------------------------------------------------- #
# Binary slots (agent level, mode level)
# --------------------------------------------------------------------------- #

@dataclass
class BinaryConformal:
    """Mondrian split conformal over {0, 1} using score = 1 - p(true label)."""

    alpha: float = 0.1
    q: dict[str, float] = field(default_factory=dict)
    q_pooled: float = float("inf")
    n_cal: dict[str, int] = field(default_factory=dict)
    fell_back: set[str] = field(default_factory=set)

    def fit(self, p1: Sequence[float], y: Sequence[int],
            groups: Optional[Sequence[str]] = None) -> "BinaryConformal":
        p1 = np.asarray(list(p1), float)
        y = np.asarray(list(y), int)
        s = np.where(y == 1, 1.0 - p1, p1)
        self.q_pooled = conformal_quantile(s, self.alpha)
        if groups is None:
            return self
        by = defaultdict(list)
        for g, sc in zip(groups, s):
            by[g].append(sc)
        for g, sc in by.items():
            self.n_cal[g] = len(sc)
            if len(sc) < MIN_CAL:
                self.fell_back.add(g)
                self.q[g] = self.q_pooled
            else:
                self.q[g] = conformal_quantile(sc, self.alpha)
        return self

    def predict_set(self, p1: float, group: Optional[str] = None) -> set[int]:
        q = self.q.get(group, self.q_pooled) if group else self.q_pooled
        out: set[int] = set()
        if 1.0 - p1 <= q:
            out.add(1)
        if p1 <= q:
            out.add(0)
        return out


# --------------------------------------------------------------------------- #
# Multiclass: the earliest-fault step
# --------------------------------------------------------------------------- #

@dataclass
class MulticlassConformal:
    """LAC (threshold) conformal over candidate labels.

    LAC gives the smallest sets at a given alpha, which is what we want: the
    set is handed to a human as a multiple-choice question, so every extra
    option is real reading cost.  ``method="aps"`` is available when
    conditional coverage matters more than set size.
    """

    alpha: float = 0.1
    method: Literal["lac", "aps"] = "lac"
    q: dict[str, float] = field(default_factory=dict)
    q_pooled: float = float("inf")
    n_cal: dict[str, int] = field(default_factory=dict)
    fell_back: set[str] = field(default_factory=set)

    def _scores(self, probs: dict[str, float], truth: str) -> float:
        if self.method == "lac":
            return 1.0 - probs.get(truth, 0.0)
        order = sorted(probs.items(), key=lambda kv: -kv[1])
        cum = 0.0
        for lab, pr in order:
            cum += pr
            if lab == truth:
                return cum
        return 1.0

    def fit(self, probs: Sequence[dict[str, float]], truth: Sequence[str],
            groups: Optional[Sequence[str]] = None) -> "MulticlassConformal":
        s = [self._scores(pr, t) for pr, t in zip(probs, truth)]
        self.q_pooled = conformal_quantile(s, self.alpha)
        if groups is None:
            return self
        by = defaultdict(list)
        for g, sc in zip(groups, s):
            by[g].append(sc)
        for g, sc in by.items():
            self.n_cal[g] = len(sc)
            if len(sc) < MIN_CAL:
                self.fell_back.add(g)
                self.q[g] = self.q_pooled
            else:
                self.q[g] = conformal_quantile(sc, self.alpha)
        return self

    def predict_set(self, probs: dict[str, float],
                    group: Optional[str] = None) -> set[str]:
        q = self.q.get(group, self.q_pooled) if group else self.q_pooled
        if self.method == "lac":
            return {lab for lab, pr in probs.items() if 1.0 - pr <= q}
        out, cum = set(), 0.0
        for lab, pr in sorted(probs.items(), key=lambda kv: -kv[1]):
            out.add(lab)
            cum += pr
            if cum >= q:
                break
        return out


# --------------------------------------------------------------------------- #
# Trace-level routing
# --------------------------------------------------------------------------- #

@dataclass
class LevelDecision:
    level: Literal["agent", "step", "mode"]
    decision: Decision
    #: for binary levels: {slot_key: prediction set}; for step: one set
    sets: dict[str, set] = field(default_factory=dict)
    ambiguous_keys: list[str] = field(default_factory=list)
    max_set_size: int = 0
    empty_keys: list[str] = field(default_factory=list)


@dataclass
class TraceRoute:
    trace_id: str
    decision: Decision
    levels: dict[str, LevelDecision]
    #: descending expected-agreement-gain; the order the queue is worked
    priority: float
    n_human_questions: int
    reasons: list[str] = field(default_factory=list)

    @property
    def bucket(self) -> str:
        return {
            "AUTO": "corpus",
            "VERIFY": "human_queue",
            "REVIEW": "human_queue_full_read",
            "NOVEL": "residual_pool",
        }[self.decision]


@dataclass
class RouterConfig:
    alpha: float = 0.10
    #: a VERIFY set larger than this is not a multiple-choice question any more
    max_verify_set: int = 3
    #: a trace needing more than this many human questions goes to full review
    max_questions: int = 6
    group_by: tuple[str, ...] = ("kind", "framework")


class ConformalRouter:
    def __init__(self, cfg: RouterConfig = RouterConfig(),
                 taxonomy_signature: Optional[str] = None) -> None:
        self.cfg = cfg
        #: optional RoutingBackend for agent/mode slots; None = split conformal
        self.binary_backend = None
        self.binary = BinaryConformal(alpha=cfg.alpha)
        self.step = MulticlassConformal(alpha=cfg.alpha)
        self.calibration_report: dict[str, Any] = {}
        self.taxonomy_signature = taxonomy_signature

    def check_signature(self, signature: Optional[str]) -> None:
        """Coverage is only guaranteed under exchangeability of calibration and
        test data. A taxonomy change alters the label space, so quantiles from
        the old one certify nothing about the new one -- and the sets will
        still look perfectly reasonable, which is what makes this worth an
        exception rather than a warning."""
        if self.taxonomy_signature is None or signature is None:
            return
        if self.taxonomy_signature != signature:
            raise RuntimeError(
                f"conformal quantiles were calibrated on taxonomy "
                f"{self.taxonomy_signature}, applied to {signature}. The "
                "1-alpha coverage guarantee does not hold across a change of "
                "label space; recalibrate on the calibration pool.")

    # -- grouping --------------------------------------------------------- #
    def group_key(self, kind: str, framework: str,
                  code: Optional[str] = None, split: str = "-") -> str:
        parts = []
        for g in self.cfg.group_by:
            parts.append({"kind": kind, "framework": framework,
                          "code": code or "-", "split": split}[g])
        return "|".join(parts)

    # -- fitting ---------------------------------------------------------- #
    def fit(
        self,
        bin_p: Sequence[float], bin_y: Sequence[int], bin_g: Sequence[str],
        step_probs: Optional[Sequence[dict[str, float]]] = None,
        step_truth: Optional[Sequence[str]] = None,
        step_g: Optional[Sequence[str]] = None,
    ) -> "ConformalRouter":
        self.binary.fit(bin_p, bin_y, bin_g)
        if step_probs and step_truth:
            self.step.fit(step_probs, step_truth, step_g)
        self.calibration_report = {
            "alpha": self.cfg.alpha,
            "binary_groups": dict(self.binary.n_cal),
            "binary_fellback": sorted(self.binary.fell_back),
            "binary_q": {k: round(v, 4) for k, v in self.binary.q.items()},
            "step_groups": dict(self.step.n_cal),
            "step_fellback": sorted(self.step.fell_back),
        }
        return self

    # -- routing ---------------------------------------------------------- #
    def route(
        self,
        trace_id: str,
        framework: str,
        agent_slots: dict[str, tuple[float, Optional[str]]],
        mode_slots: dict[str, tuple[float, Optional[str]]],
        step_probs: dict[str, float],
        agreement: Optional[dict[str, float]] = None,
        beliefs: Optional[dict[str, Any]] = None,
    ) -> TraceRoute:
        """``*_slots`` map slot key -> (calibrated p1, code or None).

        ``beliefs`` maps slot key -> Belief and is read only when a pluggable
        binary backend is set; an interval backend needs it, since the point
        in ``*_slots`` has already lost the width.
        """
        agreement = agreement or {}
        levels: dict[str, LevelDecision] = {}
        reasons: list[str] = []
        n_questions = 0

        for level, slots in (("agent", agent_slots), ("mode", mode_slots)):
            ld = LevelDecision(level=level, decision="AUTO")
            for key, (p, code) in slots.items():
                g = self.group_key(level, framework, code)
                if self.binary_backend is not None:
                    # Pluggable Stage-3 backend. 0.7.25 added these and never
                    # routed through them: `router_backend` was a config field
                    # nothing read, so ACI and Venn-Abers passed their own
                    # tests and the pipeline used split conformal regardless.
                    #
                    # NOVEL is asked of the backend rather than inferred from
                    # an empty set, because the interval router never returns
                    # an empty set -- its NOVEL signal is width.
                    b = (beliefs or {}).get(key)
                    if b is None:
                        from .calibration_backends import Belief
                        b = Belief.point(p)
                    s = (set() if self.binary_backend.is_novel(b, g)
                         else self.binary_backend.predict_set(b, g))
                else:
                    s = self.binary.predict_set(p, g)
                ld.sets[key] = s
                ld.max_set_size = max(ld.max_set_size, len(s))
                if len(s) == 0:
                    ld.empty_keys.append(key)
                elif len(s) > 1:
                    ld.ambiguous_keys.append(key)
            if ld.empty_keys:
                ld.decision = "NOVEL"
                reasons.append(f"{level}:empty_set:{','.join(ld.empty_keys[:3])}")
            elif ld.ambiguous_keys:
                ld.decision = "VERIFY"
                n_questions += len(ld.ambiguous_keys)
            levels[level] = ld

        sd = LevelDecision(level="step", decision="AUTO")
        g = self.group_key("step", framework)
        sset = self.step.predict_set(step_probs, g) if step_probs else set()
        sd.sets["earliest_fault_step"] = sset
        sd.max_set_size = len(sset)
        if len(sset) == 0:
            sd.decision = "NOVEL"
            reasons.append("step:empty_set")
        elif len(sset) > self.cfg.max_verify_set:
            sd.decision = "REVIEW"
            reasons.append(f"step:set_size={len(sset)}")
            n_questions += 1
        elif len(sset) > 1:
            sd.decision = "VERIFY"
            n_questions += 1
        levels["step"] = sd

        decisions = {ld.decision for ld in levels.values()}
        if "NOVEL" in decisions:
            final: Decision = "NOVEL"
        elif "REVIEW" in decisions or n_questions > self.cfg.max_questions:
            final = "REVIEW"
            if n_questions > self.cfg.max_questions:
                reasons.append(f"too_many_questions={n_questions}")
        elif "VERIFY" in decisions:
            final = "VERIFY"
        else:
            final = "AUTO"

        # queue priority: expected error a human can actually remove
        gains = []
        for level, slots in (("agent", agent_slots), ("mode", mode_slots)):
            for key, (p, _code) in slots.items():
                if key in levels[level].ambiguous_keys:
                    gains.append(min(p, 1 - p) * agreement.get(key, 1.0))
        priority = float(max(gains)) if gains else 0.0

        return TraceRoute(trace_id, final, levels, priority,
                          n_questions, reasons)


# --------------------------------------------------------------------------- #
# Evaluation
# --------------------------------------------------------------------------- #

def evaluate_binary_coverage(
    conf: BinaryConformal,
    p1: Sequence[float], y: Sequence[int], groups: Sequence[str],
) -> dict[str, dict[str, float]]:
    """Empirical coverage and set size, overall and per Mondrian group.

    Report the per-group numbers, not just the pooled one -- pooled coverage
    hitting 1-alpha while one framework sits at 1-3*alpha is the exact failure
    Mondrian exists to prevent, and it is invisible in the pooled figure.
    """
    out: dict[str, dict[str, float]] = {}
    buckets = defaultdict(list)
    for p, t, g in zip(p1, y, groups):
        buckets[g].append((p, t))
        buckets["__all__"].append((p, t))
    for g, items in buckets.items():
        cov, size, empty, singleton = [], [], 0, 0
        for p, t in items:
            s = conf.predict_set(p, None if g == "__all__" else g)
            cov.append(1.0 if t in s else 0.0)
            size.append(len(s))
            empty += int(len(s) == 0)
            singleton += int(len(s) == 1)
        n = len(items)
        out[g] = {
            "n": n,
            "coverage": float(np.mean(cov)),
            "avg_set_size": float(np.mean(size)),
            "empty_rate": empty / n,
            "singleton_rate": singleton / n,
            "fell_back": float(g in conf.fell_back),
        }
    return out


def automation_curve(
    conf_factory: Callable[[float], BinaryConformal],
    p_cal: Sequence[float], y_cal: Sequence[int], g_cal: Sequence[str],
    p_test: Sequence[float], y_test: Sequence[int], g_test: Sequence[str],
    alphas: Sequence[float] = (0.02, 0.05, 0.10, 0.15, 0.20),
) -> list[dict[str, float]]:
    """The operating curve you actually report: for each alpha, how much of the
    corpus is auto-admitted and how wrong that admitted portion is."""
    rows = []
    for a in alphas:
        c = conf_factory(a).fit(p_cal, y_cal, g_cal)
        auto_correct = auto_n = 0
        for p, t, g in zip(p_test, y_test, g_test):
            s = c.predict_set(p, g)
            if len(s) == 1:
                auto_n += 1
                auto_correct += int(next(iter(s)) == t)
        n = len(p_test)
        rows.append({
            "alpha": a,
            "automation_rate": auto_n / n,
            "auto_error": 1 - auto_correct / auto_n if auto_n else float("nan"),
            "human_rate": 1 - auto_n / n,
        })
    return rows
