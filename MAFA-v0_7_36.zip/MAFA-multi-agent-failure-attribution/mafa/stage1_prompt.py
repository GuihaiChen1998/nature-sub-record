"""
stage1_prompt.py
================
Prompt construction for Call 1a (the reasoner).

Two things here are load-bearing and should not be "tidied away" later:

*Outcome-blind by default.*  MedAgentAudit shows the auditor the ground truth
and the system's final answer for every failure mode.  Its released human
evaluation has specificity below sensitivity on all ten codes (mean .82 vs
.95) -- the auditor over-flags.  Since our faulty split is defined by
``is_correct == False``, showing the outcome would let the annotator shortcut
from "the answer was wrong" to "therefore find a fault".  So the transcript is
rendered outcome-blind unless one of the selected codes genuinely needs the
correct answer in its definition (only 3.1.1 does).  Set
``force_outcome_visible=True`` for the ablation arm.

*Verbatim evidence.*  Every finding must carry a quote copied character-for-
character out of the transcript.  ``verify_span`` then checks it offline.  This
converts hallucination into a measurable, zero-extra-cost signal, and it is
also what lets a human reviewer adjudicate by reading three quoted lines
instead of the whole trace.
"""

from __future__ import annotations

from typing import Optional

from .taxonomy import Taxonomy
from .stage1_schema import SlotPlan
from .trace_adapter import Trace

REASONER_SYSTEM = (
    "You are a senior clinician and an expert in the failure analysis of "
    "medical multi-agent systems. You audit consultation transcripts and "
    "report, precisely and conservatively, where collaboration broke down.\n\n"
    "Four rules govern everything you output:\n"
    "1. Report a failure only when the transcript itself demonstrates it. A "
    "conclusion you find clinically unwise, but which the agent argued for "
    "coherently from the evidence available to it, is not a failure.\n"
    "2. Every finding must be anchored to a quote copied character-for-"
    "character from the transcript, together with the step_id it came from. "
    "Quotes are checked automatically against the source; a quote that cannot "
    "be located invalidates the finding it supports.\n"
    "3. Multiple agents may fail, and one agent may fail in several ways. Do "
    "not collapse everything into a single root cause, and do not manufacture "
    "additional failures for symmetry.\n"
    "4. Judge each agent independently and on its own output. Agents in one "
    "consultation routinely differ: some fail while others perform correctly. "
    "An agent is not at fault merely for appearing alongside one that is, nor "
    "for relaying a claim it had no way to check. You are told nothing about "
    "how many agents, if any, are at fault."
)


def _taxonomy_block(plan: SlotPlan, taxonomy: Taxonomy) -> str:
    lines = ["### FAILURE MODE DEFINITIONS (applicable to this framework)"]
    for code in plan.applicable_codes:
        m = taxonomy.get(code)
        if m is None:
            continue
        lines.append(
            f"- **{m.code} {m.name}**: {m.definition} "
            f"(may be located in: {', '.join(sorted(m.allowed_phases))})"
        )
    if plan.excluded_codes:
        lines.append("")
        lines.append(
            "The following codes are NOT scoreable for this framework because "
            "it lacks the required structure; do not report them:"
        )
        for code, missing in sorted(plan.excluded_codes.items()):
            m = taxonomy.get(code)
            nm = m.name if m else code
            lines.append(f"- {code} {nm} (missing: {', '.join(missing)})")
    return "\n".join(lines)


def build_reasoner_prompt(
    trace: Trace,
    plan: SlotPlan,
    taxonomy: Taxonomy,
    max_chars_per_step: int = 4000,
    force_outcome_visible: bool = False,
    legacy: bool = False,
) -> tuple[str, str, bool]:
    """Return ``(system, user, outcome_was_shown)``.

    ``legacy=True`` reproduces the pre-0.6.2 prompt: no base-rate framing, no
    explicit evidence rule, and the older slot wording is left to the caller.
    It exists so both variants can be run on the SAME traces, which is the only
    way to tell whether the revision moved specificity rather than the wording.
    """
    needs_gt = any(
        (m := taxonomy.get(c)) is not None and m.needs_ground_truth
        for c in plan.applicable_codes
    )
    outcome_visible = force_outcome_visible or needs_gt

    transcript = trace.render(
        max_chars_per_step=max_chars_per_step,
        outcome_blind=not outcome_visible,
    )

    system = REASONER_SYSTEM
    if legacy:
        system = (REASONER_SYSTEM.split("4. Judge each agent")[0].rstrip()
                  .replace("Four rules govern", "Three rules govern"))
    system = REASONER_SYSTEM
    if legacy:
        system = (REASONER_SYSTEM.split("4. Judge each agent")[0].rstrip()
                  .replace("Four rules govern", "Three rules govern"))
    parts = [transcript, "", _taxonomy_block(plan, taxonomy), ""]

    if outcome_visible:
        parts += [
            "### NOTE ON THE OUTCOME",
            "The correct answer is shown above because code 3.1.1 is defined "
            "relative to it. Use it ONLY to judge 3.1.1. For every other code, "
            "judge the process on its own terms: an agent that reasoned "
            "soundly and still reached the wrong answer has not committed a "
            "process failure, and an agent that reasoned badly and happened to "
            "be right has.",
            "",
        ]
    else:
        parts += [
            "### NOTE ON THE OUTCOME",
            "The correct answer and the system's final answer are withheld "
            "deliberately. Judge the collaboration process on its own terms.",
            "",
        ]

    if not legacy:
        parts += [
            "### WHAT YOU ARE NOT TOLD",
            "You are not told whether this consultation went well or badly. "
            "Some transcripts contain no failure at all; in others several "
            "agents fail. Do not infer from the fact that you were asked to "
            "audit this trace that a failure must be present.",
            "",
            "### WHAT THE INPUT BLOCKS ARE",
            "Some steps are preceded by an indented block marked INPUT "
            "PROVIDED TO THIS AGENT. That is material the system handed the "
            "agent -- tool outputs, retrieved records, case material, "
            "instructions. It is context for judging the agent, never evidence "
            "against it. Two consequences: a figure or fact the agent repeats "
            "from its input block is sourced, not fabricated; and a failure is "
            "something an agent DID, so the earliest fault step is the first "
            "step whose OUTPUT is defective. Flawed or incomplete input is not "
            "itself a failure step.",
            "",
            "### WHEN NOTHING ON THE LIST FITS",
            "The list above is not complete and is not assumed to be. It was "
            "written from other collaboration structures and is known to "
            "transfer imperfectly. So a passage can be defective in a way none "
            "of these codes names.",
            "Silence is not the safe answer here. Reporting no failure because "
            "no code fits loses the observation entirely; proposing one that "
            "turns out to be an existing code merely gets it merged later. The "
            "second is recoverable and the first is not.",
            "",
            "### THE EVIDENCE RULE",
            'An agent-level or mode-level answer of "1" REQUIRES a '
            'corresponding entry in "findings" carrying a verbatim quote from '
            "that agent's own output. If you cannot produce the quote, the "
            'answer is "0". A suspicion you cannot quote is not a finding. '
            "This is checked automatically and unsupported verdicts are "
            "discarded.",
            "",
        ]

    parts += [
        "### DECISIONS TO MAKE",
        f"Below are {len(plan.slots)} numbered binary questions. Return a "
        f'"verdicts" array of exactly {len(plan.slots)} entries, each the '
        f'single character "1" or "0", in this exact order:',
        "",
        plan.render(),
        "",
        "### ADDITIONALLY",
        '- "earliest_fault_step_id": the step_id where a failure first '
        'appears, or "none" if the trace is clean. This must be consistent '
        "with your verdicts: it cannot precede every failure you report, and "
        "the agent who owns it must be one you flagged.",
        "- \"findings\": one entry for each slot you answered \"1\" at the mode "
        "level, pinning it to a specific agent_uid and step_id and carrying "
        "1-3 verbatim quotes. Copy quotes exactly; do not fix typos, do not "
        "add ellipses, do not merge non-adjacent sentences.",
        '- "novel_modes": this is where a failure goes when the codes above '
        "cannot express it. Both mistakes are costly and the second is the one "
        "that is usually made: inventing a mode for something an existing code "
        "already covers, and saying nothing about a failure you can see because "
        "no code fits it. If you would describe a passage as defective to a "
        "colleague but cannot name it from the list, that is a novel mode, not "
        "an absence. Say specifically why the closest existing code does not "
        "fit, and quote the passage verbatim as you would for any other "
        "finding. If nothing of the sort occurred, leave it empty.",
        "- \"self_assessment\": your 0-100 confidence at each of the three "
        "levels, and one sentence naming the judgement you found hardest.",
    ]

    return system, "\n".join(parts), outcome_visible


def build_scorer_transcript(
    trace: Trace,
    max_chars_per_step: int = 4000,
    outcome_visible: bool = False,
) -> str:
    """Transcript for Call 1b.

    Kept identical in content to the reasoner's transcript so that the two
    signals are measured on the same evidence, but with no taxonomy block and
    no slot list: the scorer sees one question at a time and cannot anchor on
    its own earlier commitments.
    """
    return trace.render(
        max_chars_per_step=max_chars_per_step,
        outcome_blind=not outcome_visible,
    )
