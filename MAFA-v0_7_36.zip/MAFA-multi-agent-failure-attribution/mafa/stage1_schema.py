"""
stage1_schema.py
================
The Stage-1 annotation contract: what the annotator must emit, how it is
parsed, and how it is checked before any uncertainty number is computed.

Why the annotation is split into two calls
------------------------------------------
We want BOTH a black-box signal (verbalised confidence, evidence, rationale)
and a white-box signal (the log-probability of the verdict token).  On the
GPT-5.x families these cannot come from the same call: reasoning output does
not expose logprobs, and there are multiple reports that
``include=["message.output_text.logprobs"]`` returns an empty list as soon as
Structured Outputs (``json_schema``) is enabled.  Verify this against the
current API before building on it -- but the two-call design below is the safe
default either way, and it is *better* science: the scorer sees only the
anchor question, so its probability is not contaminated by the reasoner's own
committed narrative.

    Call 1a  "reasoner"  -- json_schema, reasoning on, NO logprobs.
             Produces: slot verdicts, evidence spans, rationales, earliest
             fault step, NOVEL proposals, verbalised confidence.

    Call 1b  "scorer"    -- plain text, reasoning effort none, logprobs=True,
             top_logprobs=20, max_output_tokens small.  One call per slot the
             reasoner flagged plus a stratified sample of unflagged slots.
             The response is expected to be the single character 0 or 1, so
             token alignment is trivial and p(1) is read directly off the
             first content token.

Slot design
-----------
A *slot* is one binary decision.  ``build_slot_plan`` enumerates them from the
trace and the taxonomy:

    agent slots  : one per agent          -> "did this agent fault at all?"
    step  slots  : one per step           -> "is the earliest fault at/ before?"
    mode  slots  : one per applicable code-> "does this failure mode occur?"

Default mode granularity is ``trace`` (|applicable codes| slots), with the
agent/step attribution carried by the finding's evidence rather than by the
cross-product.  ``agent`` and ``agent_step`` granularities are available for
ablation; ``agent_step`` reproduces MedAgentAudit's exhaustive scan, which
costs ~n_agents x n_steps x n_modes decisions per trace.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field, asdict
from typing import Any, Iterable, Literal, Optional

from .taxonomy import NOVEL_CODE, FailureMode, Taxonomy
from .trace_adapter import SpanMatch, Trace, verify_span

SlotKind = Literal["agent", "step", "mode"]
ModeGranularity = Literal["trace", "agent", "agent_step"]


# --------------------------------------------------------------------------- #
# Slots
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Slot:
    index: int
    kind: SlotKind
    key: str                       # human-readable, unique within the plan
    agent_uid: Optional[str] = None
    step_id: Optional[str] = None
    code: Optional[str] = None
    question: str = ""

    def as_prompt_line(self) -> str:
        return f"{self.index}. [{self.kind}] {self.key} -- {self.question}"


@dataclass
class SlotPlan:
    trace_id: str
    slots: list[Slot]
    mode_granularity: ModeGranularity
    applicable_codes: list[str]
    #: codes excluded because the framework structurally cannot exhibit them
    excluded_codes: dict[str, list[str]] = field(default_factory=dict)

    def __len__(self) -> int:
        return len(self.slots)

    def of_kind(self, kind: SlotKind) -> list[Slot]:
        return [s for s in self.slots if s.kind == kind]

    def render(self) -> str:
        return "\n".join(s.as_prompt_line() for s in self.slots)


def build_slot_plan(
    trace: Trace,
    taxonomy: Taxonomy,
    mode_granularity: ModeGranularity = "trace",
    legacy: bool = False,
) -> SlotPlan:
    slots: list[Slot] = []
    i = 0

    for a in trace.agents:
        slots.append(Slot(
            index=i, kind="agent", key=f"agent::{a.agent_uid}",
            agent_uid=a.agent_uid,
            question=(
                f"Does agent {a.label} commit at least one failure at any "
                f"point in this trace?" if legacy else
                f"Is there a specific passage in {a.label}'s own output that "
                f"demonstrates one of the applicable failure modes? Answer "
                f"1 only if you could quote that passage."
            ),
        ))
        i += 1

    for s in trace.steps:
        slots.append(Slot(
            index=i, kind="step", key=f"step::{s.step_id}",
            agent_uid=s.agent_uid, step_id=s.step_id,
            question=(
                f"Is step {s.step_id} ({s.agent_uid}, {s.phase}) the point at "
                f"which a failure first appears in this trace?" if legacy else
                f"Is step {s.step_id} ({s.agent_uid}, {s.phase}) the FIRST "
                f"point in this trace at which a failure appears? At most one "
                f"step in a trace can be the first."
            ),
        ))
        i += 1

    applicable = taxonomy.applicable(trace.capabilities)
    excluded: dict[str, list[str]] = {}
    for m in taxonomy.modes:
        if m not in applicable:
            missing = sorted(r for r in m.requires
                             if not trace.capabilities.get(r, False))
            excluded[m.code] = missing

    for m in applicable:
        targets: list[tuple[Optional[str], Optional[str]]]
        if mode_granularity == "trace":
            targets = [(None, None)]
        elif mode_granularity == "agent":
            targets = [(a.agent_uid, None) for a in trace.agents
                       if _agent_touches_phase(trace, a.agent_uid, m)]
        else:  # agent_step
            targets = [(s.agent_uid, s.step_id) for s in trace.steps
                       if s.phase in m.allowed_phases]

        for agent_uid, step_id in targets:
            key = "mode::" + m.code
            if agent_uid:
                key += f"@{agent_uid}"
            if step_id:
                key += f"@{step_id}"
            scope = ""
            if step_id:
                scope = f" at step {step_id}"
            elif agent_uid:
                scope = f" by agent {agent_uid}"
            slots.append(Slot(
                index=i, kind="mode", key=key, code=m.code,
                agent_uid=agent_uid, step_id=step_id,
                question=m.anchor_question + (
                    f" (Scope: {scope.strip()})" if scope else
                    " (Scope: anywhere in this trace)"
                ),
            ))
            i += 1

    return SlotPlan(
        trace_id=trace.trace_id,
        slots=slots,
        mode_granularity=mode_granularity,
        applicable_codes=[m.code for m in applicable],
        excluded_codes=excluded,
    )


def _agent_touches_phase(trace: Trace, agent_uid: str, mode: FailureMode) -> bool:
    card = trace.agent(agent_uid)
    if card is None:
        return False
    return any(p in mode.allowed_phases for p in card.phases)


# --------------------------------------------------------------------------- #
# Call 1a -- reasoner output contract
# --------------------------------------------------------------------------- #

def reasoner_json_schema(plan: SlotPlan) -> dict[str, Any]:
    """Strict-mode-compatible JSON Schema for the reasoner call.

    Deliberately avoids ``minItems``/``maxItems`` (unsupported under OpenAI
    strict mode); the array length is stated in the prompt and enforced by
    :func:`parse_reasoner_output`.
    """
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["verdicts", "earliest_fault_step_id", "findings",
                     "novel_modes", "self_assessment"],
        "properties": {
            "verdicts": {
                "description": (
                    f"Exactly {len(plan.slots)} entries, index-aligned with the "
                    f"numbered slot list. Each entry is the single character "
                    f'"0" (no) or "1" (yes).'
                ),
                "type": "array",
                "items": {"type": "string", "enum": ["0", "1"]},
            },
            "earliest_fault_step_id": {
                "description": (
                    'step_id of the earliest step at which a failure appears, '
                    'or "none" if the trace contains no failure.'
                ),
                "type": "string",
            },
            "findings": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["slot_index", "code", "agent_uid", "step_id",
                                 "evidence", "rationale", "confidence"],
                    "properties": {
                        "slot_index": {"type": "integer"},
                        "code": {"type": "string"},
                        "agent_uid": {"type": "string"},
                        "step_id": {"type": "string"},
                        "evidence": {
                            "description": (
                                "1-3 verbatim quotes copied character-for-"
                                "character from the transcript. Do not "
                                "paraphrase, do not summarise, do not repair "
                                "typos. A quote that cannot be found in the "
                                "transcript invalidates the finding."
                            ),
                            "type": "array",
                            "items": {
                                "type": "object",
                                "additionalProperties": False,
                                "required": ["step_id", "quote"],
                                "properties": {
                                    "step_id": {"type": "string"},
                                    "quote": {"type": "string"},
                                },
                            },
                        },
                        "rationale": {"type": "string"},
                        "confidence": {
                            "type": "string",
                            "enum": ["low", "medium", "high"],
                        },
                    },
                },
            },
            "novel_modes": {
                "description": (
                    "Failures observed that no code in the current taxonomy "
                    "covers. Leave empty unless a genuine gap exists."
                ),
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["proposed_name", "definition", "agent_uid",
                                 "step_id", "evidence", "why_not_existing_code"],
                    "properties": {
                        "proposed_name": {"type": "string"},
                        "definition": {"type": "string"},
                        "agent_uid": {"type": "string"},
                        "step_id": {"type": "string"},
                        "evidence": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "additionalProperties": False,
                                "required": ["step_id", "quote"],
                                "properties": {
                                    "step_id": {"type": "string"},
                                    "quote": {"type": "string"},
                                },
                            },
                        },
                        "why_not_existing_code": {"type": "string"},
                    },
                },
            },
            "self_assessment": {
                "type": "object",
                "additionalProperties": False,
                "required": ["agent_level", "step_level", "mode_level",
                             "hardest_judgement"],
                "properties": {
                    "agent_level": {"type": "integer",
                                    "description": "0-100 confidence"},
                    "step_level": {"type": "integer"},
                    "mode_level": {"type": "integer"},
                    "hardest_judgement": {"type": "string"},
                },
            },
        },
    }


# --------------------------------------------------------------------------- #
# Parsed representation
# --------------------------------------------------------------------------- #

@dataclass
class Evidence:
    step_id: str
    quote: str
    match: Optional[SpanMatch] = None

    @property
    def grounded(self) -> bool:
        return bool(self.match and self.match.found)


@dataclass
class Finding:
    slot_index: int
    code: str
    agent_uid: str
    step_id: str
    evidence: list[Evidence]
    rationale: str
    confidence: str

    @property
    def groundedness(self) -> float:
        if not self.evidence:
            return 0.0
        return sum(e.match.score if e.match else 0.0
                   for e in self.evidence) / len(self.evidence)


@dataclass
class NovelProposal:
    proposed_name: str
    definition: str
    agent_uid: str
    step_id: str
    evidence: list[Evidence]
    why_not_existing_code: str


@dataclass
class Stage1Annotation:
    trace_id: str
    plan: SlotPlan
    verdicts: list[int]
    earliest_fault_step_id: Optional[str]
    findings: list[Finding]
    novel_modes: list[NovelProposal]
    self_assessment: dict[str, Any]
    violations: list[str] = field(default_factory=list)
    #: filled in by the Stage-1b scorer; index-aligned with ``plan.slots``
    p_positive: list[Optional[float]] = field(default_factory=list)
    #: verbalised 0-100 scores, same alignment. Kept separate from p_positive:
    #: a saturated logprob and a self-reported percentage fail in different
    #: ways, so pooling them would hide which regime a slot was scored under.
    p_verbalised: list[Optional[float]] = field(default_factory=list)
    #: slot index -> SteerConf diagnostics (mu_c, sigma_c, kappa_conf,
    #: kappa_ans). Kept separate from p_positive because a low kappa_ans means
    #: the steering levels disagreed, which is exactly what should be routed
    #: to a human and is invisible once collapsed into a single probability.
    steer_detail: dict = field(default_factory=dict)
    #: VPD's distribution over failure codes plus the `none` bucket. `p_none`
    #: is the model's belief that no existing code covers this trace, which is
    #: the quantity Stage 4 is trying to discover -- keep it, do not collapse
    #: it into the per-slot probabilities.
    vpd_detail: dict = field(default_factory=dict)

    def flagged_slots(self) -> list[Slot]:
        return [s for s, v in zip(self.plan.slots, self.verdicts) if v == 1]

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["plan"] = {"slots": [asdict(s) for s in self.plan.slots],
                     "mode_granularity": self.plan.mode_granularity,
                     "applicable_codes": self.plan.applicable_codes,
                     "excluded_codes": self.plan.excluded_codes}
        return d


# --------------------------------------------------------------------------- #
# Parsing + structural consistency
# --------------------------------------------------------------------------- #

def parse_reasoner_output(
    raw: dict[str, Any],
    trace: Trace,
    plan: SlotPlan,
    taxonomy: Taxonomy,
) -> Stage1Annotation:
    """Parse, ground every quote, and run the cross-level consistency checks.

    The returned ``violations`` list is not just diagnostics -- it is a feature
    vector for the uncertainty model.  A structurally incoherent annotation is
    an unreliable annotation even when the model claims high confidence.
    """
    violations: list[str] = []

    raw_v = raw.get("verdicts") or []
    if len(raw_v) != len(plan.slots):
        violations.append(
            f"verdict_length_mismatch:{len(raw_v)}!={len(plan.slots)}")
    verdicts = [1 if str(v).strip() == "1" else 0 for v in raw_v]
    verdicts = (verdicts + [0] * len(plan.slots))[:len(plan.slots)]

    def _ev(items: Iterable[dict]) -> list[Evidence]:
        out = []
        for e in items or []:
            sid = str(e.get("step_id", "")).strip()
            q = str(e.get("quote", ""))
            out.append(Evidence(sid, q, verify_span(trace, sid, q)))
        return out

    findings = [
        Finding(
            slot_index=int(f.get("slot_index", -1)),
            code=str(f.get("code", "")).strip(),
            agent_uid=str(f.get("agent_uid", "")).strip(),
            step_id=str(f.get("step_id", "")).strip(),
            evidence=_ev(f.get("evidence")),
            rationale=str(f.get("rationale", "")),
            confidence=str(f.get("confidence", "medium")),
        )
        for f in raw.get("findings") or []
    ]

    novel = [
        NovelProposal(
            proposed_name=str(n.get("proposed_name", "")),
            definition=str(n.get("definition", "")),
            agent_uid=str(n.get("agent_uid", "")),
            step_id=str(n.get("step_id", "")),
            evidence=_ev(n.get("evidence")),
            why_not_existing_code=str(n.get("why_not_existing_code", "")),
        )
        for n in raw.get("novel_modes") or []
    ]

    earliest = str(raw.get("earliest_fault_step_id", "")).strip()
    earliest = None if earliest.lower() in {"", "none", "null"} else earliest

    ann = Stage1Annotation(
        trace_id=trace.trace_id, plan=plan, verdicts=verdicts,
        earliest_fault_step_id=earliest, findings=findings,
        novel_modes=novel,
        self_assessment=raw.get("self_assessment") or {},
        p_positive=[None] * len(plan.slots),
        p_verbalised=[None] * len(plan.slots),
    )
    ann.violations = check_consistency(ann, trace, plan, taxonomy)
    ann.violations = violations + ann.violations
    return ann


def check_consistency(
    ann: Stage1Annotation,
    trace: Trace,
    plan: SlotPlan,
    taxonomy: Taxonomy,
) -> list[str]:
    v: list[str] = []
    slot_by_idx = {s.index: s for s in plan.slots}
    flagged_mode_slots = [s for s in ann.flagged_slots() if s.kind == "mode"]
    flagged_agents = {s.agent_uid for s in ann.flagged_slots() if s.kind == "agent"}
    flagged_steps = [s.step_id for s in ann.flagged_slots() if s.kind == "step"]

    # -- referential integrity ------------------------------------------- #
    for f in ann.findings:
        if f.agent_uid and trace.agent(f.agent_uid) is None:
            v.append(f"unknown_agent:{f.agent_uid}")
        if f.step_id and trace.step(f.step_id) is None:
            v.append(f"unknown_step:{f.step_id}")
        if f.code != NOVEL_CODE and taxonomy.get(f.code) is None:
            v.append(f"unknown_code:{f.code}")
        if f.slot_index not in slot_by_idx:
            v.append(f"finding_slot_out_of_range:{f.slot_index}")

    # -- evidence groundedness ------------------------------------------- #
    for f in ann.findings:
        if not f.evidence:
            v.append(f"finding_without_evidence:{f.code}")
        for e in f.evidence:
            if not e.grounded:
                v.append(f"ungrounded_quote:{f.code}@{e.step_id}")
            elif e.match and e.match.relocated:
                v.append(f"quote_step_misattributed:{f.code}@{e.step_id}"
                         f"->{e.match.step_id}")

    # -- phase legality --------------------------------------------------- #
    for f in ann.findings:
        m = taxonomy.get(f.code)
        st = trace.step(f.step_id)
        if m and st and st.phase not in m.allowed_phases:
            v.append(f"phase_illegal:{f.code}@{st.phase}")

    # -- cross-level coherence -------------------------------------------- #
    if flagged_mode_slots and not flagged_agents:
        v.append("mode_flagged_but_no_agent_flagged")
    if flagged_agents and not flagged_mode_slots and not ann.novel_modes:
        v.append("agent_flagged_but_no_mode_flagged")
    if flagged_mode_slots and ann.earliest_fault_step_id is None:
        v.append("mode_flagged_but_no_earliest_step")
    if ann.earliest_fault_step_id and not flagged_mode_slots and not ann.novel_modes:
        v.append("earliest_step_without_mode")

    if ann.earliest_fault_step_id:
        est = trace.step(ann.earliest_fault_step_id)
        if est is None:
            v.append(f"unknown_earliest_step:{ann.earliest_fault_step_id}")
        else:
            # nothing may be attributed strictly before the earliest fault
            for f in ann.findings:
                st = trace.step(f.step_id)
                if st and st.idx < est.idx:
                    v.append(f"finding_before_earliest:{f.step_id}<{est.step_id}")
            if flagged_steps and est.step_id not in flagged_steps:
                v.append("earliest_step_not_in_flagged_step_slots")
            owner = est.agent_uid
            if flagged_agents and owner not in flagged_agents:
                v.append(f"earliest_step_owner_not_flagged:{owner}")

    # -- an agent flagged with no finding anywhere in its own steps ------- #
    for uid in flagged_agents:
        card = trace.agent(uid)
        if card is None:
            continue
        own = set(card.step_ids)
        if not any(
            (f.step_id in own) or any(e.match and e.match.step_id in own
                                      for e in f.evidence)
            for f in ann.findings
        ):
            v.append(f"agent_flagged_without_local_evidence:{uid}")

    # -- NOVEL hygiene ----------------------------------------------------- #
    for n in ann.novel_modes:
        if not n.evidence or not any(e.grounded for e in n.evidence):
            v.append("novel_without_grounded_evidence")
        if len(n.definition.split()) < 8:
            v.append("novel_definition_too_thin")

    return v


# --------------------------------------------------------------------------- #
# Call 1b -- token-level scorer
# --------------------------------------------------------------------------- #

SCORER_SYSTEM = (
    "You are auditing one specific aspect of a medical multi-agent "
    "consultation transcript. Answer the question with a single character: "
    "1 if yes, 0 if no. Output nothing else -- no punctuation, no explanation."
)


def scorer_user_prompt(transcript: str, slot: Slot) -> str:
    return (
        f"{transcript}\n\n"
        f"### QUESTION\n{slot.question}\n\n"
        f"### ANSWER (single character, 1 or 0)\n"
    )


def batched_scorer_schema() -> dict[str, Any]:
    """Schema for the batched scorer call.

    Deliberately minimal -- ``verdicts`` is the ONLY property, so every "0" or
    "1" token in the response stream belongs to a verdict and positional
    alignment is unambiguous. Adding any other field would break that.
    """
    return {
        "type": "object", "additionalProperties": False,
        "required": ["verdicts"],
        "properties": {"verdicts": {
            "type": "array",
            "items": {"type": "string", "enum": ["0", "1"]}}},
    }


def batched_scorer_prompt(transcript: str, slots: Sequence["Slot"]) -> str:
    qs = "\n".join(f"{i + 1}. {s.question}" for i, s in enumerate(slots))
    return (f"{transcript}\n\n"
            f"### QUESTIONS\n{qs}\n\n"
            f"Answer each question independently with \"1\" (yes) or \"0\" (no). "
            f"Return exactly {len(slots)} verdicts, in the order asked.\n")


def p_positive_series_from_logprobs(
    token_logprobs: list[dict[str, Any]],
    n_expected: int,
    positive_token: str = "1",
    negative_token: str = "0",
) -> list[Optional[float]]:
    """Read p(1) for each verdict from one batched response.

    The observed token stream for a two-verdict response is

        ['{"', 'ver', 'dict', 's', '":["', '1', '","', '0', '"]', '}']

    so the verdict values arrive as clean single tokens. We take them in
    order; if the count does not match, we return what we have padded with
    None rather than guessing an alignment, because a silently misaligned
    verdict is worse than a missing one.
    """
    out: list[Optional[float]] = []
    for tok in token_logprobs:
        text = str(tok.get("token", "")).strip().strip('"').strip(",").strip("[")
        if text not in {positive_token, negative_token}:
            continue
        alts = {str(a.get("token", "")).strip().strip('"'): a.get("logprob")
                for a in tok.get("top_logprobs") or []}
        alts.setdefault(text, tok.get("logprob"))
        lp_pos, lp_neg = alts.get(positive_token), alts.get(negative_token)
        if lp_pos is None and lp_neg is None:
            out.append(1.0 if text == positive_token else 0.0)
        elif lp_pos is None:
            out.append(max(0.0, 1.0 - math.exp(lp_neg)))
        elif lp_neg is None:
            out.append(min(1.0, math.exp(lp_pos)))
        else:
            a, b = math.exp(lp_pos), math.exp(lp_neg)
            out.append(a / (a + b) if (a + b) > 0 else 0.5)
    if len(out) != n_expected:
        out = (out + [None] * n_expected)[:n_expected]
    return out


def p_positive_from_logprobs(
    token_logprobs: list[dict[str, Any]],
    positive_token: str = "1",
    negative_token: str = "0",
) -> Optional[float]:
    """Read p(1) off the first content token of a scorer response.

    ``token_logprobs`` is the provider's per-token list; each element is
    expected to expose ``token`` and ``top_logprobs`` (a list of
    ``{"token", "logprob"}``).  We renormalise over {0, 1} only, so stray
    probability mass on whitespace or quote tokens does not deflate the score.
    """
    for tok in token_logprobs:
        text = str(tok.get("token", "")).strip().strip('"')
        if text not in {positive_token, negative_token}:
            continue
        alts = {str(a.get("token", "")).strip().strip('"'): a.get("logprob")
                for a in tok.get("top_logprobs") or []}
        alts.setdefault(text, tok.get("logprob"))
        lp_pos, lp_neg = alts.get(positive_token), alts.get(negative_token)
        if lp_pos is None and lp_neg is None:
            return 1.0 if text == positive_token else 0.0
        if lp_pos is None:
            return max(0.0, 1.0 - math.exp(lp_neg))
        if lp_neg is None:
            return min(1.0, math.exp(lp_pos))
        a, b = math.exp(lp_pos), math.exp(lp_neg)
        return a / (a + b) if (a + b) > 0 else 0.5
    return None


def scorer_slot_budget(
    ann: Stage1Annotation,
    plan: SlotPlan,
    negatives_per_kind: int = 3,
    rng_seed: int = 0,
) -> list[Slot]:
    """Which slots to spend a scorer call on.

    All flagged slots (we need calibrated p for anything we might route), plus
    a stratified sample of unflagged ones so the calibration set is not
    conditioned on the reasoner having said yes.
    """
    import random

    rng = random.Random(rng_seed)
    chosen = {s.index for s in ann.flagged_slots()}
    for kind in ("agent", "step", "mode"):
        pool = [s for s in plan.of_kind(kind) if s.index not in chosen]
        rng.shuffle(pool)
        chosen.update(s.index for s in pool[:negatives_per_kind])
    return [s for s in plan.slots if s.index in chosen]
