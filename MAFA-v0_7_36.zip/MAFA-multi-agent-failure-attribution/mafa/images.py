"""Attach the images a trace refers to, for the annotator only.

The AEGIS traces name their images but do not carry them: `Trace.images` holds
`['MM-1-a.png']` and the transcript says `IMAGE PROVIDED: Yes (1)`. The
question text goes further and says so out loud —

    [Note: this question references 2 image(s): MM-1-a.png, MM-1-b.png.
     A multimodal-capable agent should consult the image(s) for diagnosis.]

— so the **agents under audit never saw the pixels either**. That is a fact
about the traces and is not something to fix: changing it would audit a
different system than the one that ran.

What can change is what the *annotator* sees. Code `1.2.1` is "neglect or
misinterpretation of modality information", and deciding whether an agent
misread a mammogram is not possible from the agent's own prose. Without the
image the annotator can only judge whether the wording *sounds* like someone
answering blind, which is a different question and probably explains why 1.2.1
has been the least stable code in this project — `rate_spread` 1.00 on one
cluster, three re-audits returning 0, 1, 1.

Off by default. Turning it on makes mdagents annotations a new measurement
that cannot be pooled with any existing run, so the only honest use is a
paired comparison: the same traces, the same annotator, images the only
variable.
"""
from __future__ import annotations

import base64
from pathlib import Path
from typing import Iterable, Optional

#: extensions the corpus actually uses (2235 .jpeg, 283 .png, 3 .JPG)
_MEDIA = {".png": "image/png", ".jpg": "image/jpeg",
          ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp"}


class ImageStore:
    """Filename -> bytes, over one or more directories.

    Matching is case-insensitive on the stem and the extension is taken from
    whatever is on disk, because the corpus mixes `.jpeg` and `.JPG` and a
    trace may name either.
    """

    def __init__(self, roots: Iterable[str | Path]) -> None:
        self._by_name: dict[str, Path] = {}
        for root in roots:
            root = Path(root)
            if not root.exists():
                continue
            for p in root.rglob("*"):
                if p.is_file() and p.suffix.lower() in _MEDIA:
                    self._by_name.setdefault(p.name.lower(), p)

    def __len__(self) -> int:
        return len(self._by_name)

    def get(self, name: str) -> Optional[Path]:
        return self._by_name.get(name.lower())

    def coverage(self, traces) -> tuple[int, int, list[str]]:
        """(referenced, missing, examples) across a set of traces."""
        ref = miss = 0
        examples: list[str] = []
        for t in traces:
            for name in (getattr(t, "images", None) or []):
                ref += 1
                if self.get(name) is None:
                    miss += 1
                    if len(examples) < 5:
                        examples.append(name)
        return ref, miss, examples

    def blocks(self, trace, max_images: Optional[int] = None,
               max_total_bytes: int = 24_000_000
               ) -> tuple[list[dict], list[str]]:
        """Return ``(blocks, dropped)`` for a trace's images, in trace order.

        **No cap by default.** An earlier version defaulted to four, which
        would have silently truncated 102 of the mdagents traces -- 92 carry
        five images and 10 carry six. A question that references six images
        and gets four is a different question, and nothing in the output would
        have said so. Counts here are 1:1341, 2:222, 3:60, 4:9, 5:92, 6:10.

        Whatever is dropped, for any reason, comes back in ``dropped`` so the
        caller can record it. Silent truncation is the failure mode this
        method exists to avoid.
        """
        names = list(getattr(trace, "images", None) or [])
        out: list[dict] = []
        dropped: list[str] = []
        total = 0
        for i, name in enumerate(names):
            if max_images is not None and len(out) >= max_images:
                dropped.append(f"{name} (over max_images={max_images})")
                continue
            p = self.get(name)
            if p is None:
                dropped.append(f"{name} (not found)")
                continue
            raw = p.read_bytes()
            # base64 inflates by ~4/3; budget against the encoded size
            enc = len(raw) * 4 // 3
            if total + enc > max_total_bytes:
                dropped.append(f"{name} (over byte budget)")
                continue
            total += enc
            out.append({
                "type": "image_url",
                "image_url": {"url": f"data:{_MEDIA[p.suffix.lower()]};base64,"
                                     + base64.b64encode(raw).decode()}})
        return out, dropped


IMAGE_PREAMBLE = (
    "The image(s) below are the ones this question refers to. The agents in "
    "the transcript did NOT see them -- they were given only a note saying "
    "images exist. Use the image(s) to judge whether an agent's claims about "
    "the imaging findings are correct. Do not fault an agent merely for not "
    "describing the image."
)


def shard_preserving_ids(src: str | Path, out_root: str | Path,
                         n_shards: int, limit: Optional[int] = None
                         ) -> list[Path]:
    """Split a corpus file into shards WITHOUT changing any trace_id.

    `trace_id` embeds the record's line number in its source file
    (`...#00000#MM-1`), so the obvious `awk 'NR%3==i'` split renumbers from 1
    in every shard and quietly renames every trace. Nothing errors: the
    annotations complete and simply no longer match the corpus. That fault has
    landed three times here -- 51 traces unpaired in the fold-back run, a
    `KeyError` in the image comparison, and an image-ablation batch that was
    reported as "3 positive verdicts, 0 flips" when the real figures were 12
    and 3, because most lookups missed silently and the comparison ran on
    nearly nothing.

    Padding each shard so every record keeps its original line index is the
    cheap fix: blank lines are skipped by the loader, so a record written at
    line 7 of a shard is still line 7 of the original.
    """
    src = Path(src)
    out_root = Path(out_root)
    lines = src.read_text(encoding="utf-8").splitlines()
    if limit is not None:
        lines = lines[:limit]
    made: list[Path] = []
    for k in range(n_shards):
        d = out_root / f"shard_{k}"
        d.mkdir(parents=True, exist_ok=True)
        p = d / src.name
        with p.open("w", encoding="utf-8") as fh:
            for i, line in enumerate(lines):
                fh.write((line if i % n_shards == k else "") + "\n")
        made.append(p)
    return made
