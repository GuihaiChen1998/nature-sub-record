#!/usr/bin/env python3
"""
make_figure.py
==============
Emits the framework figure as a hand-controlled SVG.

    python make_figure.py                 -> framework.svg
    python make_figure.py --grey          -> framework_grey.svg  (print-safe)
    python make_figure.py --png out.png   -> also rasterise (needs cairosvg)

Everything is driven by the LAYOUT constants below, so nudging a block is a
one-line change and every arrow that touches it follows.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass

W, H = 1900, 1040

# --------------------------------------------------------------------------- #
# Palette
# --------------------------------------------------------------------------- #

COLOUR = {
    "slate":      "#4A5A6A",
    "teal":       "#2E7D74",
    "amber":      "#C89B3C",
    "indigo":     "#4C5BA8",
    "terracotta": "#B5654A",
    "green":      "#4A7C59",
    "orange":     "#C4703A",
    "ink":        "#26292E",
    "muted":      "#6B7280",
    "line":       "#5A6472",
    "fill":       "#F7F6F4",
    "fill2":      "#FFFFFF",
    "band":       "#FCFBFA",
}

GREY = {
    "slate": "#4D4D4D", "teal": "#5E5E5E", "amber": "#727272",
    "indigo": "#404040", "terracotta": "#333333", "green": "#5E5E5E",
    "orange": "#727272", "ink": "#1A1A1A", "muted": "#666666",
    "line": "#4D4D4D", "fill": "#F4F4F4", "fill2": "#FFFFFF",
    "band": "#FAFAFA",
}

FONT_SCALE = 1.0        # bumped by --text-scale
FONT = "Inter, 'Helvetica Neue', Helvetica, Arial, sans-serif"


# --------------------------------------------------------------------------- #
# Layout
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Box:
    x: float
    y: float
    w: float
    h: float

    @property
    def cx(self): return self.x + self.w / 2

    @property
    def cy(self): return self.y + self.h / 2

    @property
    def r(self): return self.x + self.w

    @property
    def b(self): return self.y + self.h


L = {
    # --- upper band ------------------------------------------------------ #
    "traces":     Box(46, 196, 152, 232),
    "adapter":    Box(238, 168, 168, 288),
    "stage1":     Box(446, 104, 292, 428),
    "s1_reason":  Box(468, 168, 248, 104),
    "s1_scorer":  Box(468, 300, 248, 84),
    "s1_checks":  Box(468, 412, 248, 100),
    "stage2":     Box(778, 150, 296, 268),
    "headA":      Box(798, 222, 128, 96),
    "headB":      Box(942, 222, 112, 96),
    "anchor":     Box(866, 470, 132, 74),
    "stage3":     Box(1100, 150, 210, 268),
    "tags":       Box(1342, 168, 158, 42),          # first tag; step 56
    "expert":     Box(1548, 286, 84, 92),
    "corpus":     Box(1700, 196, 140, 96),
    # --- lower band ------------------------------------------------------ #
    "stage4":     Box(206, 692, 1420, 292),
    "residual":   Box(1412, 760, 190, 92),
    "cluster":    Box(1172, 760, 190, 92),
    "reaudit":    Box(932, 760, 190, 92),
    "gate":       Box(672, 760, 190, 92),
    "taxo":       Box(392, 760, 210, 92),
    "branchB":    Box(900, 876, 196, 34),
    "branchA":    Box(900, 928, 196, 34),
}

TAG_STEP = 56
TAGS = [("AUTO", "green"), ("VERIFY", "amber"),
        ("REVIEW", "orange"), ("NOVEL", "terracotta")]


def tag_box(i: int) -> Box:
    t = L["tags"]
    return Box(t.x, t.y + i * TAG_STEP, t.w, t.h)


# --------------------------------------------------------------------------- #
# Primitives
# --------------------------------------------------------------------------- #

class SVG:
    def __init__(self, palette):
        self.p = palette
        self.out: list[str] = []

    def add(self, s: str):
        self.out.append(s)

    def esc(self, s: str) -> str:
        return (s.replace("&", "&amp;").replace("<", "&lt;")
                 .replace(">", "&gt;"))

    def rect(self, b: Box, *, fill="fill", stroke=None, sw=2.0, rx=8,
             dash=None, opacity=1.0):
        f = self.p.get(fill, fill)
        st = f'stroke="{self.p.get(stroke, stroke)}" stroke-width="{sw}"' if stroke else 'stroke="none"'
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<rect x="{b.x}" y="{b.y}" width="{b.w}" height="{b.h}" '
                 f'rx="{rx}" ry="{rx}" fill="{f}" fill-opacity="{opacity}" {st}{d}/>')

    def text(self, x, y, s, *, size=14, weight=400, anchor="middle",
             fill="ink", ls=0, italic=False):
        size = round(size * FONT_SCALE, 2)
        st = ' font-style="italic"' if italic else ""
        self.add(f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{size}" '
                 f'font-weight="{weight}" text-anchor="{anchor}" '
                 f'letter-spacing="{ls}" fill="{self.p.get(fill, fill)}"{st}>'
                 f'{self.esc(s)}</text>')

    def lines(self, x, y, rows, *, size=12, lh=16, fill="muted", weight=400,
              anchor="middle"):
        for i, r in enumerate(rows):
            self.text(x, y + i * lh, r, size=size, fill=fill,
                      weight=weight, anchor=anchor)

    def path(self, d, *, stroke="line", sw=1.8, marker="ar_line", dash=None,
             fill="none"):
        da = f' stroke-dasharray="{dash}"' if dash else ""
        mk = f' marker-end="url(#{marker})"' if marker else ""
        self.add(f'<path d="{d}" fill="{fill}" stroke="{self.p.get(stroke, stroke)}" '
                 f'stroke-width="{sw}" stroke-linecap="round" '
                 f'stroke-linejoin="round"{da}{mk}/>')

    def arrow_h(self, x1, x2, y, **kw):
        self.path(f"M {x1} {y} L {x2} {y}", **kw)

    def arrow_v(self, x, y1, y2, **kw):
        self.path(f"M {x} {y1} L {x} {y2}", **kw)

    def cylinder(self, b: Box, *, stroke="slate", fill="fill2", sw=2.0):
        ry = 13
        st, f = self.p.get(stroke, stroke), self.p.get(fill, fill)
        self.add(
            f'<path d="M {b.x} {b.y+ry} L {b.x} {b.b-ry} '
            f'A {b.w/2} {ry} 0 0 0 {b.r} {b.b-ry} L {b.r} {b.y+ry} Z" '
            f'fill="{f}" stroke="{st}" stroke-width="{sw}"/>')
        self.add(f'<ellipse cx="{b.cx}" cy="{b.y+ry}" rx="{b.w/2}" ry="{ry}" '
                 f'fill="{f}" stroke="{st}" stroke-width="{sw}"/>')

    def person(self, cx, cy, *, stroke="indigo", sw=2.0):
        st = self.p.get(stroke, stroke)
        self.add(f'<circle cx="{cx}" cy="{cy-16}" r="11" fill="none" '
                 f'stroke="{st}" stroke-width="{sw}"/>')
        self.add(f'<path d="M {cx-19} {cy+16} a 19 19 0 0 1 38 0" fill="none" '
                 f'stroke="{st}" stroke-width="{sw}" stroke-linecap="round"/>')

    def group_header(self, b: Box, colour: str, kicker: str, title: str):
        """Coloured container with a tinted header strip.

        Narrow containers stack the kicker over the title; side-by-side would
        collide, which is exactly the kind of thing a generated figure gets
        wrong and a hand-built one should not.
        """
        stacked = b.w < 240
        hh = 52 if stacked else 34
        self.rect(b, fill="band", stroke=colour, sw=2.4, rx=12)
        self.add(f'<path d="M {b.x} {b.y+hh} L {b.x} {b.y+12} '
                 f'a 12 12 0 0 1 12 -12 L {b.r-12} {b.y} '
                 f'a 12 12 0 0 1 12 12 L {b.r} {b.y+hh} Z" '
                 f'fill="{self.p.get(colour, colour)}" fill-opacity="0.10"/>')
        if stacked:
            self.text(b.cx, b.y + 20, kicker, size=11, weight=700,
                      anchor="middle", fill=colour, ls=1.1)
            self.text(b.cx, b.y + 41, title, size=14.5, weight=700,
                      anchor="middle", fill=colour)
        else:
            self.text(b.x + 14, b.y + 23, kicker, size=11.5, weight=700,
                      anchor="start", fill=colour, ls=1.1)
            self.text(b.r - 14, b.y + 23, title, size=15, weight=700,
                      anchor="end", fill=colour)

    def render(self) -> str:
        defs = []
        markers = [("ar_line", "line"), ("ar_terra", "terracotta")]
        markers += [(f"ar_{k}", k) for k in
                    ("terracotta", "green", "amber", "orange", "indigo",
                     "slate", "teal")]
        for name, col in markers:
            c = self.p.get(col, col)
            defs.append(
                f'<marker id="{name}" viewBox="0 0 10 10" refX="9" refY="5" '
                f'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{c}"/></marker>')
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
            f'viewBox="0 0 {W} {H}">\n<defs>\n' + "\n".join(defs) +
            f'\n</defs>\n<rect width="{W}" height="{H}" fill="#FFFFFF"/>\n' +
            "\n".join(self.out) + "\n</svg>\n")


# --------------------------------------------------------------------------- #
# The figure
# --------------------------------------------------------------------------- #

def build(palette) -> str:
    s = SVG(palette)

    # ===== band captions ================================================== #
    s.text(46, 78, "Automated annotation pass  ·  one trace, left to right",
           size=13, weight=600, anchor="start", fill="muted", ls=0.4)
    s.text(206, 668,
           "Evolution pass  ·  what the taxonomy could not absorb, right to left",
           size=13, weight=600, anchor="start", fill="muted", ls=0.4)

    # ===== 0. traces ====================================================== #
    b = L["traces"]
    s.text(b.cx, b.y - 34, "Medical MAS traces", size=14, weight=700)
    s.text(b.cx, b.y - 16, "unlabelled  ·  n = 1,552", size=11.5, fill="muted")
    for i, name in enumerate(["MDAgents", "DyLAN",
                              "ClinicalAgent", "ClinicalAgent-5"]):
        r = Box(b.x, b.y + i * 58, b.w, 46)
        s.rect(r, fill="fill", stroke="slate", sw=1.8, rx=7)
        s.text(r.cx, r.cy + 5, name, size=13.5, weight=500, fill="slate")

    # ===== Stage 0. adapter =============================================== #
    a = L["adapter"]
    s.group_header(a, "slate", "STAGE 0", "Trace Adapter")
    for i, (t, sub) in enumerate([
            ("Unified Trace", "step ids · char offsets"),
            ("Capability Mask", "structure, not MAS name")]):
        r = Box(a.x + 16, a.y + 84 + i * 92, a.w - 32, 70)
        s.rect(r, fill="fill2", stroke="slate", sw=1.6, rx=7)
        s.text(r.cx, r.cy - 4, t, size=13.5, weight=600, fill="ink")
        s.text(r.cx, r.cy + 15, sub, size=10.5, fill="muted")
    s.text(a.cx, a.b - 14, "agent-uid = name–role_index", size=10.5,
           fill="muted", italic=True)

    # ===== Stage 1. annotation ============================================ #
    g = L["stage1"]
    s.group_header(g, "teal", "STAGE 1", "Annotation")
    r = L["s1_reason"]
    s.rect(r, fill="fill2", stroke="teal", sw=1.8, rx=7)
    s.text(r.cx, r.y + 28, "1a  Reasoner", size=14, weight=700, fill="teal")
    s.lines(r.cx, r.y + 48, ["structured output · outcome-blind",
                             "slot verdicts · verbatim evidence",
                             "earliest step · NOVEL proposals"], size=10.8, lh=15)
    r2 = L["s1_scorer"]
    s.rect(r2, fill="fill2", stroke="teal", sw=1.8, rx=7)
    s.text(r2.cx, r2.y + 28, "1b  Scorer", size=14, weight=700, fill="teal")
    s.lines(r2.cx, r2.y + 48, ["single token · logprobs",
                               "one anchor question at a time"], size=10.8, lh=15)
    r3 = L["s1_checks"]
    s.rect(r3, fill="fill2", stroke="teal", sw=1.8, rx=7, dash="5 4")
    s.text(r3.cx, r3.y + 26, "Offline Checks", size=13, weight=700, fill="teal")
    s.lines(r3.cx, r3.y + 46, ["evidence grounding",
                               "structural consistency",
                               "zero extra API cost"], size=10.8, lh=15)
    s.arrow_v(r.cx, r.b + 3, r2.y - 5, stroke="teal", marker="ar_line", sw=1.6)
    s.arrow_v(r2.cx, r2.b + 3, r3.y - 5, stroke="teal", marker="ar_line", sw=1.6)

    # ===== Stage 2. calibration =========================================== #
    c = L["stage2"]
    s.group_header(c, "amber", "STAGE 2", "Calibration")
    for box, title, sub, note in [
            (L["headA"], "Head A", "P(label = 1)", "calibrated verdict"),
            (L["headB"], "Head B", "P(agreement)", "is it resolvable?")]:
        s.rect(box, fill="fill2", stroke="amber", sw=1.8, rx=7)
        s.text(box.cx, box.y + 28, title, size=13.5, weight=700, fill="amber")
        s.text(box.cx, box.y + 50, sub, size=12, weight=600, fill="ink")
        s.text(box.cx, box.y + 70, note, size=10.5, fill="muted")
    s.text(c.cx, c.b - 18, "fitted per slot kind  ·  13 hybrid features",
           size=10.8, fill="muted")
    an = L["anchor"]
    s.cylinder(an, stroke="amber")
    s.text(an.cx, an.cy + 4, "Anchor Set", size=12.5, weight=700, fill="ink")
    s.text(an.cx, an.cy + 21, "human-labelled", size=10.5, fill="muted")
    s.text(an.cx, an.b + 20, "the only human supervision", size=10.5,
           fill="muted", italic=True)
    s.arrow_v(an.cx, an.y - 4, c.b + 6, stroke="amber", sw=1.6)

    # ===== Stage 3. router ================================================ #
    t3 = L["stage3"]
    s.group_header(t3, "indigo", "STAGE 3", "Router")
    s.text(t3.cx, t3.y + 68, "Split Conformal", size=14, weight=700, fill="indigo")
    s.lines(t3.cx, t3.y + 96, ["coverage \u2265 1 \u2212 \u03b1",
                               "Mondrian by framework",
                               "", "set size = decision"], size=11.2, lh=17)
    s.text(t3.cx, t3.b - 26, "|S| = 1 \u2192 auto      |S| = 0 \u2192 novel",
           size=10.8, fill="muted")

    # ===== tags =========================================================== #
    tag_meta = {
        "AUTO":   ("|S| = 1", "green"),
        "VERIFY": ("|S| = 2\u20133", "amber"),
        "REVIEW": ("|S| > 3", "orange"),
        "NOVEL":  ("|S| = 0", "terracotta"),
    }
    for i, (name, col) in enumerate(TAGS):
        tb = tag_box(i)
        s.rect(tb, fill="fill2", stroke=col, sw=2.2, rx=18)
        s.text(tb.x + 18, tb.cy + 5, name, size=13, weight=700,
               anchor="start", fill=col)
        s.text(tb.r - 16, tb.cy + 4, tag_meta[name][0], size=10.5,
               anchor="end", fill="muted")
        s.path(f"M {t3.r + 4} {t3.cy} C {t3.r + 26} {t3.cy}, "
               f"{tb.x - 26} {tb.cy}, {tb.x - 5} {tb.cy}",
               stroke=col, sw=1.7, marker=f"ar_{col}")

    # ===== expert + corpus ================================================ #
    ex = L["expert"]
    s.rect(ex, fill="fill2", stroke="indigo", sw=1.6, rx=8, dash="4 4")
    s.person(ex.cx, ex.cy - 6, stroke="indigo")
    s.text(ex.cx, ex.b - 10, "Expert", size=11.5, weight=700, fill="indigo")
    s.text(ex.cx, ex.b + 18, "closed-form choice", size=10.5, fill="muted")
    s.text(ex.cx, ex.b + 33, "from the set", size=10.5, fill="muted")

    cp = L["corpus"]
    s.cylinder(cp, stroke="green")
    s.text(cp.cx, cp.cy + 2, "Labelled", size=13, weight=700, fill="ink")
    s.text(cp.cx, cp.cy + 20, "Corpus", size=13, weight=700, fill="ink")
    for i, lab in enumerate(["agent", "step", "mode"]):
        lb = Box(cp.x + i * 44, cp.b + 16, 40, 24)
        s.rect(lb, fill="fill", stroke="green", sw=1.3, rx=6)
        s.text(lb.cx, lb.cy + 4, lab, size=10, weight=600, fill="green")
    s.text(cp.cx, cp.b + 60, "three-level joint labels", size=10.5,
           fill="muted", italic=True)

    ta, tv, tr = tag_box(0), tag_box(1), tag_box(2)
    s.path(f"M {ta.r + 6} {ta.cy} C {ta.r + 90} {ta.cy}, "
           f"{cp.x - 40} {cp.cy - 30}, {cp.x - 6} {cp.cy - 14}",
           stroke="green", sw=1.9, marker="ar_green")
    s.path(f"M {tv.r + 6} {tv.cy} C {tv.r + 60} {tv.cy}, "
           f"{ex.x - 24} {ex.cy}, {ex.x - 6} {ex.cy}",
           stroke="amber", sw=1.9, marker="ar_amber")
    s.path(f"M {tr.r + 6} {tr.cy} C {tr.r + 58} {tr.cy}, "
           f"{ex.x - 20} {ex.b - 12}, {ex.x - 6} {ex.b - 16}",
           stroke="orange", sw=1.6, marker="ar_orange", dash="5 4")
    s.path(f"M {ex.r + 4} {ex.cy - 10} C {ex.r + 26} {ex.cy - 10}, "
           f"{cp.x - 26} {cp.cy + 22}, {cp.x - 6} {cp.cy + 14}",
           stroke="indigo", sw=1.9, marker="ar_line")

    # ===== main left-to-right arrows ====================================== #
    mid = 300
    for x1, x2 in [(L["traces"].r + 4, L["adapter"].x - 6),
                   (L["adapter"].r + 4, L["stage1"].x - 6),
                   (L["stage1"].r + 4, L["stage2"].x - 6),
                   (L["stage2"].r + 4, L["stage3"].x - 6)]:
        s.arrow_h(x1, x2, mid, stroke="line", sw=2.0)

    # ===== Stage 4. evolution ============================================= #
    e = L["stage4"]
    s.group_header(e, "terracotta", "STAGE 4", "Taxonomy Evolution")
    steps = [
        (L["residual"], "Residual Pool", ["NOVEL · empty sets",
                                          "grounded evidence only"]),
        (L["cluster"], "HDBSCAN", ["no \u03b5 to transfer",
                                   "explicit noise label"]),
        (L["reaudit"], "Unmasked Re-audit", ["all masks removed",
                                             "all seed codes offered"]),
        (L["gate"], "Admission Gate", ["G1 support · G2 distinctness",
                                  "G3 utility · G4 anti-regression"]),
        (L["taxo"], "Taxonomy  T(k+1)", ["versioned · changelog"]),
    ]
    for box, title, subs in steps:
        s.rect(box, fill="fill2", stroke="terracotta", sw=1.9, rx=7)
        s.text(box.cx, box.y + 30, title, size=13.5, weight=700, fill="ink")
        s.lines(box.cx, box.y + 52, subs, size=10.5, lh=15)
    for left, right in [(L["cluster"], L["residual"]),
                        (L["reaudit"], L["cluster"]),
                        (L["gate"], L["reaudit"]),
                        (L["taxo"], L["gate"])]:
        s.arrow_h(right.x - 4, left.r + 6, right.cy,
                  stroke="terracotta", sw=1.9, marker="ar_terra")

    # triage split: labels ride on the arrows, so nothing crosses a box
    ra, gate, taxo = L["reaudit"], L["gate"], L["taxo"]
    dx, dy, dr = ra.cx, ra.b + 46, 20
    s.path(f"M {ra.cx} {ra.b + 2} L {ra.cx} {dy - dr - 2}",
           stroke="terracotta", sw=1.9, marker=None)
    s.add(f'<path d="M {dx} {dy-dr} L {dx+dr} {dy} L {dx} {dy+dr} '
          f'L {dx-dr} {dy} Z" fill="{palette["fill2"]}" '
          f'stroke="{palette["terracotta"]}" stroke-width="1.9"/>')
    s.text(dx, dy + 4, "?", size=15, weight=700, fill="terracotta")
    s.text(dx + dr + 10, dy + 4, "triage", size=10.5, anchor="start",
           fill="muted", italic=True)

    yB, yA = dy, dy + 54
    s.path(f"M {dx - dr - 2} {yB} L {gate.cx + 12} {yB} "
           f"Q {gate.cx} {yB}, {gate.cx} {yB - 12} L {gate.cx} {gate.b + 6}",
           stroke="terracotta", sw=2.2, marker="ar_terra")
    s.path(f"M {dx} {dy + dr + 2} L {dx} {yA - 12} "
           f"Q {dx} {yA}, {dx - 12} {yA} L {taxo.cx + 12} {yA} "
           f"Q {taxo.cx} {yA}, {taxo.cx} {yA - 12} L {taxo.cx} {taxo.b + 6}",
           stroke="terracotta", sw=1.5, marker="ar_terra", dash="5 4")

    s.add(f'<rect x="{taxo.cx + 18}" y="{yA - 11}" width="212" height="22" '
          f'rx="11" fill="{palette["band"]}"/>')
    s.text(taxo.cx + 124, yA + 4, "absorbed \u2014 bypasses the gate",
           size=9.8, fill="muted", italic=True)
    for txt, x, y, weight, fill, wbox in [
            ("B  \u00b7  new failure type", 888, yB, 700, "terracotta", 178),
            ("A  \u00b7  scope revision", 838, yA, 600, "muted", 158)]:
        s.add(f'<rect x="{x - wbox/2}" y="{y - 12}" width="{wbox}" '
              f'height="24" rx="12" fill="{palette["band"]}"/>')
        s.text(x, y + 4, txt, size=12, weight=weight, fill=fill)

    # ===== cross-band: NOVEL -> residual pool ============================= #
    tn = tag_box(3)
    s.path(f"M {tn.cx} {tn.b + 4} L {tn.cx} 620 "
           f"Q {tn.cx} 640, {tn.cx + 20} 640 "
           f"L {L['residual'].cx - 20} 640 "
           f"Q {L['residual'].cx} 640, {L['residual'].cx} 660 "
           f"L {L['residual'].cx} {L['residual'].y - 6}",
           stroke="terracotta", sw=2.0, marker="ar_terra")

    # ===== cross-band: T(k+1) -> Stage 1  (the self-evolution loop) ======= #
    tx, st1 = L["taxo"], L["stage1"]
    loop_y, loop_x = 600, 268
    s.path(f"M {tx.x - 6} {tx.cy} L {loop_x + 20} {tx.cy} "
           f"Q {loop_x} {tx.cy}, {loop_x} {tx.cy - 20} "
           f"L {loop_x} {loop_y + 20} "
           f"Q {loop_x} {loop_y}, {loop_x + 20} {loop_y} "
           f"L {st1.cx - 20} {loop_y} "
           f"Q {st1.cx} {loop_y}, {st1.cx} {loop_y - 20} "
           f"L {st1.cx} {st1.b + 8}",
           stroke="terracotta", sw=3.2, marker="ar_terra")
    s.add(f'<rect x="{st1.cx - 112}" y="{loop_y - 15}" width="208" height="28" '
          f'rx="14" fill="#FFFFFF"/>')
    s.text(st1.cx - 8, loop_y + 5, "self-evolution loop", size=13,
           weight=700, fill="terracotta")

    return s.render()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--grey", action="store_true",
                    help="greyscale variant for black-and-white printing")
    ap.add_argument("--out", default=None)
    ap.add_argument("--png", default=None)
    ap.add_argument("--text-scale", type=float, default=1.0,
                    help="multiply every font size; use ~1.3 when the figure "
                         "will be printed at column width rather than viewed "
                         "on screen")
    a = ap.parse_args()

    global FONT_SCALE
    FONT_SCALE = a.text_scale
    palette = GREY if a.grey else COLOUR
    svg = build(palette)
    out = a.out or ("framework_grey.svg" if a.grey else "framework.svg")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(svg)
    print(f"wrote {out}")

    if a.png:
        import cairosvg
        cairosvg.svg2png(bytestring=svg.encode(), write_to=a.png, scale=1.0)
        print(f"wrote {a.png}")


if __name__ == "__main__":
    main()
