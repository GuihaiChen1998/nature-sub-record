# Candidate failure codes for review — `run_ab4_faulty_n180`
180 traces, 525 residual items, 10 clusters, 1 admitted.
Read the quotes before the definition. The definition was written by a model that had just been shown the cluster and asked what its members share, so it will read as coherent whether or not the cluster is. The quotes come from the transcripts.
For each code below:
- [ ] **Real mechanism**, or an artefact of clustering?
- [ ] **Do the quotes show one mechanism**, or several?
- [ ] **Would a clinician call this an error** in the consultation?

---

## All-cause trial-failure rate used as safety evidence
cluster 8 · support **75** · triage `B` · **admitted**
frameworks: clinical_agent 16, clinical_agent5 59 · phases: independent_analysis 74, decision 1

nearest held-out code: `2.2.1` (cosine 0.4813) — judged distinct

**Evidence from the transcripts** (5 of 109 quotes, 75 members):

> Historical data for targeted diseases like stage III grade 1 follicular lymphoma (failure rate 0.55, moderate-high) indicate tolerable safety in similar populations, reducing the likelihood of safety-driven trial halts.
>
> — `clinical_agent` / independent_analysis / proposed as *Irrelevant surrogate inference*

> Historical data for targeted diseases like stage III grade 1 follicular lymphoma (failure rate 0.55, moderate-high) indicate tolerable safety in similar populations, reducing the likelihood of safety-driven trial halts.
>
> — `clinical_agent` / independent_analysis / proposed as *Invalid aggregate-outcome proxy for regimen safety*

> The safety profile strongly favors clinical-trial success due to the use of well-established CHOP-based regimens and supportive chemotherapies with a historical failure rate of 0.42 in lymphoma trials, indicating manageable toxicities.
>
> — `clinical_agent` / independent_analysis / proposed as *Metric category error in safety assessment*

> Historical failure rate for the drug (0.42) is lower than for refractory brain tumors (0.55), indicating a safety profile that moderately favors clinical-trial success by reducing attrition from adverse events.
>
> — `clinical_agent` / independent_analysis / proposed as *Metric-semantic conflation*

> Historical failure rate for the drug (0.42) is lower than for refractory brain tumors (0.55), indicating a safety profile that moderately favors clinical-trial success by reducing attrition from adverse events.
>
> — `clinical_agent` / independent_analysis / proposed as *All-cause trial failure miscast as safety evidence*

<details><summary>Definition as written by the summariser</summary>

An agent treats a nonspecific all-cause historical trial-failure statistic (drug-, regimen-, or disease-level) as if it directly measured safety, toxicity, tolerability, or safety-related attrition/termination, without evidence that those failures were safety-caused. Observable as an explicit mapping from an overall failure rate to a domain-specific safety conclusion or as relabeling that rate as a safety-failure estimate. Does not apply when the cited statistic is actually safety-specific, when overall failure rates are used only for non-safety endpoints, when safety is argued from clinical knowledge without that metric conversion, or when the issue is authority bias, false consensus, or minority-view suppression.

</details>

Verdict: ______    Notes:

---
