# Candidate failure codes for review — `run_ab3_clean_n180`
180 traces, 457 residual items, 10 clusters, 3 admitted.
Read the quotes before the definition. The definition was written by a model that had just been shown the cluster and asked what its members share, so it will read as coherent whether or not the cluster is. The quotes come from the transcripts.
For each code below:
- [ ] **Real mechanism**, or an artefact of clustering?
- [ ] **Do the quotes show one mechanism**, or several?
- [ ] **Would a clinician call this an error** in the consultation?

---

## All-cause failure-rate domain misattribution
cluster 8 · support **80** · triage `B` · **admitted**
frameworks: clinical_agent5 54, clinical_agent 26 · phases: independent_analysis 80

nearest held-out code: `2.2.1` (cosine 0.4849) — judged distinct

**Evidence from the transcripts** (5 of 119 quotes, 80 members):

> Etanercept has a moderate historical clinical-trial failure rate (0.42), indicating a non-negligible safety-related attrition risk.
>
> — `clinical_agent5` / independent_analysis / proposed as *Unsupported conversion of overall failure rates into safety risk*

> The stomatitis indication itself carries a moderate-high historical failure rate (0.55), suggesting additional safety or tolerability challenges specific to this condition.
>
> — `clinical_agent5` / independent_analysis / proposed as *Unsupported conversion of overall failure rates into safety risk*

> However, the disease category of brain tumors carries a moderate-high failure rate of 0.55, suggesting higher safety-related challenges in this indication.
>
> — `clinical_agent5` / independent_analysis / proposed as *Cross-domain failure-rate attribution*

> Overall, the safety failure risk is moderate-high, driven primarily by the disease context.
>
> — `clinical_agent5` / independent_analysis / proposed as *Cross-domain failure-rate attribution*

> However, the disease category of brain tumors carries a moderate-high failure rate of 0.55, suggesting higher safety-related challenges in this indication.
>
> — `clinical_agent5` / independent_analysis / proposed as *Domain misattribution of an overall failure prior*

<details><summary>Definition as written by the summariser</summary>

In a specialist's independent analysis, the agent treats an overall, all-cause, or otherwise nonspecific historical trial, drug-program, or indication failure rate as direct evidence of risk in its assigned clinical domain (typically safety), without evidence that those failures were caused by that domain. Observable markers include recasting the statistic as a 'safety failure rate', inferring toxicity/tolerability from it, or using it as a lane-specific risk prior. Does not apply if the supplied statistic is actually domain-specific, if the agent uses the overall rate only as a nonspecific base rate without attributing it to the assigned lane, or if the defect is consensus suppression rather than interpretation of the statistic.

</details>

Verdict: ______    Notes:

---

## Invalid quantitative aggregation
cluster 7 · support **42** · triage `B` · **admitted**
frameworks: clinical_agent 42 · phases: decision 29, planning 13

nearest held-out code: `2.2.1` (cosine 0.504) — judged distinct

**Evidence from the transcripts** (5 of 47 quotes, 42 members):

> Overall failure probability averages these drivers, weighted toward efficacy strength, at 0.34.
>
> — `clinical_agent` / decision / proposed as *Inconsistent quantitative aggregation*

> Overall failure probability averages these drivers, weighted toward efficacy strength, at 0.34.
>
> — `clinical_agent` / decision / proposed as *Inconsistent aggregation method*

> To combine these, I will take a weighted average of the three failure probabilities (40% Safety, 40% Efficacy, 20% Enrollment, reflecting their relative impact on trial success), adjusting upward for any identified interdependencies such as safety issues exacerbating enrollment challenges.
>
> — `clinical_agent` / planning / proposed as *Invalid aggregation of component failure probabilities*

> Next, I will combine these using a weighted average (e.g., 30% Safety, 40% Efficacy, 30% Enrollment) to reflect efficacy's central role in trial success, while cross-checking for interactions like safety exclusions impacting enrollment.
>
> — `clinical_agent` / planning / proposed as *Arbitrary domain-probability aggregation*

> Synthesizing sub-agent outputs (0.25, 0.48, enrollment 0.4), the trial failure probability is 0.38.
>
> — `clinical_agent` / decision / proposed as *Incommensurate score aggregation*

<details><summary>Definition as written by the summariser</summary>

A coordinating or deciding agent combines numerical component estimates into an overall failure probability using an unjustified operator (e.g., averaging disjunctive or overlapping failure events), treats quantities with different constructs, scopes, or labels as commensurate, and/or reports a composite that is not produced by the stated weights or calculation. Observable as an explicit numerical synthesis whose semantics, independence assumptions, or arithmetic do not support the reported overall figure. Does not apply to authority bias, suppression of a correct minority view, false consensus among incompatible rationales, or a disclosed, internally consistent combination of like quantities that is not presented as a calibrated joint probability.

</details>

Verdict: ______    Notes:

---

## Absence-of-evidence overinference
cluster 6 · support **38** · triage `B` · **admitted**
frameworks: clinical_agent5 7, clinical_agent 31 · phases: independent_analysis 37, decision 2

nearest held-out code: `2.2.1` (cosine 0.5678) — judged distinct

**Evidence from the transcripts** (5 of 50 quotes, 39 members):

> Therefore, the efficacy failure risk is high.
>
> — `clinical_agent5` / independent_analysis / proposed as *Absence of efficacy evidence treated as evidence of failure*

> <efficacy_score>0.9</efficacy_score>
>
> — `clinical_agent5` / independent_analysis / proposed as *Absence of efficacy evidence treated as evidence of failure*

> Without any detailed preclinical or clinical efficacy data, the likelihood of successful treatment is very low.
>
> — `clinical_agent5` / independent_analysis / proposed as *Absence of evidence treated as evidence of inefficacy*

> <efficacy_score>0.9</efficacy_score>
>
> — `clinical_agent5` / independent_analysis / proposed as *Absence of evidence treated as evidence of inefficacy*

> Without any detailed preclinical or clinical efficacy data, the likelihood of successful treatment is very low.
>
> — `clinical_agent5` / independent_analysis / proposed as *Absence of evidence treated as evidence of inefficacy*

<details><summary>Definition as written by the summariser</summary>

An agent converts missing, sparse, incomplete, or explicitly stubbed retrieved records into an affirmative claim that efficacy, mechanistic support, or prior clinical validation is weak or absent, often then assigning a strongly adverse efficacy judgment. Observable as a direct inference from source missingness or stub status to a negative evidential or efficacy conclusion, rather than to uncertainty or retrieval limitation. Does not apply when the agent merely reports incompleteness and remains uncommitted, when inefficacy is grounded in affirmative contrary evidence, or when the error is overconfident favorable calibration from weak or non-specific supporting signals.

</details>

Verdict: ______    Notes:

---
