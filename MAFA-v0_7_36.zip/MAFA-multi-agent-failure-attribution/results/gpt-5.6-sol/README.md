# Results produced with `gpt-5.6-sol-disc` as the annotator

Frozen 2026-09-13. Everything under this directory was annotated by
**`gpt-5.6-sol-disc` via aihubmix**. Nothing here is comparable to a run made
with a different annotator, for a reason worth stating plainly rather than
leaving as a footnote:

    gpt-5.6-sol-disc @ aihubmix   logprobs=True, alternatives=False, max_alternatives=1
    deepseek-flash   @ deepseek   logprobs=True, alternatives=True,  max_alternatives=20

Stage 2 builds its uncertainty features out of the scorer's token-level
distribution. One model returns the chosen token's logprob and nothing else;
the other returns twenty candidates. That is exactly the layer the calibration
reads, so a `gpt` annotation and a `deepseek` annotation of the same trace are
two different measurements, not two samples of one. **Do not pool them and do
not compare a number here against a number from the deepseek runs.**

The Stage-4 judge was `claude-opus-5` via aiberm throughout, and stays that way
in the deepseek runs. Cross-family is a design requirement, not a convenience:
if the model that produced the annotation also rules on whether an existing
code already covers it, the verdict is a self-assessment.

Embeddings were `text-embedding-3-small` via aihubmix. deepseek serves no
embedding endpoint, so that stays put and the caches here remain valid.

## What is here

    stage1/     360 annotations, 45 per framework per split
                clean_*.jsonl, faulty_*.jsonl, and the two concatenations
    stage4/     run_ab2_n36    the 36-trace ablation, complete
                run_ab3_n180   the 180-trace ablation, INCOMPLETE
    stage23/    calibration and routing on 745 pseudo-anchors
    logs/       stdout of every run, including the failures

## How far to trust each of these

**`stage23/run_s23_pseudoanchors/` — reproduced.** Deterministic, no API calls.
Reproduces `examples/fit_report_pseudo_anchors.json` to the digit: AUC
0.913992673992674, ECE 0.04622061278503893, selective error 0.0374 / 0.0496 /
0.0893 / 0.1126. Routing on 85 traces: VERIFY 51 (60.0%), REVIEW 28 (32.9%),
AUTO 6 (7.1%). `head_b_fitted: false` — the pseudo-anchors carry one vote per
slot, so there is no disagreement for Head B to model. Only people close that.

**`stage4/run_ab2_n36/` — complete, and one of its findings was withdrawn.**
Three clusters, all stopping at `AB?`, nothing reaching the gate. The reported
`absorbed_by: 1.2.1` on cluster 0 did **not** survive re-measurement:
`filter_arms.json` re-ran the same eight items three times and the vote came
back 12–12 between 1.2.1 and 2.1.1. The original run read a coin balanced on
its edge as a result. What did replicate is that 1.2.1 absorbs the
clinical_agent groups (23 of 24 votes on c100) — it is acting as a sink through
the second clause of its definition, which names no modality, phase or
framework.

**`stage4/run_ab2_n36/filter_arms.json` — three arms, three repeats each, the
most carefully measured thing here.** Filtering the re-audit's candidates by
`allowed_phases` and `requires` never changed which code won; it only lowered
the rate. c0 chose 2.1.1 with six codes offered and still chose 2.1.1 with
2.1.1 as the only candidate, but its rate fell 1.00 → 0.25. The filter
collapses the candidate set to one code for most items, turning a six-way
choice into a yes/no, and a yes/no draws more refusals. Framing, not
correction. This is why `reaudit_respects_structure` defaults to False.

**`stage1/` — complete, but residual counts are noisy.** Re-annotating the same
36 traces produced 66 residuals the first time and 77 the second, +17%. Per-
framework rates differ sevenfold (dylan 0.62 per trace, clinical_agent 4.61),
so any pooled residual rate is mostly reporting the framework mix. Compare
paired, on the same trace_ids, or not at all.

**`stage4/run_ab3_clean_n180/` and `run_ab4_faulty_n180/` — both complete.**
180 clean traces: 457 residuals, 10 clusters, 149 noise, **3 codes admitted**.
180 faulty traces: 525 residuals, 10 clusters, 224 noise, **1 code admitted**.
The first codes this project has ever put through the admission gates; at n=36
there were two clusters and nothing reached a gate at all.

**Held-out recovery is 0 of 4 in both runs.** `recovered: []` each time. Every
admitted code was judged distinct from its nearest held-out code (G1 `same:
False`, confidence `high`, cosine 0.42-0.57). By the ablation's own yardstick
both runs failed. See the note in RUN.md on why that yardstick is being
demoted rather than the runs being called a success.

**What did replicate: the clusters, much more than the verdicts.** The two runs
share no traces -- one is runs that ended correct, the other runs that ended
wrong -- and were clustered, named and triaged independently. The four largest
clusters recur in both at similar support:

    Recruitment output-contract violation / overreach   86 B  <->  88 B   cos 0.874
    All-cause failure-rate -> domain/safety evidence     80 B  <->  75 B   cos 0.609
    Invalid / Ungrounded quantitative aggregation        42 B  <->  33 A   cos 0.611
    Absence-of-evidence / sparse-retrieval overinference 38 B  <->  41 AB? cos 0.532

Two of those four get **different verdicts** on the two samples. Cluster
recurrence is the strong signal here; verdict recurrence is not. The cosines
are over cluster *names* only, so they support the pairing rather than
establishing it -- support counts, framework mix and definition text carry more
weight than the number.

The one code admitted in both runs is the all-cause failure-rate mechanism, at
support 80 and 75, framework mix clinical_agent5 54/26 and 59/16, nearest
held-out 2.2.1 at cosine 0.4849 and 0.4813. It is also the cluster `resplit`
cut out of the 37-item mixed group back at n=36, where it was 15 items and
stopped at `AB?`.

**A new concentration worth checking, not yet checked.** On faulty, all five
`A` verdicts absorbed into 3.1.3; on clean only one did. That may be 3.1.3
playing the role 1.2.1 appeared to play at n=36, or it may be that this failure
really is common in traces that end wrong. Nothing here settles it.

**1.2.1 remains unstable.** On clean it absorbed three small clusters, one with
`rate_spread` 1.00 -- three re-audits returning 0, 1, 1. On faulty, spreads of
0.75 and 0.375. `max_rate_spread` caught all of them and routed them to `AB?`,
which is the check working. It also means no claim about 1.2.1 being a sink is
currently supported, in either direction.

`stage1/faulty_180.jsonl` has now been through Stage 4 (`run_ab4`). This was
the project's first Stage-4 result on traces where the system reached the
wrong answer; every earlier one came from `clean`.
