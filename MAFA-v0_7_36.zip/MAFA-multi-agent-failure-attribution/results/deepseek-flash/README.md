# Results produced with `deepseek-flash` as the annotator

Annotator: **`deepseek-flash` via https://api.deepseek.com**.
Probe: `LogprobSupport(logprobs=True, alternatives=True, max_alternatives=20)`.
Judge stays `claude-opus-5` via aiberm. Embeddings stay
`text-embedding-3-small` via aihubmix — deepseek serves no embedding endpoint.

## Do not compare counts with `../gpt-5.6-sol/`

Paired on the same 137 traces, novel proposals per trace:

    clinical_agent   4.81 -> 0.41     dylan      0.46 -> 0.12
    clinical_agent5  1.98 -> 0.13     mdagents   2.43 -> 0.71
    overall          2.34 -> 0.26

Every framework, so this is the annotator and not the sample. gpt calls 18.0%
of slots positive, 2.72 findings per trace, 21% of traces with no proposal;
deepseek-flash calls 9.2% positive, 0.82 findings, **76%** with none.

Residual pools, cluster counts and absorb rates are therefore roughly an order
of magnitude smaller here. The two directories are separate measurements, not
two samples of one.

## What is here

    stage1/    base_seed6_paired137.jsonl   six-code seed
               ext_fold9_paired137.jsonl    seed + D0.1/D0.2/D0.3
    foldback/  foldback.json, both taxonomies, failures.json
    logs/

## Fold-back result

137 paired clean traces, same annotator, taxonomy the only variable.

    uptake      D0.1 73, D0.3 57, D0.2 46   (all six seed codes: 48)
    1.2.1       23 -> 8    (-15)            2.1.1  4 -> 4   (0)
    3.1.3       11 -> 7     (-4)            2.2.2  3 -> 4  (+1)
    residual    34 -> 26                    violations 54 -> 54

The pairing is the result: 1.2.1 — long suspected of acting as a sink through
the modality-free second clause of its definition — loses 65% of its work,
while the codes that were already precise do not move. Either half alone reads
the other way.

Read the residual drop as a direction, not a percentage: eight items on a
small base, and this annotator rarely proposes novel modes at all, so fold-back
measured on it is a lower bound.

## Coverage

`foldback/failures.json` lists every incomplete trace with an `error_class`.
Of 66 failures, 41 were `infra_quota` / `infra_rate_limit` — a spent key and
too much concurrency on my side — and 25 were `model_empty_output`, 20 of them
mdagents.

Paired coverage: clinical_agent5 45/45, clinical_agent 37/45, dylan 41/45,
mdagents 14/45. **Not missing at random** — failures concentrate where the
reasoner runs long. The three discovered codes draw all their members from
clinical_agent and clinical_agent5, the two best-covered frameworks, so the
main measurement rests on the sound part. mdagents and dylan are a ragged
control and support qualitative reading only.
