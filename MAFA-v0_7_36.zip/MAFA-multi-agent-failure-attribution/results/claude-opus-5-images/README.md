# Image ablation — does the annotator judge differently when it can see the images?

Annotator: **`claude-opus-5` via aiberm**, Anthropic Messages API.
Images: 2858 files, 100% of the 2521 referenced by mdagents traces.

**A third measurement regime. Do not pool with `../gpt-5.6-sol/` or
`../deepseek-flash/`.** Different annotator, and the Anthropic backend has no
`scored` method, so the scorer falls back to verbalised 0-100 and every slot
carries `p_token_missing`. These annotations cannot feed Stage 2.

## What was varied

Only whether the trace's own images were attached to the **annotator's**
prompt. The audited agents never saw them in either arm — the corpus replaced
the pixels with a note saying images exist — so this changes who can check a
modality claim, not what was audited. Verified per record: the no-image arm
has `n_images_sent: 0` throughout, the image arm matches each trace's
reference count exactly (1, 2 and 5 images), zero dropped.

## Result

Two independent batches, 28 paired traces, ~168 mode verdicts.

| | random 15 | 13 where gpt scored 1.2.1 positive |
|---|---|---|
| 1.2.1 | 12 -> 11 | 12 -> 12 |
| total flips | 3 | 1 |

Flips: `MM-12` 1.2.1 1->0, `MM-2` 3.1.2 0->1, `MM-24` 3.1.2 1->0,
`MM-68` 2.1.1 0->1. The 3.1.2 pair cancels and has no direction.

**Seeing the images barely moves any verdict, and moves 1.2.1 once in 24.**

## What this refutes

The standing hypothesis in RUN.md was that 1.2.1 is the least stable code in
this project (`rate_spread` 1.00 on one cluster — three re-audits returning 0,
1, 1) *because* its main clause, "neglect or misinterpretation of modality
information", cannot be judged without the image, leaving the annotator to
guess from phrasing.

That is wrong. Supplying the image changes nothing, so the annotator was never
judging modality in the first place. What it is actually using is the second
clause of the definition — "or evades the specific clinical question asked,
offering a generic description instead" — which names no modality, no phase
and no framework.

**1.2.1 is a general answers-the-wrong-question code wearing a modality
name.** That agrees with the fold-back result from the other direction: given
three codes that state their mechanisms precisely, 1.2.1 lost 65% of its work
while the already-precise codes did not move. The recommendation is to split
it or rewrite the definition; that is a decision for a person, not the loop.

## A correction to an earlier report in this log

The first batch was initially reported as "3 positive verdicts in total, 0
flips, signal too weak". That number was computed with un-restored trace_ids
(see the line-number fault in RUN.md): most lookups silently missed and the
comparison ran on nearly empty data. The real figures are 12 positives and 3
flips. The conclusion did not change, but the stated reason for running a
second batch — "the sample had too few positives" — was wrong. The second
batch stands as an independent replication rather than a fix.

## Files

    stage1/p121_{noimg,img}_13.jsonl    batch 2, selected on gpt's 1.2.1 hits
    stage1/random15_{noimg,img}.jsonl   batch 1, first 15 mdagents traces
    stage1/selected_trace_ids.json      the 13 ids and how they were chosen
    image_ablation.json                 per-code counts and every flip
    logs/stage1.log
