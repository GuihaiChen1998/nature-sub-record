# RUN.md

How to run the MAFA annotation pipeline.

> **Keep this file current.** Every change to the interface, to a default, or
> to a measured number belongs here, in the changelog at the bottom. A run
> book that lags the code is worse than none, because it is trusted.

---

## 0. What this is

An annotation pipeline, not an inference model. It takes unlabelled
multi-agent consultation traces and produces a corpus labelled at three
levels — which agents failed, at which step a failure first appears, and which
failure modes occurred — plus a failure taxonomy that grows from the data.

Four stages, arranged as a loop rather than a line:

```
Stage 0  adapter        heterogeneous traces -> unified schema + capability mask
Stage 1  annotation     reasoner (structured, outcome-blind) + token scorer
Stage 2  calibration    hybrid features -> Head A P(label), Head B P(agreement)
Stage 3  routing        conformal prediction sets -> AUTO / VERIFY / REVIEW / NOVEL
Stage 4  evolution      residuals -> clusters -> A/B triage -> admission gate -> T(k+1)
                        └── feeds back into Stage 1
```

The "complete framework" only exists after **two** passes: the first produces
T1, the second runs against it. A single pass is necessarily partial.

---

## 1. Install

```bash
pip install -r requirements.txt
export OPENAI_API_KEY=...
export OPENAI_BASE_URL=...          # omit for OpenAI direct
```

Python 3.10+. `scikit-learn>=1.3` matters — HDBSCAN moved into
`sklearn.cluster` there.

## 2. Data layout

Put trace `.jsonl` files under `data/`. The framework is inferred from the
filename, so it must contain one of `mdagents`, `dylan`, `clinical_agent5`,
`clinical_agent` (checked in that order).

```
data/
  mdagents_fm_clean_none_none-allfalse.jsonl
  dylan_fm_clean_none_none-allfalse.jsonl
  ...
  medxpertqa-mm-100-mdagents_clean-paired_normal.jsonl     # clean controls
```

`.jsonl`, not `.zip` — unzip the archives into `data/` first. Subdirectories
are searched recursively, so the two archives can keep their own folders.

**Include the clean traces.** They are the negative control that measures the
annotator's false-positive rate, and they are how you show that process
failure and outcome failure come apart. A run on faulty traces alone cannot
distinguish "found a fault" from "knew the answer was wrong".

### The simulated split

`AEGIS-custom-simulated-faults-dataset` is a third split, and its role is
different from the other two: it is **not** training or evaluation data for the
attribution method — using synthetic faults there would import their bias into
the headline result — it is **validation data for the annotator**, because it
is the only place ground truth is free.

3,519 traces, every one with `is_correct=False` and `is_valid_error=True`.
Faults were injected by the **MAST** taxonomy (Cemri et al., NeurIPS 2025), a
different label space from the MedAgentAudit seed the annotator uses.

What comes free, and at which level:

| level | source | taxonomy-dependent? |
|---|---|---|
| which agents carry a fault | `multi_injection_info` | no |
| which steps are corrupted | `injection_applied` per turn | no |
| earliest fault step | first marked turn | no |
| which agents are **confirmed clean** | complement | no |
| fault type | `fm_error_type` (MAST) | **yes** |

The first four are label-space independent, so recall and specificity are
measurable directly. Measured properties of the split:

- genuinely multi-point: 1–6 injected agents, mode 2 (2,304 of 3,519 traces)
- **every trace keeps at least one clean agent** — injected fraction averages
  0.49 and never exceeds 0.86, so confirmed negatives are never empty. This is
  the only place specificity is directly measurable; natural traces provide no
  confirmed negatives anywhere.
- all 14 MAST codes appear, unevenly across frameworks
- two strategies: `response_corruption` (5,455) and `prompt_injection` (3,967)
- `response_corruption` turns carry `clean_response_before_corruption`, the
  same agent's uncorrupted output — a within-trace counterfactual

```bash
python scripts/run_stage1.py --data data/simulated --work runsim
python scripts/validate_on_injected.py --data data/simulated --work runsim --by-strategy
python scripts/coverage_matrix.py --data data/simulated --work runsim --reaudit
```

`coverage_matrix.py` answers the question MedAgentAudit's premise rests on:
how much of MAST can the medical seed taxonomy actually express? Every
injection has a known MAST code at a known agent and step, the annotator sees
only the seed, so the contingency between them is directly measurable. Output
is a MAST x MedAgentAudit matrix with a NOVEL column and a miss column, plus
the codes that come out uncovered — the places where a medical-specific code is
genuinely needed.

It is also **the only place the Stage 4 A/B triage can be validated.** Natural
traces carry no ground truth for "is this failure already covered by an
existing code", so the triage is unverifiable there. With `--reaudit` the
script runs the same unmasked re-audit the triage uses and scores its verdict
against what the coverage matrix says, giving an accuracy for the mechanism
itself.

`mafa/mast.py` ships a `PRIOR_MAPPING` — a written-down hypothesis about which
MAST codes the seed covers, with six predicted uncovered (context omission,
refusal to commit, restarting reasoning, hedging, deliberate wrong answer,
premature termination). The script reports agreement with it. It is a
hypothesis registered in advance, not an answer; where the measurement
disagrees, the measurement wins.

Two rules that must hold or the numbers mean nothing:

1. **Never put MAST definitions in the annotator's prompt.** The faults were
   generated from those definitions; a model holding them would be finding what
   it was told to find. `mafa/mast.py` exists for the coverage analysis only,
   and nothing in the Stage 1 path imports it.
2. **Injected recall is an upper bound on natural recall.** Inserted faults are
   blunter than the ones a system commits by itself. Specificity transfers
   better — a false positive on a confirmed-clean agent is a false positive
   either way — so lead with specificity, not recall.

### Two properties of AEGIS-custom worth knowing

**Record ids are not unique.** 10 ids repeat inside a single faulty file, and 3
appear in both the faulty and the clean file for the same framework. `trace_id`
is therefore built from `framework::source_stem#line_index#id`, which is unique
by construction; the original id survives in `meta["record_id"]`. Keep this in
mind if you join against anything keyed on the raw id.

**The clean split is not a matched control.** Query overlap between the faulty
and clean files is 10 / 7 / 3 / 0 traces for clinical_agent / clinical_agent5 /
dylan / mdagents — essentially none. For MDAgents the two splits are different
benchmarks entirely, though both happen to be fully multimodal (682/682 and
49/49 traces carry images), so at least modality does not confound that pair.
The consequence: a difference in flagging rate between splits is
outcome + question-distribution, not outcome alone. To claim process/outcome
decoupling cleanly you need traces where the *same* question produced both a
correct and an incorrect run; failing that, state the confound.

## 3. The run

### 3.1 Pre-flight (free, do it every time)

```bash
python scripts/preflight.py --data data
```

Reports trace counts, agent-uid collisions, slots per trace, which codes are
structurally excluded per framework, and whether logprobs work (retried 3×, so
one flaky call does not downgrade a whole batch).

Read the last line. If it says logprobs are unavailable, the scorer degrades
to verbalised 0–100 and `p_token_missing` is set on every slot — the pipeline
still runs, the white-box signal does not.

### 3.2 Stage 1 — annotate everything (no humans needed)

```bash
python scripts/run_stage1.py --data data --work run01
```

Resumable: re-running skips traces already in `run01/stage1.jsonl`, so a
killed job costs nothing. Run it under `tmux`/`nohup` — it is the long step.

Useful flags:

| flag | effect |
|---|---|
| `--limit 5` | 5 traces per file, for a smoke test |
| `--concurrency 8` | scorer parallelism (one warm-up call runs first, for the prefix cache) |
| `--single-pass` | disable the outcome-blind split — **ablation only** |
| `--granularity agent_step` | MedAgentAudit's exhaustive scan, for the cost ablation |

Output: `run01/stage1.jsonl`, one record per trace with slot verdicts,
findings with verbatim evidence, structural violations, and `p_positive`.

### 3.3 Stage 4 preview — free, and run it now

```bash
python scripts/run_evolution.py --work run01 --gates G1,G2 --auto-threshold
```

The residual pool's first source is Stage 1's own `NOVEL` proposals, which
need no human labels. This gives an early read on whether failure types
outside the seed taxonomy exist, which is usually the thing you most want to
know. G3/G4 are skipped; they need anchors.

`--auto-threshold` derives G2's `max_centroid_cos` from the seed taxonomy's own
geometry. **Do this whenever you change embedding backend** — cosine
similarity is not comparable across models, and the 0.82 default was set
against `text-embedding-3-small`.

### 3.4 Stage 2a — pick what humans should look at

```bash
python scripts/make_anchor_tasks.py --work run01 --budget 300 --step-traces 120 --annotators 3
```

Writes `run01/tasks.jsonl` (closed-form questions with quoted evidence) and
`run01/frozen_split.json` (which traces are reserved for gate G4, decided
before annotation so the split cannot be made to flatter the results).

Two task shapes:

- **binary** — "does this failure occur?", answer in `human_votes`
- **step** — "at which step does a failure first appear?", one multiple-choice
  question per trace, answer in `human_choice`

Copy `tasks.jsonl` to each annotator; they fill it independently and return
`done_1.jsonl`, `done_2.jsonl`, … **At least two annotators**, or Head B
cannot be fitted and the queue falls back to ranking by model risk alone.

Budget: per-group coverage stabilises around **100 adjudicated slots per
Mondrian group**. `--group-by kind` is 3 groups (~300 slots); adding
`framework` makes 12 (~1200), which is usually unaffordable. The script prints
the arithmetic and warns if the budget is short. Do not report pooled coverage
as if it held per group.

### 3.5 Stage 2b + 3 — calibrate and route

```bash
python scripts/fit_and_route.py --work run01 \
    --annotated run01/done_1.jsonl run01/done_2.jsonl run01/done_3.jsonl
```

Outputs:

| file | contents |
|---|---|
| `fit_report.json` | ECE/AUC/Brier, per-group conformal coverage, selective error |
| `routes.jsonl` | per-trace decision, prediction sets, queue priority |
| `corpus.jsonl` | AUTO — admitted labels |
| `human_queue.jsonl` | VERIFY — ranked, with evidence cards |
| `human_queue_full_read.jsonl` | REVIEW — model was uninformative |
| `residual_pool.jsonl` | NOVEL — empty prediction sets |
| `anchors.jsonl` | both pools with the frozen fingerprint |

Check `fit_report.json` for under-covered groups; the script warns but does not
stop.

### 3.6 Stage 4 full

```bash
python scripts/run_evolution.py --work run01 --gates G1,G2,G3,G4 --held-out 60
```

Now G3 (does the candidate reduce the residual rate on held-out traces) and G4
(does it degrade the frozen anchor set) run. They cost roughly
`2 × |held-out| + |anchor|` reasoner calls **per candidate**; evaluate
candidates against a shared held-out split rather than weakening the gate.

### 3.7 Second pass

If Stage 4 admitted anything, the taxonomy signature changed, and the
calibrator and conformal quantiles from pass 1 are **invalid** — the label
space moved, so exchangeability is gone. The code raises rather than warns.

```bash
python scripts/run_stage1.py --data data --work run02 --taxonomy run01/taxonomy_T1.json
python scripts/fit_and_route.py --work run02 --taxonomy run01/taxonomy_T1.json \
    --annotated run01/done_*.jsonl
```

Refitting needs no new human labels for slots that already existed; only the
new codes' slots are unlabelled.

---

## 4. Knobs worth knowing

### Admission gate (`run_evolution.py --gates`)

Four criteria in two tiers. Screening (G1 support, G2 distinctness) is free and
short-circuits; validation (G3 utility, G4 anti-regression) costs API calls.

| preset | flag | use |
|---|---|---|
| exploratory | `--gates G2 --min-support 3 --min-frameworks 1` | see the long tail |
| cheap | `--gates G1,G2` | no API budget yet |
| strict | `--gates G1,G2,G3,G4` | anything you report |

Disabled criteria are still computed and reported. Every admitted code records
`gates_enabled` and `gates_binding`, so a permissive run cannot later be
mistaken for a strict one.

### G1 counted frameworks the wrong way (v0.7.10)

Requiring support in two frameworks reads as ordinary prudence and was
sometimes a demand for the impossible. The ablation produced a cluster of 22
describing a recruiter breaking its output contract, 20 of them from MDAgents —
which is the only one of the four frameworks that **has** a recruitment stage.
No quantity of further data could ever have supplied a second framework for it.
Under a flat `min_frameworks >= 2` that candidate was unadmittable by
construction, and so is every failure specific to a coordination design.

The count is now taken against `eligible_frameworks(cluster, framework_caps)` —
the frameworks whose structure permits the cluster's phases — and the
requirement is capped at that number. The two cases separate cleanly:

| cluster | frameworks seen in | eligible | required | G1 |
|---|---|---|---|---|
| recruitment-stage failure | mdagents 20, clinical_agent 2 | mdagents | 1 | **pass** |
| decision-stage failure | clinical_agent5 14 | 3 frameworks | 2 | **fail** |

The first cannot cross frameworks; the second could and did not, which is worth
suspecting, since three designs permit it and only one shows it. Previously
both were treated the same way.

`min_framework_fraction` caps the requirement at a share of the eligible set so
it stays meaningful as the corpus changes, and
`--ignore-framework-eligibility` restores the old behaviour for comparison.
Omitting the capability map leaves the old semantics and says so in the report,
so no existing call changes meaning silently.

### Every gate is adjustable

Which criteria bind and how hard is entirely the caller's choice:

```python
GateConfig(
    enabled=("G1", "G2"),          # which criteria bind at all
    min_support=12,                # absolute
    min_support_frac=0.05,         # or a share of the residual pool; the larger wins
    min_frameworks=2,              # counted against the eligible set
    min_framework_fraction=0.5,    # capped at a share of it
    max_centroid_cos=0.613,        # --auto-threshold derives this from the seed
    min_utility_gain=0.02,
    max_anchor_drop=0.01,
    short_circuit=True,            # skip the expensive pair if the free pair fails
)
```

Presets: `GATE_EXPLORATORY` (G2 only, support 3, one framework),
`GATE_CHEAP_ONLY` (G1 and G2), `GATE_STRICT` (all four). Disabled criteria are
still computed and reported, and every admitted code records `gates_enabled`
and `gates_binding`, so a permissive run cannot later pass for a strict one.

On loosening G1: support is what separates a failure *type* from a handful of
correlated annotator mistakes, and `min_frameworks` is what separates it from
one framework's implementation bug. Prefer `--min-support` with the
proportional partner (`min_support_frac`) over a smaller constant: 12 out of a
pool of 80 is a mode, 12 out of 20,000 is noise.

### A/B triage (`--absorb-threshold`, `--ambiguous-band`)

Clusters whose absorb rate lands within the band are marked `AB?` and go to a
human rather than being rounded to a side. `admit()` refuses `AB?` as loudly as
it refuses `A`. Set `--ambiguous-band 0` for the hard-cut ablation; the
`triage_sensitivity` table in `evolution_report.json` shows how the A/B counts
move with the threshold, and **should be reported** — a novelty claim that only
survives at one threshold is not a finding.

### Sampling strategy

Default is stratified coverage, not uncertainty sampling. Uncertainty sampling
gives a well-discriminating but badly calibrated Head A, and breaks the
exchangeability that conformal coverage depends on. `strategy="uncertainty"`
exists for the ablation and prints a warning.

---

## 4b. Endpoint behaviour (measured, 2026-09)

Proxies differ in ways that change what the pipeline can do. Re-run
`scripts/preflight.py` against any new endpoint rather than assuming.

| endpoint | structured outputs | logprobs | `top_logprobs` alternatives |
|---|---|---|---|
| qingyuntop | yes | yes | **stripped** (`n_alts=0`) |
| aihubmix | yes | yes at `effort="none"` | yes, but see below |
| aiberm (Anthropic API) | n/a | none (Claude never exposes logprobs) | n/a |

`aiberm` serves `claude-opus-5` and `claude-sonnet-5` on the Anthropic
Messages API at base_url `https://aiberm.com` — **no trailing `/v1`**, or the
SDK posts to `/v1/v1/messages` and 404s. An empty prompt costs `in=1 out=1`,
i.e. no wrapper is injected; endpoints that prepend a large hidden system
prompt both cost money on every call and quietly interfere with the
outcome-blind framing, so check this before adopting one.

Three findings that cost real debugging time:

**It is reasoning, not structured output, that disables logprobs.** On aihubmix,
`json_schema` + logprobs coexist happily at `effort="none"` (12 logprob tokens
returned), while `effort="medium"` returns
`400 logprobs are not supported with reasoning models`. So the two-call split
stays — but for a different reason than first assumed, and the scorer call can
now use `json_schema`.

**A system-role message collapses `top_logprobs` to one alternative.**
Reproducible 4/4: the same coin-flip question returns 2 alternatives as a bare
string or a user-only message list, and 1 alternative when a system message is
present. `OpenAICompatClient.scored` therefore prepends the instruction to the
user content and sends no system role.

**Alternatives are returned above a probability floor, not always.** When the
model is confident (p > 0.999) only the emitted token comes back, which is
indistinguishable from an endpoint that strips alternatives. The probe uses a
question that is borderline *under the audit framing* rather than borderline in
the abstract, but the distinction is still not always crisp; treat
`LogprobSupport.alternatives` as a hint and check the observed `p_token`
distribution instead. On the simulated split, 10% of `p_token` values landed in
[0.15, 0.85] — the white-box signal is real but heavily concentrated at the
extremes.

**Batched scoring.** Every scorer call re-sends the whole transcript, so one
call per slot made the scorer roughly ten times the reasoner's input cost.
`ScorerConfig.batch_slots` (default 8) asks several questions per call and
reads the verdicts positionally out of the JSON token stream, which arrives as
clean single tokens (`['{"','ver','dict','s','":["','1','","','0','"]','}']`).
Measured: 20 slots went from ~14 calls to 2.

**Cross-family judging.** `--judge-backend anthropic` points Stage 4 at a
Claude model while Stage 1 runs on GPT:

```bash
export ANTHROPIC_API_KEY=... ANTHROPIC_BASE_URL=https://aiberm.com
python scripts/run_evolution.py --work run01 --gates G1,G2 \
    --judge-backend anthropic --judge-model claude-opus-5
```

The A/B triage decides whether a failure is already covered by an existing
code; letting the model that produced the annotation decide that makes it a
self-assessment. The triage needs no logprobs, so cross-family costs nothing.
Running with the same model prints a warning rather than failing.

**Judges answer with the code *and its name*.** `claude-opus-5` returns
`"2.2.1 Repetition of initial views (echo chamber)"`, not `"2.2.1"`. Matching
that against the code set fails, the vote is dropped, `absorb_rate` comes out
0.0, and every cluster is triaged **B** — the pipeline would report maximal
novelty precisely because the judge was being helpful. `normalise_code()` now
extracts the bare code. This was observed, not anticipated; check any new judge
model against `taxonomy_evolution.normalise_code` before trusting a triage run.

## 5. Known issues

| issue | status |
|---|---|
| Some proxies strip `top_logprobs`, returning the emitted token's logprob but no alternatives. `p_positive_from_logprobs` then cannot renormalise over {0,1} and `p_token` quantises hard — measured 25% of values in [0.15,0.85], the rest pinned at 0/1. | **Verify on your endpoint.** Weakens but does not break the white-box half. |
| Per-group conformal coverage under-covers when a group falls below `MIN_CAL=40` and silently uses the pooled quantile. Measured 0.793 against a 0.90 target on one MedAgentAudit group. | Mitigated by the `[fit]` warning; the real fix is more anchors or fewer grouping dimensions. |
| Two-pass annotation costs +74% input tokens, not the +30% first estimated (two full transcripts). | Accepted; the bias it removes is not optional when the faulty split was selected on wrong answers. |
| Record ids in AEGIS-custom are not unique (13 collisions), so `trace_id` embeds the source file and line index. | **Fixed in 0.4.1.** |
| `p_token` remains concentrated at 0/1 even with alternatives available (10% in [0.15,0.85] on the simulated split). Alternatives help but do not fix it. | Open. Watch the distribution rather than the probe flag. |
| `MIN_CAL=40` and `verify_span`'s `fuzzy_floor=0.82` are still hand-set constants. | Deferred until real data gives a signal to set them from. |
| Prompt caching is available (~78% prefix reuse observed) but not guaranteed — a multi-node proxy may miss. | Don't build cost estimates on it. |

---

## 6. Repository layout

```
mafa/
├── RUN.md                     this file
├── HANDOFF.md                 state of play, for picking the work up cold
├── requirements.txt
├── mafa/                      the package
│   ├── trace_adapter.py       Stage 0: unified schema, capability mask, span verification
│   ├── taxonomy.py            seed codes, structural applicability, versioning, signature
│   ├── stage1_schema.py       slot plan, JSON contract, 20 consistency checks
│   ├── stage1_prompt.py       prompt construction, outcome-blind rendering
│   ├── annotator_client.py    two-call annotation, two-pass split, logprob extraction
│   ├── uncertainty.py         hybrid features, violation families, two-head calibration
│   ├── anchor_sampler.py      stratified anchor selection, task file, frozen reservation
│   ├── conformal_router.py    Mondrian split conformal, four-way routing
│   ├── embeddings.py          OpenAI / vLLM / offline backends, threshold suggestion
│   ├── estimators.py          pluggable confidence estimators
│   ├── images.py              image attachment + id-preserving sharding
│   ├── taxonomy_evolution.py  residual pool, HDBSCAN, A/B triage, admission gate
│   ├── reaudit_llm.py         LLM adapters for summarise / re-audit / distinctness / G3 / G4
│   └── pipeline.py            orchestration, anchor pools, bucket export
├── scripts/
│   ├── preflight.py           environment and data checks (needs data + a key)
│   ├── selfcheck_offline.py   wiring invariants: no data, no API, no money
│   ├── fold_back.py           does a discovered code earn its place?
│   ├── make_pseudo_anchors.py anchors from the injection log, no humans
│   ├── cross_sample_validate.py  does a code recur in a disjoint sample?
│   ├── export_for_human_read.py  candidates + transcript quotes, for a person
│   ├── measure_reaudit_filter.py re-audit under three filter strengths
│   ├── keepalive.sh           restart runs the environment reaped
│   ├── run_stage1.py          Stage 1
│   ├── make_anchor_tasks.py   Stage 2a
│   ├── fit_and_route.py       Stage 2b + 3
│   ├── run_evolution.py       Stage 4
│   ├── ablate_seed.py          hold codes out, measure how many come back
│   └── anchor_calibration.py  replication on MedAgentAudit's 383 human-eval instances
├── figures/                   framework figure (SVG generator + TikZ, colour and greyscale)
│   ├── dataflow.html               interactive: click a module, see its I/O
│   ├── explorer.html               interactive: 8 traces, live capability mask
│   └── instance_walkthrough.html   linear read of one trace, print-friendly
└── examples/
    └── stage1_sample.jsonl    5 real annotated traces, for format reference
```

---

## 6b. First end-to-end run on the simulated split (12 traces, 2026-09)

Small, so treat every figure as a signal rather than a result. What it
established:

*The pipeline runs.* preflight -> Stage 1 -> validate_on_injected ->
coverage_matrix, all four frameworks, resumable, `outcome_shown=False` on
12/12, `regime=logprob` on 12/12. Batched scoring did 16-22 slots in **2 calls
per trace**.

*The annotator appeared to over-flag.* It largely did not -- see the
contamination finding below -- but this is what the first run showed:

```
agent-level   recall=0.912   specificity=0.469   precision=0.646
              positives=34   confirmed negatives=32
step-level    recall=0.250
earliest step exact=0.667  within1=0.750   offsets {-3:1,-1:1,0:8,3:1,5:1}
by strategy   response_corruption 1.000 | prompt_injection 0.824
```

Recall of 0.91 on injected faults is unsurprising -- they are blunt. **A
specificity of 0.47 means the annotator flags more than half of the agents
confirmed to carry no injected fault.** Same direction as MedAgentAudit's
released numbers, further along. This is exactly why the simulated split is run
before anchors are annotated: 300 adjudicated slots against an annotator in
this state would be measuring a broken instrument with the one resource that
cannot be bought back.

*Step recall 0.25 but earliest-step 0.67 exact.* The annotator localises the
first failure far better than it enumerates every failing step. The task only
needs the first, so this is workable, but the per-step slots carry little
signal and will weaken the step conformal head.

*The coverage matrix is not yet interpretable.* Ten of twelve MAST codes came
out "covered", but code `1.2.1` is the dominant match for six different MAST
types. One seed code absorbing six unrelated general failure modes is more
consistent with an annotator applying it indiscriminately than with genuine
breadth. Coverage numbers computed on top of specificity 0.47 measure the
over-flagging, not the taxonomy. **Fix specificity first, then re-run the
matrix.**

### The contamination finding (v0.6.4) -- read this before trusting any specificity number

The specificity of 0.469, and the 0.659 that a revised prompt produced, were
both measuring the wrong thing.

Exporting every false positive from a 15-trace run showed that **15 of 15 were
agents that speak after an injection**, every one carrying a grounded verbatim
quote, and the findings describe real defects: an agent reversing its answer
with no new evidence (3.2.1), an agent misattributing a claim to a peer
(1.1.1), an agent restating its own prior turn (2.2.1). Those are genuine
process failures. The annotator was right.

They score as false positives because the injection label answers *"did we
inject a fault here"*, not *"did this agent fail"*. Corruption propagates: a
clean agent handed a corrupted claim can be carried off course and then fail on
its own. Splitting the negatives accordingly, on 63 traces:

| negative set | n | specificity | 95% CI |
|---|---|---|---|
| **upstream clean** (finishes speaking before the first injection) | 21 | **0.905** | [0.711, 0.973] |
| downstream clean (exposed to an upstream injection) | 161 | 0.634 | [0.557, 0.704] |
| pooled, as previously reported | 182 | 0.665 | — |

z = 2.48, p = 0.013. **Pooling understates specificity by about 0.27.**

Consequences, in order of how much they cost:

1. `Trace.upstream_clean_agents` is now the negative set, and
   `validate_on_injected.py` leads with it. Downstream is still reported, and
   still labelled as contaminated rather than dropped, because the gap between
   the two is itself informative about propagation.
2. Two rounds of work -- the prompt revision below, and a rule that discarded
   agent verdicts lacking grounded local evidence -- were spent fixing a
   problem that did not exist. Neither moved discrimination, and now it is
   clear why.
3. It also explains a result that looked alarming: among flagged slots, the
   uncertainty features separated "true" from "false" positives at AUC 0.32,
   *below chance*, with false positives carrying **higher** mean confidence
   (0.618 vs 0.536). There was nothing to separate. Many of those false
   positives were correct.

Upstream negatives are scarce and unevenly distributed: dylan injects from step
one and contributed 1 of the 21, clinical_agent contributed 20. **Sample
clinical_agent and clinical_agent5 when the quantity of interest is
specificity.**

### What the transcript was missing (v0.6.5) -- the largest single fix so far

`Step.content` held only what an agent said. `input_messages` -- the tool
outputs, retrieved records and per-turn instructions handed TO the agent -- was
dropped. On ClinicalAgent5 a SafetyAgent would be given

    Safety tool outputs: The historical failure rate of etanercept ... is 0.42

repeat the figure in its answer, and be scored as 1.1.1 factual hallucination,
because from the transcript alone the number had no source. That single
omission accounted for most of what looked like over-flagging.

`Step.context` now carries the novel part of the user message, deduplicated
across steps (debate prompts restate the whole history; echoing it back would
double the transcript) and rendered under a header that marks it as material
the agent was **given**, not claims it made.

Paired runs on identical traces:

| | recall | upstream spec | downstream spec | 1.1.1 cited | violations |
|---|---|---|---|---|---|
| dylan, n=32, no context | 0.891 | — | 0.556 | 27 | 10 |
| dylan, n=32, with context | 0.891 | — | **0.762** | 24 | 15 |
| ClinicalAgent5, n=30, no context | 0.672 | 0.619 | 0.683 | 15 | 93 |
| ClinicalAgent5, n=30, with context | **0.731** | **0.738** | **0.732** | 10 | 84 |

Recall and specificity rise together, which is what separates a real gain from
the operating-point shift the prompt revision produced. The effect concentrates
exactly where the diagnosis said it would: upstream retrieval sub-agents
(Safety/Efficacy/Enrollment) went from **0.450 to 0.700** specificity. Cost is a
41-54% longer transcript, which the scorer pays on every call.

**Every specificity figure measured before this fix is void.** The 0.469, the
0.659, the 0.701 -- all measured on transcripts missing the evidence the agents
were working from.

### The contamination gap shrank with sample size

The upstream/downstream split reported at 63 traces did not hold up:

| traces | upstream spec | downstream spec | gap | p |
|---|---|---|---|---|
| 63 | 0.905 (n=21) | 0.634 (n=161) | +0.271 | 0.013 |
| 82 | 0.729 (n=48) | 0.645 (n=186) | +0.084 | — |
| 122 | 0.701 (n=97) | 0.599 (n=242) | +0.102 | 0.079 |

Propagation is real but explains roughly ten points, not twenty-seven. Keep the
split -- the gap is informative -- but do not lead with the n=21 figure. This
is a usable illustration of a p=0.013 result at n=21 becoming p=0.079 at n=97.

### Stage 4 on real residuals (81 items, 62 traces)

Clustering the annotator's own NOVEL proposals, with `claude-opus-5` as an
independent judge (Stage 1 ran on GPT, so the triage is not a self-assessment):

| cluster | n | framework | verdict | absorbed by | votes |
|---|---|---|---|---|---|
| Assigned-lane nonperformance | 16 | ca5 | A | 2.1.2 | 3/4 |
| Aggregation nonexecution | 15 | ca5 | A | 1.2.1 | 4/4 |
| Intra-turn reasoning–answer contradiction | 13 | dylan | A | 3.2.1 | 8/8 |
| Unsupported evidentiary inflation | 6 | ca5 | A | 1.1.1 | 6/6 |

**All four were absorbed. No new failure type survived** -- which is the right
outcome to report, and a working demonstration that the triage resists
novelty rather than manufacturing it. The `NOVEL_UNSUPPORTED_*` family, the one
candidate that survived the context fix, turned out to be 1.1.1 with a wider
scope.

The `structural_difference` field is where the value is. On the intra-turn
cluster the judge wrote: *3.2.1 was written for a meta-agent flipping between
rounds, so the contradiction is detected by comparing two turns; here it is
compressed into one.* On the evidentiary cluster: *the code was written for
perceptual case-fact inputs, whereas here the misread input is a retrieved
knowledge-graph edge.* Those are concrete, citable scope revisions, and they
are the quantitative form of "the seed taxonomy was written for debate-style
systems and has to be stretched to fit a pipeline".

Two operational notes. `--auto-threshold` put G2 at **0.613** (q95 of pairwise
cosine among seed codes) against the hardcoded 0.82, which would have passed
almost anything. And residuals are lopsided: 66 of 81 came from ClinicalAgent5
against 15 from dylan, so pipelines generate four times the out-of-taxonomy
residue.

### Where the numbers settled (v0.6.6)

Measured on 73 simulated traces with the context fix in place. Everything
earlier is superseded.

```
agent recall              0.773   n=163
specificity UPSTREAM      0.686   n= 70   95% CI [0.570, 0.782]
specificity DOWNSTREAM    0.714   n=112   95% CI [0.625, 0.790]
precision                 0.700
earliest step  exact=0.589  within1=0.795
step recall               0.246
```

**The upstream/downstream gap is gone, and slightly reversed.** Whatever
propagation contributes is smaller than the noise once the transcript shows
what each agent was working from. The full retraction, across four
measurements of the same quantity:

| | upstream | downstream | gap |
|---|---|---|---|
| 63 traces, no context | 0.905 (n=21) | 0.634 | +0.271 (p=0.013) |
| 122 traces, no context | 0.701 (n=97) | 0.599 | +0.102 (p=0.079) |
| 73 traces, **with context** | 0.686 (n=70) | 0.714 | **-0.028** |

Downstream agents were flagged more not because they were contaminated but
because they lean hardest on material the transcript did not show. Keep the
split reported -- it costs nothing and the gap is a diagnostic -- but do not
attribute anything to propagation.

So the annotator's real specificity is about **0.70**, with recall about
**0.77**. That is a middling instrument, and the correct response is
calibration and conformal routing, which is what the pipeline was built to do.
It is not more prompt engineering.

### Three prompt revisions, none of them measurable

Chronologically: an evidence rule plus neutral base-rate framing (0.6.2), a
post-hoc filter discarding agent verdicts without grounded local evidence, and
a note that input blocks are given material rather than agent behaviour
(0.6.6). Paired on identical traces:

| change | effect |
|---|---|
| evidence rule + base rate | specificity +0.068, recall -0.100. Balanced accuracy fell. An operating-point shift, not discrimination. |
| discard ungrounded verdicts | specificity unchanged (0.659 -> 0.659), recall -0.033. The false positives quote real text. |
| input-block note | exact, within1 and too-early all identical to three decimal places. |

The third one is worth dwelling on. It was written to fix a jump in
`predicted-too-early` from 0.032 to 0.219 -- which turned out not to exist. The
two figures came from samples with different framework mixes (mostly
ClinicalAgent5 versus mostly dylan), and on paired traces the rate is 0.071
either way. **That is the same mistake `compare_prompts.py` prints a warning
about, made by the person who wrote the warning.**

Four times now a result has evaporated under pairing or a larger sample: the
0.905 upstream specificity, the +0.271 propagation gap, the prompt-revision
specificity gain, and this. **Pair every comparison. Do not compare across
samples, however similar they look.**

### Anchor task file (73 traces)

```
317 tasks: 149 agent, 98 mode (binary), 70 step (one multiple-choice per trace)
144 carry evidence cards | 13 strata | 51 calibration traces, 22 frozen
```

One caveat visible in the strata. The probability bins came out
`{p:0/5: 76, p:1/5: 4, p:2/5: 1, p:3/5: 4, p:4/5: 113}` -- 189 of 247 binary
slots sit at the extremes and 9 in the middle three bins. Stratified coverage
sampling fills bins in proportion to the population; it cannot manufacture
mid-range examples that do not exist. The calibrator will therefore be fitted
almost entirely on confident slots, and its behaviour in the middle -- exactly
where routing decisions are made -- rests on very little.

This was initially blamed on `top_logprobs` being stripped. It is not (see the
bimodality section): a graded 0-100 score is just as extreme. **The task file
does not need regenerating** -- stratifying on the verbalised score picks
essentially the same slots -- so send it as it is rather than spending more
time upstream of the annotators.

### The confidence signal is bimodal, and that is the model, not the endpoint (v0.6.7)

Every proxy tried returns `top_logprobs` empty, so p(1) is `exp(logprob)` of the
emitted token and cannot be renormalised over {0, 1}. The obvious diagnosis was
that this is what pins the score to the extremes. It is not.

Asking the scorer for a graded 0-100 integer instead -- same call count, same
questions, a system prompt that explicitly says to use the full range and to
say 40 or 65 when the evidence points that way -- moves almost nothing:

| | in [0.15, 0.85] | bins (5) |
|---|---|---|
| `p_token` (logprob) | 6/144 = 4% | {0: 55, 1: 4, 2: 1, 4: 84} |
| `p_verbalised` (0-100) | 11/144 = 8% | {0: 61, 1: 1, 2: 2, 3: 7, 4: 73} |

Five slots. **The model is simply very confident about these audit questions**,
in either output format. Three levers have now been tried and none of them
opened up the middle: a different endpoint, a different output format, and a
system prompt demanding calibrated use of the range. What is left is repeated
sampling (semantic entropy, self-consistency), which the design rules out.

Two things follow.

**Calibration has to rest on the black-box features.** Evidence groundedness,
the six violation families, cross-level coherence, verbalised confidence. That
is not a consolation prize: on the MedAgentAudit anchor, groundedness alone was
the largest single contributor (AUC 0.872 -> 0.890 of a 0.861 -> 0.900 total),
and that data contains no logprobs at all.

**Conformal matters more, not less.** A bimodal score cannot be usefully
thresholded -- there is nothing at the threshold. Quantile calibration on a
held-out set is the only thing that turns it into a decision with a stated
error rate.

`ScorerConfig.mode` is `auto | logprob | verbalised | both`, defaulting to
`auto`, which picks logprob only when the probe sees real alternatives. `both`
keeps the two as separate features with their own missingness indicators --
worth having because a decoding probability and a self-report fail in different
ways, but it doubles the scorer calls for the five slots above, so it is not the
default.

### Prompt revision (v0.6.2), and what it did not fix

Three changes aimed at the over-flagging: neutral base-rate framing (the
annotator is told explicitly that some transcripts contain no failure and that
it is told nothing about how many agents are at fault), an explicit evidence
rule (a "1" requires a findings entry with a verbatim quote from that agent's
own output), and slot questions reworded from "does this agent commit a
failure" to "is there a passage you could quote".

The key's quota ran out two traces into the comparison run, so the paired
result is n=2 and proves nothing on its own:

| | recall | specificity | findings | violations |
|---|---|---|---|---|
| old prompt | 0.833 | 0.00 (0/2) | 10 | 4 |
| new prompt | 0.833 | 0.00 (0/2) | **16** | **2** |

Identical verdicts, but findings rose 10 -> 16 and structural violations fell
4 -> 2: the annotator is now attaching evidence to verdicts it was previously
asserting bare. That is the mechanism the change was aimed at, and it is
working; whether it moves specificity is untested. Both traces happened to have
six of seven agents injected, leaving a single confirmed negative each, so
specificity on this subset is 0/2 either way and carries no information.

**Re-run the comparison on 50+ traces per framework before drawing any
conclusion, and prefer frameworks with a higher clean-agent fraction (dylan and
clinical_agent inject ~2 of 4-6 agents; mdagents injects 4 of 7).**

Both prompts now run from the same code, so the comparison is paired:

```bash
python scripts/run_stage1.py --data data/sim --work run_legacy  --legacy-prompt
python scripts/run_stage1.py --data data/sim --work run_current
python scripts/compare_prompts.py --data data/sim --a run_legacy --b run_current
```

Pairing matters more than sample size here. Between-framework variance in the
clean-agent fraction is larger than any plausible prompt effect, so an unpaired
comparison across different samples can move specificity by more than the
change being measured. `compare_prompts.py` warns below 100 confirmed
negatives; 300+ is a reasonable floor.

On model names: aihubmix serves a discounted `gpt-5.6-sol-discount` alongside
`gpt-5.6-sol` and `gpt-5.6-sol-disc`. All three take the same call shape, so
`--model gpt-5.6-sol-discount --scorer-model gpt-5.6-sol-discount` is the cheap
default there.

Note that "usage limit exhausted" on aihubmix is a **per-key cap**, separate
from the account balance -- topping up the account does not clear it. The key's
own limit has to be raised and the key reactivated in the key management page.

## 6d. First run on the real corpus (92 traces)

Everything above was measured on injected traces. This is the natural corpus:
48 traces the systems got wrong and 44 they got right, balanced across all four
frameworks, annotated with the context fix and the current prompt.

### Quality holds up, and is better than the simulated split suggested

```
200 findings, 0 quotes that failed verification
violations 0.52 per trace  (against 2.8 on ClinicalAgent5 simulated)
```

Zero ungrounded quotes out of 200. Structural self-consistency is five times
better than on injected traces. The simulated split was understating the
annotator.

### Does the annotator distinguish a run that failed from one that did not?

There is no injection label here, so the clean split is the only available
stand-in for specificity. Paired within framework:

| framework | n f/c | flag rate, wrong | flag rate, right | Δ | findings, wrong | findings, right |
|---|---|---|---|---|---|---|
| clinical_agent | 12/12 | 0.278 | 0.208 | +0.069 | 1.83 | 1.42 |
| clinical_agent5 | 12/10 | 0.300 | 0.280 | +0.020 | 2.25 | 2.10 |
| **dylan** | 12/12 | **0.750** | **0.478** | **+0.272** | **3.42** | **1.92** |
| mdagents | 10/12 | 0.300 | 0.238 | +0.062 | 2.10 | 2.33 |

One framework separates the two clearly; three do not. Pooling them produces a
flat result, which is what the first look reported before the per-framework
split was done -- the same mixing error this file warns about twice already.

The code distributions say more than the rates. On dylan:

```
wrong:  2.2.1 x19   3.2.1 x12   1.1.1 x10
right:  2.2.1 x20   3.2.1 x 1   1.1.1 x 0
```

Repetition of initial views is equally common either way; self-contradiction
and factual error essentially vanish from the runs that came out right. **Not
every failure type is coupled to the outcome, and the annotator separates the
ones that are.** On the pipelines the picture inverts: `clinical_agent` cites
1.1.1 twelve times on wrong runs and eleven times on right ones.

The likely cause is structural. Cross-round codes (2.2.1, 2.2.2, 3.2.1) are
only askable where there is debate; the pipelines are masked out of them and
are left with single-turn codes, which occur at similar rates whatever the
outcome. **Pipeline architectures are less attributable, and that is a property
of the architecture rather than of the method.**

### What the pipeline 1.1.1 findings actually are

1.1.1 fires 34 times across the two pipeline frameworks, evenly split between
correct and incorrect runs, so it was audited offline for a repeat of the
missing-context artefact. It is not one:

```
34/34 of the flagged steps had a context block
17 quotes contain a decimal figure; 15 of those have every figure traceable
   to that step's own context
16 of 34 are SafetyAgent
```

The numbers are sourced. What the annotator objects to is semantic misuse: a
tool output gives an *overall* historical trial failure rate of 0.42, and the
agent reports it as a *safety* failure rate; a rate supplied for one drug is
attributed to a two-drug combination; permitted concomitant therapies are read
as a mandatory four-drug regimen. Those are real clinical reasoning errors,
concentrated in one role, and mild enough not to change the final answer --
which is exactly why the code appears equally on runs that succeeded.

It also stretches the code. MedAgentAudit's 1.1.1 covers asserting facts absent
from or contradicting the input; here the figures are present and the error is
in what they are taken to mean. That is a scope revision of the same shape as
the intra-turn one Stage 4 found, and it is the single most useful thing to put
in front of a human annotator.

### Anchors, from the real corpus

```bash
python scripts/make_anchor_tasks.py --data data --work run_real \
    --budget 360 --step-traces 92 --annotators 3 --group-by kind,split
```

```
400 tasks: 176 agent, 132 mode, 92 step
split      faulty 201 / clean 199
framework  clinical_agent 113, dylan 98, mdagents 97, clinical_agent5 92
verdicts   (wrong,1) 45  (wrong,0) 110  (right,1) 35  (right,0) 118
```

`split` is now a Mondrian dimension. It has to be: dylan's flag rate moves by
0.272 between splits and ClinicalAgent5's by 0.02, so one calibrator fitted
across both is wrong for both.

The 35 slots flagged on runs that came out right are where the human judgement
is worth most, and among them the ten 1.1.1 tasks carry a question the
annotator cannot settle for itself: *the tool output said "historical failure
rate 0.42" and the agent wrote "safety failure rate 0.42" -- is that a failure?*
Answering yes widens 1.1.1 from hallucination to evidence misuse. Answering no
means the pipeline false-positive rate has to be re-estimated. Flag those tasks
to the annotators explicitly.

## 6c. Three visual artefacts

`figures/dataflow.html` — the framework diagram made operable, and written for
a reader with no background in the area.

Three things distinguish it from the diagram in the paper. Every edge is placed
by hand as orthogonal segments rather than auto-routed, so no arrowhead lands
behind a box and no line crosses one. That took two attempts: the first version
reused one left-to-right shape for every edge, and the four right-to-left edges
along the bottom were consequently drawn from the source box's *right* edge to
the target's *left*, straight through both. The feedback arrow and the adapter
arrow also landed on the same point of the same box, which reads as one
connection rather than two. Selecting a module dims everything else
to half and fills three panels — what the module does, what it receives, what it
produces — with the actual values for whichever case is chosen. And each module
carries a small schematic of the transformation itself, in the visual grammar of
a conference figure: a vector as a bar of cells with a filled circle in each, an
operation as a symbol in a bubble, a probability as a partly filled bar, a
shortlist in braces.

A status ribbon above the diagram carries the headline figures, with the
pending ones hatched rather than omitted: 400 clinician questions unanswered
and zero new mistake types admitted are as much a part of the progress report
as the 0.90 and the 71%.

Above those panels sits the answer the whole pass produces: the three labels
for the selected conversation, written out. Which assistants made a mistake,
where the first one appears, and what kind — each entry marked settled, clear,
or handed to a doctor, so the reader can see both what was decided and what was
declined. Anything the reviewer could not name is listed separately as feeding
the lower row.

Five modules open a full-width panel underneath, because they are the ones a
reader will not accept on assertion: every question put to the reviewer with
its answer and confidence; all twenty self-checks with which ones failed here;
the twenty-six numbers with what each measures and its value for one chosen
question; the four admission tests with what has to be true and what each
costs; and a two-panel sketch of the grouping step, with a table of the four
choices made in it and why.

The vocabulary is deliberately plain. No module is called a calibrator, a
conformal router or a taxonomy; they are "learn how often it is right", "decide
what needs a doctor" and "the list of mistake types". Coverage is described as
"a shortlist that contains the right answer at least nine times in ten" rather
than as 1 − α. A reviewer outside the field should be able to follow the whole
path without a glossary. Fifteen modules
and seventeen edges are generated from data rather than hand-placed, so every
module carries an id, a hit area and keyboard focus. Selecting one dims
everything else to 50% and fills three panels: what the module is for, what
crosses its input boundary, and what crosses its output boundary — with the
**actual values** for whichever of the eight consultations is chosen, not a
description of what the values would be. Picking the adapter shows the step
list, the derived capabilities and the codes ruled out with the capability each
one is missing; picking the reasoner shows the verdict array, each finding as
`code@agent/step`, the earliest fault step and the self-confidence figures.

Each module also carries the note it earned. The re-audit module records that
the judge answers with the code *and its name* — "2.2.1 Repetition of initial
views" rather than "2.2.1" — which failed the code match, dropped every vote
and made every cluster come out novel. Observed, not anticipated.

Calibration and the conformal router are drawn hollow and their output panels
say `no model fitted` and `no sets produced`. Both need anchors; 400 tasks are
drawn and waiting. An empty panel is a more useful thing to show a reviewer
than an invented one.

`figures/explorer.html` — an explainer in the spirit of Transformer Explainer. Eight recorded consultations, two per framework and one of each
outcome. The board is three columns: the transcript, the capability mask and
question grid, the findings.

What makes it more than a diagram is that the capability switches are live.
Turn off *agents can read each other* and codes 2.2.1 and 2.2.2 go dashed, the
question count drops, and any finding that depended on them disappears from the
right-hand column. That is the argument about structural applicability made by
letting someone break it, rather than asserted. Hovering a question lights the
steps it concerns; clicking a finding opens the step it came from and
highlights the quoted span in place, which is the evidence check running in
front of the reader.

`figures/instance_walkthrough.html` — a linear read of a single instance for
when a reader wants the argument in order rather than under their hands. Better
suited to print supplementary material.

Both are self-contained single files with the data embedded, no build step and
no network beyond a webfont. Calibration and routing are deliberately absent
from both: they need anchors that do not exist yet, and showing a stage that
has never run would be a fabrication.

## 6c-b. Walkthrough page

`figures/instance_walkthrough.html` is a single self-contained file (no build,
no network beyond a webfont) that follows one real trace --
ClinicalAgent5 / NCT00031551 -- through every stage: the normalised transcript,
the capability mask that rules four codes out, all sixteen slots with their
questions and scorer probabilities, the findings and the quotes holding them
up, the structural checks, the scoring against the injection log, and the three
proposals that fell outside the taxonomy. Slots are clickable.

Everything on it is from a recorded run rather than mocked up, including the
one false positive and the earliest-step prediction landing a step early. It is
meant to double as supplementary material: a reviewer can see what a
"three-level annotation" actually is without reading the code.

Stages 2 and 3 are deliberately absent from the page. They need human anchors,
and none have been collected.

## 6e. Calibration and routing, actually run (v0.7.2)

These two stages had never run on our own traces for want of human labels. They
do not need human labels to run at all — the injection log gives agent-level and
step-level truth for free, so 745 pseudo-anchors were built from 85 simulated
traces and used to fit Head A and calibrate the conformal quantiles.

```
Head A    AUC 0.9140   ECE 0.0462   Brier 0.0905   accuracy 0.8874
          fitted on 372 anchors, calibrated on a disjoint 373
selective error   50% coverage 3.7%   70% 5.0%   100% 11.3%
```

Conformal coverage, α = 0.10, Mondrian over slot kind × framework:

| group | n | coverage | avg set | singleton |
|---|---|---|---|---|
| agent \| clinical_agent5 | 87 | 0.920 | 1.30 | 0.701 |
| agent \| dylan | 53 | 0.925 | 1.28 | 0.717 |
| step \| clinical_agent5 | 96 | 0.917 | 1.03 | 0.969 |
| step \| dylan | 137 | 0.912 | 0.93 | 0.934 |
| pooled | 373 | 0.903 | 1.06 | 0.938 |

**All four groups clear the target and none fell back to the pooled quantile.**
On the earlier MedAgentAudit anchor one group sat at 0.793 while the pooled
figure looked healthy — the difference is enough anchors per group.

Routing, checked against the injection log:

```
agent slots   280 admitted automatically, 113 sent to a human   automation 71.2%
              on the admitted portion: error 9.6%, recall 0.876, specificity 0.927
              against 11.3% error with no routing at all
traces        AUTO 5, VERIFY 52, REVIEW 28
human load    219 questions over 80 traces, 2.7 per queued trace
```

Trace-level AUTO is low by design: a trace is admitted only when every one of
its slots is a singleton, so one ambiguous slot out of sixteen sends the whole
trace to a human. Three levels have to be reliable together before a trace
enters the corpus unreviewed.

Three limits belong next to these numbers.

**Pseudo-anchors are not human labels.** The injection log answers *where did we
inject*, not *which agent failed*; how many of the 11 false positives are
propagation rather than error is not answerable from this data.

**Head B is not fitted.** Agreement needs at least two annotators and the
injection log is one. The queue ranks by model risk alone, losing whatever the
resolvability head would have bought.

**The loop has never turned twice.** All four clusters were absorbed, so T0 was
never superseded and the recalibration path — which the code enforces by
refusing to score across a taxonomy change — has not been exercised on a real
change. Worth stating plainly: the self-evolution loop is implemented and
tested, not demonstrated.

**Mode level has no anchors at all.** MAST and MedAgentAudit are different label
spaces, so an injected `fm_error_type` cannot score a MedAgentAudit code. Error
level remains uncalibrated, and that is exactly the hole the 400 human tasks are
cut to fill.

## 6f. Holding codes out, so that there is something to find (v0.7.6)

Run with all ten codes, Stage 4 absorbed every cluster and admitted nothing.
That is the correct outcome, but it demonstrates the loop only in its refusal.
Removing codes creates a case where something genuinely should be discovered
and turns "can it evolve" into a number: of k codes held out, how many come
back.

`scripts/ablate_seed.py --suggest-holdout` first prints what the corpus
actually exhibits, because removing a code that never fires measures the corpus
rather than the method. Over 86 real traces:

```
1.1.1  53   2.2.1  34   2.1.2  24   3.2.1  13   1.2.1  12
3.1.1   5   2.1.1   4   2.2.2   2   3.1.2   1   3.1.3   1
```

So the four most frequent are held out and the six rare ones kept as the seed.
Re-annotating under the six-code taxonomy, the residue appears immediately: 75
traces produced **38 proposals under 37 distinct names**, against 81 residual
items from 86 traces with the full taxonomy. Several names are visibly the
held-out concepts resurfacing in other words —

```
"Conclusion–rationale contradiction"              cf. held-out 3.2.1
"Conclusion contradicts stated reasoning"         the same thing again
"Diagnostic reasoning–answer qualifier mismatch"
"Recruitment instruction violation and role overreach"  ×6, in no seed code
```

Three conditions decide whether the experiment measures anything, and all three
are enforced in the script rather than left to the operator.

**The unmasked re-audit sees only the seed.** It is the step that decides
whether a cluster is already covered; give it the full taxonomy and a held-out
code absorbs its own rediscovery on the spot.

**Matching is semantic, never by name.** A recovered code will be called
something else. Recovery is scored twice — by embedding proximity to the
held-out definition, and by an independent judge asked whether a domain expert
would say the two describe the same failure — and both are reported, because
they disagree often enough to be worth seeing.

**The judge is a different model family** from the annotator, so the taxonomy is
not marking its own work.

What it cannot settle: the annotator has almost certainly seen MedAgentAudit
and MAST in pretraining, so recovery is not invention from nothing. The claim
is that the pipeline surfaces a real repeated failure its taxonomy cannot
express and packages it well enough to clear the admission gate — not that the
model derived the concept unaided. State it that way.

### Discovered codes are not numbered into the seed

`admit()` used to mint `T{version}.{cluster_id}`, and the obvious alternative
was to slot the new code into the seed numbering as, say, `2.1.3`. Both are
wrong. The seed numbers are MedAgentAudit's and encode its three-stage
structure, so `2.1.3` quietly asserts membership in that structure and a
position in its ordering, neither of which has been shown. Two runs discovering
different things would also both land on `2.1.3` and stop being comparable. In
the ablation it is worse still: auto-naming a rediscovery `1.1.1` writes the
answer into the identifier.

Discovered codes now take the form `D<version>.<slug>` —
`D1.conclusion-rationale-contradiction` — where the version says when it
entered and the slug says what it is. Collisions get a numeric suffix. Where the
code sits structurally is recorded in a separate `stage` field, which is enough
to group it with the seed codes in a report without renumbering anything, and a
`parent` field records the code it narrows or widens when it is a scope
revision. `normalise_code` accepts the new form, so a judge answering with the
identifier and its name still matches.

### What the ablation actually produced

Held out 1.1.1, 2.2.1, 2.1.2 and 3.2.1; kept the six rare codes as the seed;
re-annotated 91 real traces under it. The residue clustered into three groups:

| cluster | n | framework | verdict | name it gave itself |
|---|---|---|---|---|
| 0 | 15 | mdagents | AB? | Role-boundary violation via premature task completion |
| 1 | 5 | clinical_agent5 | **B** | Overall failure-rate domain conflation |
| 2 | 7 | clinical_agent | A → 3.1.3 | Unverifiable numerical synthesis by the aggregating agent |

**None of the four held-out codes came back in recognisable form.** Two
candidates appeared that belong to neither the seed nor the held-out set, which
is a different and more interesting outcome than the one the experiment was
designed to test.

Cluster 1 is worth reading closely. Its members —

```
Overall trial failure rate misattributed
Metric-domain conflation in lane scoring
Unsupported safety reinterpretation of a general failure rate
Misapplication of an overall failure rate
Source-scope misattribution
```

— are the mechanism found by hand when the 34 pipeline 1.1.1 findings were
audited: an undifferentiated historical failure rate reported as a
safety-specific one, a single-drug figure attributed to a combination. The
re-audit voted 0 of 5 for absorption, and it is right to: 1.1.1 covers
asserting facts absent from the input, whereas here the figure *is* in the
input and the error is in what it is taken to measure. The pipeline arrived at
a distinction that had previously been reached by reading transcripts by hand.

Cluster 0 sat at an absorb rate of 0.40 and was routed to a human by the
ambiguous band. That is also correct — a recruiter breaking an explicit output
contract and answering the clinical question itself is in neither taxonomy.

Cluster 2 was absorbed by 3.1.3 on 4 of 5 votes, but the fit is a stretch:
3.1.3 is about claiming agreement over incompatible reasons, and this is about
a figure that cannot be reconstructed from the components it claims to combine.
Worth flagging as a case where the absorb threshold was probably too generous.

### A silent drop that cost a result

Cluster 1 did not appear in the first run at all. Eight items, all the same
mechanism, were judged incoherent by a single summariser call and discarded
before the re-audit ever saw them — and nothing recorded that the cluster had
existed. Re-running after the fix, the same data yields a coherent five-item
cluster with a precise definition and a unanimous novelty verdict.

`TriageConfig.incoherent` is now `route` by default: a cluster the summariser
cannot name goes to the human queue as `AB?`, carrying whatever name and
members it has, and `evolution_report` lists them under `incoherent_but_kept`.
`drop` restores the old behaviour for the ablation. **One model call should not
hold a silent veto over a clustering that worked**, and silent loss is a worse
failure than a visible misjudgement: a wrong verdict stays in the report where
someone can argue with it.

### The ceiling on discovery is upstream

The four held-out codes did not return because the residue never contained
them. Removing 2.2.1 and 3.2.1 — 34 and 13 findings respectively under the full
taxonomy — did not produce 47 corresponding proposals; the whole residual pool
was 45 items and most of it was something else. **When no code fits, the
annotator largely goes quiet rather than proposing one.**

So Stage 4's recall is bounded by Stage 1's willingness to say "I see
something I cannot name", and the prompt currently treats the NOVEL field as an
exception to be used sparingly. That is the next thing to change, and it is
testable: re-run this same ablation after the prompt change and compare the
residual pool against the 45 items and three clusters recorded here.

### What the ablation actually produced

91 real traces re-annotated under the six-code seed gave 45 residual proposals
under 44 distinct names, which clustered into three groups:

| cluster | n | framework | verdict | name it was given |
|---|---|---|---|---|
| 0 | 15 | mdagents | **AB?** | Role-boundary violation via premature task completion |
| 1 | 5 | clinical_agent5 | **B** | Overall failure-rate domain conflation |
| 2 | 7 | clinical_agent | A, absorbed by 3.1.3 | Unverifiable numerical synthesis by the aggregating agent |

**None of the four held-out codes came back as itself.** What came back instead
were two candidates that are in neither the seed nor the held-out set.

Cluster 1 is the interesting one. Its definition — *an agent cites an
undifferentiated trial-level failure rate and treats it as measuring failure in
the analytic lane it was assigned* — is the mechanism found by hand-auditing the
34 pipeline 1.1.1 findings earlier, where a tool output giving an overall
historical failure rate was reported as a safety-specific one. The re-audit
voted 5–0 that no seed code covers it, and it is right to: 1.1.1 is about
asserting facts absent from the input, whereas here the figure is present and
the error is in what it is taken to mean. The pipeline arrived at a distinction
that had previously needed a person to notice.

Cluster 0 was held by the ambiguous band at an absorb rate of 0.40 — correctly,
since it describes a recruiter breaking an explicit output contract and
answering the clinical question itself, which fits nothing in either set.

Three conclusions, of which the second is the most useful.

**The loop does produce new types**, with definitions specific enough to survive
an unmasked re-audit by a different model family.

**Gaps in a taxonomy do not become residue on their own.** 2.2.1 and 3.2.1 fire
34 and 13 times under the full taxonomy; with them removed, the corresponding
material largely did not reappear as NOVEL proposals. The annotator tends to
say nothing when it has no code to hand, rather than to say it has no code.
Stage 4's recall is therefore bounded by Stage 1's willingness to admit
ignorance, which is a prompt-level problem and a testable one.

**Silent dropping is worse than misjudging.** See below.

### A single model call had a silent veto (v0.7.7)

Cluster 1 did not appear in the first run of this ablation. It was clustered
correctly, all eight of its members were the same mechanism, and then one
summariser call returned `coherent: false` and `require_coherent=True` dropped
it before the re-audit ever saw it. Nothing in any output recorded that it had
existed.

`TriageConfig.incoherent` now takes `route` (the default), `drop` or `ignore`.
An incoherent verdict sends the cluster to the human queue as `AB?`, carrying
whatever name and members it has, and `evolution_report` lists these separately
under `incoherent_but_kept`. Re-running the same cluster under the new default
produced the `B` verdict above.

The general shape is worth keeping in mind: a misjudgement stays in the report
and can be argued with, a silent drop cannot. Prefer routing to discarding
anywhere a single model call stands between a result and oblivion.

### Telling it that silence is not safe (v0.7.8)

The ablation showed that a gap in the taxonomy does not become residue on its
own: remove 2.2.1 and 3.2.1, which fire 34 and 13 times, and the corresponding
material largely fails to reappear as proposals. The annotator says nothing
when it has no code to hand, rather than saying it has no code.

The `novel_modes` instruction was a single line inside a list, and asked for
restraint. It is now its own section and argues from asymmetric cost:

> The list above is not complete and is not assumed to be. It was written from
> other collaboration structures and is known to transfer imperfectly.
>
> Silence is not the safe answer here. Reporting no failure because no code
> fits loses the observation entirely; proposing one that turns out to be an
> existing code merely gets it merged later. **The second is recoverable and the
> first is not.**

Paired on 36 simulated traces, against the previous prompt:

| | old | new | Δ |
|---|---|---|---|
| recall | 0.779 | 0.857 | **+0.078** |
| specificity, upstream (n=33) | 0.727 | 0.727 | **0.000** |
| specificity, downstream (n=56) | 0.679 | 0.554 | −0.125 |
| earliest step exact | 0.639 | 0.694 | +0.056 |
| proposals per trace | 1.47 | 2.78 | +1.31 |
| self-check failures per trace | 1.78 | 2.86 | +1.08 |

**This is the first prompt change in six that is not an operating-point shift.**
Recall rises, upstream specificity — the only uncontested kind, measured on
agents that finish speaking before any injection — does not move at all, and
earliest-step accuracy improves. The five earlier attempts all traded one
against another.

The downstream drop is on agents exposed to an upstream corruption, where the
earlier false-positive audit found the flags to be largely correct and the
injection label simply not to count them. It is also within noise at n=56.

Five earlier attempts and one success is a ratio worth remembering: the
successful one argued from a cost asymmetry the annotator could act on, and
the failures asked it to be more careful.

### A gate that rejects nothing, kept anyway

The self-check failures doubled alongside the proposals, and the obvious
suspect was hasty proposals. `ResidualFilter` was added to the pool entrance to
require a real name, a definition of at least eight words, and a stated reason
why the nearest existing code does not fit.

Measured on both runs it rejects **nothing** — every proposal clears every
threshold. The extra self-check failures come from the extra findings, not from
the proposals. The hypothesis was wrong.

It is kept for a different reason. It sits where the cost of one bad entry is
high, since a category seeded from an unquotable or three-word proposal
propagates into the taxonomy; it is free; and it reports what it rejects rather
than dropping quietly. The version that silently ate a correct cluster is one
release back, and the lesson generalises.

### Re-running the ablation with the new instruction (v0.7.9)

The point of the prompt change was to remove the bottleneck the ablation
exposed. Re-run under the same six-code seed:

| | old instruction, 91 traces | new instruction, 36 traces |
|---|---|---|
| proposals per trace | 0.49 | **1.83** |
| clusters | 3, plus 12 noise | **2, plus 5 noise** |
| largest cluster | 15 | **39** |
| clusters spanning more than one framework | 0 | **2** |

Thirty-six traces now yield more residue than ninety-one did, and the clusters
are cleaner. The cross-framework count is the one that matters operationally:
gate G1 requires support in at least two frameworks, and under the old
instruction no cluster could ever have met it.

### The A/B verdict flipped on the same mechanism

Worth setting out plainly, because it is a reliability problem rather than a
result.

```
old instruction   "Overall failure-rate domain conflation"            n= 5  ->  B   (0/5 absorbed)
new instruction   "Non-specific base-rate misread as domain-specific"  n=28  ->  A   (5/5 by 1.2.1)
```

Both describe the same thing: an undifferentiated aggregate failure rate used
as domain-specific evidence. One run says no seed code covers it; the other says
1.2.1 covers it, unanimously.

The likeliest cause is that the sharper definition made it classifiable. The new
one states that an agent assigned one analytic dimension cites an
undifferentiated aggregate statistic — and 1.2.1 is "answers something other
than the specific question asked", which that fits on a literal reading. A vaguer
definition gave the judge nothing to match against. Cluster composition (5
traces from one framework versus 28 across two) and judge nondeterminism are
also live.

**The ambiguous band did not protect against this.** It catches absorb rates
near the threshold; these landed at 0.00 and 1.00, at opposite ends, and their
mean of 0.33 would have fallen outside the band and been accepted as novel.

`TriageConfig.repeats` (default 3) now runs the whole re-audit several times
and `max_rate_spread` (default 0.34) sends a cluster to a human when the runs
disagree by more than that, wherever the mean lands. The two mechanisms catch
different things and both are needed:

| | catches |
|---|---|
| ambiguous band | the model is *consistently* unsure — every run near 0.5 |
| spread threshold | the model *changes its mind* — runs at 0.0 and 1.0 |

The second is the more dangerous, because it can disguise itself as any mean at
all, including a confident-looking one. Checked against the four cases:

```
stable A          rates [1.00, 0.95, 1.00]  spread 0.05  ->  A
stable B          rates [0.00, 0.05, 0.00]  spread 0.05  ->  B
the real failure  rates [0.00, 1.00, 0.00]  spread 1.00  ->  AB?   (new)
consistently unsure rates [0.50, 0.52, 0.48] spread 0.04 ->  AB?   (band)
```

`absorbing_code` is now the code most runs settle on rather than whatever the
last one said, and `reaudit_detail` carries `rates`, `rate_spread` and
`code_votes` for audit. The cost is three times the judge calls on the most
expensive step in Stage 4, so `repeats=1` restores single-vote behaviour.
Three is the smallest usable default: two cannot tell an accidental
disagreement from a systematic one.

The second cluster behaved as designed: 22 items across two frameworks, votes
split 3–2 between 1.2.1 and 2.1.1, absorb rate 0.60, routed to `AB?`. It
describes an agent under a narrowed mandate producing output belonging to
another agent, which is genuinely between the two codes and genuinely a
person's call.

### `resplit` shipped switched on and could not run (v0.7.14)

Found before the re-run, not after, which is the only reason it is a note
rather than another overturned result.

`resplit` landed in 0.7.13 with `resplit_unnameable=True` by default. The
branch that calls it is guarded on `embed is not None`, and `embed` is a
keyword argument of `triage_clusters` that **neither driver script passed**:

```python
# scripts/ablate_seed.py, scripts/run_evolution.py  -- both, before 0.7.14
clusters = triage_clusters(clusters, seed, make_summarise(judge),
                           make_unmasked_reaudit(judge, tcfg), tcfg)
```

Both scripts build an embedder a few lines earlier and use it for
`cluster_residuals` and for `code_centroids`. It simply was not handed on.

So the first item on the handoff list — re-run the held-out ablation with
`resplit` live — would have run to completion, printed nothing unusual, routed
the 39-item cluster to `AB?` exactly as in 0.7.9, and cost a full round of
judge calls to learn nothing. The likely reading of that output is *resplit
does not help on the real cluster*, which would have been wrong and expensive
to unlearn. **This is the same shape as the silent drop in 0.7.7 and the
`sample_per_cluster < min_votes` combination in 0.6.5: the feature is present,
the run looks normal, and the behaviour is the old one.**

Reproduced offline with the hash embedder and a stub summariser that refuses on
anything over 12 items, on a 24-item group holding three lexically separable
mechanisms:

| | clusters out | triage |
|---|---|---|
| as the drivers called it | 1 | `AB?`, whole, unnamed |
| with `embed=` passed | **3** of 8/8/8 | each named, each reaching a verdict |

Three changes:

- both call sites pass `embed=embed`;
- when `resplit_unnameable` is on and a cluster is large enough but no embedder
  was supplied, `triage_clusters` prints the reason and records
  `summarise_detail["resplit_skipped"]`, so the no-op can no longer be silent;
- `resplit`'s own `HDBSCAN` call sets `copy=True`, matching `cluster_residuals`.
  Tested on this data path in sklearn 1.8 it does not mutate `E` — so this is
  not a live bug — but `E` is reused immediately for the part centroids, which
  feed gate G2, and sklearn's default flips in 1.10.

Also removed: `TriageConfig` carried **two further copies** of the same three
knobs under different names (`split_unnameable` / `min_splittable` /
`max_split_depth`, then `split_unnameable` again / `split_min_items` /
`split_max_depth`), one of them declaring `split_unnameable` twice in the same
dataclass, plus a dead `split_cluster()` duplicating `resplit()`. None of it
was read anywhere. Setting `split_unnameable=False` to turn the feature off
would have done nothing at all. The 0.7.13 changelog entries were duplicated in
this file for the same reason — the patch was applied more than once under
drifting names.

### `scripts/selfcheck_offline.py`

New, and it is the general lesson rather than the specific fix. `preflight.py`
answers *can this environment run?* and needs data and a key. This one answers
*are the features that are switched on reachable?* and needs neither:

```bash
python scripts/selfcheck_offline.py      # exits non-zero on any failure
```

Three checks today, all of which would have caught this class of bug:

1. every `triage_clusters` call site in `scripts/` passes `embed=` (AST, not grep);
2. no `TriageConfig` field is declared twice, and none is write-only;
3. an unnameable mixed cluster actually comes apart, end to end, with the
   hash embedder and a stub judge — and does *not* when `embed=` is withheld,
   which is checked as a negative control so the test cannot pass vacuously.

Add a check here whenever a feature depends on an argument a caller may omit.
The cost of this one was a few minutes; the cost of the last three of its kind
was a result each.

### The first run with `resplit` actually reachable (v0.7.14)

Data and both endpoints live; `run_ab2/` holds the run. Same six-code seed as
0.7.9, same recorded Stage 1 file (`examples/stage1_heldout_newprompt_36.jsonl`,
36 traces), so this is paired against that run and not against a fresh sample.

```
[ablate] residual pool 66 items          1.83 per trace, matching 0.7.9
[ablate] 2 clusters, 7 noise
[triage] cluster 1: all 3 naming attempts refused on 37 items; split into 2 of [16, 4]
  cluster 100: n=15 fw=2 -> AB?  'Nonspecific Failure-Rate Statistic Recast as Domain-Sp…'
  cluster 101: n= 4 fw=2 -> AB?  'Absence of Evidence Treated as Evidence of Inefficacy'
  cluster   0: n=22 fw=2 -> AB?  'Assigned-Scope Overreach (Role/Stage Boundary Violation…)'
```

**The mechanism works.** Three naming attempts refused on a 37-item group, the
group was cut, and the two pieces named cleanly on the next pass. The split is
also the right split: 0.7.9 recorded that the one definition the summariser did
eventually produce ended by listing four *other* error types present in the same
group, one of which was absent evidence converted into a prediction. That is now
cluster 101 under its own name. `cluster 100` comes back as n=15 rather than 16
because the summariser marked one member an outlier.

**Two things went wrong, and neither is the mechanism.**

*Seventeen items disappeared in the cut.* 37 went in, 16 + 4 came out. `resplit`
keeps only members HDBSCAN labels into a part and returns them; anything landing
at `-1` is simply not in the returned list, so it never reaches a queue, a
report, or a noise count. A quarter of the residual pool left no trace. **This is
the 0.7.7 silent drop again at a smaller granularity** — that one lost a whole
cluster on one summariser call, this one loses most of a cluster on one
clustering call. Fixed below.

*Nothing reached the admission gate.* All three clusters stopped at `AB?`, and
`ablate_seed.py` only calls `evaluate_gate` on `triage == "B"`. So the
recovery count is 0 of 4 held-out codes, but **the gate was never the thing
refusing** — G1 still has not been exercised, which was the stated reason for
this run. Causes broken out in the next section.

### Why nothing reached the gate: 1.2.1 is a sink (v0.7.15)

`run_ab2/ablation.json`, all three clusters:

| cluster | n | frameworks | dominant phase | absorbed_by | rate |
|---|---|---|---|---|---|
| 100 | 15 | clinical_agent5 14, clinical_agent 2 | independent_analysis | **1.2.1** | 0.875 |
| 101 | 4 | clinical_agent5 3, clinical_agent 1 | independent_analysis | **1.2.1** | 0.417 |
| 0 | 22 | mdagents 20, clinical_agent 2 | **recruitment** | **1.2.1** | 0.542 |

Every cluster in the run absorbed into the same code, and `1.2.1` is
*Neglect or misinterpretation of modality information*. Its definition carries
two mechanisms joined by "or", and the second one —

> …or evades the specific clinical question asked, offering a generic
> description instead.

— names no modality, no phase and no framework. It will accept almost anything.
`101` is absence-of-evidence reasoning and `0` is recruitment-stage scope
overreach; neither is modality neglect, and neither is really evasion.

**A structural violation, not a matter of opinion.** `1.2.1` declares
`allowed_phases = {discussion, independent_analysis, review}`. Cluster 0 is
**20 of 22 items at `recruitment`**. Stage 1 could not have assigned 1.2.1 to
those steps: `stage1_schema.py:152` never builds a slot for a code the step's
phase excludes, and `:496` records `phase_illegal` as a violation if one appears
anyway. The Stage-4 re-audit has no such filter —

```python
# mafa/reaudit_llm.py, make_unmasked_reaudit
codes = "\n".join(f"- {m.code} {m.name}: {m.definition}" for m in taxonomy.modes)
```

— it offers every code in the taxonomy for every item, ignoring both
`allowed_phases` and `requires`. So **a cluster can be declared already-covered
by a code the annotator was forbidden to apply to it.** The asymmetry runs one
way only: absorption is the "nothing new here" verdict, so the missing filter
biases the loop against discovering anything. Clusters 100 and 101 are
phase-legal for 1.2.1 (all `independent_analysis`), so their absorption is a
judgement about the definition rather than a structural fault — worth keeping
separate when reporting.

The same hole exists for `requires`. `2.1.1` requires `has_recruitment`, and
41 of the 66 residual items come from clinical_agent / clinical_agent5 traces
that have no recruitment stage at all; the re-audit offers it to them anyway.

Not fixed here, deliberately. Filtering the re-audit's candidate list by phase
and capability is a one-line change with a large effect on every absorb rate in
the project, and the honest thing is to measure before and after on the same
clusters rather than fold it in with an unrelated fix. Recorded as the next
experiment. Whether 1.2.1's second clause should be split into its own code is
a taxonomy question for a human, not something the loop should decide.

Also: `ablation.json` records `absorb_rate` but not `triage_reason`, `rates` or
`rate_spread`, so the reason each cluster stopped at `AB?` had to be inferred
from the thresholds — 0.875 clears `hi=0.65` and should have been an `A`, which
leaves `rate_spread > 0.34` as the only remaining explanation. That inference
should not have been necessary. Recording the reason is on the list below.

### `resplit` deleted 17 of 37 items (v0.7.15)

`resplit` returned only the members HDBSCAN labelled into a part. On the real
cluster that was 16 + 4 of 37: **17 items, 46% of the group, left the pipeline
without a queue, a count or a line of output.** Same shape as the 0.7.7 silent
drop, one level finer — that one lost a cluster on a summariser call, this one
loses most of a cluster on a clustering call.

`resplit` now returns `(parts, remainder)`; the signature is a tuple precisely
so a caller cannot ignore the leftovers by accident. `triage_clusters` routes
the remainder as `AB?` with a reason naming the split it fell out of, and does
not recurse on it — items too sparse to join any part are not a group, and
asking the summariser to name them as one would be asking the wrong question.

Replayed on the real cluster from the cached embeddings, no API calls:

```
37 -> parts [16, 4] + remainder 17 = 37
remainder 199: fw={clinical_agent: 12, clinical_agent5: 5}
               phases={independent_analysis: 9, decision: 5, planning: 3}
  - [planning] Inconsistent component-score direction
  - [planning] Score polarity mismatch in aggregation plan
  - [planning] Trial objective misframing
  - [independent_analysis] Nonresponsive generic safety assessment
```

The first two are the same mechanism at the same phase, and there are three
planning-phase items in there. That may well be a real failure type. It was
being deleted.

`selfcheck_offline.py` grows two checks: members in equals members out across a
split, and a remainder that exists is routed with a reason. The second one
passed vacuously at first — HDBSCAN had gathered the synthetic one-offs into a
part of their own, so no remainder was produced and "all zero remainders are
routed" was trivially true. The fixture now uses three mutually unrelated
one-offs below `min_cluster_size`, which forces label `-1` and makes the check
bite.

### Stages 2 and 3 were never broken; the entry point was (v0.7.16)

`fit_and_route.py --annotated examples/pseudo_anchors.jsonl` fails with
*"only 0 usable anchors"*. The module is fine. `--annotated` expects per-
annotator **task files**, which `load_completed` parses by looking for
`human_votes`; `pseudo_anchors.jsonl` is an **`AnchorPool.save` dump** — 745
calibration slots, 218 frozen, a fingerprint on line 1, votes under `votes`.
`load_completed` finds no `human_votes`, returns an empty list, and the run dies
four steps later complaining about the anchor count. **A wrong-format file read
as an empty one.** Fourth wiring failure in this codebase, and the second where
the error surfaced far from its cause.

`--anchor-pool` added, mutually exclusive with `--annotated`, and `--annotated`
now fails immediately with a message naming the other flag when nothing parses.
A saved pool is loaded as-is and not re-split: the frozen half is the ruler G4
measures against, so re-splitting it would defeat its only purpose.

```bash
cp examples/stage1_with_context_73.jsonl run_s23/stage1.jsonl
python scripts/fit_and_route.py --data data --work run_s23 \
    --anchor-pool examples/pseudo_anchors.jsonl
```

The Stage-1 file has to be the one the anchors were drawn from.
`stage1_with_context_73.jsonl` covers all 85 anchor traces;
`stage1_real_92.jsonl` overlaps zero of them and produces the same
"0 usable anchors" error for an entirely different reason.

Reproduces `examples/fit_report_pseudo_anchors.json` to the digit — AUC
0.913992673992674, ECE 0.04622061278503893, selective error 0.0374 / 0.0496 /
0.0893 / 0.1126. Deterministic, no API calls. Routing on the 85 traces:
VERIFY 51 (60.0%), REVIEW 28 (32.9%), AUTO 6 (7.1%), 202 human questions.

**All five stages now run end to end.** Head B still does not fit, and that is
not a wiring problem: the pseudo-anchors carry one vote per slot, so there is no
disagreement to model. `[fit] single-annotator anchors: Head B disabled, the
queue will be ranked by model risk alone`. Only people can close that.

### First codes through the gates, and a change of yardstick (v0.7.17)

Two ablations at n=180, same six-code seed, same four codes held out, judge
`claude-opus-5` throughout, `reaudit_respects_structure=False` to stay paired
with `run_ab2`. Annotator `gpt-5.6-sol-disc`; archived under
`results/gpt-5.6-sol/`.

| | traces | residuals | clusters | noise | admitted |
|---|---|---|---|---|---|
| `run_ab3` clean | 180 | 457 | 10 | 149 | **3** |
| `run_ab4` faulty | 180 | 525 | 10 | 224 | **1** |

**The loop has now put codes through the admission gates for the first time.**
At n=36 there were two clusters, one of them a 37-item mixture, and nothing
reached a gate at all. That result was a small-sample artefact.

`run_ab4` is also the first Stage-4 result in this project on traces where the
system reached the **wrong** answer. Every previous one, without exception, came
from `clean` — runs that ended correct.

**Held-out recovery is 0 of 4 in both.** Every admitted code was judged distinct
from its nearest held-out code, `same: False` at `high` confidence, cosine
0.42–0.57. On the ablation's own yardstick, both runs failed.

#### Why that yardstick is being demoted

Held-out recovery was never the goal; it was the only falsifiable check
available. Clustering always returns clusters and a language model will always
name one fluently, so without an answer key "we found three new failure types"
cannot be wrong. Recovery could be.

It has two problems, and the second is recorded in `ablation.json`'s own note:

1. In deployment there is no ground truth for an unseen framework, so recovery
   rate measures nothing about the situation the method is for.
2. The annotator has almost certainly read the source taxonomies during
   pretraining, so "recovered 2.2.1" is ambiguous between finding a mechanism
   and recalling a label.

Recovery stays as a diagnostic. Three checks that need no answer key become the
main route, in increasing order of what they can establish:

**Cross-sample recurrence** — `scripts/cross_sample_validate.py`. Two disjoint
trace sets clustered, named and triaged independently. Shows the loop tracks
something in the traces rather than packaging noise.

**Human read** — `scripts/export_for_human_read.py`. Exports each candidate
with quotes pulled from the transcripts. The only check that can say a code is
*real* rather than merely *stable*, and it costs a reading session.

**Fold-back** — not yet built. Add the code to the taxonomy, re-run Stage 1,
measure whether it absorbs previously unclassifiable residue without
mislabelling anything. The only check that says the code is *useful*.

#### What cross-sample recurrence found

`results/gpt-5.6-sol/stage4/cross_sample.json`, pairing on name + definition:

```
cosine  pair   verdict   clean                          <->  faulty
 0.876   yes      same   Recruitment output-contract   86 B  <->  88 B
 0.835   yes      same   All-cause failure-rate        80 B  <->  75 B
 0.602   yes    DIFFER   Quantitative aggregation      42 B  <->  33 A
 0.543   yes    DIFFER   Absence-of-evidence           38 B  <->  41 AB?
```

8 of 10 clusters recur across the two samples; of those, **only 4 of 8 get the
same verdict**. Cluster recurrence and verdict recurrence are reported
separately in the tool because they do not travel together, and quoting the
first without the second would overstate the result.

One code was admitted in **both** runs: the all-cause failure-rate mechanism,
support 80 and 75, framework mix clinical_agent5 54/26 and 59/16, nearest
held-out 2.2.1 at cosine 0.4849 and 0.4813. It is the cluster `resplit` cut out
of the 37-item mixture at n=36, where it was 15 items and stopped at `AB?`.
Its quotes read as one mechanism — an overall trial failure rate of 0.42 or
0.55 restated as safety-specific attrition risk.

Pairing on cluster *names* alone gave 0.609 for that pair; adding the
definitions gave 0.835. Names are four words and pair things that merely sound
alike. `cross_sample_validate.py` embeds name and definition together.

#### Open, and not settled by these runs

On faulty, **all five `A` verdicts absorbed into 3.1.3**; on clean only one did.
That may be 3.1.3 playing the role 1.2.1 appeared to play at n=36, or this
failure may simply be common in traces that end wrong. Unchecked.

1.2.1 stayed unstable: `rate_spread` 1.00 on one clean cluster (three re-audits
returning 0, 1, 1), 0.75 and 0.375 on faulty. `max_rate_spread` caught all of
them, which is the check working — and means no claim about 1.2.1 being a sink
is supported in either direction.

`export_for_human_read.py` first matched quotes by cluster name and recovered
zero, because the summariser renames the cluster and the proposals it was built
from carry different names. Falling back to "no quotes found" would have left
the reviewer with nothing but the model's own prose, which is the part least
worth trusting. It now rebuilds cluster membership from the cached embeddings —
exact, not approximate, since HDBSCAN is deterministic — and warns if the
rebuilt partition does not line up with `ablation.json`.

### Fold-back: the discovered codes are used, and they take 1.2.1's work (v0.7.18)

`results/deepseek-flash/foldback/`. Annotator `deepseek-flash`, 137 paired
clean traces annotated twice — once under the six-code seed, once under the
same seed plus `D0.1`/`D0.2`/`D0.3` built from `run_ab3`'s admitted codes.
Same annotator, same trace_ids, taxonomy the only variable.

| | before | after |
|---|---|---|
| uptake | — | D0.1 **73**, D0.3 **57**, D0.2 **46** |
| residual items | 34 | 26 (0.25 → 0.19 per trace) |
| violations | 54 | 54 |

Seed codes, positive counts on the same traces:

```
1.2.1   23 -> 8    -15      2.1.1    4 -> 4     0
3.1.3   11 -> 7     -4      2.2.2    3 -> 4    +1
3.1.2    4 -> 1     -3      3.1.1    3 -> 2    -1
```

**1.2.1 loses 65% of its work and 2.1.1 / 2.2.2 do not move.** That pairing is
the result. 1.2.1 is the code this project has suspected of acting as a sink
since n=36 — named for modality neglect, applied all over text-only trial
traces through the second clause of its definition, which names no modality.
Given three codes that say the thing precisely, the annotator stops reaching
for it. The codes that were already precise are untouched, so the takeover is
targeted rather than three new codes hoovering up everything. Either half
alone would be consistent with the opposite reading; only together do they
mean anything.

Uptake is not decoration either: 176 positive slots for three new codes
against 48 for the six seed codes.

**Two limits on the residual number.** 34 → 26 is a drop of eight items on a
small base, which supports the direction and not a figure like "24% fewer".
And see below: this annotator barely proposes novel modes at all, so fold-back
measured on it understates what a code absorbs.

#### Two silent faults found on the way here, both mine

**Reading the verdicts off the wrong field.** `fold_back.py` first reported
`uptake: 0` — "the annotator could not find these in the wild". It read
`slot.code` as the code the run *assigned*. The data model is that
`plan.slots` carries the code each slot **asks about** and `ann.verdicts`
carries the answers, aligned by index. Reading `slot.code` alone returns every
code that was offered. The real counts were 73 / 57 / 46.

Worse, the check written to verify that finding read `slot.codes` — a field
that does not exist — and so reported that the new codes never entered the
slot plan at all. **A wrong check confirmed a wrong result.** Both only came
apart against the raw `verdicts` array.

Displacement was wrong in the same way and for a related reason: a mode slot's
key is `mode::<code>`, so new codes bring new keys rather than taking over old
ones, and a key-level diff is structurally always zero. It now compares
per-code positive counts across the paired set.

**trace_id carries a line number.** 51 of 139 traces would not pair. The ids
look like `...#00000#NCT00000174`, and the sharding used `awk 'NR%3==i'`, which
restarts numbering in every shard — so the same trace was written under a
different id. `dylan` and `clinical_agent5` were never sharded and were fine;
`clinical_agent` and `mdagents` were sharded and lost 36 and 15. Nothing
errored: every annotation completed, and simply no longer matched the corpus.
Rebuilt by indexing the clean split on the business id, which is unique within
that split (440 keys, no collisions); all 139 resolved.

### deepseek-flash proposes ~9x fewer novel modes than gpt-5.6-sol-disc

Paired on the same 137 traces, novel proposals per trace:

```
clinical_agent   4.81 -> 0.41     dylan      0.46 -> 0.12
clinical_agent5  1.98 -> 0.13     mdagents   2.43 -> 0.71
overall          2.34 -> 0.26
```

Every framework, no exception, so this is the annotator and not the sample.
Wider: gpt calls 18.0% of slots positive with 2.72 findings per trace and
leaves 21% of traces with no proposal; deepseek-flash calls 9.2% positive with
0.82 findings and leaves **76%** with none.

This is a property of the annotator, not a defect, but it sets the scale of
everything downstream. Residual pools, cluster counts, and every Stage-4
number computed from them are roughly an order of magnitude smaller on
deepseek-flash. **Do not compare a residual count, cluster count or absorb
rate across the two directories.** It also means the fold-back above is a
lower bound: an annotator that rarely proposes anything has little residue for
a new code to absorb.

#### Coverage, honestly

`results/deepseek-flash/foldback/failures.json` lists every trace that did not
complete, with an `error_class`. Of 66 failures, 41 were `infra_quota` or
`infra_rate_limit` — a spent key and my own concurrency, not the model — and
**25 were `model_empty_output`, 20 of them mdagents**. An earlier "mdagents
fails 41% of the time" figure in this log was computed during a billing outage
and is withdrawn; `error_class` exists so that cannot happen again.

Paired coverage by framework: clinical_agent5 45/45, clinical_agent 37/45,
dylan 41/45, mdagents 14/45. The missing traces are **not** missing at random —
failures concentrate where the reasoner runs long — and mdagents is the worst
covered. The three discovered codes draw all their members from
clinical_agent and clinical_agent5, which are the two best covered, so the
main measurement rests on the good part; mdagents and dylan are a ragged
control and support only qualitative reading.

### Why deepseek-flash returns empty content (v0.7.18)

The failure is `Expecting value: line 1 column 1 (char 0)` — an empty string
from the reasoner. Raw response:

```
status: incomplete   incomplete_details: reason='max_output_tokens'
usage: output_tokens=16000, reasoning_tokens=16000   output_text: ''
```

The reasoning chain consumes the entire output budget and no answer is
written. Raising the budget does not fix it: at 32000 the model reasons for
32000. `effort="low"` and `effort="minimal"` do not fix it either — only
`effort="none"` does, and that turns the chain off entirely, which changes
annotation quality rather than fixing a bug.

Two mitigations were tested and rejected:

- **Asking for brevity in the prompt.** Tried in the system message, the user
  message, and both. Reasoning stayed pinned at 16000 in all three. Consistent
  with the pattern in this log: five constraint-style prompt changes failed,
  two information-style ones worked.
- **Thresholding on prompt size.** The failures do not separate: failing
  prompts were 29427 / 31376 / 33362 characters against a succeeding range of
  8499–41897, with the longest success longer than every failure and identical
  median slot counts. Any threshold either misses them all or takes down a
  large number of traces that would have succeeded. It would also create a
  mixed annotation regime correlated with trace complexity, which is worse
  than dropping traces because it is invisible.

So failures are recorded and the traces dropped. `pipeline.annotate` now
writes a `{"status": "failed", "error_class": ...}` record instead of printing
a line and moving on; `load_stage1` skips those records and lets a later
success overwrite an earlier failure; `annotate(retry_failed=True)` is the
default, since some failures are intermittent and a retry does get them.

This took three rounds longer than it should have because every reproduction
attempt targeted the single-pass reasoner, while the log said
`reasoner(blind)` — the first of the two passes, which builds its prompt from
a *subset* of the taxonomy and a different slot plan. The single-pass path
reasons for 3000–5500 tokens and never fails. Read the label on the error.

### Images change almost nothing, and that settles what 1.2.1 actually is (v0.7.19)

`results/claude-opus-5-images/`. Annotator `claude-opus-5` over the Anthropic
Messages API; the only variable is whether the trace's own images are attached
to the **annotator's** prompt. The audited agents saw none in either arm — the
corpus replaced the pixels with a note — so this changes who can check a
modality claim, not what was audited.

Two independent batches, 28 paired traces, ~168 mode verdicts:

| | random 15 | 13 where gpt scored 1.2.1 positive |
|---|---|---|
| 1.2.1 | 12 → 11 | 12 → 12 |
| total flips | 3 | 1 |

Four flips in total: `MM-12` 1.2.1 1→0, `MM-2` 3.1.2 0→1, `MM-24` 3.1.2 1→0,
`MM-68` 2.1.1 0→1. The 3.1.2 pair cancels and has no direction. Verified per
record: the no-image arm is `n_images_sent: 0` throughout, the image arm
matches each trace's reference count exactly (1, 2 and 5), nothing dropped.

**This refutes the hypothesis this whole line was built on.** The standing
guess was that 1.2.1 is the least stable code here — `rate_spread` 1.00 on one
cluster, three re-audits returning 0, 1, 1 — *because* its main clause,
"neglect or misinterpretation of modality information", cannot be judged
without the image. Supply the image and nothing moves, so the annotator was
never judging modality. What it uses is the second clause, "or evades the
specific clinical question asked", which names no modality, phase or
framework.

**1.2.1 is a general answers-the-wrong-question code wearing a modality
name.** That agrees with the fold-back result from the other side: given three
codes that state their mechanisms precisely, 1.2.1 lost 65% of its work while
the already-precise codes held. Splitting it or rewriting the definition is a
decision for a person.

Note the Anthropic backend has no `scored` method, so the scorer falls back to
verbalised 0-100 and every slot carries `p_token_missing`. **These annotations
cannot feed Stage 2.** Fine for a Stage-1-only comparison, which is why the
image work was scoped that way and never enters Stage 4 — using claude-opus-5
as annotator while it is also the Stage-4 judge would make the triage a
self-assessment.

#### A correction to an earlier entry

The first batch was reported here as "3 positive verdicts in total, 0 flips,
signal too weak to answer the question". Wrong: 12 positives and 3 flips. The
count was computed with un-restored trace_ids, most lookups missed silently,
and the comparison ran on nearly empty data. The conclusion survives, but the
stated reason for running a second batch was false, and batch 2 should be read
as an independent replication rather than a fix.

### The line-number fault, fixed at the cause this time (v0.7.19)

`trace_id` embeds the record's line number in its source file
(`...#00000#MM-1`). Every shard built with `awk 'NR%n==i'` renumbers from 1 and
therefore renames every trace in it. Nothing errors — the annotations complete
and simply stop matching the corpus.

Three hits, and the third is the reason this is now fixed rather than patched:

1. fold-back: 51 of 139 traces would not pair (`clinical_agent` 36,
   `mdagents` 15; `dylan` and `clinical_agent5` were never sharded and were
   fine).
2. the image comparison: a `KeyError` on the first lookup.
3. the image ablation: **no error at all** — the missing lookups were skipped
   and the run reported "0 flips" on almost no data.

The first two were repaired by rebuilding ids from the business key. That
fixed the data and left the cause, so it came back.

`mafa.images.shard_preserving_ids` pads each shard so every record keeps its
original line index — blank lines are skipped by the loader, so a record at
line 7 of a shard is still line 7 of the original. Verified on the real
mdagents file: 49 traces, 0 lost, 0 renumbered. `selfcheck_offline.py` gains a
check that shards against the real corpus and fails if any id is renumbered;
it skips with a message when `data/` is absent rather than passing vacuously
on a synthetic fixture the adapters would reject anyway.

### Uncertainty estimation is now pluggable (v0.7.20)

Stage 2 read the scorer's token distribution to build its features, which was
fine when every endpoint returned logprobs and is not fine now: deepseek's
Responses API hands back an empty array, glm has none at all, qwen exposes
them only on `chat.completions`. Left alone, the choice of annotator would be
decided by an API detail rather than annotation quality — deepseek scored
highest on injected-fault recall (0.834 against qwen's 0.728) and was the one
model that could not feed Stage 2.

`mafa/estimators.py` makes the estimator a strategy object that declares what
it needs and what it costs:

| | calls | needs logprobs | |
|---|---|---|---|
| `logprob` | 1 | yes | the original path |
| `verbalised` | N | no | the original fallback, now with `repeats` |
| `steerconf` | 2L+1 | no | SteerConf, NeurIPS 2025 |
| `vpd` | 1 | no | VPD, best calibration in the 24-method survey |

Selected with `--scorer-mode`. A new estimator implements three methods.

**Batching is the whole reason this is affordable.** Read naively, SteerConf
is 2L+1 calls *per slot*: 16 slots x 5 levels = 80, against the 2 the batched
scorer spends. But the steering level is a property of the prompt, not of the
slot, so one batched call scores every slot at that level. Measured: 10 calls,
not 80. VPD is 2.

#### VPD needed a structural decision, not a port

Each `mode` slot asks about **one** code (`mode::1.2.1` -> "does 1.2.1
apply?"), so the taxonomy is spread across slots rather than sitting inside
one as a candidate set. Scoring them individually would be binary VPD N times
over — verbalised confidence with normalisation, which is not VPD. So a
trace's mode slots are merged into a single distribution question: candidates
are their codes, `none` is "no code applies".

**The `none` mass is kept in `ann.vpd_detail`, not folded into the per-slot
probabilities.** It is the model's belief that the taxonomy does not cover
this trace — the residue Stage 4 exists to find. Collapsing it into p would
discard the one number most worth having.

`agent` and `step` slots stay binary and are flagged `degenerate_binary`.
VPD's advantage over TopK comes from spreading belief over several
candidates; with two there is nothing to spread. Do not read a binary VPD
number as evidence about VPD.

`invert_softmax` implements the paper's correction. A verbalised distribution
is already normalised, so scaling it and renormalising applies softmax twice:

```
original            [0.70, 0.20, 0.10]
naive softmax(p/1)  [0.46, 0.28, 0.25]   <- distorted at T=1
invert_softmax      [0.70, 0.20, 0.10]   <- identity at T=1
```

Default `T=1` therefore changes nothing until a temperature is fitted on
anchors, which is the honest default.

#### DiNCo: deliberately not implemented here

DiNCo normalises a verbalised confidence by the confidence its **mutually
exclusive distractors** attract, weighting each by uniqueness and
contradiction, both from an NLI model. A slot verdict is binary, so the only
distractor is the negation: `w_unique` collapses to a constant and
`w_contra` becomes NLI on a sentence and its own negation. The survey marks
DiNCo open-ended only, which agrees. It would also add a deberta-scale
dependency.

DiNCo belongs on the **taxonomy-evolution** side instead, where a residual
item genuinely competes against several candidate codes. Different
integration point, still open.

#### Four bugs found in my own port, all silent

Worth listing because each would have left the method running and wrong:

1. **Parsing took the verdict as the confidence.** `"0, 95"` -> the regex
   matched `0`. A confident *no* became `mu_c = 0.0`; a set of 1s at
   scattered confidences became `mu_c = 1.0`. The spread SteerConf exists to
   measure was destroyed.
2. **`kappa_ans` cannot be the raw majority fraction on a binary verdict.**
   With two options the majority is always >= 1/2, so it only ranges over
   [0.5, 1]. A 3:2 split — a near coin-flip — scored 0.6 and produced
   p = 0.73. **The most uncertain slots would have been reported as
   confident and never routed to a human.** Rescaled to [0, 1]; 3:2 now gives
   0.576.
3. **`ChatCompatClient.scored` was missing the `schema` argument.**
   `_score_batched` catches every exception and returns `[None] * len(chunk)`,
   so a `TypeError` about argument count surfaced as "this endpoint has no
   usable logprobs" — 0 of 16 slots scored on a model whose probe had just
   reported five alternatives. `selfcheck_offline.py` now checks that every
   client shares one signature.
4. **The batched steerconf budget had no floor.** At `16 + 12n` tokens,
   glm — which cannot disable reasoning — spent the whole allowance thinking
   and returned an empty string, which read as a parse failure rather than a
   truncation. `ScorerConfig.steer_min_tokens` now floors it.

Self-check grew from 17 to 32, including a monotonicity test on SteerConf
(3:2 < 4:1 < unanimous, 0.576 < 0.728 < 0.975) and the `T=1` identity for
invert-softmax. Those two exist because the failure mode of a mis-ported
estimator is a plausible number pointing the wrong way, not a crash.

Verified end to end on glm, which has no logprobs at all: 2 calls per trace,
distributions summing to 1 with real spread between codes
(`{1.2.1: 0.30, 2.2.2: 0.65, none: 0.05}`), and `missing_options` recording
what the model failed to mention rather than silently filling it with zero.

**Not yet established: whether these estimators beat verbalised scoring
here.** They are strong methods with benchmark evidence behind them, and the
open question is whether my port is faithful, which only an AUROC comparison
on the injected-fault set can answer.

### Four annotators, and what each endpoint actually supports (v0.7.20)

Measured on the same 80 injected-fault traces, against the injection log:

| | deepseek (medium) | qwen (none) | glm (low) |
|---|---|---|---|
| agent recall | **0.834** | 0.728 | 0.741 |
| agent precision | 0.852 | 0.775 | **0.847** |
| specificity upstream | **1.000** | 0.974 | 0.978 |
| step recall | 0.295 | 0.259 | **0.303** |
| earliest step exact | **0.740** | 0.568 | 0.628 |
| coverage | 73/80 | 74/80 | **78/80** |
| scorer regime | verbalised | **logprob, 5 alts** | verbalised |

deepseek leads on attribution, most clearly on earliest-step localisation.
glm is fastest with the best coverage. qwen is the only one exposing real
logprobs. **The reasoning levels differ (medium / none / low), so part of the
gap is the level rather than the model** — qwen at medium is too slow to run
and glm cannot go below low, so that confound is not resolvable by measurement
here.

#### Two models I wrongly declared unusable

Both were my API misuse, both corrected only after being pointed at the
vendor documentation, and either would have cost a working annotator:

* **qwen**: I used the Responses endpoint (the docs use `chat.completions`),
  omitted the `json_schema` wrapper, and set `max_tokens`, which their
  documentation explicitly forbids under structured output because it
  truncates the JSON. That truncation is what produced a reply consisting of
  the single character `{`. Corrected, the real slot schema passes first try:
  16 verdicts, values strictly `0`/`1`.
* **glm**: Zhipu serves only `{"type": "json_object"}` — there is no
  `json_schema` mode. Sending one does not error; the model ignores the
  schema and free-associates (asked for `{verdicts, note}` it returned
  `{"A": "pass", "B": "contradicted"}`, which *parses*). Their docs put the
  schema in the system message and validate client-side. Done that way: three
  of three clean, 16/16 aligned, ~21s.

`ChatCompatClient` now learns each endpoint's dialect at runtime — reasoning
parameter (`enable_thinking` vs `reasoning_effort`, and glm cannot disable
it), schema mode, and the `top_logprobs` ceiling, which qwen caps at 5 while
the default asks for 20. **The schema fallback triggers on a failed
validation, not on an exception**, because an endpoint that ignores
`json_schema` does not say so.

#### Stage 2/3 run on real annotations now

`scripts/make_pseudo_anchors.py` was missing entirely —
`examples/pseudo_anchors.jsonl` predates this log and nothing recorded how it
was built, so those 745 anchors could not be regenerated or pointed at another
split. Rebuilt from the injection log.

Step-level anchors were the gap keeping routing at 100% REVIEW.
`_step_calibration_data` requires `set(marked) == set(step_ids)` — a whole
trace or nothing, since a partially marked trace cannot express "no step
fired" and scoring it as NONE would fabricate calibration points. The
injection log covers a whole trace by construction, so this is one of the few
labels completable without a human. With them:

```
before: step_head n_calibration_traces=0   -> REVIEW 100%
after:  step_head n_calibration_traces=26, q_pooled=0.914
        -> REVIEW 84.9% + VERIFY 15.1%
```

Head A AUC moved 0.919 -> 0.821, which is **not a regression**: the evaluation
set changed from agent slots only to agent + step (262 calibration points
against 84), and step-level judgements are harder — the injected-fault run
shows the same split (agent recall 0.834, step recall 0.295).

**Head B still does not fit and cannot be made to.** One vote per slot means
no disagreement, and disagreement is the entire signal. Only real annotators
close that.

## 6g. Where the project stands

Sorted by how much weight each finding will bear.

### Established

**Uncertainty is predictable from the annotation itself, and transfers across
codes.** On MedAgentAudit's 383 human-judged instances, calibration lifts AUC
from 0.861 to 0.900 and ECE from 0.133 to 0.040; routing the least certain 30%
to a person takes the error on what is kept from 14.4% to 9.0%, against a flat
random-routing curve. Leave-one-code-out AUC is 0.901 — the calibrator works on
codes it never saw, which is what an evolving taxonomy requires.

**Verbatim quotation holds on real data.** 200 findings across 92 real traces,
**zero** quotes that could not be located. Self-check failures 0.52 per trace.
On the anchor set, evidence groundedness was the largest single contributor
among the black-box features.

**Calibration and routing work on our own traces.** Fitted on 745 pseudo-anchors
from the injection log: AUC 0.914, ECE 0.046, conformal coverage 0.912–0.925 in
all four Mondrian groups with none falling back, 71.2% of agent judgements
settled without review at 9.6% error against 11.3% unrouted, and 219 questions
for a person across 80 traces.

**A fixed taxonomy really does not transfer, and the reason is structural.** No
code applies in all four frameworks. The debate framework separates runs that
failed from runs that did not (flag rate +0.272); the pipelines barely do
(+0.02 to +0.07), because the cross-round codes they would need are ruled out
by their own structure. Attributability is a property of the architecture.

**Two changes worked, and both supplied information rather than adjusting
caution.** Rendering the material handed to each agent raised recall and
specificity together (0.672→0.731, upstream 0.619→0.738). Rewriting the
novel-mode instruction as a cost asymmetry raised recall 0.078 while leaving
upstream specificity untouched, and tripled the residue per trace. Against
that: five changes that asked the annotator to be more careful, all of which
moved the operating point and none of which improved discrimination.

### Suggestive, underpowered

Downstream specificity fell 0.125 after the novel-mode change (n=56, interval
±0.13). The contamination hypothesis shrank across three measurements of the
same quantity, +0.271 → +0.102 → −0.028, and now explains nothing. The A/B
verdict flipped between two runs on one mechanism.

### Not established

**Whether the annotator agrees with clinicians is unknown.** 400 questions are
prepared and unanswered. Until then the mistake-type level has no anchors at
all and its reliability cannot be stated.

**No discovered code has passed all four admission tests.** Under the full
taxonomy all four clusters were absorbed; under the held-out seed, one cluster
was absorbed and one went to a human. **The loop has never turned twice.**

## 7. Measured numbers so far

From `scripts/anchor_calibration.py` on MedAgentAudit's released human
evaluation (383 instances, 1200 votes, no API calls). Black-box features only —
no logprobs in that data, so these are a lower bound.

| | accuracy | AUC | Brier | ECE |
|---|---|---|---|---|
| raw auditor label | 0.867 | 0.861 | 0.133 | 0.133 |
| calibrated (5-fold OOF) | 0.856 | 0.900 | 0.111 | **0.040** |

Accuracy does not improve, and is not meant to; the deliverable is a usable
confidence. Selective error at 70% coverage: **9.0%** against 14.4% overall and
14.3% for random routing. Leave-one-code-out AUC 0.901 — the calibrator
transfers to codes it never saw, which is what the evolving taxonomy needs.

Ablation: auditor label alone 0.861 → + text style 0.872 → **+ evidence
groundedness 0.890** → + context 0.900.

Per-code human Fleiss κ ranges 0.42 (3.1.3) to 0.73 (2.2.1). Correlation
between mean model confidence and per-code κ is 0.141, which is why routing is
weighted by a learned Head B rather than by κ.

Two-pass vs single-pass on one real MDAgents trace: agents flagged 6 → 2,
structural violations 3 → 0.

---

## 8. Session restart, 2026-09-17 — what the archive does and does not contain

A new session was opened from `MAFA-v0.7.20.zip` plus the four data archives.
Before doing anything else the archive was audited against the state the
previous session reported at its end. **The archive predates that state.** This
section records the gap so it is not rediscovered a third time.

### What the previous session reported, and what is here

The last message of the previous session reported a Stage-4 run over the full
faulty split: 1,109 annotated traces → 488 residuals → 9 clusters including
`resplit` products 100/101/199, with one code through the admission gate
(`aggregate_outcome_metric_conflated_with_lane_specific_score`, from
clinical_agent5). None of that is in the package.

| reported | in the archive |
|---|---|
| Stage 1 over the full faulty split (1,109 traces) | 180 faulty + 180 clean, plus 45-per-framework subsamples. 720 records total. |
| Stage 4 on 488 residuals, 9 clusters, 1 gate pass | newest Stage-4 dir is `run_ab4_faulty_n180` — 180 traces, 525 residuals, 0 gate passes |
| a fix to the cluster-name filter, admitting snake_case names | `ResidualFilter.min_name_words` still counts `str.split()` on whitespace, so a snake_case name is one word and is rejected as *"name is a label, not a description"* |
| `--reaudit dinco` wired into the re-audit | no DiNCo anywhere in the tree. `mafa/estimators.py:18` documents why it was deliberately left out of 0.7.20, and no driver accepts the flag. |
| §6g and the changelog reflecting the above | changelog ends at 0.7.20; §6g still reads *"No discovered code has passed all four admission tests"* |

So the "DiNCo did not take effect" diagnosis from the previous session is not a
wiring bug to be found in this code — **the feature was never in this code.**
No script in v0.7.20 accepts `--reaudit <value>`: `run_evolution.py` and
`ablate_seed.py` have no `--reaudit` at all, and `coverage_matrix.py`'s is a
`store_true`. `argparse` would have rejected the command outright. The previous
session was therefore running a modified working copy that was not re-zipped,
and `dinco_rate` printing `-` is consistent with a field that was added to the
report template before the estimator behind it was finished.

Worth stating plainly: DiNCo was excluded from 0.7.20 **on a stated argument**
(`mafa/estimators.py:18` — it normalises a verbalised confidence against
mutually exclusive distractors, which a binary verdict does not have). If it is
to come back, it comes back on the taxonomy-evolution side as that note already
says, and the argument against it needs answering, not bypassing.

Everything that is *recorded* in the archive — v0.7.20 code, RUN.md through
0.7.20, `run_ab2/ab3/ab4`, the fold-back and image-ablation results — is intact
and consistent. It is only the last session's compute that is missing.

### Environment reconstructed

```
data/clean       440 traces   4 files
data/faulty     1112 traces   4 files
data/simulated  3519 traces   4 files
```

`scripts/preflight.py --data data` reads 5,071 traces,
`{mdagents: 1734, dylan: 1397, clinical_agent5: 1346, clinical_agent: 594}`,
0 duplicate agent uids — matching every documented figure.

`scripts/selfcheck_offline.py`: **31 passed, 0 failed**, 1 skipped (the shard
check needs `data/`, and now has it). MedAgentAudit 9.2 unpacked separately for
`anchor_calibration.py`; its `human_eval/` and `datasets/` trees are present.

### Why held-out recovery is 0/4, and why it was always going to be

Three runs, three scales, the same 0/4: clean 180, faulty 180, faulty 1109.
Stability across a 6x change in sample size is the tell — a recall figure that
does not move with n is not measuring recall. It is not. There are three
independent reasons, none of which is about the discovery loop.

**1. Half the held-out set is structurally confined to one framework, and that
framework barely reaches the residual pool.**

`requires` is satisfied per trace from the capability vector. Counted over the
whole 5,071-trace corpus:

| capability | clinical_agent | clinical_agent5 | dylan | mdagents |
|---|---|---|---|---|
| has_aggregator | 594 | 1346 | **0** | 1734 |
| has_multi_round | **0** | **0** | 1158 | **0** |
| has_peer_exposure | **0** | **0** | 1397 | 1734 |
| has_recruitment | **0** | **0** | **0** | 1734 |

`has_multi_round` is true in **dylan only**. So:

| code | eligible in | eligible traces |
|---|---|---|
| 1.1.1 | all four | 5071 |
| 2.1.2 | all four | 5070 |
| **2.2.1** | **dylan only** | **1158** |
| **3.2.1** | **dylan only** | **1158** |

And dylan is the framework the residual pool barely represents. Recomputed
offline from the packaged runs (no API calls):

| run | ca | ca5 | dylan | mdagents |
|---|---|---|---|---|
| ab4 faulty 180 — residuals | 189 | 128 | **65** | 143 |
| ab4 — of those, clustered | 78 | 88 | **9** | 121 |
| ab3 clean 180 — residuals | 210 | 89 | **28** | 130 |
| ab3 — of those, clustered | 124 | 61 | **4** | 116 |

86% of dylan residuals fall to HDBSCAN noise in both runs. With
`min_cluster_size=6`, a dylan-specific mechanism has 9 items to build a cluster
from. **2.2.1 and 3.2.1 could not have been recovered.** The achievable
maximum was 2/4 before either run started, and the denominator of 4 is wrong.

This is the 0.7.10 lesson in a new place. That fix taught G1 to count
frameworks against the ones whose structure could exhibit the failure. The
recovery metric never learned it.

**2. Recovery is scored only over gate-admitted clusters.**

`ablate_seed.py` iterates `for c in admitted:`. A cluster that rediscovers a
held-out code and then fails a gate is recorded as *not recovered*, with no
separate record of which happened. In ab3, 5 clusters reached triage B and 3
were admitted — 2 never tested. In ab4, 2 reached B and 1 was admitted; the
untested one was cluster 4, n=88, the largest in the run. So 0/4 reports the
gate's strictness and the loop's recall summed together, which is exactly the
conflation `cross_sample_validate.py` was added in 0.7.17 to avoid.

**3. There is no full-taxonomy baseline anywhere in the archive, so
precondition 3 was never checked.**

The script's own docstring requires holding out codes *the corpus exhibits*,
and cites frequencies from the 91-trace real-corpus run. Every Stage-1 file in
`results/gpt-5.6-sol/stage1/` was annotated under the **six-code seed** — the
held-out codes appear in none of them. `faulty_180.jsonl` is byte-identical to
`run_ab4_faulty_n180/stage1.jsonl` (md5 `2cd89d14…`); it is the ablation run,
not a full-taxonomy control. So the base rate of 1.1.1 / 2.1.2 / 2.2.1 / 3.2.1
on these 180 traces is **unmeasured**, and 0/4 may be reporting the corpus,
which is the failure mode the docstring names.

Code-frequency check across the packaged runs, all six-code seeds: `1.2.1`
takes 51 of 565 findings on faulty 180 and 57 of 490 on clean 180, against 32
and 12 for the other five seed codes combined. 1.2.1 is still the sink 0.7.15
identified.

**What this changes.** Held-out recovery was demoted from criterion to
diagnostic in 0.7.17. It should now be demoted again, to *broken as
constructed*, and either repaired or dropped. Repairing it means three things,
all cheap:

- hold out codes with **cross-framework eligibility only** (1.1.1, 2.1.2, and
  2.2.2 / 3.1.x as further candidates), or report recovery against the number
  of *eligible* held-out codes rather than against 4;
- score recovery over **every cluster that reached triage B**, and report
  admitted and not-admitted separately, so the gate is not silently in the
  numerator;
- annotate one sample under the **full ten-code taxonomy** to establish the
  base rate, which makes precondition 3 a number instead of an assumption. 180
  traces, once, and it also gives the paired full-vs-reduced comparison the
  archive currently cannot support.

Until the third of those exists, no statement about what the loop failed to
recover is supportable in either direction.

### The cost of re-running

The expensive step is Stage 1, and it is the step that was lost. Re-running the
full faulty split is ~1,112 traces of reasoner + scorer calls. Stage 4 on top of
an existing Stage-1 file is cheap by comparison and cached
(`judge_cache.jsonl`). Before paying for Stage 1 again, decide whether the run
should be repeated as it was or with the naming filter fixed first — the
previous session's single gate pass depended on that fix, so the two runs are
not comparable, and re-running unfixed reproduces a result already known to
discard snake_case candidates before clustering.

---

### The paired control run, 2026-09-17 — where the signal is actually lost

The repair in 0.7.21 made the question answerable; this run answers it. Two
arms, **the same 180 faulty traces** (the ab4 set, pinned with the new
`--trace-ids`), **the same annotator** (glm-5.3-flash), differing only in the
taxonomy offered:

- **Arm A** — full ten-code T0. The control the archive never had.
- **Arm B** — the six-code seed, `2.2.1 / 3.2.1 / 1.1.1 / 2.1.2` withheld.

360 annotations, 0 failures. Cross-annotator comparison against the existing
gpt-5.6-sol-disc runs was rejected as a design: 0.7.18 already measured a ~9x
difference in novel-mode rate between annotators, so pairing Arm A against
`run_ab4` would have measured the annotator.

#### Precondition 3 — a number, but the annotator's, not the corpus's

*Corrected 2026-09-18 after replication. The original text of this subsection
reported glm's base rates as "the corpus" and called them emphatic. Two more
annotators on the same 180 traces show that the counts are a property of the
annotator. The structural half of the finding survives unchanged; the
frequency half does not.*

Held-out code counts under the full ten-code taxonomy, same 180 faulty traces,
pinned with `--trace-ids`:

| code | glm-5.3-flash (180) | gpt-5.6-sol-disc (180) | deepseek-flash (61) |
|---|---|---|---|
| **1.1.1** | 44 | 75 | 11 |
| **2.1.2** | 9 | 46 | 23 |
| **2.2.1** | 12 | 70 | 0 |
| **3.2.1** | 39 | 33 | 0 |
| 1.2.1 | 10 | 20 | 0 |
| 3.1.2 | 7 | **0** | 1 |
| novel proposals | 0.21/trace | **2.60/trace** | 0.62/trace |

The two complete arms disagree on nearly everything measurable. `2.1.2` is 6
against 34 on the same 45 clinical_agent5 traces; `2.2.1` is 12 against 70 on
the same 45 dylan traces; `3.1.2` fires seven times for glm and **never** for
gpt; novel proposals differ 12-fold. deepseek, at 61 traces, reports neither
`2.2.1` nor `3.2.1` at all.

So the defensible statement is: **all four held-out codes are observed under
more than one annotator, at rates that differ by 3-6x.** That is enough for
precondition 3 — the denominator is not empty — and it is all that is enough.
"The corpus exhibits all four, emphatically" was glm's result read as the
corpus's, and it is withdrawn.

#### The structural half, which replicates exactly

Where a code *can* appear is a different quantity from how often an annotator
says it did, and only the first is stable:

| framework (45 traces each) | glm `2.2.1` / `3.2.1` | gpt `2.2.1` / `3.2.1` |
|---|---|---|
| clinical_agent | 0 / 0 | 0 / 0 |
| clinical_agent5 | 0 / 0 | 0 / 0 |
| **dylan** | **12 / 39** | **70 / 33** |
| mdagents | 0 / 0 | 0 / 0 |

Across the 135 non-dylan traces the two annotators report these codes **zero
times between them**. They disagree on which of the two is more common — glm
39:12, gpt 33:70, opposite orderings — and they agree completely on where
either can occur, because `requires: has_multi_round` is read off the
capability vector and never reaches the model.

This is what the 0.7.21 denominator fix rests on, and it now rests on two
annotators whose measurements agree on nothing else. `2.2.1` and `3.2.1` are
structurally confined to one framework, cannot produce a cross-framework
cluster, and are unrecoverable under `min_frameworks >= 2` before any run
starts. Recovery is out of 2, not out of 4.

The §6d reading — "the residue never contained them" — was right about the
residue and wrong about the reason, and that correction stands: the codes are
observed, repeatedly, by every annotator that covers dylan.

#### The funnel

Pairing each held-out instance in Arm A to the same (trace, agent, step) in
Arm B, 93 instances match exactly:

| stage | count | of previous |
|---|---|---|
| held-out instances in the control | 93 | — |
| **survive Stage 1** (proposed as a novel mode) | **16** | **17.2%** |
| — never flagged at all | 64 | 68.8% |
| — relabelled under a kept code | 13 | 14.0% |
| residual pool (all sources) | 73 | — |
| clustered by HDBSCAN | 36 | 49% |
| reach triage B | **0** | **0%** |
| pass the gate | 0 | — |
| **recovered** | **0 / 2** | — |

Per code, the silence is not uniform: `2.2.1` is never proposed as novel
(10 of 11 simply unflagged), while `1.1.1` survives at 23%. `3.2.1`'s
relabelling lands on `2.2.2` six times out of six — a specific, fixable
confusion between self-contradiction across rounds and its neighbour.

**The ceiling is Stage 1, and on this annotator it is 17%.** A perfect
clusterer, a perfect triage and a perfect gate could have reached 16 items.
Every downstream repair in 0.7.10 through 0.7.21 was operating under that
ceiling, and 0/4 was never going to move until it lifted. Removing a code does
not merely remove a label; in a slot-based design it removes the ability to
*see* the failure, and the NOVEL escape hatch recovers about a sixth of what
the code caught.

*Caveat added 2026-09-18, and it is a large one.* 17% is one annotator's
number and the replication says it will not hold. Under the **full** ten-code
taxonomy — where there is least reason to propose anything new — gpt-5.6-sol-disc
emits **2.60 novel proposals per trace against glm's 0.21**, a 12-fold
difference, and deepseek-flash sits between them at 0.62. A model that
proposes twelve times as much when it has every code available will not lose
five sixths of the held-out signal when codes are removed. The gpt Arm B that
would measure this has not been run.

The claim that survives the replication is the *mechanism*, not the number:
in a slot-based design, recall is bounded by the vocabulary, and the NOVEL
escape hatch recovers only a fraction of what the code caught. The size of
that fraction is an annotator property, probably spanning something like
5-40%, and reporting it as a constant was the same error as reporting glm's
base rates as the corpus's. Which annotator you choose is not an
implementation detail; it moves the ceiling by a factor of several.

This is the finding. It is also the thing that distinguishes us from AdaMAST,
which induces codes without a fixed slot plan and so does not have this
ceiling — while having no structural eligibility to bound false positives.
The trade is stateable and neither paper has stated it.

#### What the loop did find

Four clusters, none of which reached B, and all four are legible mechanisms:

| cluster | n | frameworks | triage | absorbed by |
|---|---|---|---|---|
| Intra-step answer–reasoning contradiction | 11 | dylan 7, mdagents 4 | A (0.88) | 3.1.3 |
| Role-Scope Violation: Unsolicited Answer Emission by a Coordination Agent | 9 | mdagents 9 | AB? (0.54) | 2.1.1 |
| Role-scope overreach by a specialist agent | 5 | ca 5 | A (1.00) | 2.1.1 |
| Unfaithful quantitative aggregation of sub-agent estimates | 4 | ca 4 | AB? | 3.1.3 |

Two things worth keeping. First, the mdagents cluster is the **same mechanism**
as the largest cluster of the lost full-faulty run (n=192, "Out-of-role answer
emission by coordination…"): different annotator, different scale, same
framework, same recruitment phase. That is an independent replication of the
one substantive discovery this project has made, and it is the strongest
evidence so far that the mechanism is real rather than an artefact of one
annotator.

Second, the triple re-audit earned its keep. Cluster 1 returned rates
[0.5, 0.75, 1.0], spread 0.50 against a 0.34 ceiling, and was refused as
unstable rather than absorbed on the 0.75 mean. That is 0.7.16 behaving
exactly as designed on real data.

#### The naming filter, and a judgement I got wrong

`ResidualFilter.min_name_words` counted `str.split()`. On gpt-5.6-sol-disc it
rejected 3 of 460 proposals (0.7%) and was assessed here, from that one
sample, as not worth fixing. **On glm-5.3-flash it rejected 52 of 74 (70%)**,
because glm names in snake_case almost exclusively, and the residual pool
collapsed from 73 to 21 — below `min_cluster_size` for most frameworks. Stage 4
would have found nothing and the run would have read as "this annotator
proposes nothing worth clustering".

Fixed in 0.7.22: words are counted across `[\s_\-:./]` and camelCase
boundaries. Arm B's pool goes 21 → 73; the gpt ab4 pool is unchanged at 525,
so the fix is not retroactively rewriting old results.

The lesson is the one already written at the top of this file — *pair every
comparison, do not generalise from one sample* — and it was violated in the
assessment of a filter rather than in a measurement. The cost of an
annotator-dependent parameter estimated on one annotator is not small just
because the estimate was small.

#### What this run cannot support

glm-5.3-flash has no logprobs and does not honour `json_schema` (the client
falls back to `json_object` with client-side validation). So every slot here
carries `p_token_missing` and scoring is verbalised. **These arms support
statements about base rate, fate and discovery; they support nothing about
calibration.** Two of 104 findings came back with a malformed or empty code —
the price of the weaker schema path, and worth knowing before choosing this
endpoint for anything where the code string matters.

A second endpoint quirk: glm-5.3-flash always reasons and rejects
`reasoning_effort: none` with a 400. `ChatCompatClient` is supposed to learn an
endpoint's reasoning parameter at runtime (0.7.20); it sent `none`, took the
400 and gave up rather than retrying at `low`. That retry is still missing.

### Turning the loop twice: what propagates and what refuses to (0.7.21 note)

A discovered code that passes the gate is folded in by `Taxonomy.add()`, which
returns **a new taxonomy object** at `version + 1` with a changelog entry
carrying the code, its provenance and the gate evidence. The identifier is
`D<version>.<slug>` from `discovered_code()` — deliberately not a number in
MedAgentAudit's scheme, since `2.1.3` would assert membership in someone
else's structure and two runs discovering different things would collide on
the same number. Structural position lives in `stage` instead.
`scripts/fold_back.py build` then writes the extended taxonomy, and `compare`
measures what it cost (uptake, residual, displacement, violations).

So the taxonomy accumulates. **The calibrator and the router do not, and that
is deliberate.** Both are bound to `Taxonomy.signature()` — a hash over every
code's phases, requirements and ground-truth flag — and `check_signature`
raises rather than scoring across a change (0.3.0). Adding one code changes
the signature, so T1 annotations cannot be scored by a calibrator fitted on
T0.

The consequence is the real obstacle to a second turn, and it is not the gate:

```
T0 --annotate--> residuals --gate--> new code --> T1
                                                   |
   calibrator(T0)  --refuses-->  annotations(T1)  <-'
```

Every turn of the loop invalidates Stage 2 and Stage 3 and requires refitting
them on anchors drawn under the new taxonomy. At the agent and step level that
is affordable — the injection log's ground truth is label-space independent,
which is what the 745 pseudo-anchors rest on. **At the mistake-type level it is
not**: the only anchors there would have to be human, and the 400 questions are
unanswered. So a second turn is currently possible for the taxonomy and the
annotator, and blocked for the calibrated routing on top of them.

Worth stating in the paper rather than hiding: a self-evolving taxonomy and a
calibrated router are in tension, because the router's guarantee is defined
against a fixed label space. Options are to refit per version (needs anchors),
to carry the calibrator across versions for codes whose definitions did not
change (the leave-one-code-out AUC of 0.901 is the evidence that this might
hold), or to state the operating point as valid for T_k only. None of the
three has been tried.

## 9. AdaMAST (Cemri et al., arXiv 2607.16387) — read in full, 2026-09-17

Same authors as MAST, including Cemri, Gonzalez, Zaharia, Dimakis and Stoica.
Best Paper at the ICML 2026 Workshop on Failure Modes of Agentic AI. It is a
workshop paper, not a main-track one, and the repository is young (15 commits),
but the lineage means it will be the reference point for anything that claims a
fixed failure taxonomy is insufficient. That claim is ours. It is now also
theirs.

### What it does

Induces a per-target-system failure taxonomy from that system's own traces.
Three fixed axes — A system-level, B role-specific, C domain-specific — chosen
as *intervention points*: repair the harness (A), rewire a role (B), inject task
knowledge (C). Every code name, definition and evidence pattern is induced; no
code hand-authored, no trace human-annotated.

Generation is four phases — ANALYSIS, CURATION, CONSOLIDATION,
INTER-ANNOTATOR AGREEMENT — and the first three are **eight LLM calls, once per
target system**. The taxonomy is then consumed by three dissimilar procedures
(evolutionary agent search, runtime self-check, best-of-N verifier), each of
which improves over free-text reflection.

Headline downstream numbers: search beats free-form reflection on all five
benchmarks; SWE-agent on SWE-bench Verified Mini 60% → 70%, Claude Code
64.0% → 70.7%; best-of-5 on Terminal-Bench 2.0 +8–15 points over Pass@1.
Artifact properties: ~18x compression with 89% unique code signatures, mean
cross-domain Jaccard 0.14.

### Where it overlaps us, honestly

1. **"A fixed taxonomy does not transfer."** Their cross-domain Jaccard 0.14
   says it across six domains. Our version gives the mechanism — capability
   vectors, structural exclusion, attributability as an architectural property —
   and theirs does not, but theirs has the breadth.
2. **Taxonomy induction from residuals** is our Stage 4 in another form, done
   without a seed at all and for eight calls.
3. **The four-annotator agreement gate** does, without humans, the job our 400
   unanswered anchor questions are waiting on.

### The gap, precisely, and it is in their own tables

The gate is **inter-annotator**: mean pairwise Cohen's κ ≥ 0.75 over four LLM
annotators at the **area** level, coverage floor 0.70, over at most 25 traces
(five per round, up to five rounds). The paper is explicit about what this
does not buy:

> This gate certifies that the taxonomy is consistently applicable; it does not
> certify that its codes are correct.

Correctness is checked once, externally, on TRAIL — 117 GAIA traces annotated
by four software-engineering experts. And the granularity of that check is the
thing to notice.

| level | what it compares | κ vs expert gold |
|---|---|---|
| **area** (3 buckets: Reasoning / Planning / System) | headline claim | **0.725** |
| **leaf** (the 20/29 actual codes) | reported as "diagnostic only" | **≈0.34** |

Per-annotator leaf κ against the experts is 0.301–0.334 (Table 23). Pairwise
κ *among the annotators* is 0.587–0.794 at leaf level and 0.650–0.814 at area
level (Table 24).

**The panel agrees with itself about twice as well as it agrees with the
experts, at the level where the codes are actually used.** Consumers fire leaf
codes — A.3, B.6, C.2 — in search feedback, the runtime skill and the verifier.
The artifact is validated at three buckets and consumed at twenty-nine codes.

Two further things worth having on hand:

- **The vocabulary comparison runs at thr=1.** Table 5's 0.516 (TRAIL
  hand-crafted, 20 categories) against 0.682 (AdaMAST, 29 codes) is the thr=1
  column — at least one of four annotators fires the area. Under a union-of-four
  consensus, a 29-code vocabulary mapped many-to-one into three areas (their
  F.6 mapping is 28/29 clean) has mechanically more ways to land in the right
  area than a 20-category one used directly. The comparison is not obviously
  vocabulary quality rather than granularity. F.3 states the threshold openly;
  the table does not.
- **The cross-family panel claim reverses at stricter thresholds.** Table 21:
  cross-family no-grounding gives 0.682 / 0.500 / 0.307 at thr=1/2/3, while the
  same-model 4×GPT-5.4 panel gives 0.625 / 0.630 / 0.563. Diversity wins only
  at thr=1; at thr=2 and thr=3 the homogeneous panel wins. The appendix says
  "the comparison narrows and reverses"; the main text reports only thr=1.

### What this means for us

**Do not compete on taxonomy induction.** Twelve authors, five benchmarks,
three consumers, and the MAST lineage. We would lose, and we would be arguing
against the better-resourced version of our own premise.

Compete on what their gate explicitly does not certify. Their pipeline answers
*what vocabulary*; ours answers *which of these annotations can be trusted
without a clinician*. Concretely, we hold three things they do not:

1. **Calibrated per-instance uncertainty and selective routing.** Their
   JUDGES emits a `confidence` float with no calibration claim anywhere. We
   have ECE 0.040, per-group conformal coverage 0.912–0.925, and a stated
   operating point (71.2% automatic at 9.6% error). Their κ gate is one
   number for a whole taxonomy; ours is a decision per annotation.
2. **Multi-point attribution.** JUDGES selects *the single best-supported
   failure code* per trace. Medical MAS failures are multi-agent, multi-step
   and multi-code — that is MedAgentAudit's and AEGIS's premise, and our
   Stage 1 is built for it.
3. **A domain with real human κ to check against.** MedAgentAudit's 383
   human-judged instances give per-code Fleiss κ 0.42–0.73. TRAIL gives them
   one external check at three-bucket granularity; the medical corpus gives us
   a per-code human floor. Their leaf κ≈0.34 sits below every one of our ten
   codes' human-human agreement.

Two experiments follow directly, and neither needs new data:

- **Replicate the gate/validity gap in the medical domain.** Run our four
  existing annotator endpoints (gpt-5.6-sol-disc, deepseek-flash,
  qwen3.8-flash, glm-5.3-flash — all wired in 0.7.20) as an AdaMAST-style
  panel on the 383 human-judged MedAgentAudit instances. Report inter-annotator
  κ and annotator-vs-human κ at the *code* level, side by side. If the ~2x gap
  reproduces on codes whose human κ we know, that is a result about agreement
  gates in general, measured where the stakes are clinical.
- **Use AdaMAST as an input, not a rival.** It is `pip install adamast` and
  reads jsonl. Induce a taxonomy on the AEGIS corpus, then run Stage 1 under
  three seeds — MedAgentAudit's ten, AdaMAST-induced, and our evolved set —
  and compare residue rate, uptake and calibrated selective error. That makes
  it an experimental condition rather than a competitor, and it is the natural
  baseline a reviewer will ask for anyway.

One caution about their per-system design: because a taxonomy is induced for
one target system and cross-domain vocabularies are nearly disjoint (Jaccard
0.14), there is no shared vocabulary in which to say "this failure occurs in
MDAgents and DyLAN at rates X and Y". For a clinical-safety argument that is a
real limitation, and it is the one place our seed-plus-evolution design is
straightforwardly better than induction from scratch.

## 10. Experiment A — what an agreement gate actually certifies (2026-09-17)

AdaMAST accepts an induced taxonomy when four LLM annotators reach mean
pairwise Cohen's kappa >= 0.75, and says in §3.1 that this certifies
consistent applicability, not correctness. Its one external correctness check
is at *area* granularity (3 buckets, kappa 0.725 against TRAIL experts); at
leaf granularity it reports ~0.34 against experts while the annotators agree
with each other at 0.587–0.794. The prediction taken into this experiment was
that the ~2x gap would reproduce in a medical domain.

**It did not reproduce, and what replaced it is a stronger objection.**

### Substrate

MedAgentAudit's audit human-eval set: 400 instances, 10 codes x 20 positive
x 20 negative, each judged yes/no by 3 of 6 clinicians in a balanced
incomplete block design (pairwise overlaps 66–134). Gold is majority of 3.
Recomputed here rather than taken from the paper:

- mean pairwise human kappa **0.635** (range 0.578–0.778 over 12 pairs)
- unanimous 3/3 on **296/400 (74.0%)**; the rest resolved 2–1
- per code **0.273 (3.1.2) to 0.744 (2.1.2)** — **0 of 10 codes reach 0.75**

Four annotators, one per family — glm-5.3-flash, qwen3.8-flash,
deepseek-flash, gpt-5.6-sol-disc — each given the identical prompt: one code
definition, one collaboration transcript, one binary verdict. 384 instances
survived in all four arms (glm 396/400 parsed, deepseek 387/400; the rest are
JSON failures on the `json_object` fallback path and are dropped from every
arm so no gate gets an easier subset).

### The gate rejects a taxonomy clinicians can apply

| | mean pairwise kappa |
|---|---|
| the four LLM annotators, with each other | **0.477** |
| the panel majority against expert gold | **0.504** |
| the six clinicians, with each other | **0.635** |

`0.477 < 0.75`, so **G-A rejects, and rejects on all ten codes individually
(0/10)**. These are MedAgentAudit's codes: built from real medical MAS traces,
used by clinicians, human-applicable at 0.635.

So the gate is not measuring the taxonomy. It is measuring the panel's
competence in the domain, and a weak panel fails a good taxonomy. That is a
different and more serious objection than "the threshold is too high": a
threshold can be tuned, but a measurement that confounds the artefact with the
instrument cannot be rescued by moving it. It also raises a circularity the
paper does not confront — AdaMAST's induced taxonomies are judged by the same
panel that induced them, which is a condition under which agreement is
expected to be high for reasons unrelated to code quality.

The predicted 2x inflation is absent in aggregate: self-agreement 0.477 versus
validity 0.504 is a ratio of **0.95x**. The panel agrees with the experts
about as well as it agrees with itself. It is not confidently wrong; it is
uniformly mediocre.

### But self-agreement and validity are decorrelated per code

| code | human K | panel self-K | panel vs gold | ratio |
|---|---|---|---|---|
| 1.2.1 | 0.652 | 0.701 | 0.346 | **2.03x** |
| 1.1.1 | 0.643 | 0.179 | 0.096 | 1.86x |
| 3.1.2 | 0.273 | 0.407 | 0.223 | 1.82x |
| 2.2.1 | 0.713 | 0.585 | 0.438 | 1.34x |
| 3.1.1 | 0.496 | 0.419 | 0.488 | 0.86x |
| 3.1.3 | 0.441 | 0.434 | 0.515 | 0.84x |
| 2.2.2 | 0.676 | 0.537 | 0.706 | 0.76x |
| 3.2.1 | 0.551 | 0.562 | **0.825** | 0.68x |
| 2.1.2 | 0.744 | 0.320 | 0.500 | 0.64x |
| 2.1.1 | 0.693 | 0.256 | **0.589** | 0.43x |

Correlation across the ten codes between self-agreement and validity is
**+0.35** — weak, and nowhere near a substitute. `1.2.1` is the textbook
agreement-without-validity case: the panel agrees with itself better than the
clinicians do (0.701 vs 0.652) and lands at 0.346 against the experts.
`2.1.1` is the inverse: the panel barely agrees with itself (0.256) and is one
of its most valid codes (0.589). **AdaMAST's inflation is real but
code-specific, and the aggregate mean that the gate uses hides it in both
directions.**

Three alternative gates on the same data:

| gate | rule | admits |
|---|---|---|
| G-A | panel self-K >= 0.75 (as published) | **0/10** |
| G-B | panel self-K >= that code's human K | 3/10 — 1.2.1, 3.1.2, 3.2.1 |
| G-C | panel-vs-gold K >= that code's human K | 3/10 — 2.2.2, 3.1.3, 3.2.1 |

G-B and G-C admit almost disjoint sets. They overlap on `3.2.1` alone. A gate
built on self-agreement and a gate built on validity are close to independent
instruments, and only one of them measures the property anybody wants.

### G-D: unanimity is a routing signal, not a verdict

The clinicians' own protocol is three judges and a majority, with 26% needing
2–1 resolution. Scoring the panel the same way:

| panel | unanimous | accuracy on those | blanket majority error |
|---|---|---|---|
| 4 models | 59.6% | 84.7% (err 15.3%) | 22.1% |
| 3 models | 69.3% | 82.3% (err 17.7%) | 21.9% |

Unanimity carries real signal — auto-deciding the unanimous 59.6% costs 15.3%
error against 22.1% for deciding everything — but the operating point is poor.
**For comparison, Stage 2/3 on this project's own corpus routes 71.2%
automatically at 9.6% error.** A calibrated per-instance router beats a
unanimity vote on both coverage and error, which is the concrete form of the
claim that our contribution is orthogonal to AdaMAST's rather than competing
with it.

Note the three-model panel is the configuration to report, not the four-model
one: it matches the clinicians' protocol instance for instance, so coverage
and error are comparable to the 74%/26% split the humans produced, and there
is no need to justify a panel size that has no human counterpart.

### What to take from this

1. **Do not adopt 0.75.** It rejects a taxonomy clinicians apply at 0.635. It
   is a domain-blind constant presented as a threshold.
2. **Do not adopt an agreement gate at all as the primary instrument.** Self-
   agreement correlates with validity at +0.35 across codes. It is not a proxy.
3. **Report the operating point, not the verdict.** Coverage at fixed error,
   against the human floor measured in the same domain, is computable here and
   is what an operator needs. This is the gate to build, and it is where the
   existing conformal router already applies.
4. The honest framing for the paper is *orthogonality*, not superiority:
   AdaMAST answers what vocabulary to use, and does it at eight LLM calls per
   system. Nothing here weakens that. What this shows is that its acceptance
   criterion does not transfer, and that the question it explicitly declines to
   answer — which annotations can be trusted — has a measurable answer that
   an agreement gate cannot produce.

### Caveats that belong in any writeup

- The four annotators are all flash/fast-tier models. A panel of frontier
  models would likely score higher, and this experiment does **not** show that
  LLM panels cannot reach human agreement — only that this panel, on this
  domain, does not, and that the published threshold rejects a good taxonomy
  when they do not.
- 16 of 400 instances were lost to JSON parse failures on the `json_object`
  fallback path (glm 4, deepseek 13). Dropped from every arm, not imputed.
- Gold is a majority of three clinicians whose own mean pairwise kappa is
  0.635. Every "validity" number here is agreement with that construction, not
  with ground truth, and on 2–1 instances it encodes one expert's dissent as
  error.
- 400 audit ids map to 383 unique transcripts (17 instances audited twice
  under different codes). Kept, since the code differs and the judgement is
  per code.

## 11. Replication across annotators, and two silent defaults (2026-09-18)

### What was run

Arm A — the full ten-code control — repeated on the **same 180 faulty traces**
with two further annotators, pinned with `--trace-ids` so the sets are
identical:

| annotator | traces | endpoint | notes |
|---|---|---|---|
| glm-5.3-flash | 180 | bigmodel | the original |
| gpt-5.6-sol-disc | 180 | aihubmix | the project's reference annotator |
| deepseek-flash | 61 | deepseek | paused; ca5 complete, ca partial |

deepseek was stopped at 61 traces deliberately. Its rate had fallen to ~0.3
traces/minute, and the point it was needed for — that base rate is an
annotator property — was already carried by the 45 clinical_agent5 traces it
had finished. Its Arm B was not worth four hours either: at 0.62 novel
proposals per trace under the full taxonomy it would land in the range glm
already covers, where gpt at 2.60 is the informative end.

Results and the corrections they force are in §8, which has been rewritten
rather than appended to: the base-rate table now carries three columns, and
the 17% ceiling now carries the range it actually implies. Two sentences were
withdrawn outright — "the corpus exhibits all four, emphatically" and "the
ceiling is Stage 1 and it is 17%".

### What replicated and what did not

Nothing about *how often* a code fires replicated. `2.1.2` is 6 against 34 on
the same 45 traces; `2.2.1` is 12 against 70; `3.1.2` fires seven times for
one annotator and never for the other; novel-proposal rates differ 12-fold.

Everything about *where* a code can fire replicated exactly. Across the 135
non-dylan traces, the two complete arms report `2.2.1` and `3.2.1` zero times
between them, while disagreeing on which of the two is more common — opposite
orderings, 39:12 against 33:70. `requires: has_multi_round` is read off the
capability vector and never reaches the model, so it is the one quantity here
the annotator cannot move.

That split is the useful result. Frequency is a measurement made by a model;
eligibility is a fact about an architecture. The 0.7.21 denominator fix rests
entirely on the second, which is why it survives a replication that overturns
most of the first.

### Two silent defaults, same shape

**`--images` was optional and its absence was unlogged.** `run_stage1.py` set
`store = None` when the flag was omitted, so a corpus with 57 image references
across its mdagents traces was annotated text-only, four arms in a row, with
nothing in the output distinguishing that from a run with images attached.
The 0.7.19 ablation (n=28, claude-opus-5) makes the results defensible after
the fact — images moved four verdicts out of ~168, two of which cancelled —
but that is an argument found afterwards, not a decision made in advance.

Now a corpus with image references and no `--images` **exits** rather than
running, and names both ways forward; `--no-images` runs text-only on purpose
and prints what was withheld, noting that `1.2.1` verdicts in particular are
made without the pixels. A text-only run is a valid experiment; an accidental
one is not.

Worth flagging, not resolving: the 0.7.19 ablation is itself a single-annotator
result, and this session's central finding is that annotators differ by
factors of several on nearly every quantity measured. On mdagents — the
framework holding all 57 image references — gpt reports `2.1.1` eight times to
glm's one and `3.1.2` zero times to glm's seven. "Images change almost
nothing" may be as annotator-dependent as the base rates and the ceiling
turned out to be. It is not currently known.

**A progress counter used `wc -l` on stage1.jsonl.** Stage 1 appends a record
on failure and a second one when the retry succeeds, so the file outgrows the
corpus: 194 lines for 180 traces, of which 163 were annotated and 17 were
still failing on `400 cannot be served`. The supervisor read 194 >= 180,
declared Arm A complete and started Arm B against an incomplete control. Fixed
by counting trace_ids that carry an annotation, which reported 163/180 on its
first run and resumed.

Both are the same failure: a cheap proxy standing in for the quantity that
matters, never checked at the boundary where it stops being a proxy. This is
the fifth instance in two days — the others being `min_name_words` counting
whitespace (0.7% of proposals on one annotator, 70% on another), the logprob
probe reading one backend and reporting a model capability, and a per-call
latency measured on a single-verdict task extrapolated to a 20-slot one.
`selfcheck_offline.py` gains a `silent defaults` group; the suite is 32 -> 52
since 0.7.20.

### Endpoint notes worth keeping

- **deepseek-flash supports logprobs**, with five alternatives, which is more
  than gpt-5.6-sol-disc offers on aihubmix (one). The earlier "no logprobs"
  reading came from running it on `--annotator-backend chat`, whose
  completions path returns an empty array; the Responses path returns the full
  list. A property of the backend chosen, not of the model. Unresolved: the
  project's probe returns alternatives at `effort=none` and an empty array at
  `effort=max`, while external testing reports logprobs at `max`. Not used for
  anything until settled.
- **deepseek-flash always reasons**, and the default 6000-token reasoner
  budget is consumed by the chain of thought on long transcripts, leaving no
  message block: 4 of the first 9 traces failed as `model_empty_output`.
  `--reasoner-effort low --reasoner-max-tokens 24000` fixes it; the four
  failures were recovered on retry.
- **glm-5.3-flash also always reasons** and rejects `reasoning_effort: none`
  with a 400 naming its own accepted values. `ChatCompatClient` is supposed to
  learn an endpoint's reasoning parameter at runtime (0.7.20); it sent `none`,
  took the 400 and gave up rather than retrying at `low`. That retry is still
  missing.
- **aihubmix returns `400 cannot be served`** for gpt-5.6-sol-disc under load:
  none at concurrency 12, 14 failures at 45. Not a rate limit and not
  accompanied by a retry-after, so backing off is guesswork. Throughput at 12
  is ~0.6-1.7 traces/minute against glm's 2.4 at any concurrency.
- Of the four endpoints, **glm-5.3-flash is the fastest for Stage 1** by a
  factor of 4-5. The panel experiment's per-call timings do not predict this:
  deepseek was fastest there at ~2s per single binary verdict and is slowest
  here at a 20-slot two-pass trace.

## 12. Making the loop turnable: pluggable Stage 2 / Stage 3 (0.7.25)

Self-evolution is the claim, and the loop has never turned twice. §8 traced
the obstacle: it is not the admission gate. `Taxonomy.add()` changes
`signature()`, and the calibrator and the conformal router are both bound to
that signature and refuse to score across a change. The refusal is correct —
a calibrator fitted on T_k extrapolates on T_{k+1} and **fails silently**,
returning perfectly plausible wrong probabilities — but it makes a second turn
cost a full re-anchoring, and at the mistake-type level the anchors can only
be human. The 400 questions are still unanswered.

So the fixed-label-space assumption becomes a **declared choice per backend**
rather than a property of the pipeline.

### What each stage was really assuming

ACI and Venn-Abers do not substitute for each other; they change different
things, which is why one switch could not have covered both.

| | changes | guarantee | needs |
|---|---|---|---|
| split conformal | — (current) | marginal coverage ≥ 1−α, finite sample | **exchangeability** |
| **ACI** | Stage 3's quantile, online | **long-run** coverage under *arbitrary* shift | sequential **feedback** |
| **Venn-Abers** | Stage 2's output type: point → interval | automatic calibration; width reports its own ignorance | exchangeability, but degrades visibly |

### The common type

Both sides now agree on one object:

```python
@dataclass(frozen=True)
class Belief:
    lo: float
    hi: float          # a point estimator sets lo == hi
```

`Belief.p` collapses an interval with the Venn-Abers formula `hi / (1 − lo +
hi)`, not the midpoint. For a symmetric interval the two coincide, which is
why the self-check tests an asymmetric one.

### Backends

**Stage 2** (`mafa/calibration_backends.py`):

| name | what it is | policy on a taxonomy change |
|---|---|---|
| `logistic` | the existing TwoHeadCalibrator | `REFIT_REQUIRED` — **raises** |
| `venn_abers` | IVAP over the raw score | `DEGRADES_VISIBLY` |
| `logistic_va` | Head A's scores wrapped in Venn-Abers | `DEGRADES_VISIBLY` |

`logistic_va` is the one to reach for: isotonic regression is one-dimensional
and monotone, so handing it raw features discards every interaction Head A
learns. The inner model is fitted on half the anchors and the isotonic
calibration read off the other half — the same split-to-avoid-self-reading
that split conformal exists to enforce, one layer up.

**Stage 3** (`mafa/routing_backends.py`):

| name | what it is | policy |
|---|---|---|
| `split` | the existing BinaryConformal | `REFIT_REQUIRED` |
| `aci` | Gibbs & Candès adaptive conformal, per Mondrian group | `ADAPTS_ONLINE` |
| `venn_abers` | routes from the interval; no calibration set | `DEGRADES_VISIBLY` |

### ACI's feedback is already being produced

The update is one line, per group:

```
alpha_{t+1} = alpha_t + gamma * (alpha_target - err_t),   err_t = 1 if truth not in C_t
|(1/T) sum err_t - alpha| <= (alpha_1 + gamma) / (T * gamma)
```

for **any** sequence, adversarial included, with no exchangeability. Miss too
often and `alpha_t` falls, the quantile rises and the sets widen; over-cover
and they tighten.

What makes this the right fit rather than a generic robustness trick: **every
VERIFY and REVIEW decision already goes to a human and comes back with a
label.** The routing loop produces exactly the sequential signal ACI consumes.
The human-in-the-loop design and the adaptive guarantee are the same mechanism
viewed from two ends.

Measured on 200 synthetic slots, target α = 0.10:

```
t=  1  alpha_t=0.1000  q=0.6800
t= 50  alpha_t=0.0500  q=0.6818  empirical coverage 0.880
t=100  alpha_t=0.1000  q=0.6800  empirical coverage 0.900
t=200  alpha_t=0.1500  q=0.6250  empirical coverage 0.905
```

`warming_up` is true until a group has seen `warmup = 50` verdicts, and a
taxonomy change resets the counters — until then the sets are reported without
the long-run claim.

### The NOVEL channel had to be rebuilt for intervals

A Venn-Abers interval is never empty, and **empty-set is how Stage 3 hands
work to Stage 4**. Width takes over, and it is arguably the better statement
of what the empty set was approximating all along: an empty conformal set
means no label is conformal, which is evidence about coverage reached
indirectly; width says directly that the calibration data does not constrain
this slot.

The first fixed threshold chosen (0.4) was above the widest interval the data
produced (0.303), which would have **disabled the channel silently** — the
same failure shape as the five in §11. So the threshold is `"auto"` by
default: set at fit time to the width quantile that fires on
`target_novel_rate` of slots, and `is_novel()` **raises** if called before
`fit()` rather than defaulting.

```
novel_width auto-set to 0.4700, the 95% width quantile, so the NOVEL channel
fires on about 5% of slots
```

### Incompatible pairings are rejected, not discovered

`check_compatible()` refuses `logistic` + `venn_abers` routing: width would be
0 for every slot and NOVEL would never fire. The error names the fix
(`logistic_va`).

`describe_pairing()` returns the claim, taking the **weaker** of the two
policies:

| calibrator | router | loop policy | can turn without re-anchoring |
|---|---|---|---|
| logistic | split | refit_required | **no** |
| logistic | aci | refit_required | **no** |
| logistic_va | split | refit_required | **no** |
| logistic_va | aci | adapts_online | **yes** |
| logistic_va | venn_abers | degrades_visibly | **yes** |

**The second row is the finding.** ACI alone does not make the loop turnable:
the logistic calibrator raises before the router ever sees a belief. To turn
the loop you have to change the *calibrator*, not just the router — the
adaptive machinery on the routing side is useless behind a scorer that refuses
to score.

### What is honestly claimed

Stated plainly so nobody reads more into the code than it supports:

- **Nothing here makes a taxonomy change free.** Venn-Abers is valid under
  exchangeability exactly as split conformal is, and a taxonomy change breaks
  it for both. What VA buys is that the breakage appears as width instead of
  as a confident wrong number.
- **ACI's guarantee is long-run and conditional on feedback continuing.** It
  says nothing about any single step, and lapses entirely if the human queue
  stops returning verdicts.
- `gamma = 0.05`, `warmup = 50` and `target_novel_rate = 0.05` are **guesses,
  not calibrated values.** None has been ablated. Add them to the list with
  `ambiguous_band` and `max_rate_spread` (§4.3 of the Q&A doc).
- **No empirical comparison of the three pairings on real anchors exists
  yet.** The pseudo-anchor file carries labels but not features, so the
  comparison needs a Stage-1 run over the simulated split — where the
  injection log supplies free ground truth — and then one fit per pairing.
  That is the experiment that would turn the table above from a set of stated
  policies into measured coverage and set sizes.

Defaults are unchanged: `logistic` + `split`, byte-identical behaviour to
0.7.24. Self-check 52 → **75**.

## 13. Unsupervised calibration: making a turn cost no annotation (0.7.26)

§12 offered ACI and Venn-Abers as the backends that let the loop turn, and
**both are supervised**. Stated plainly, because the earlier framing was too
comfortable:

* **ACI** needs `err_t`, which needs the realised label. §12 argued the
  feedback is free because the VERIFY/REVIEW queue already returns human
  verdicts. That is weaker than it read. Feedback arrives **only on routed
  slots**, which are the uncertain ones by construction, so the long-run
  guarantee is earned over the *routed subpopulation*, not the corpus. And
  after `Taxonomy.add()` the new code's slots receive no verdicts at all
  until somebody annotates them -- which is precisely the cost the loop was
  meant to avoid, the 400 unanswered mistake-level questions.
* **Venn-Abers** needs a labelled calibration set for its isotonic fits.
  Width degrades honestly, but the fits are supervised.

So §12 made the cost of a turn *explicit*; it did not remove it.

### LaSCal fits, BaseCal does not

| method | what it needs | usable here |
|---|---|---|
| **LaSCal** (NeurIPS 2024) | source labels, **no target labels**; label shift | **yes** |
| **BaseCal** (ACL 2026) | the annotator's **base** model, and hidden states for `-Proj` | **no** |
| PseudoCal | unlabelled target features only | possible, not implemented |

BaseCal calibrates a post-trained LLM against its own base model. It is
genuinely unsupervised and reports large ECE reductions, and it is unusable
here for a deployment reason rather than a scientific one: every annotator is
reached through a third-party chat endpoint, so there are no hidden states and
no served base checkpoint for `gpt-5.6-sol-disc` or the others. Recorded
rather than silently dropped: **if a local open-weights annotator is ever
used, BaseCal-ReEval becomes the cheapest unsupervised option available.**

LaSCal's situation is exactly ours -- labels under T_k, none under T_{k+1} --
and its assumption holds **partly**, which is the part worth being careful
about:

* For an **existing** code's slots, adding a new code moves p(Y): instances
  once labelled 2.2.1 may now be labelled D1.x, so the positive rate falls.
  p(X|Y) is plausibly stable. **Label shift is a reasonable model.** Caveat:
  the annotator's prompt gains a code, so `p_token` can move conditional on
  the label too -- covariate shift layered on top, outside what LaSCal
  corrects.
* For the **new** code's own slots there is no label shift, because there was
  no source class to shift. It is a label-space extension, and no reweighting
  of source labels can speak to it.

That split is the design. `LaSCalBackend` recalibrates the old codes with no
labels and **abstains** on the new code -- `known_codes` marks which classes
existed in the source, and a slot outside that set comes back as
`Belief(0.0, 1.0)`, maximally wide, which routes it to a human. The loop
turns on the part that can be corrected and declines on the part that cannot.

### Prior correction, not temperature

The first implementation swept a temperature against the label-free CE. It
pinned to the edge of the grid at every shift magnitude and made the **true**
ECE worse than doing nothing on the no-shift case:

| true target rate (source 0.40) | before | prior + T | prior only |
|---|---|---|---|
| 0.10 | 0.0646 | 0.0235 | **0.0196** |
| 0.15 | 0.0547 | 0.0315 | **0.0252** |
| 0.25 | 0.0347 | 0.0360 | **0.0260** |
| **0.40 (no shift)** | 0.0336 | **0.0451** | **0.0306** |
| 0.60 | 0.0595 | 0.0407 | **0.0406** |

The 0.40 row is the damning one: nothing shifted, there was nothing to
correct, and fitting a temperature to a noisy label-free objective invented a
correction and lost 0.012 ECE.

The reason is structural. Under label shift the exact correction is on the
**odds**, `p_target(y=1|x) ∝ w_1 · p_source(y=1|x)`, so the odds are
multiplied by `w_1/w_0`. A temperature divides the logit and therefore
sharpens or flattens symmetrically about 0.5 -- **it cannot move a prior**.
It was compensating for a prior shift with the wrong instrument.

Temperature is now off by default and kept switchable for the ablation. Prior
correction alone never did worse than doing nothing across the five
magnitudes tried.

### BBSE refuses rather than inverting noise

Weights come from black-box shift estimation: the predicted-label marginal on
the target satisfies `q(ŷ) = Σ_y p(ŷ|y)·p_target(y)`, and `p(ŷ|y)` is
measurable on the source where labels exist. Invert and read off the target
marginal.

The inversion needs a confusion matrix that is not near-singular. `det(C)` is
bounded on this scale -- C holds joint probabilities summing to 1, so a
perfect classifier on balanced classes gives 0.25 and a coin flip gives 0.
The first floor chosen, `1e-3`, sat **far below the sampling noise of a
useless classifier**: a coin flip on 400 points came back at |det| = 0.011 and
was inverted rather than refused. The floor is now 0.02, above that noise and
well below anything a classifier worth calibrating produces. Below it the
backend returns unit weights and says so rather than returning loud nonsense.

That is the sixth instance of the same failure shape in this project and the
second one caught by its own self-check rather than by a run.

### The policy tier

`EvolutionPolicy` gains `ADAPTS_UNSUPERVISED`, ranked above `ADAPTS_ONLINE`
**on cost, not on strength of guarantee**. What it gives up is the coverage
bound: this is consistency under label shift, not a finite-sample
certificate. `describe_pairing()` says so in the claim string.

| calibrator | router | can turn the loop | what a turn costs |
|---|---|---|---|
| logistic | split | no | full re-anchoring |
| logistic | aci | no | the calibrator raises first |
| logistic_va | aci | yes | human verdicts on routed slots |
| logistic_va | venn_abers | yes | nothing, but no coverage claim |
| **lascal** | split / aci | **yes** | **nothing** |

### What is still not claimed

- Everything above is measured on **synthetic data where the label-shift
  assumption was made true by construction**. Whether a real
  `Taxonomy.add()` produces something close enough to label shift is
  unmeasured, and it is the experiment that matters. It needs a Stage-1 run
  under T_k and another under T_k + one admitted code, on the same traces.
- The BBSE estimate is biased toward the source in these runs (true 0.15,
  estimated 0.226), so the correction is real but partial.
- `min_det = 0.02`, `bins = 10` and the abstention rule join the list of
  values that have not been ablated.

Self-check 75 → **84**.

## 14. Black-box calibration: the only backends that can speak to a new code (0.7.27)

Three attempts at the same problem, constraints narrowing each time:

| version | backends | needs |
|---|---|---|
| 0.7.25 | ACI, Venn-Abers | **labels** |
| 0.7.26 | LaSCal | source labels; models **label shift** only, abstains on a new code |
| **0.7.27** | sample consistency, DACA, consistency distillation | **nothing but chat API output** |

That last row is what the claim needs. LaSCal recalibrates the old codes for
free and then has to say "I don't know" about the one code the turn actually
added. These three can produce a confidence for it.

### What survives the API constraint, and what does not

Assessed against a pipeline where every annotator is a third-party chat
endpoint:

| method | usable | why |
|---|---|---|
| Sample Consistency (AAAI 2025) | **yes** | k samples, agreement rate, nothing else |
| Consistency distillation (arXiv 2026) | **yes** | samples offline, one call at inference |
| DACA (NeurIPS 2025) | **partly** | needs a reference believed better calibrated; we have no base checkpoints, but we can *measure* which endpoint qualifies |
| BaseCal (ACL 2026) | no | no served base checkpoint, no hidden states |
| ATS (EMNLP 2024) | no | token-level hidden states |
| CFT/RCFT (ICML 2025), bilevel (COLM 2026) | no | fine-tuning; we cannot touch weights |

### The concrete win: saturation

`p_token` is one-sided on every endpoint in use — the top-k logprobs come
back with a single alternative — so the estimate pins to 0 or 1. The sampler
documented the consequence: 189 of 247 slots at the extremes and 9 across the
middle three bins, which is a calibration set with almost nothing where
routing actually happens.

Measured on 800 simulated slots:

| estimate | share at the extremes | distinct values |
|---|---|---|
| `p_token` (one-sided logprob) | **100.0%** | **2** |
| 10-sample agreement rate | **0.0%** | **10** |

A Laplace pseudo-count keeps a unanimous vote off 1.0 (observed range
[0.203, 0.797]) — k unanimous samples are evidence for a high probability,
not proof of certainty, and an uncalibrated 1.0 breaks every downstream odds
computation.

This works identically on endpoints that return no logprobs at all, which is
three of the four in use.

### The caveat this project can state and the papers cannot

Every consistency method estimates **how much a model agrees with itself**
and uses it as a proxy for **how often it is right**. §10 measured that proxy
directly, in this domain, against clinicians:

- four LLM annotators agreed with each other at mean pairwise κ **0.477**,
  and with the expert gold at **0.504** — so in aggregate self-agreement was
  not inflated;
- but across the ten codes the correlation between panel self-agreement and
  panel validity was only **+0.35**, running both ways per code: `1.2.1`
  self-agreement 0.701 against validity 0.346, `2.1.1` self-agreement 0.256
  against validity 0.589.

The simulation reproduced the consequence, on 800 slots where the annotator's
competence was fixed at 0.85 and the samples cluster on its *belief* rather
than the truth:

| calibrator | ECE vs the true label | accuracy |
|---|---|---|
| raw `p_token` | 0.155 | 0.845 |
| sample consistency | 0.129 | 0.845 |
| consistency distillation | 0.115 | 0.845 |
| DACA | 0.096 | 0.845 |

*and the simulation was too pessimistic.* See §15: on real slots with real
clinician labels, 5-sample agreement reaches ECE **0.060**, not 0.129. The
fixture's samples were made to cluster on the belief with probability 0.9 at
every slot, which understates how much a real model's output distribution
spreads on the cases it is actually unsure about. The self-check assertion
that consistency must not reach the supervised ECE is now scoped to the
fixture, where it is a statement about the fixture's construction, not a
claim about the method.

### DACA: the assumption replaced by a measurement

DACA optimises a temperature so the target's probabilities match a
reference's, **using only the slots where the two agree** — on a disagreement
slot the reference's confidence describes the correctness of its own
prediction, not the target's.

The paper's justification is that a pre-trained base model is better
calibrated than its post-trained descendant. **That does not transfer**: there
is no served base checkpoint for any endpoint here.

What replaces it is stronger than an assumption. This project has 400
MedAgentAudit instances with three clinicians each, and §10 already scored
every endpoint against that gold. `rank_references_by_gold()` ranks candidate
references by measured ECE against the human majority;
`set_verified_reference()` records the choice. Until that is done the backend
reports the reference as **UNVERIFIED** and says why:

> Without it this is temperature scaling toward an arbitrary second opinion,
> and §10 measured those four endpoints agreeing with each other (κ 0.477)
> about as well as with experts (0.504).

### Cost, and why distillation exists

Sample consistency costs k scorer calls per slot — at 20 slots per trace and
k = 10, 200 extra calls per trace. `consistency_distill` pays that once,
offline, and fits the **existing feature head** against the agreement rate
instead of a human label. Inference returns to one call per slot.

The fit with this codebase is exact: Stage 2 already maps a feature vector to
a probability with a logistic head, and the only thing that made it
supervised was the target. `soft` regresses on the agreement rate and keeps
its gradation; `hard` thresholds at 0.5 — soft is the default, since
thresholding would discard the gradation that sampling was bought to obtain.

### Where this leaves the loop

| calibrator | turns the loop | covers a newly added code | what a turn costs |
|---|---|---|---|
| logistic | no | — | full re-anchoring |
| logistic_va | yes | abstains (wide) | routed-slot verdicts |
| lascal | yes | **abstains** | nothing |
| **sample_consistency** | yes | **yes** | k samples per slot |
| **consistency_distill** | yes | **yes** | k samples once, offline |
| daca | yes | via the reference | nothing, if a reference is verified |

### Still not claimed

- All numbers above are **simulated**, on a fixture built so that samples
  cluster on the annotator's belief rather than the truth. It reproduces the
  §10 phenomenon by construction; it does not show the magnitude is right on
  real slots.
- The real experiment is cheap and has not been run: sample k verdicts per
  slot on the 180 traces already annotated, and compare the agreement rate
  against the 745 pseudo-anchors at the agent and step levels where free
  ground truth exists.
- `k = 10`, `laplace = 1.0` and the soft/hard choice join the unablated list.
- DACA's reference has **not** been verified on the 400 instances yet, so the
  backend correctly reports UNVERIFIED. Doing that is one script run against
  data already in `results/panel_vs_humans/`.

Self-check 84 → **105**.

## 15. The consistency validation, on real slots with clinician labels (0.7.28)

§14 was measured on a fixture. This is the same question on the only place in
this project where a mistake-level slot carries a human label: MedAgentAudit's
audit human-eval set, 400 instances across ten codes, three clinicians each,
gold = majority.

Protocol: glm-5.3-flash, the same prompt as §10, **k = 5 samples at
temperature 1.0**. The temperature matters and is not incidental — sampling at
0 returns the mode five times and the agreement rate is a constant 1.0. 2,000
votes drawn, 394 of 400 instances usable (the rest lost to JSON parse
failures on the `json_object` fallback path).

### The headline

| confidence from | ECE | Brier | accuracy |
|---|---|---|---|
| a single sample (§10 panel) | **0.2298** | 0.2298 | 0.7702 |
| **5-sample agreement rate** | **0.0604** | **0.1682** | 0.7753 |

**ECE falls 74%.** Brier falls 27%. Accuracy is unchanged, which is what
calibration should do — it does not move the argmax.

For scale: the supervised two-head calibrator measures **0.046** on the
pseudo-anchors. A label-free estimate at 0.060 is much closer than the fixture
predicted (0.129), so **§14's "does not come close to the supervised head" was
too pessimistic and has been corrected in place.** The fixture made samples
cluster on the model's belief with probability 0.9 at every slot, which
understates how much a real model's output distribution spreads on the cases
it is genuinely unsure about.

### The saturation fix, on real data

| | at the extremes | distinct values |
|---|---|---|
| single sample | **100.0%** | **2** |
| 5-sample agreement | **0.0%** | **10** |

This is the problem `anchor_sampler` has been documenting since 0.7.x — 189
of 247 slots at the extremes, 9 across the middle three bins — and five
samples at T=1.0 removes it on an endpoint that returns no usable logprobs at
all.

### Unanimity as an operating point

| | share | accuracy |
|---|---|---|
| unanimous 5/5 | **80.7%** | **0.818** |
| split | 19.3% | 0.615 |

Auto-deciding the unanimous covers 80.7% at 18.2% error. Compare §10's
four-model panel: 59.6% coverage at 15.3% error. **Much higher coverage, worse
error** — and the reason is worth stating rather than celebrating: five
samples from *one* model agree far more readily than four *different* models
do. The coverage gain is partly the same model repeating itself.

### The finding: self-agreement does not rank the codes

| code | mean agreement | accuracy | ECE |
|---|---|---|---|
| 3.1.1 | 0.955 | 0.821 | 0.109 |
| 3.1.2 | 0.955 | **0.700** | 0.160 |
| 2.1.2 | 0.955 | 0.825 | 0.121 |
| 3.1.3 | 0.951 | 0.789 | **0.071** |
| 3.2.1 | 0.945 | **0.895** | 0.112 |
| 1.2.1 | 0.945 | 0.725 | 0.143 |
| 2.2.1 | 0.944 | 0.744 | 0.108 |
| **1.1.1** | 0.942 | **0.650** | **0.199** |
| 2.2.2 | 0.937 | 0.825 | 0.109 |
| **2.1.1** | **0.885** | 0.825 | 0.110 |

Self-agreement spans **0.885 to 0.955** — seven percentage points — while
accuracy spans **0.650 to 0.895**. Across the ten codes the correlation is
**−0.118**. In a band that narrow the sign is noise, but the conclusion is
not: **self-agreement carries essentially no information about which codes
the model gets right.**

`1.1.1` is the case to keep: agreement 0.942, accuracy 0.650, ECE 0.199. The
model is confident and wrong, consistently, on the most frequent code in the
corpus. `2.1.1` is the mirror — least agreement, high accuracy.

§10 measured the panel version of this at +0.35. The single-model version is
weaker still, and for a structural reason: four different models can disagree
about which codes are hard, five samples from one model mostly cannot.

**So a pooled ECE must not be reported alone.** 0.060 is true and it hides
0.199 on `1.1.1` and 0.160 on `3.1.2`. The self-check now fails if the worst
code is not several times the pooled value, so that the spread cannot be
quietly dropped from a later revision.

### DACA's reference, chosen by measurement

Ranking the four endpoints by ECE against the clinicians' majority on the 384
instances all four answered:

```
glm-5.3-flash      ECE=0.2240  acc=0.7760   <- best
deepseek-flash     ECE=0.2604  acc=0.7396
gpt-5.6-sol-disc   ECE=0.2682  acc=0.7318
qwen3.8-flash      ECE=0.2865  acc=0.7135
```

So glm is the evidence-backed reference, not a guess. One caveat that makes
this provisional: these are hard 0/1 verdicts, so ECE is identically
1 − accuracy and the ranking is an accuracy ranking wearing a calibration
label. A reference needs graded probabilities — which is exactly what the
sampling run now provides, and re-running the ranking on 5-sample rates is
the obvious next step.

### What this does and does not establish

- **Establishes:** on real medical MAS slots with clinician gold, label-free
  5-sample consistency calibrates far better than a single verdict and close
  to a supervised head, on an endpoint with no usable logprobs.
- **Does not establish:** that it transfers to the agent and step levels.
  This is a mode-level measurement, and the mode level is precisely where the
  project has no anchors. The agent/step version is available for free from
  the injection logs and has not been run.
- **Does not establish:** anything about a newly added code. That was the
  motivation in §14 and it remains untested — it needs a turn of the loop.
- k = 5 was chosen for cost. The k-vs-ECE curve is unmeasured; 2,000 votes
  took about 30 minutes at concurrency 14.

Self-check 105 → **115**. Data archived in `results/consistency_validation/`.

## 16. The loop's first candidate, and the agent level (0.7.29)

### Agent-level consistency: transfers, weaker, and not poolable

§15 measured 5-sample agreement at the mode level against clinicians. This is
the agent level, where ground truth is **free and taxonomy-independent**: the
simulated split's injection log records which agents were corrupted, and that
fact does not change when a code is added. So this measurement can be
repeated after every turn of the loop without an annotation.

glm-5.3-flash, k = 5 at T = 1.0, 40 traces balanced across frameworks, **220
agent slots all at k = 5**, 115 positive (52%).

| confidence | ECE | Brier | accuracy |
|---|---|---|---|
| single sample | 0.3227 | 0.3227 | 0.677 |
| **5-sample agreement** | **0.1292** | **0.2216** | 0.686 |

ECE falls 60%, the same direction as the mode level's 74%, but the absolute
value is **twice** the mode level's (0.129 vs 0.060).

**Per framework, and this is where the finding is:**

| framework | n | ECE | acc | recall | spec. upstream |
|---|---|---|---|---|---|
| clinical_agent | 60 | **0.098** | 0.733 | 0.500 | 1.000 |
| clinical_agent5 | 50 | 0.180 | 0.720 | **0.381** | 0.933 |
| mdagents | 70 | 0.171 | 0.686 | 0.741 | — |
| **dylan** | 40 | **0.304** | **0.575** | **0.950** | — |

Two different failures, and they should not be averaged:

* **dylan flags nearly everything** (recall 0.950, accuracy 0.575), and the
  cause is structural. dylan is multi-round with peer exposure, so an injected
  claim reaches every agent in later rounds. There is **no upstream clean
  agent in dylan at all** -- nobody finishes speaking before the first
  injection -- so the "specificity upstream" cell is empty rather than low.
  On dylan the injection log is not a usable agent-level ground truth: it
  calls contaminated agents clean, and a model that correctly flags them is
  scored as a false positive. **A substantial part of dylan's 0.304 is error
  in the labels, not in the calibration.**
* **The clinical frameworks under-flag** (recall 0.500 and 0.381). These are
  pipeline structures without peer exposure, so there is no propagation to
  blame. The model misses injected agents. This is a real miss.

The propagation split reproduces the old measurement almost exactly:
specificity on upstream clean agents **0.947** (n = 19) against downstream
**0.651** (n = 86), a gap of 0.30, where `validate_on_injected.py` measured
0.27 (z = 2.48, p = 0.013). Pooling the two would understate specificity by
about a third. n = 19 upstream is small and its interval is wide.

Unanimity routes 74.5% at accuracy 0.726, against 0.571 on split slots.

### The prompt bug that the first run measured instead

The first agent run omitted the taxonomy block. The agent slot question asks
whether a passage "demonstrates **one of the applicable failure modes**", and
that phrase refers to the block Stage 1 renders above the slot list. Without
it the question became "did this agent do anything wrong at all":

| | ECE | accuracy | flag rate |
|---|---|---|---|
| no taxonomy block | 0.249 | 0.589 | **71.1%** |
| **with it** | **0.129** | **0.686** | **49.1%** |

The flag rate returning to 49% against a 52% base rate is the check that the
fix did what it was for. Mode-level slots were never affected, because each
mode question carries its own definition -- which is why §15 was clean. The
bad run is archived as `votes_agent_NOTAXONOMY_glm.jsonl` as a control.

### A token ladder instead of a token budget

glm-5.3-flash always reasons, and the chain of thought is billed against
`max_tokens`. A fixed budget was wrong in every direction tried:

| budget | failure rate | note |
|---|---|---|
| 3000 | **66%** | reasoning 2993 of 3000, content `""` |
| 16000 | 40% | |
| 32000 | 35% | **throughput collapsed to 1.8 votes/min** |
| **ladder 10k → 20k → 40k** | **0%** | 323 calls |

The 32000 row is the one worth remembering: a larger budget did not just cost
more, it induced longer reasoning — one successful call spent 8006 tokens and
73 seconds, of which **7930 were reasoning and 76 were the answer**. The model
expands to fill what it is given.

The ladder starts cheap and escalates only on truncation. It distinguishes the
two failures that had been conflated as `JSONDecodeError`: `finish_reason ==
"length"` with an empty body means the reasoning ate the budget, which is a
reason to climb; a complete but malformed answer is not, and retrying it
larger only costs more. Measured distribution over 323 calls:

```
10000: 270 (83.6%)    20000: 51 (15.8%)    40000: 2 (0.6%)
```

That turns a guessed constant into a measurement of how much reasoning this
task needs. It also exposed that the rising failure rate — 32% climbing to 66%
— was never an endpoint degrading. Tasks ran in framework order, and the
later mdagents traces have longer transcripts and fuller taxonomy blocks, so
the reasoning grew and the fixed budget failed more often.

This is the **same bug** as deepseek-flash's `model_empty_output`, fixed
hours earlier there with `--reasoner-max-tokens 24000` and not carried into
this script. The ladder now lives only in `validate_consistency_levels.py`;
`run_stage1.py` and `panel_vs_humans.py` still use fixed budgets and should be
moved onto it.

### The first cluster to reach the gate

Every cluster in this project's history had stopped before the gate. The
glm Arm B cluster c3 — *Role-Scope Violation: Unsolicited Answer Emission by a
Coordination Agent*, n = 9, all members in the `recruitment` phase — was held
at triage by a defect, then at the gate by two, and one of the two is still
standing.

**Triage: rate stability without code stability is not stability.** Three
re-audits returned rates [0.625, 0.5, 0.5], spread 0.125 and stable, while
naming **2.1.1 twice and 1.2.1 once**. `rate_spread` asked whether the repeats
agreed on how much was absorbed and never whether they agreed on *which* code.
The A/B question is per code, and if the repeats cannot agree on the code, no
single code has been shown to cover the cluster. New `min_code_agreement =
0.67`, which at three repeats fires on any dissent — deliberately, since this
file already argues the A/B call should be routed rather than rounded.
Disagreement at a high absorb rate is read as impurity (split first); at a
moderate rate as not covered (B).

Replayed on the four archived clusters it moved **exactly one**: c3, the only
one whose repeats disagreed. The other three had unanimous code votes and
were untouched.

**G1 frameworks: observed phases now narrow eligibility.** `eligible_frameworks`
fell back to *every* framework when the summariser left `allowed_phases` empty,
which it did for c3 — so a cluster with all nine members in a phase only
MDAgents has was judged as though four frameworks could have shown it. Its own
docstring describes this exact case (a recruiter breaking its output contract,
20 of 22 from MDAgents). Now, with no declared phases, it uses the observed
phase distribution when at least 80% of at least 6 members concentrate there.
c3's eligible frameworks went from four to `['mdagents']` and
`frameworks_required` dropped to 1.

**G1 support: coupled to the clusterer.** `min_support = 12` had no
derivation. It was calibrated by eye against a pool of about 80 and shipped as
a constant, in a module whose docstring argues the threshold must not be a
constant, with its recommended proportional term shipped disabled. And it was
never reconciled with the clusterer: HDBSCAN at `min_cluster_size = 5`
produced 11, 9, 5 and 4 while the gate asked for 12, so the gate measured the
mismatch rather than support.

The requirement is now the largest of three stated terms:

| term | value here | argument |
|---|---|---|
| absolute floor | 6 | guards a degenerate config only |
| share of pool | 4 | `0.05 × 73`; now on by default |
| **above the clusterer's floor** | **10** | `2.0 × min_cluster_size` |

A requirement *at* `min_cluster_size` is satisfied by construction and carries
no information. `2.0` is an argument: a cluster at twice the floor would still
have been found if the corpus were cut in half.

**c3 has support 9 against a requirement of 10. It fails by one.** The
multiple could be set to 1.8 to pass it, and that would be choosing a rule
with the answer in view. The miss by one is the evidence that this rule was
not reverse-engineered, and it is left standing.

G2 is **not evaluable** from the archive: `ablation.json` persists neither
member embeddings nor, for c3, a definition (`null`). A run's artifacts should
be enough to re-run its own gate; these are not. G3 and G4 were not run.

### What turns it

Support has to grow, not be lowered. deepseek-flash Arm B is running on the
same 180 traces; at its measured novel rate the pool should land near 200,
where the requirement stays at 10 and a cluster scaling with the pool would
reach roughly 25. The same mechanism was n = 192 in the lost full-faulty run.

### Two more bugs, found on the way

* **Two-pass merge sizes the score arrays from the blind subset.** The merged
  annotation carries the outcome-blind plan, so `p_verbalised` has fewer
  positions than the scorer writes. It only fires when an endpoint supports
  logprobs **and** verbalised scoring is requested, which runs both scorers
  over the full plan — glm never reached it, deepseek crashed a worker thread
  after seven traces. Fixed by growing the array to cover the plan with
  `None`, which the feature extractor treats as missing. The deeper point: glm
  and deepseek do not traverse the same scoring code path, so a replication
  across annotators is also a replication across branches of the pipeline.
* **A total standing in for a per-unit condition, again.** The supervisor
  called the agent level done at 800 total votes; 170 of 220 slots were at
  k = 5 and 47 had none. Now checks every slot.

Nine instances of the same shape in two days.

Self-check 115 → **124**.

## 17. Stage 0 as mapping files, and what the records say about the declarations (0.7.30)

### The problem

Stage 0 had four hand-written adapters and could ingest nothing else. On a
ColaCare record from the MedAgentAudit release all four raised `KeyError`,
`infer_framework` raised `ValueError`, and `load_all_traces` caught that and
printed `[skip]` -- a file from an unseen framework was dropped and the run
went on smaller. Its design note says applicability is expressed over
structure "so the taxonomy transfers". True of the taxonomy; not of the
adapters.

### What prior work says

| work | format | what it implies here |
|---|---|---|
| OpenTelemetry GenAI semconv | `invoke_agent` / `invoke_workflow` / `chat` spans, parent-child tree, messages as role + parts | the emerging interchange format; anything instrumented with it needs no mapping |
| OpenInference (TRAIL is recorded in it) | OTel-compatible span kinds | TRAIL is a free, real test set for an OTel importer |
| Who&When | one JSON per task, `history` list | schema varies even between its own two subsets |
| TraceElephant | trace metadata + ordered steps, raw I/O | incomplete observation biases attribution |
| Implicit Execution Tracing (2603.17445) | -- | LLMs recovering *who spoke* from plain text: token acc < 0.33, IoU 0.11-0.19, worse with more agents; an HMM reached ~0.6 |

The last row decides the design. A model may propose *which JSON field holds
the speaker*; it must never be asked to *infer the speaker from the prose*.

### The design: layers, cheapest and most reliable first

- **L1 declarative `MappingSpec`** (`mafa/trace_spec.py`, `mafa/specs/*.json`).
  Built. Paths with `[*]` wildcards and `^field` ancestor references, so
  nested per-phase layouts work as well as flat logs.
- **L2 OTel / OpenInference importer.** Designed, not built. There is no real
  OTel trace here to test against, and writing an importer against a
  specification alone is how the previous silent defaults got in. TRAIL is
  the obvious test set.
- **L3 a model proposes a spec from a few sample records**, accepted only if
  `validate_trace` passes with no model in the loop. Not built.
- **L4 a hand-written adapter.** Last resort, as before.

### Result 1: the rewrite changes nothing downstream

The four AEGIS adapters re-expressed as four specs are **byte-identical on all
5,071 traces**: every Step field (id, round, uid, name, role index, role,
phase, raw phase, content, context), capabilities, injections, rounds and
split. `load_all_traces` now goes through the spec layer; preflight gives the
same 5,071 / 440 / 1,112 / 3,519 / 0 duplicates.

### Result 2: an unseen framework is a 40-line JSON file

ColaCare: **2,395 traces, 24 files, detected automatically, zero validation
problems.** Three doctors in `independent_analysis`, a Coordinator in
`synthesis`, the doctors again in `review`, the Coordinator in `decision`.
`review` is a canonical phase no previous adapter ever produced.

Its rounds are read from an **explicit field**: 2,325 single-round, 60
two-round, 10 three-round. So **2.2.1 and 3.2.1 are eligible in ColaCare's 70
multi-round traces**. §8 called them structurally unrecoverable under
`min_frameworks >= 2` because only DyLAN has multiple rounds. That held for
the four-framework corpus, not for the codes. With ColaCare in, a second
framework can show them -- and its rounds do not rest on DyLAN's
re-appearance heuristic, which was the exact caveat §-Stage 0 raised.

### Result 3: capabilities now say where they came from

Every capability is DECLARED (asserted in the spec, with its stated reason),
DERIVED (from an explicit field) or INFERRED (from what the record shows each
agent was given), with the method. Where a spec declares a value, inference
runs anyway and disagreement is reported.

That turned up two things the moment it ran.

**`has_peer_exposure` is declared with opposite values for the same
structure.**

| framework | declared | anyone sees anyone | a non-aggregator sees a peer |
|---|---|---|---|
| clinical_agent | False | 592/594 | 98/594 |
| clinical_agent5 | False | 1346/1346 | 3/1346 |
| dylan | True | 1158/1397 | 1158/1397 |
| **mdagents** | **True** | 1729/1734 | **0/1734** |

MDAgents is declared True because "the Aggregator sees every expert answer".
Not one MDAgents trace has a non-aggregator agent seeing a peer. ClinicalAgent
is declared False because "only the synthesiser does" -- the same structural
fact, opposite value.

The consequence is measurable. `2.2.2` requires peer exposure, so **every
MDAgents expert is asked 2.2.2** although no expert ever sees another (glm
and gpt reported it 9 and 8 times on MDAgents), while **the ClinicalAgent
synthesiser -- the exact counterpart of the MDAgents aggregator -- is never
asked it**. This is the per-trace-versus-per-agent limitation the Stage 0
document named, now quantified and shown to produce inconsistent eligibility
across frameworks.

**DyLAN is declared peer-exposed on all 1,397 traces**, and the 239
single-round ones show none: one round means independent opinions only.

Neither declaration was changed. Changing either alters which codes are
asked and invalidates past per-framework counts, which is a decision, not a
fix. The options:

1. consistent-strict: peer exposure means non-aggregators see each other --
   MDAgents becomes False and loses 2.2.2;
2. consistent-loose: anyone sees anyone -- the Clinical synthesiser gains
   2.2.2;
3. **per-agent capability** -- 2.2.2 eligible for the aggregator/synthesiser
   in both frameworks and not for the experts; 2.2.1 for DyLAN and ColaCare
   agents in round >= 2. Correct, and a change to the Stage 0 -> Stage 1
   interface, since eligibility is currently decided per trace.

### Two silent defaults removed

- an unrecognised file is now an **error**, naming the file and its
  top-level keys, unless `--allow-unknown` is passed;
- an unmapped raw phase label still falls back to `independent_analysis`,
  but is now recorded in `meta["unmapped_phases"]` and fails
  `validate_trace` instead of disappearing.

### Validation contract (`validate_trace`, no model involved)

non-empty steps, unique step ids, one name per uid, no empty content, only
canonical phases, no unmapped phase, a content slice of each probed step
round-trips through `verify_span` to the same step, and no declared
capability contradicted by the record. This is what would make a
model-proposed spec (L3) safe to accept.

Self-check 129 -> **140**.

## 18. Guards before any Stage 0 semantics change (0.7.31)

§17 found `has_peer_exposure` declared on inconsistent grounds, and the
correct fix -- capabilities per agent -- changes slot plans for about 3,900
of 5,071 traces. Before touching that, two things had to exist, because
without them the change would fail silently in two different places.

### Why neither existing check would have fired

- The calibrator and router are bound to the **taxonomy** signature, which
  hashes each code's number, allowed phases, requirements and ground-truth
  flag -- **nothing from Stage 0**. Change a capability, the slot plans and
  feature distribution change, the signature still matches, and the
  calibrator extrapolates silently: the failure the signature exists to
  prevent, arriving from a side it cannot see.
- `load_stage1` rebuilt the slot plan from the current trace and **ignored
  the plan stored in the archive** ("rebuilt from the trace rather than
  trusted from the file"). A different length surfaced only as a violation,
  with `p_positive` copied at its old length -- the `_reseat` misalignment
  again. The same length with a changed meaning loaded with no signal at all.

### Guard 1 -- a Stage 0 signature, per framework

`trace_spec.stage0_signature(spec)` hashes the spec's turn sources, phase
rules, declarations and a `STAGE0_SEMANTICS` version for the inference rules.
Every trace carries it in `meta`. `Pipeline.fit` records the signature each
framework was calibrated under; `Pipeline.route` refuses a trace whose
framework's signature has changed. Per framework, so adding ColaCare does not
invalidate a calibrator fitted on MDAgents; a framework unseen at fit is
reported and scored by the pooled fallback exactly as before, so results do
not change.

### Guard 2 -- archived plans are compared, keys and questions

`load_stage1` now compares the stored plan's slot keys **and question text**
with the rebuilt plan. Default `on_mismatch="raise"`; with `"skip"` every
mismatched trace is collected in `PLAN_MISMATCHES` with its diff (`length`,
`added`, `removed`, `question_changed`, `reordered`) -- the exact list of
traces to re-annotate, while the rest of the archive stays usable.

### Neutral on every existing result

Every archived Stage 1 run reloaded under its own taxonomy:

| archive | loaded | mismatches |
|---|---|---|
| glm Arm A (10 codes) | 180 | 0 |
| glm Arm B (6 codes) | 180 | 0 |
| gpt Arm A (10 codes) | 180 | 0 |
| ds Arm A (10 codes) | 61 | 0 |
| ds Arm B (6 codes, running) | 137 | 0 |
| gpt ab4 (6 codes) | 180 | 0 |

### And both fire where they should

**Declaring ClinicalAgent peer-exposed:** exactly the 90 Clinical traces are
refused, each with `{'length': [16, 17], 'added': ['mode::2.2.2']}`; the 90
dylan and MDAgents traces load unchanged; the route-time check refuses the
changed signature.

**Rewording only 2.2.2's question**, which is what narrowing its scope to the
aggregator would look like: the taxonomy signature is **unchanged**
(`T0:210546d507` before and after), and `load_stage1` refuses exactly the 90
traces where 2.2.2 is eligible, all as `question_changed`.

That second case corrects an explanation given earlier. The taxonomy
signature leaves out question wording deliberately, and the Q&A document
defended that as "a rewording does not change the plan, so forcing a refit is
wasteful". That may hold for the calibrator. It does not hold for archived
annotations: reworded, the model is answering a different question, and a
verdict recorded under the old wording is not an answer to the new one.

### What this buys for the capability fix

With the guards in place the per-agent capability change becomes mechanical:
make it, reload each archive with `on_mismatch="skip"`, and re-annotate only
the traces in `PLAN_MISMATCHES`. The rest of two days of runs stays valid.

Self-check 140 -> **150**.

## 19. Status at session handoff (0.7.31)

Agreed next steps, in order (approved): (1) finish deepseek Arm B under the
current Stage 0 -- 137/180 at handoff, the remaining 43 are mostly MDAgents,
which is where cluster c3 lives; (2) implement route A: `2.2.2` stays one slot
per trace, eligible only if at least one agent is peer-exposed per recorded
visibility, question scoped to those agents; bump `STAGE0_SEMANTICS` to
`stage0-v2`; (3) reload every archive with `on_mismatch="skip"`; (4)
re-annotate the traces in `PLAN_MISMATCHES`, glm arms first.

In flight at handoff, all resumable: `results/runs_snapshot/ds_seed6_180/`
(137/180) and `results/runs_snapshot/consistency/votes_step_glm-5.3-flash.jsonl`
(45 of 206 step slots below k=5). Restore with
`cp -r results/runs_snapshot/. /home/claude/work/runs/`. Both only progress
while polled: the environment reaps background processes during long
non-polling work, and Stage 1 checkpoints per finished trace.

## 20. New session: restore, and route A re-measured before building it (2026-09-22)

### Restore -- three things the handoff's recipe did not cover

- **`openai` is not in a fresh container.** Both keepalives launched, died on
  `ModuleNotFoundError`, and the keepalive reported nothing wrong: it checks
  whether the process is running, not whether it ever started working.
  `pip install -r requirements.txt` first.
- **The AEGIS zips nest one level** (`data/clean/AEGIS-custom-clean-dataset/*.jsonl`);
  the scripts glob `data/**` so they would have worked, but flatten anyway so
  paths match every command in this file. Counts verified: 440 / 1,112 / 3,519.
- **`keepalive_consistency.sh` in the zip still says `--concurrency 14`.** The
  drop to 5 for glm rate limits was made on the live copy and never saved
  back. Fixed in the restored `ka12.sh`; the repo copy should be updated too.

The human gold set: the handoff lists a separate `MedAgentAudit.zip` (9.2)
for `work/maa/`. It was not re-uploaded; `MedAgentAudit-4_23-observation.rar`
is something else (raw per-case MAS outputs, 6 frameworks x 6 datasets x ~100,
1.86 GB, no `human_eval`). `maa2/github_release_files/human_eval` has the
same tree, so `work/maa/MedAgentAudit-9.2/datasets_and_logs` is a symlink to
`maa2` -- **checked, not assumed**: `human_kappa.py` regenerates
`human_gold.json` byte-identical to the snapshot and the same kappa range
0.273-0.744. The `.rar` is left packed (disk: ~9 GB free).

### Self-check: 146, then 150, then 151

The first run said **146 passed, 0 failed** -- four checks missing with no
failure shown. They were the ColaCare checks, inside a bare `if cola:` that
drops them when `maa2` is not unpacked. This is the pattern §17 removed from
`load_all_traces` ("a skipped file shrinks the corpus without saying so"),
still present in the check that guards it. Absence is now a failing check.
With `maa2` unpacked: **151 passed, 0 failed**.

### Route A, measured before any code

Per-agent exposure read off the records (an earlier different agent's output
appears in this agent's recorded input -- the probe `_infer_peer_exposure`
already uses), over all 7,466 traces including ColaCare:

| framework | traces | any agent exposed | who is exposed |
|---|---|---|---|
| mdagents | 1,734 | 1,729 | the decision agent only |
| dylan | 1,397 | 1,158 | discussion agents, rounds >= 2 |
| clinical_agent | 594 | 592 | decision (591), planning (98) |
| clinical_agent5 | 1,346 | 1,346 | decision (1,346), 4 others |
| colacare | 2,395 | 2,395 | review + decision |

DyLAN's 239 unexposed traces are exactly its single-round traces
(1,158 multi-round = 1,158 exposed). Context is present where it matters, so
record-derived eligibility does not quietly zero a framework.

**On the 180-trace set, route A changes the 2.2.2 slot of every trace, not ~143:**

| framework | now | under route A | n |
|---|---|---|---|
| Clinical (both) | no slot | slot added | 90 |
| MDAgents | slot, scope "anywhere" | scope -> the decision agent | 45 |
| DyLAN multi-round | slot, scope "anywhere" | scope -> exposed agents (~1.9 of ~3.9) | 33 |
| DyLAN single-round | slot | slot removed | 12 (handoff guessed ~8) |

The handoff's 143 left out the 33 DyLAN traces whose slot survives but whose
question is re-scoped -- `question_changed` in `load_stage1`, same as
MDAgents. And 2.2.2 is in all three six-code Arm B taxonomies as well as the
ten-code arms, so **every arm re-annotates in full**. Still only 2.2.2's
counts can move; the section 15/16 results stand.

**A conflict the measurement exposes.** Under route A the scoped agent in
MDAgents and ClinicalAgent is the aggregator, whose canonical phase is
`decision`. 2.2.2's `allowed_phases` are `discussion, review, synthesis` --
`decision` is not among them. At `mode_granularity="trace"` eligibility reads
only `requires`, so the plan builds; at `agent` or `agent_step` granularity
2.2.2 would have **zero targets** in both frameworks, and Stage 4's phase
triage would treat a 2.2.2 finding at `decision` as out-of-phase. Either
`decision` joins 2.2.2's allowed phases (a taxonomy change: the taxonomy
signature moves and calibrators refit), or the aggregator's step is mapped to
`synthesis` in those two specs (a Stage 0 change, already covered by the
`stage0-v2` bump). Not decided unilaterally -- listed for the user.

### Sequencing hazard

Route A must not be edited into the live tree while deepseek Arm B runs.
`ka11.sh` restarts `run_stage1.py` from the current code; after a change the
resume would either raise on plan mismatch or -- worse, for the MDAgents
traces not yet started -- annotate them under the new question, giving an arm
half under each Stage 0. Build it in a copy, or after the arm finishes.

### Decision: route A takes option (b)

User approved (b): in the MDAgents and ClinicalAgent specs the aggregator's
step maps to `synthesis` instead of `decision`. Checked before choosing: every
code that allows `decision` (1.1.1, 3.1.1-3.1.3, 3.2.1) also allows
`synthesis`, so the remap removes no code's eligibility and only gives 2.2.2
the targets it should have; the source phase names are `aggregation` and
`final_synthesis`, so `synthesis` is also the more literal mapping. Not yet
built -- deferred until deepseek Arm B finishes (sequencing hazard above).

### Stage 0 on genuinely unseen frameworks: it guessed

Asked whether Stage 0 handles unseen frameworks, tested on the four
MedAgentAudit frameworks with no spec (reconcile, mac, medagent,
healthcareagent; 2,395 traces each). **All four loaded, all labelled
`colacare`.** `detect()` fell back from filename to record shape, and the
ColaCare spec's `match_keys` (`qid`, `case_history`) are the release-wide
envelope: MedAgentAudit normalises every framework to
`case_history.rounds[*].{opinions, synthesis, reviews, decision}`. The
ColaCare paths then extracted plausible steps, wrong in specific ways:

| framework | validate problems | peer exposure | what went wrong |
|---|---|---|---|
| reconcile | 1,200 / 2,395 | 0 / 2,395 | a debate framework; no `llm_input` recorded, so exposure unrecoverable -> 2.2.1/2.2.2 never asked; 3,882 empty steps |
| mac | **0** | 0 / 2,395 | same missing input; passes validation cleanly |
| medagent | **0** | 2,395 | passes cleanly, labelled colacare |
| healthcareagent | 1,200 | 2,324 | `plan` and `inquiry` stages dropped on every trace |

Two of four pass `validate_trace` with zero problems. The guarantee "unknown
is an error, never a skip" held only until the first spec with generic keys
was added -- then unknown became a guess, which is worse than a skip because
it also contaminates the framework it is mistaken for (calibration and
eligibility are per framework). Separately, MedAgentAudit's own `mdagents_*`
files match the AEGIS MDAgents spec by filename and ingest as **zero-step
traces**, flagged by `validate_trace` but not refused by `load_file`.

Fixed (0.7.32): detection is filename-only; a shape resemblance appears in
the error as a named candidate, never acted on; a filename match whose record
lacks the spec's keys is refused as "same name, different format";
`load_file` refuses any zero-step ingest. The four frameworks and
MedAgentAudit-mdagents are now refused, ColaCare loads, the AEGIS regression
still shows 0 of 300 sampled traces differing. Self-check 151 -> **156**.

What this says about the claim: Stage 0 handles an unseen framework **once
someone writes its spec** -- JSON, no code (ColaCare: one file) -- and now
refuses it until then. It does not handle one zero-shot. For these four the
specs are small variants of ColaCare's, but ReConcile and MAC do not record
agent inputs, so their peer exposure cannot be read off the records and would
have to be declared -- exactly the provenance class §17 found unreliable.

### Status

deepseek Arm B 138/180 (resumed from 137); step validation 44 of 206 slots
below k=5. Both confirmed advancing by file mtime.

## 21. L3 in practice, five outside frameworks, and what Stage 3 can drop (2026-09-22)

### L3: propose-and-verify, built and measured

`mafa/stage0_auto.py`. A model proposes a MappingSpec from a path inventory
(paths, presence, text mass, small value vocabularies) plus one truncated
record; six model-free checks accept or return problems, up to 3 rounds.
The checks: text conservation (per path, with duplicate detection), effective
reads (resolved through the real resolver, not the inventory), duplicate
step ingestion, phase-vs-dataflow, capability keys must be real, and
"unobservable is not False".

**ColaCare held out as if unseen, scored against the hand spec on all 2,395
traces: step counts identical, all 19,800 steps identical in content, phase
and round, capabilities identical 2,395/2,395.** Only the aggregator's name
differs (Meta Agent vs Coordinator) and the context string is built
differently (user message only vs whole `llm_input`), which changes no
inferred capability. The four unseen MedAgentAudit frameworks were all
accepted and re-verified with 0 problems on held-out records (records 50-60
of each file, never shown to the model).

**Every check in that list was added because it caught something the previous
set missed**, and two of those were bugs in our own code, not the model's:

* `get()` returned None silently for a relative path containing `[*]`. The
  model's `llm_input.user_message.content[*].text` was correct against the
  data; every step came out with an empty input, peer exposure went False on
  all 2,395 traces, and four checks passed. Inventory-level checks ask whether
  a path exists and is referenced; only resolving through the real code asks
  whether the spec gets it. `[*]` is now expanded (AEGIS regression unchanged,
  0 of 300 sampled traces differ).
* The absence check flagged each `content` candidate separately, although
  content is first-non-empty-wins. A false alarm pushes the model to "fix"
  a correct spec. Judged as a union now.
* Duplicate ingestion was unchecked: the model twice mapped ColaCare's
  `final_decision_log` as a turn as well as the last round's `decision`,
  double-counting the final answer.
* Unknown `declared` keys (`logs_agent_input`, `has_synthesis_phase`) were
  silently dropped by `_assemble`, reasons and all.
* The dataflow check counted an orchestrator's plan as a peer's opinion; 28
  spurious contradictions in healthcareagent, 0 after excluding planning and
  recruitment phases.

With "unobservable is not False" in place, reconcile and mac both stopped
declaring `has_peer_exposure: False` and listed it under `unobservable`.
**The downstream does not yet consume that field** -- `has_peer_exposure`
still lands False in `capabilities`, so 2.2.x is skipped as inapplicable
rather than recorded as unmeasurable. That is the next correctness item after
route A.

### The five frameworks the user asked about

Judged from the code that writes the logs; none of the five repositories ships
a sample run log, so nothing here was ingested from real output.

| framework | what it writes | Stage 0 |
|---|---|---|
| LungNoduleAgent | `<case>_conversation.json`: `conversation[*].responses[*]` with `agent`, `role`, `judgement`, `content`, plus `round_num` and a per-round `summary` | **L1 today.** A spec was written against `stages/doctor.py:_serialize_conversation` and verified on a synthetic record: 0 problems |
| ConSensus (nokia) | plain text `log.txt`, one block per message, `[agent] [SYSTEM\|HUMAN\|AI]` then content, plus a per-agent copy in its own directory | needs a deterministic text->JSON pre-parser (regex on the speaker delimiter, no model). Then L1. `HUMAN` blocks are the recorded input, so peer exposure is recoverable -- better than reconcile/mac |
| CodeSeeker (Code Like Humans) | per-stage HF datasets (`analyse`/`locate`/`verify`/`assign`), each an `output` column; no per-case trace, no speaker field, prompts only in the request cache | needs a join across four stage files keyed by case before any spec. Sequential pipeline: no rounds, no peer exposure -> 2.2.x structurally inapplicable, not merely unobserved |
| OEMA | JSONL per query from `AskGPT_*.py`, keyed by `idx` | same shape of problem: three agents are three scripts over datasets, not turns in one record. Token-level NER, so much of the taxonomy does not apply |
| TriageAgent | **no code at all** -- the repository has prompts, datasets and assets only | nothing to ingest; not a Stage 0 question until someone runs it |

So: one of five works today, one needs a text pre-parser, two need a
cross-file join and would exercise a small part of the taxonomy, one has no
runnable code. The LungNoduleAgent test also exposed a silent default:
`{"field": "^round_num"}` on a turn source whose own object holds `round_num`
searches ancestors only, finds nothing, and falls back to round 1 without a
word. Phase mapping records `was_mapped`; round does not. Worth fixing.

### Stage 3, three questions

Answers drafted this session, **none implemented, none measured**:

1. *Training-free routing.* Distribution-free coverage needs labelled
   exchangeable calibration data; nothing removes that. What can be removed is
   the separate labelled calibration set: `ACIBackend` already updates
   alpha_t from feedback, and the VERIFY route is that feedback, so the
   humans who work the queue calibrate the router. `VennAbersRoutingBackend`
   needs no calibration set at all but its guarantee is about probabilities,
   not sets.
2. *Progressive disclosure on AUTO.* Tiered display, ordered by risk, with
   catch trials seeded into the stream so attentiveness is measurable rather
   than assumed.
3. *Dropping REVIEW.* Dropping is informative censoring, not missing at
   random: REVIEW is selected by model uncertainty, which is where novel modes
   live -- Stage 4's input. Defensible only with Manski bounds whose width is
   the REVIEW share, or a reviewed random subsample with IPW.

**The measurement that decides #3 was attempted and did not run:**
`fit_and_route.py` on the archived glm arm with `examples/pseudo_anchors.jsonl`
gives "745 anchors had no matching annotated slot" -- the pseudo-anchor pool
is built from the injected corpus and the 180-trace arms are a different
slice. Aligning them is the next step; the route shares are unknown until
then.

## 22. User-set thresholds as a fourth routing backend (0.7.34, 2026-09-22)

### What Stage 3 actually does

It does not choose a threshold. `alpha` is chosen; the calibration scores give
a quantile; the quantile gives a prediction SET per slot; and the set's size
is the route (1 -> AUTO, 2..k -> VERIFY, 0 -> NOVEL, >k -> REVIEW). The
thresholds exist but are outputs. So "can the user set the thresholds" is a
real request, not a rephrasing of "can the user set alpha": it asks for a
different kind of knob, one stated in the units a site actually has -- a
reviewer budget, or an error ceiling on what may enter the corpus unreviewed.

### ThresholdBackend

A fourth `RoutingBackend` (`ROUTERS["threshold"]`, `--router-backend
threshold`). Routing is by user bands over p, globally or per Mondrian group;
`Band(lo, hi, decision)` with decision in {one, both, none} so a user can
express more than two cuts, including a NOVEL band. **A gap in the bands
raises** rather than defaulting to AUTO.

It carries no guarantee and does not pretend to: `fit` measures the user's
rule instead of certifying it -- auto share, auto error, and a
Clopper-Pearson upper bound per group, with thin groups named. `report()`
states `guarantee: none by construction`.

`calibrate_bands(...)` is the other direction, and the one worth
recommending: the user gives an ERROR BUDGET, and it returns the most
permissive symmetric cuts whose upper 95% bound on auto-route error meets it,
per group. One monotone family, one bound, so this is the single-parameter
case of Learn-then-Test and needs no multiplicity correction. **A group where
no threshold meets the budget gets `None`, not the strictest threshold** --
the refusal is the answer.

### Measured on the 610 labelled slots (pseudo-anchor pool x `stage1_with_context_73`)

Raw Stage-1 `p_yes`, NOT Stage-2 calibrated -- these are the scores whose
single-sample ECE was 0.23-0.32 in section 15, so read the mechanism, not the
final numbers.

| rule | auto share | auto error | upper 95% |
|---|---|---|---|
| thresholds 0.05 / 0.95 | 94% | 0.128 | 0.153 |
| thresholds 0.1 / 0.9 | 95% | 0.132 | 0.158 |
| thresholds 0.2 / 0.8 | 98% | 0.138 | 0.163 |

Three plausible hand-set rules differ by 4 points of auto share and by 1 point
of error: the knob a user would reach for barely moves the thing they care
about, because the scores pile up at 0 and 1. Moving the cut from 0.9 to 0.95
is not a 5% tightening of anything.

From the other direction, at a 10% error budget: pooled t_auto = 1.0,
t_zero = 0.0 -- only slots at the numerical extremes may auto-route -- for a
39% auto share (16 errors in 239, upper bound 0.0999). At 5% and at 2%, **no
threshold qualifies at all**, pooled or per framework, and dylan already fails
at 10%. That is the useful output: the budget is unreachable with these
scores, said out loud, instead of a strict-looking threshold that quietly
misses it.

### What this changes about the recommendation

A user-set threshold is now a first-class, comparable option rather than
something to be argued out of. But on this data the honest advice is: set the
error budget, not the cut. And since the same measurement says 5% is
unreachable on raw scores, the next question it raises is whether Stage-2
calibrated probabilities move it -- that is a one-command experiment once an
arm is calibrated, and it has not been run.

Self-check 156 -> **162**, including: a gap in the bands raises; 0 errors in 7
points does not read as error 0; an unmeetable budget returns no threshold.

## 23. The REVIEW share, measured (2026-09-22)

Section 21 left "can REVIEW be dropped" undecided because `fit_and_route.py`
found no anchors matching the 180-trace arms. The pool matches
`examples/stage1_with_context_73.jsonl` instead (85 of 85 trace ids), which
was found by overlapping trace ids across every archive rather than guessing.

At alpha = 0.10, supervised head on the pseudo-anchor pool (ECE 0.046,
accuracy 0.887):

| route | traces | share |
|---|---|---|
| AUTO | 6 | 7.1% |
| VERIFY | 51 | 60.0% |
| REVIEW | 28 | **32.9%** |

202 human questions over 85 traces.

**So REVIEW cannot be dropped.** Manski bounds on any rate estimated after
dropping it are as wide as the dropped share: a 33-point interval states
nothing. The reviewed-subsample-with-IPW route stays available, but at this
share it is not a saving -- it is most of the work. Two caveats before this
number is used in the paper: 85 traces from the injected/simulated slice, and
alpha = 0.10 was not varied. The AUTO share being 7% also reframes the
progressive-disclosure design of section 21: on this data the auto route is
the small one, so a human glance over all of it is cheap, and the expensive
question is VERIFY's 202 questions, not AUTO's 6 traces.

Selective error from the same fit, for the record: 3.7% at 50% coverage,
5.0% at 70%, 8.9% at 90%, 11.3% at 100%.

## 24. REVIEW is a step-level problem, and alpha does not buy automation (0.7.35)

### Why the 28 REVIEW traces were REVIEW

Every one of them. 27 for `step:set_size` alone, 1 with a question count on
top. Not one was sent to full re-read because its mode-level or agent-level
verdicts were ambiguous. And inside those 28, the mode level was **fully
settled** (every set a singleton) in 15, the agent level in 6.

So the section-23 question was posed wrongly. "Drop REVIEW or read all of
it" is a choice between discarding a third of the corpus and paying for it
in full, and neither is necessary: what cannot be resolved is the earliest
fault STEP, while the mode-level labels on the same trace are already
certified. Folding a trace to its worst level was a reporting decision, never
part of the conformal claim -- coverage is a per-slot property.

`Pipeline.export_level_buckets` routes each level separately, writing
`level_*.jsonl` alongside the existing files, with `level` on every row (a
trace can now be in the corpus and the queue at once). On the same 85 traces
at alpha = 0.10:

| | trace-level fold | per level |
|---|---|---|
| corpus | 6 traces | mode 63, agent 33, step 12 |
| human_queue | 51 | mode 22, agent 52, step 45 |
| full re-read | 28 | step 28 only |

**63 of 85 mode-level annotations are admissible, against 6 under the fold.**
The full re-read is still 28, but it is now 28 step-level questions rather
than 28 whole traces.

### The alpha sweep: alpha trades REVIEW against NOVEL, not against human cost

| alpha | AUTO | VERIFY | REVIEW | NOVEL |
|---|---|---|---|---|
| 0.02 | 0 | 0 | 100% | 0 |
| 0.05 | 0 | 10.6% | 89.4% | 0 |
| 0.10 | 7.1% | 60.0% | 32.9% | 0 |
| 0.20 | 10.6% | 36.5% | 8.2% | 44.7% |
| 0.30 | 4.7% | 17.6% | 0 | 77.6% |

**AUTO never exceeds 11% at any alpha**, and past 0.2 the sets start coming
back empty, so loosening alpha converts REVIEW into NOVEL -- a flooded
residual pool and false novelty for Stage 4 -- rather than into automation.
Anyone reading alpha as a "how much do I automate" dial is reading it wrong;
on this data it is a "how much do I send to Stage 4 as unexplained" dial.
Note AUTO is not monotone in alpha (7.1 -> 10.6 -> 4.7): at large alpha the
singleton that would have been AUTO becomes the empty set.

### Recommended scope for the route A re-annotation (revised)

Section 21 costed route A as a full re-annotation of 180 traces per arm.
That was costed as re-running the trace. Only the 2.2.2 slot changes, and
per-slot voting already exists (sections 15-16), so the work is a targeted
slot-level pass -- roughly a twentieth of an arm -- which makes correcting
**all four arms** affordable instead of correcting glm's and labelling the
rest "pre-fix".

One methodological risk first: the archived verdicts came from a joint pass
that produced every slot in one call; asking 2.2.2 alone is a different
conditioning. Control experiment before committing: re-ask 2.2.2 in isolation
on traces whose slot does NOT change (glm arm, multi-round DyLAN) and measure
agreement with the archive. High agreement -> patch all four arms; low ->
fall back to full re-annotation of the glm arms only.

Self-check 162 -> **164**.

## 25. Where the three goals actually stand (0.7.36)

### Goal 1 -- annotation against the MedAgentAudit taxonomy: this is what runs

Every experiment in this file annotates against `taxonomy.SEED_MODES`, the
ten MedAgentAudit codes (`provenance: "T0:MedAgentAudit"`), re-expressed with
structural applicability. MAST is in `mafa/mast.py` as GROUND TRUTH only, and
`mast.py` says why it must never reach the annotator: the simulated split's
faults were injected from those definitions, so showing them to the annotator
and measuring recall would be circular. The AEGIS corpora are the substrate;
the label space being annotated is MedAgentAudit's.

So goal 1 is the built one, and the clinician-gold calibration of section 15
(394 MedAgentAudit items) is its evidence.

### Goal 2 -- annotation against MAST: expressible, not built

`Taxonomy.load()` reads a taxonomy from JSON, and `FailureMode.provenance`
already anticipates `"MAST = general seed"`. What does not exist is the MAST
seed file: MAST's definitions are prose in `mast.py` with no
`allowed_phases`, no `requires`, no per-code questions, so Stage 1 cannot
build a slot plan from them. Writing it is the work, and two things make it
more than a transcription:

* **Applicability.** The structural gating that sections 8 and 17 built for
  the MedAgentAudit codes has to be decided per MAST code. Some are
  single-agent (FM-1.1 task deviation) and need no capability; others
  (FM-2.x inter-agent) need peer exposure or rounds, which is exactly where
  `unobservable` still resolves to False today.
* **The simulated corpus is unusable for it.** Annotating MAST-labelled
  traces with a MAST seed is circular. A MAST arm has to run on the real
  AEGIS splits (clean 440, real-faults 1,112) or on MedAgentAudit's corpora,
  where no MAST ground truth exists -- so it is validated against human
  labels or against agreement, not against the injection log.

### Goal 3 -- Stage 4 off by default: now a switch, was an accident

Before this version Stage 4 was off only because `Pipeline` never called it;
`taxonomy_evolution` lived behind two scripts. Nothing was enabled or
disabled, no output recorded which, and the first caller to wire evolution
into the pipeline would have turned it on silently.

Now: `EVOLUTION_DEFAULT = False`, `PipelineConfig.enable_evolution = False`,
`evolution_enabled(cfg)` as the single source of truth, and
`require_evolution(cfg)` raising `EvolutionDisabled` at the entry of both
`run_evolution.py` and `ablate_seed.py`, each with `--enable-evolution`.
A config object lacking the field reads as off. The reason is in the error
text: growing the taxonomy changes the label space and voids the coverage
guarantee of anything calibrated before it.

Self-check 164 -> **169**, including that the default is asserted rather
than assumed and that both scripts are gated, not just the library.

### What is running right now

* deepseek Arm B: 154/180, the six-code ablation, still the only blocking task.
* step-level consistency validation: STOPPED. glm returns 429 in 0.4 s
  (account-level), so the workers only burned backoff. 44 of 206 slots short.
* Everything else this session was offline analysis on archived runs.

## Changelog

- **0.7.32** -- Session restore. Self-check: the ColaCare checks sat in a bare
  `if cola:` and vanished without a failure when the corpus was absent
  (146/150 shown as all passing); absence is now a failing check (151).
  Route A re-measured on records before building: all 180 traces per arm
  change their 2.2.2 slot (not ~143), and the scoped aggregator's phase
  `decision` lies outside 2.2.2's `allowed_phases`; option (b) chosen.
  Stage 0 `detect()` no longer falls back to record shape: it had ingested
  four unseen MedAgentAudit frameworks (9,580 traces) as ColaCare. Zero-step
  ingests refused. Self-check -> 156.
- **0.7.33** -- `mafa/stage0_auto.py`: propose-and-verify Stage 0 (L3).
  Six model-free checks; ColaCare reproduced semantically on all 2,395
  traces from a model-proposed spec. `get()` now expands `[*]` in relative
  paths (it returned None silently). Five outside frameworks assessed.
- **0.7.34** -- `ThresholdBackend`: user-set routing bands per group, measured
  rather than certified, plus `calibrate_bands` which turns an error budget
  into thresholds and refuses when none meets it. Self-check -> 162.
- **0.7.35** -- `export_level_buckets`: per-level routing. All 28 REVIEW
  traces were REVIEW for the step level alone; 63 of 85 mode-level
  annotations are admissible against 6 under the trace-level fold. Alpha
  sweep: AUTO <= 11% at every alpha; loosening alpha buys NOVEL, not
  automation. Self-check -> 164.
- **0.7.36** -- Self-evolution is an explicit opt-in: `EVOLUTION_DEFAULT`,
  `PipelineConfig.enable_evolution`, `require_evolution` gating both Stage 4
  scripts behind `--enable-evolution`. Self-check -> 169.

- **0.7.31** -- Guards before any Stage 0 change. (i) Per-framework
  `stage0_signature`, stamped on every trace, recorded at fit and checked at
  route: the taxonomy signature hashes nothing from Stage 0, so a capability
  change would have passed it. (ii) `load_stage1` compares the archived plan's
  slot keys and question text with the rebuilt plan -- it used to ignore the
  stored plan -- raising by default or collecting `PLAN_MISMATCHES` with a
  diff under `on_mismatch="skip"`. Neutral on all six archived runs (0
  mismatches). Declaring ClinicalAgent peer-exposed is refused on exactly its
  90 traces; rewording only 2.2.2's question leaves the taxonomy signature
  unchanged and is refused on exactly the 90 traces where 2.2.2 applies.
  Corrects an earlier defence of leaving question wording out of the taxonomy
  signature. Self-check 140 -> 150.
- **0.7.30** -- Stage 0 as declarative mapping files. New
  `mafa/trace_spec.py` and `mafa/specs/*.json`; the four AEGIS adapters as
  four specs are byte-identical on all 5,071 traces, and `load_all_traces`
  now goes through them. A fifth spec ingests ColaCare -- 2,395 traces the
  old Stage 0 skipped -- with zero validation problems; its explicit rounds
  (70 multi-round traces) make 2.2.1/3.2.1 eligible in a second framework,
  so "structurally unrecoverable" was a property of the four-framework
  corpus. Every capability carries provenance (declared/derived/inferred),
  which immediately showed `has_peer_exposure` declared True for MDAgents
  (0/1734 traces with a non-aggregator seeing a peer) and False for
  ClinicalAgent on the same structural grounds, so MDAgents experts are asked
  2.2.2 and the ClinicalAgent synthesiser never is. Declarations left
  unchanged pending a decision. Unknown files are an error, not `[skip]`;
  unmapped phases are recorded. OTel importer and model-proposed specs
  designed, not built. Self-check 129 -> 140.
- **0.7.29** — Agent-level consistency validated on 220 injected-ground-truth
  slots, all at k=5: ECE 0.3227 -> 0.1292, but twice the mode level and not
  poolable (0.098 on clinical_agent to 0.304 on dylan, where peer exposure
  leaves no upstream clean agent and the injection log stops being a clean
  agent-level label). Propagation split reproduced (upstream 0.947 vs
  downstream 0.651). A token ladder (10k/20k/40k, escalate on truncation only)
  replaces fixed budgets: 0% failures over 323 calls where fixed 3000/16000/
  32000 failed 66/40/35%. Triage gains `min_code_agreement` -- rate stability
  without code stability is not stability -- which moves exactly one of four
  archived clusters. `eligible_frameworks` falls back to observed phases.
  `min_support` coupled to `2 x min_cluster_size` with a 5% pool share on by
  default and the unexplained 12 dropped to a floor of 6. The first candidate
  code in the project's history reaches the gate and fails G1 support by one
  (9 vs 10); left standing rather than tuned. Two more bugs: the two-pass
  merge's score arrays sized from the blind subset (crashed deepseek only), and
  a per-slot condition checked by total. New `scripts/run_gate.py`,
  `scripts/validate_consistency_levels.py`. Self-check 115 -> 124.
- **0.7.28** — Consistency calibration validated on real slots with human
  labels: glm-5.3-flash, k=5 at temperature 1.0, 394 of MedAgentAudit's 400
  clinician-judged instances. **ECE 0.2298 -> 0.0604** against the majority
  gold, Brier 0.2298 -> 0.1682, accuracy unchanged; saturation 100% -> 0% at
  the extremes, 2 -> 10 distinct values. Unanimity routes 80.7% at 18.2%
  error. §14's simulated claim that consistency "does not come close to the
  supervised head" was too pessimistic (0.060 vs the head's 0.046) and is
  corrected in place; the self-check assertion is rescoped to the fixture.
  The finding is per code: self-agreement spans 0.885-0.955 while accuracy
  spans 0.650-0.895, correlation **-0.118**, so self-agreement does not rank
  the codes -- `1.1.1` has agreement 0.942 and accuracy 0.650. Pooled ECE may
  not be reported alone and the self-check enforces it. DACA's reference
  ranked by measured ECE against the clinicians: glm-5.3-flash best of the
  four. New `scripts/validate_consistency.py`; data in
  `results/consistency_validation/`. Self-check 105 -> 115.
- **0.7.27** — Black-box calibration: `mafa/blackbox_calibration.py` with
  `sample_consistency`, `daca` and `consistency_distill`, the first backends
  that need nothing but chat API output and the only ones that can produce a
  confidence for a NEWLY ADDED code rather than abstaining. Sample consistency
  fixes the saturation the sampler has complained about since 0.7.x: a
  one-sided logprob put 100% of slots at the extremes with 2 distinct values,
  a 10-sample agreement rate puts 0% there with 10, and a Laplace
  pseudo-count keeps a unanimous vote off 1.0. Measured against the true
  label on a fixture where samples cluster on the annotator's belief: raw
  0.155 -> consistency 0.129 -> distillation 0.115 -> DACA 0.096, against the
  supervised head's 0.046 — the residual is the self-agreement/correctness
  gap §10 measured at +0.35 correlation across codes, and the self-check
  fails if it closes. DACA's premise (a better-calibrated base model) does not
  transfer, so `rank_references_by_gold()` picks the reference by measured ECE
  against the 400 clinician-labelled instances and the backend reports
  UNVERIFIED until that is done. BaseCal, ATS, CFT/RCFT and the bilevel method
  assessed and rejected — hidden states or weights. Self-check 84 -> 105.
- **0.7.26** — Unsupervised calibration, so a turn of the loop costs no
  annotation. §12's backends were both supervised and the claim that ACI's
  feedback is free was too comfortable: verdicts arrive only on ROUTED slots,
  and a newly added code gets none at all. New `mafa/label_free_calibration.py`
  with `LaSCalBackend` (registered as `lascal`): BBSE weights estimated from
  unlabelled target slots, prior correction on the odds, label-free CE
  estimate as the monitor, and **abstention** on codes absent from the source
  taxonomy, which label shift cannot speak to. Temperature scaling was tried
  and is off by default -- it pinned to the grid edge and made the true ECE
  worse than doing nothing when nothing had shifted, because a temperature
  cannot move a prior. BBSE refuses when `|det(C)| < 0.02`; the first floor
  (1e-3) was below the sampling noise of a coin-flip classifier. BaseCal
  assessed and rejected: no base checkpoint and no hidden states through a
  chat API. New `ADAPTS_UNSUPERVISED` policy tier, ranked on cost not on
  strength of guarantee. Self-check 75 -> 84.
- **0.7.25** — Stage 2 and Stage 3 are pluggable, so "the loop cannot turn a
  second time" becomes "turning it costs this specific guarantee". New
  `mafa/calibration_backends.py` (`logistic`, `venn_abers`, `logistic_va`) and
  `mafa/routing_backends.py` (`split`, `aci`, `venn_abers`), joined by one
  `Belief` type that carries a point or an interval. ACI adapts alpha per
  Mondrian group from the human verdicts the VERIFY/REVIEW queue already
  produces — long-run coverage under arbitrary shift, no exchangeability.
  Venn-Abers emits an interval whose width replaces the empty set as the NOVEL
  channel, auto-thresholded at fit time because the first fixed value (0.4) sat
  above the widest interval observed (0.303) and would have disabled the
  channel silently. `check_compatible()` rejects point-estimate calibrators
  feeding interval routers; `describe_pairing()` returns the claim, taking the
  weaker of the two policies — which shows that ACI alone does NOT make the
  loop turnable, since the logistic calibrator raises before the router sees
  anything. Defaults unchanged (`logistic` + `split`). Self-check 52 -> 75.
  Details and the honest limits in §12.
- **0.7.24** — Two silent defaults, and a replication that corrects §8.
  (i) `run_stage1.py` attached no images when `--images` was omitted and said
  nothing about it, so four arms were annotated text-only on a corpus with 57
  image references. A corpus with image references and no `--images` now exits
  and names both ways forward; `--no-images` is the explicit opt-out and
  prints what was withheld. (ii) A progress counter used `wc -l` on
  stage1.jsonl, which grows on failure and again on the retry that fixes it,
  so 194 lines read as 180 traces when 163 were annotated and 17 were still
  failing — an incomplete control was declared finished and the next arm
  started against it. Counted by annotated trace_id now. New `silent defaults`
  self-check group; suite 49 -> 52. (iii) Arm A repeated on the same 180
  traces with gpt-5.6-sol-disc (180) and deepseek-flash (61). Frequency does
  not replicate — `2.2.1` 12 vs 70, novel rate 0.21 vs 2.60 per trace — and
  eligibility replicates exactly: zero `2.2.1`/`3.2.1` across 135 non-dylan
  traces from both complete arms, with opposite orderings inside dylan. §8 is
  rewritten: the base-rate table carries three columns, "the corpus exhibits
  all four, emphatically" is withdrawn, and the 17% ceiling is qualified as
  one annotator's number with the mechanism, not the figure, as the claim.
- **0.7.23** — `scripts/panel_vs_humans.py`: a four-family LLM panel over
  MedAgentAudit's audit human-eval set (400 instances, 10 codes, 3 of 6
  clinicians each), plus the human-agreement baseline recomputed from the raw
  annotator files rather than quoted. Results in §10. The short version:
  AdaMAST's published gate (mean pairwise kappa >= 0.75) rejects all ten
  MedAgentAudit codes, which clinicians apply at mean pairwise 0.635 and no
  code of which reaches 0.75; and panel self-agreement correlates with panel
  validity at only +0.35 across the ten codes, so an agreement gate is not a
  proxy for the property it is used to certify. The predicted ~2x
  self-vs-validity inflation did **not** reproduce in aggregate (0.95x) but is
  strong and code-specific (1.2.1 at 2.03x, 2.1.1 inverted at 0.43x).
- **0.7.22** — `ResidualFilter.min_name_words` counted whitespace words, so a
  snake_case proposal was one word and was discarded as "a label, not a
  description". Words are now counted across `[\s_\-:./]` and camelCase
  boundaries. The cost of the old rule was annotator-dependent and was
  misjudged from a single sample: 3 of 460 proposals on gpt-5.6-sol-disc
  (0.7%), **52 of 74 on glm-5.3-flash (70%)**, collapsing that run's residual
  pool from 73 to 21 and guaranteeing Stage 4 found nothing. gpt runs are
  unaffected (ab4 pool 525 before and after). Also `--trace-ids`, which pins a
  run to exactly the trace set of another and exits rather than proceeding
  partially paired -- a control run must not use `--limit`, which takes the
  first n per file. Results of the first paired control run are in §8.
- **0.7.21** — The held-out-recovery metric was broken three ways and is
  repaired rather than dropped. (i) `ablate_seed.py` now computes structural
  eligibility per held-out code from the capability vectors and reports
  recovery against the codes that could reach the gate, not against every code
  removed: on this corpus `2.2.1` and `3.2.1` both require `has_multi_round`,
  which only dylan has, so the achievable maximum in every run up to 0.7.20 was
  2/4 and the reported 0/4 used a denominator of 4. This is the 0.7.10 lesson
  (count eligible frameworks, not corpus frameworks) applied where it had never
  been applied. (ii) Recovery is scored over **every cluster that reached
  triage B**, each row carrying its own `admitted` flag and gate summary;
  scoring the admitted only had put the gate in the numerator, so a
  rediscovery that failed G1 was indistinguishable from a discovery failure —
  2 of 5 B-clusters in run_ab3 and 1 of 2 in run_ab4 were never tested.
  (iii) New `--full-taxonomy-stage1` takes a control annotation of the same
  traces under the full taxonomy and reports, per held-out code, the base rate
  and what became of each instance under the reduced seed (relabelled under a
  kept code / proposed as novel / not flagged). Without it the run says
  plainly that precondition 3 is unverified. It was unverified everywhere:
  every Stage-1 file in `results/` is a six-code run, and `faulty_180.jsonl` is
  byte-identical to `run_ab4_faulty_n180/stage1.jsonl`. `ablation.json` gains
  `n_triage_b`, `n_admitted`, `scorable_held_out`, `unrecoverable_held_out`,
  `held_out_eligibility`, `recovered_and_admitted` and `base_rate`. Self-check
  32 -> 41. Also recorded: §8 (the archive audit and the 0/4 root cause) and
  §9 (AdaMAST read in full).
- **0.7.20** — Uncertainty estimation is pluggable: `mafa/estimators.py` with
  `logprob`, `verbalised`, `steerconf` (NeurIPS 2025) and `vpd`, chosen by
  `--scorer-mode`. Batched by steering level rather than per slot, so
  SteerConf is 10 calls per trace and not 80; VPD is 2. VPD merges a trace's
  `mode` slots into one distribution question and keeps the `none` mass in
  `vpd_detail` — it is the taxonomy-doesn't-cover-this signal Stage 4 looks
  for. `invert_softmax` is the identity at T=1. DiNCo deliberately left out:
  it needs mutually exclusive distractors, which a binary verdict does not
  have; it belongs on the taxonomy-evolution side. New `ChatCompatClient`
  learns each endpoint's reasoning parameter, schema mode and `top_logprobs`
  ceiling at runtime — qwen and glm were both wrongly declared unusable by me
  before reading their documentation. `make_pseudo_anchors.py` added
  (missing entirely), now with step-level anchors, which took routing from
  100% REVIEW to 84.9% REVIEW + 15.1% VERIFY. Four silent bugs fixed in my own
  estimator port, including `kappa_ans` reporting a 3:2 split as p=0.73.
  Self-check 17 -> 32.
- **0.7.19** — Image ablation: the annotator's verdicts barely move when it can
  see the images (4 flips in ~168 mode verdicts across 28 paired traces; 1.2.1
  moves once in 24), which refutes the hypothesis that 1.2.1 is unstable
  because modality cannot be judged from text. It is a general
  answers-the-wrong-question code under a modality name. New `mafa/images.py`
  (`ImageStore`, multi-image, no default cap — 102 traces carry 5-6 images —
  and `blocks()` returns `(blocks, dropped)` so nothing is truncated quietly);
  `AnthropicCompatClient` for Stage 1 over the Messages API, needed because
  aiberm returns 500 on the Responses API; `run_stage1.py` gains `--images`,
  `--annotator-backend` and `--annotator-key-env`; each record now stores
  `n_images_sent` and `images_dropped`. Fixed at the cause: sharding renumbered
  every `trace_id` (line number is part of the id), which had unpaired 51
  traces in fold-back, raised a `KeyError` in the image comparison, and
  silently produced a false "0 flips" report. `shard_preserving_ids` plus a
  self-check against the real corpus. Self-check now 17 checks.
- **0.7.18** — Fold-back run: three discovered codes folded into the taxonomy
  and re-annotated on 137 paired clean traces. Uptake 73/57/46 against 48 for
  all six seed codes; `1.2.1` drops 23→8 while `2.1.1` and `2.2.2` hold, so the
  takeover is targeted; residue 34→26; violations unchanged. `scripts/
  fold_back.py` added (`build` and `compare`). Three faults fixed on the way:
  `fold_back.py` read verdicts off `slot.code` instead of `ann.verdicts` and
  reported `uptake: 0`, and the check written to confirm that read a
  non-existent `slot.codes` and agreed; displacement now compares per-code
  positive counts rather than slot keys, which are structurally never shared.
  Sharding with `awk 'NR%3==i'` rewrote the line number embedded in every
  `trace_id`, silently unpairing 51 traces. `pipeline.annotate` records failed
  traces with an `error_class` rather than printing and skipping;
  `load_stage1` skips them and lets a retry overwrite; `retry_failed=True` by
  default. `run_stage1.py` gains `--reasoner-max-tokens` and
  `--reasoner-effort`. Documented: deepseek-flash proposes ~9x fewer novel
  modes than gpt-5.6-sol-disc on the same traces, so no residual or cluster
  count is comparable across the two results directories.
- **0.7.17** — First codes through the admission gates: 3 on 180 clean traces,
  1 on 180 faulty traces, and the project's first Stage-4 result on traces that
  ended wrong. Held-out recovery 0/4 in both, and demoted from pass/fail
  criterion to diagnostic — it measures nothing available in deployment and is
  confounded by the annotator having read the source taxonomies. Replaced by
  three checks that need no answer key: `scripts/cross_sample_validate.py`
  (recurrence across disjoint samples; reports cluster recurrence and verdict
  agreement separately, 8/10 and 4/8 here), `scripts/export_for_human_read.py`
  (candidates with transcript quotes, membership rebuilt from cached
  embeddings), and a fold-back run, not yet built. Added
  `scripts/keepalive.sh` — long runs are reaped by the environment, and with
  the judge cache a restart replays rather than re-pays.
- **0.7.16** — `fit_and_route.py` gains `--anchor-pool` for pools written by
  `AnchorPool.save`; `--annotated` (per-annotator task files) now fails
  immediately and names the other flag instead of yielding zero anchors and
  dying four steps later. Stages 2 and 3 reproduce
  `examples/fit_report_pseudo_anchors.json` exactly, so all five stages now run
  end to end. The re-audit can filter candidate codes by `allowed_phases` and
  `requires` (`TriageConfig.reaudit_respects_structure`, and
  `--no-structural-reaudit` to disable); `ablation.json` now records
  `triage_reason`, `rates`, `rate_spread`, `code_votes` and the framework and
  phase mix per cluster. New `scripts/measure_reaudit_filter.py` runs the
  re-audit alone under three filter strengths on fixed groups.
- **0.7.15** — `resplit` returned only the members HDBSCAN assigned to a part
  and silently discarded the rest: 17 of 37 items on the first real run. It now
  returns `(parts, remainder)` and `triage_clusters` routes the remainder as
  `AB?` with a reason. Self-check gains member conservation and a
  routed-remainder check (the latter initially passed vacuously; fixture fixed).
  Removed a duplicate `import re`. Diagnosis recorded, not yet fixed: the
  Stage-4 re-audit offers every code regardless of `allowed_phases` and
  `requires`, so 1.2.1 absorbed a 22-item cluster that was 20/22 at
  `recruitment` — a phase 1.2.1 forbids and Stage 1 would have refused.
- **0.7.14** — `resplit` was unreachable: both driver scripts called
  `triage_clusters` without `embed=`, and the branch is guarded on it, so the
  feature shipped switched on and did nothing. Both call sites fixed; a skipped
  resplit now prints and records its reason instead of passing silently;
  `resplit`'s `HDBSCAN` sets `copy=True` to match `cluster_residuals`. Removed
  two dead duplicate copies of the resplit knobs from `TriageConfig` (one
  declaring the same field twice) and a dead `split_cluster()`, all artefacts
  of the 0.7.13 patch being applied more than once — as were the duplicated
  changelog entries below. Added `scripts/selfcheck_offline.py`: wiring
  invariants with no data, no API calls and a negative control.
- **0.7.13** — `resplit`: a unanimous refusal to name a cluster is treated as a
  report that the cluster is mixed, and its members are re-clustered rather
  than the whole pool being loosened. `summarise_repeats` so one naming call is
  no longer a single point of failure. Added `HANDOFF.md`.
- **0.7.12** — status ribbon on `figures/dataflow.html` separating what has
  been measured from what is waiting on people; §6g summarising the findings by
  how much weight each will bear.
- **0.7.11** — `TriageConfig.repeats` and `max_rate_spread`: the A/B re-audit
  runs several times and an unstable verdict goes to a human whatever its mean,
  which is what the flip from B to A on one mechanism would have needed.
- **0.7.10** — G1 counts frameworks against the ones whose structure could
  exhibit the failure, not against the corpus; a recruitment-stage failure in
  the only framework that recruits is no longer unadmittable by construction.
  Added `min_framework_fraction` and `--ignore-framework-eligibility`.
- **0.7.9** — ablation re-run under the new instruction: residue per trace up
  3.7x, clusters cleaner, and for the first time clusters spanning two
  frameworks, which is what gate G1 requires. Recorded that the A/B verdict
  flipped from B to A on the same mechanism between runs, and that the
  ambiguous band cannot catch that.
- **0.7.8** — the `novel_modes` instruction rewritten as its own section
  arguing from asymmetric cost; paired on 36 simulated traces it raises recall
  0.078 and leaves upstream specificity unchanged, the first prompt change in
  six to improve discrimination rather than move the threshold. Added
  `ResidualFilter` at the pool entrance, which on current data rejects nothing
  and is kept as insurance rather than as a fix.
- **0.7.7** — `TriageConfig.incoherent` (route / drop / ignore), replacing a
  silent drop that had swallowed a correct cluster; incoherent-but-kept
  clusters reported separately. Held-out-codes ablation run end to end on 91
  real traces.
- **0.7.6** — `scripts/ablate_seed.py`: hold codes out of the seed and measure
  semantic recovery, with the re-audit confined to the seed and a cross-family
  judge. Discovered codes now take a provenance-bearing `D<version>.<slug>`
  identifier with a separate `stage` field, instead of being numbered into
  someone else's scheme.
- **0.7.5** — diagram edges rewritten with direction-aware shapes (the bottom
  row runs right to left and was being drawn through its own boxes); the three
  annotation boxes chained in sequence rather than fanned from the adapter; the
  feedback arrow moved to enter from above so it no longer overlaps another
  arrowhead; added a panel giving the three final labels for the selected
  conversation, marking each as settled or handed to a doctor.
- **0.7.4** — five modules in `figures/dataflow.html` gained full-width detail
  panels (the question list, all twenty checks, all twenty-six features, the
  four admission tests, and an illustrated account of the grouping step). Also:
  the checks were being described as nineteen; there are twenty.
- **0.7.3** — `figures/dataflow.html` rewritten for a non-specialist reader:
  hand-placed orthogonal edges, per-module schematics of the transformation,
  and the technical vocabulary replaced throughout.
- **0.7.2** — Stage 2 and Stage 3 run for the first time on our own traces,
  fitted on 745 pseudo-anchors from the injection log: Head A AUC 0.914, ECE
  0.046, per-group conformal coverage 0.912–0.925, 71.2% of agent slots
  admitted automatically at 9.6% error. `figures/dataflow.html` rebuilt around
  the query, the transcript and a per-module account of what each stage does.
- **0.7.1** — `figures/dataflow.html`: the framework diagram rebuilt from data,
  with per-module input/output panels populated from a chosen real trace and a
  50% mask over everything unselected.
- **0.7.0** — `figures/explorer.html`: interactive explainer over eight
  recorded consultations with a live capability mask, question grid linked to
  the transcript, and in-place evidence highlighting.
- **0.6.9** — `split` added as a Mondrian grouping dimension across the
  sampler, pipeline and router; first run on the real corpus (92 traces) and
  400 anchor tasks drawn from it. Fixed the driver scripts' use of
  `Pipeline.__new__` skipping instance attributes.
- **0.6.8** — `figures/instance_walkthrough.html`, a self-contained page
  tracing one recorded instance through the pipeline.
- **0.6.7** — `ScorerConfig.mode` (`auto`/`logprob`/`verbalised`/`both`) and a
  batched verbalised scorer; `p_verbalised` carried alongside `p_positive` with
  its own missingness indicator (feature dim 23 -> 26); anchor stratification
  prefers the verbalised score. Established that the bimodality is the model,
  not the endpoint, so calibration rests on the black-box features.
- **0.6.6** — prompt note that input blocks are given material and cannot be
  the earliest fault step (logically right, no measurable effect -- recorded as
  such, not as an improvement). Settled measurements and the full retraction of
  the propagation finding written up above.
- **0.6.5** — `Step.context` renders the material handed to each agent
  (`input_messages`), which was the source of most apparent over-flagging;
  `TriageConfig` now rejects `sample_per_cluster < min_votes`, a combination
  that silently forced every cluster to `AB?`; fixed a wrong attribute name in
  `collect_residuals`. Stage 4 exercised end to end on real residuals with a
  cross-family judge.
- **0.6.4** — negatives split into upstream and downstream by first-injection
  position (`Trace.upstream_clean_agents`); `validate_on_injected.py` leads
  with upstream specificity and reports Wilson intervals. Specificity is 0.905,
  not 0.66; the earlier figure was measuring contamination propagation.
- **0.6.3** — `--legacy-prompt` reproduces the pre-0.6.2 prompt end to end
  (system rules, framing sections and slot wording), and
  `scripts/compare_prompts.py` runs the paired comparison. The prompt A/B is
  now reproducible instead of depending on files that were not kept.
- **0.6.2** — prompt revised against over-flagging (neutral base rate, explicit
  evidence rule, slot questions demand a quotable passage); `_common.configs`
  no longer double-passes `concurrency`; `--scorer-model` lets the reasoner and
  scorer differ. First end-to-end run on the simulated split recorded above.
- **0.6.1** — `normalise_code()` (judges return code+name, which silently
  zeroed every absorb_rate and forced all-B triage); `--judge-backend
  anthropic` on the evolution and coverage scripts; null-safe judge fields.
- **0.6.0** — batched scorer (`ScorerConfig.batch_slots`), system-role removed
  from scorer calls to recover `top_logprobs` alternatives, `LogprobSupport`
  probe now reports alternatives separately from logprobs, `AnthropicJudge`
  for cross-family Stage 4.
- **0.5.1** — `scripts/coverage_matrix.py`: MAST x MedAgentAudit coverage
  matrix, and A/B triage validation against the only ground truth that exists
  for it.
- **0.5.0** — simulated split wired in: `Trace.injections` with agent/step/
  MAST ground truth, `clean_agents` as confirmed negatives,
  `scripts/validate_on_injected.py`, and `mafa/mast.py` (reference only, never
  prompted). Reframed the simulated data as annotator validation rather than
  discarded or used for evaluation.
- **0.4.1** — `trace_id` made collision-proof (`framework::stem#line#id`);
  13 traces were previously overwritten silently. Documented that the clean
  split is not question-matched to the faulty split.
- **0.4.0** — packaged as `mafa/` with driver scripts; added `anchor_sampler`
  (stratified coverage sampling, step tasks as one multiple-choice question per
  trace); this file.
- **0.3.0** — violation weights replaced by six learned families (feature dim
  13 → 23); `AnchorPool` splits calibration from the frozen G4 set with a
  fingerprint; calibrator and router bound to a taxonomy signature and refuse
  to score across a change.
- **0.2.0** — "Dual Gate" renamed `AdmissionGate`, criteria made configurable
  in two tiers with short-circuiting; `TriageConfig` with an `AB?` ambiguous
  band and a threshold-sensitivity table.
- **0.1.0** — Stage 0–4 built; two-pass outcome-blind annotation; scorer
  parallelism with cache warm-up; verified against a live endpoint.
